# NER vs LLM Enrichment Comparison

**Model**: mock
**Original entities (with codemaps)**: 20
**Enriched concepts**: 2
**Latency**: 50ms
**Tokens**: 641 prompt + 105 completion

---

## Original NER Entities (problems & procedures with codemaps)

| # | Entity Text | Type | Assertion | IMO Lexical | ICD-10 |
|---|------------|------|-----------|-------------|--------|
| 1 | osteomyelitis | problem | present | Osteomyelitis | M86.9 (Osteomyelitis, unspecified) |
| 2 | poorly controlled diabetes | problem | present | Poorly controlled diabetes mellitus | E11.65 (Type 2 diabetes mellitus with hyperglycemia) |
| 3 | amputation of the left great toe | problem | present | Amputation of left great toe | S98.112A (Complete traumatic amputation of left great toe, initial encounter) |
| 4 | amputation | procedure | present | Amputation | — |
| 5 | delayed closure | procedure | present | Delayed closure of wound | — |
| 6 | delayed closure of the wound of the left foot tomorrow | treatment | present | Delayed closure of wound of left foot | — |
| 7 | O2 Sat by Pulse Oximetry | procedure | present | Pulse oximetry | — |
| 8 | foot Assessment | procedure | present | Assessment of foot | — |
| 9 | delayed closure of left foot | procedure | present | Delayed closure of left foot | — |
| 10 | surgical closure | treatment | present | PDA closure, surgical | — |
| 11 | foot wound | problem | present | Wound of left foot | S91.302A (Unspecified open wound, left foot, initial encounter) |
| 12 | diabetes | problem | absent | Diabetes | E11.9 (Type 2 diabetes mellitus without complications) |

---

## LLM Enriched Concepts

| # | Enriched Concept | Source Entities | Inference | Clinical Reasoning |
|---|-----------------|----------------|-----------|-------------------|
| 1 | Osteomyelitis of left great toe associated with poorly controlled type 2 diabetes mellitus | osteomyelitis, left great Toe, poorly controlled diabetes | strong_suggestion | Osteomyelitis in a diabetic patient with poor glycemic control indicates diabetic osteomyelitis. The... |
| 2 | Amputation of left great toe due to diabetic osteomyelitis | amputation of the left great toe, osteomyelitis, poorly controlled diabetes | strong_suggestion | The amputation was performed as treatment for the osteomyelitis, which is a known complication of di... |

---

## Entity Linking Map

Shows which NER entities were combined into each enriched concept:

### Enriched #1: Osteomyelitis of left great toe associated with poorly controlled type 2 diabetes mellitus

- **"osteomyelitis"** (problem) → IMO: Osteomyelitis | ICD-10: M86.9
- **"left great Toe"** (no codemap)
- **"poorly controlled diabetes"** (problem) → IMO: Poorly controlled diabetes mellitus | ICD-10: E11.65
- **Reasoning**: Osteomyelitis in a diabetic patient with poor glycemic control indicates diabetic osteomyelitis. The left great toe location combined with subsequent amputation suggests diabetic foot complication.

### Enriched #2: Amputation of left great toe due to diabetic osteomyelitis

- **"amputation of the left great toe"** (problem) → IMO: Amputation of left great toe | ICD-10: S98.112A
- **"osteomyelitis"** (problem) → IMO: Osteomyelitis | ICD-10: M86.9
- **"poorly controlled diabetes"** (problem) → IMO: Poorly controlled diabetes mellitus | ICD-10: E11.65
- **Reasoning**: The amputation was performed as treatment for the osteomyelitis, which is a known complication of diabetic foot disease.
