# Contract Reconciliation Lakehouse

Databricks Medallion + Ontology architecture for contract-to-invoice reconciliation in the Supply Chain / GPO / AP Price Assurance domain.

This repository is now structured as a production-grade reference application:

- Ontology-driven reconciliation engine
- SQLite local backend for deterministic development
- Databricks SQL / Unity Catalog repository adapter
- FastAPI service entry point
- CLI and batch workflow entry points
- Structured JSON logging
- Health, readiness, metrics, graph, findings, and validation APIs
- Databricks SQL DDL for Medallion, Ontology, Gold, and Ops tables
- Container and deployment runbook assets

This project is organized by enterprise architecture layer and delivery concern:

```text
contract-reconciliation-lakehouse/
├── docs/
├── architecture/
├── asset_bundle/
├── bronze/
├── silver/
├── ontology/
├── matching/
├── validation/
├── gold/
├── workflows/
├── sql/
├── tests/
├── dashboards/
├── terraform/
├── deployment/
└── sample_data/
```

## Folder Guide

| Folder | Purpose |
|---|---|
| `docs/` | Supporting analysis, Word deliverables, and documentation index |
| `architecture/` | Enterprise, solution, Medallion, ontology, and low-level architecture documents |
| `asset_bundle/` | Databricks Declarative Automation Bundle scaffold |
| `bronze/` | Bronze-layer design notes for raw structured payloads |
| `silver/` | Silver-layer design notes for conformed entities and validation detail |
| `ontology/` | Ontology graph models, repositories, local engine, and semantic layer code |
| `matching/` | Invoice-line to contract-term matching logic |
| `validation/` | Deterministic validation rules |
| `gold/` | Gold-layer serving facts, summaries, queues, and dispute workflow notes |
| `workflows/` | Local CLI/API workflow entry points and Databricks workflow scaffold |
| `sql/` | Unity Catalog, Medallion, ontology, and Price Assurance extension DDL |
| `tests/` | Local tests for the runnable demo |
| `dashboards/` | Dashboard design placeholders |
| `terraform/` | Infrastructure-as-code placeholders |
| `deployment/` | Deployment runbooks and environment notes |
| `sample_data/` | Local demo seed data |

## Run Local Demo

```powershell
cd C:\Users\nshrivas\Documents\Codex\2026-06-03\can-you-share-me-in-tablular\outputs\contract-reconciliation-lakehouse
$env:PYTHONPATH = "."
python run_demo.py --reset --twice
```

This creates the local SQLite database under `data/demo_reconciliation.db`. The package includes `data/README.md`, while generated `.db` files are created at runtime.

## Run Local API

```powershell
pip install -e ".[api]"
$env:REPOSITORY_BACKEND = "sqlite"
$env:SQLITE_DB_PATH = "data/reconciliation.db"
$env:SEED_ON_STARTUP = "true"
contract-reconcile-api --host 127.0.0.1 --port 8008 --reset
```

API smoke test:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/health
Invoke-RestMethod -Method Post http://127.0.0.1:8008/v1/reconciliations `
  -ContentType "application/json" `
  -Body '{"invoice_id":"INV-1001"}'
```

## Run Tests

```powershell
$env:PYTHONPATH = "."
python -m unittest discover -s tests -v
```

## Key Documents

| Document | Description |
|---|---|
| `architecture/APPLICATION_ARCHITECTURE_AND_FLOW_DESIGN.md` | Client-facing application architecture and end-to-end flow design |
| `architecture/APPLICATION_ARCHITECTURE_AND_FLOW_DESIGN.docx` | Word-formatted application architecture and flow design document |
| `architecture/SOLUTION_SCHEMATIC_C4_DIAGRAMS.md` | Solution schematic plus C1, C2, C3, and C4 architecture diagrams |
| `architecture/ENTERPRISE_ARCHITECTURE_DELIVERABLES.md` | Consolidated enterprise architecture deliverable |
| `architecture/SOLUTION_ARCHITECTURE.md` | Solution architecture |
| `architecture/MEDALLION_ONTOLOGY_ARCHITECTURE.md` | Medallion + ontology layering |
| `architecture/LOW_LEVEL_DESIGN.md` | Low-level design |
| `docs/DEMO_SETUP_AND_BACKEND_GUIDE.md` | Step-by-step demo setup and backend configuration guide |
| `docs/PRICE_ASSURANCE_SEED_GAP_ANALYSIS.md` | Gap analysis from `priceAssuranceSeed.ts` |
| `docs/OOUX_BOARD_15_LOGIC_GAP_ANALYSIS.md` | Gap analysis comparing PA OOUX Board 15 with the current solution logic |
| `docs/OOUX_BOARD_15_INTEGRATION_SUMMARY.md` | Implementation summary for OOUX Board 15 logic integrated into code |
| `docs/DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md` | Delta table ownership, grain, and responsibility guide |
| `docs/Enterprise_Architecture_Deliverables.docx` | Word-formatted architecture deliverable |

## Databricks SQL

Recommended setup for new Databricks environments:

1. Run `sql/databricks_lakehouse_schema.sql`.
2. Review `docs/DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md` for each Delta table's role, grain, and ownership.

`sql/databricks_lakehouse_schema.sql` is the single canonical Unity Catalog schema script for Bronze, Silver, Ontology, Gold, and Ops tables.

Unity Catalog namespace: `platform_dev.pspa_bronze`, `platform_dev.pspa_silver`, `platform_dev.pspa_ontology`, `platform_dev.pspa_gold`, and `platform_dev.pspa_ops`.

## Production Runtime Scope

The local mode uses SQLite through the same repository abstraction used by the service. Production mode uses `REPOSITORY_BACKEND=databricks` with Databricks SQL connection environment variables and Unity Catalog Delta tables.

See `docs/PRODUCTION_APPLICATION_GUIDE.md` and `deployment/PRODUCTION_RUNBOOK.md` for operational details.
