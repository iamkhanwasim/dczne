# Application Architecture And Flow Design

## Document Purpose

This document describes the end-to-end application architecture and processing flow for the Contract Reconciliation Lakehouse solution. It is intended for client leadership, enterprise architects, data engineering teams, data science teams, operations teams, and application owners who need to review and approve the design.

The solution reconciles structured supply chain, GPO, contract, amendment, eligibility, item, and invoice data using a Databricks Lakehouse backend, Medallion data architecture, ontology-driven semantics, graph relationships, deterministic validation, matching algorithms, and optional AI/GenAI-assisted workflows.

## 1. Executive Summary

The Contract Reconciliation Lakehouse provides a governed platform for validating invoice lines against negotiated contract terms in the supply chain, GPO, and AP Price Assurance domain. The application addresses leakage caused by price variance, missed eligibility, contract amendments, item/UOM mismatches, off-contract spend, and manual exception handling.

The solution is built around four principles:

| Principle | Description |
|---|---|
| Lakehouse-native design | Delta tables in Unity Catalog organize raw, conformed, semantic, and serving data. |
| Ontology-based reasoning | Business entities and relationships are modeled explicitly so matching and validation can be explained. |
| Deterministic financial controls | Final pass/fail reconciliation decisions are produced by transparent rules and auditable evidence. |
| AI-ready architecture | AI/GenAI can assist with semantic matching, explanations, recommendations, and analyst workflow without replacing controlled financial validation. |

Expected outcomes:

- Faster invoice-to-contract validation.
- Reduced AP overpayment and contract leakage.
- Traceable audit evidence for every invoice-line decision.
- Better amendment-aware contract compliance.
- Analyst work queues for exceptions, disputes, and recovery opportunities.
- A reusable ontology and graph foundation for future sourcing, supplier, and finance use cases.

## 2. Business Context And Goals

### 2.1 Problem Statement

Supply chain and GPO invoice reconciliation is difficult because invoice data, contract data, amendments, eligibility rosters, item masters, UOM conversions, and supplier terms often live in separate systems. Manual comparison is slow, inconsistent, and difficult to audit.

The application solves this problem by creating a trusted lakehouse backend and applying line-level reconciliation logic that compares each invoice line against the correct effective contract term.

### 2.2 Current Pain Points

| Pain Point | Business Impact |
|---|---|
| Contract amendments are not consistently applied. | Invoices may be compared against obsolete pricing or terms. |
| Items are described differently across systems. | Invoice lines may not match the correct contracted item. |
| UOM and pack-size differences are hard to normalize. | Valid prices may look incorrect, or incorrect prices may pass. |
| Eligibility varies by member, facility, tier, and time period. | Ineligible spend may be incorrectly paid or valid spend may be blocked. |
| Manual AP review is inconsistent. | Analysts spend time on low-risk lines and miss high-risk variances. |
| Audit evidence is fragmented. | It is difficult to explain why a line passed or failed. |
| Downstream reporting lacks a single governed output. | Finance and sourcing teams see different numbers. |

### 2.3 Target Users

| User Group | Primary Needs |
|---|---|
| AP analysts | Review failed lines, approve exceptions, initiate disputes. |
| Price Assurance analysts | Identify recoverable overpayments and leakage patterns. |
| Contract managers | Verify amendment and term interpretation. |
| Sourcing teams | Monitor supplier compliance and contract performance. |
| Finance leaders | Track exposure, recovery, dispute, and compliance KPIs. |
| Data engineering teams | Operate pipelines, data quality checks, and Delta tables. |
| Data science teams | Evaluate matching, embeddings, recommendations, and AI explainability. |
| Architects and governance teams | Review data model, controls, lineage, security, and scalability. |

### 2.4 Expected Business Value

| Value Driver | Expected Outcome |
|---|---|
| Overpayment prevention | Detect price variances before payment. |
| Recovery opportunity identification | Quantify prior leakage and generate recovery cases. |
| Reduced manual effort | Route only ambiguous or failed lines to analyst review. |
| Faster close and AP cycle | Automate repeatable contract validation. |
| Better supplier accountability | Produce supplier-level compliance scorecards. |
| Improved audit readiness | Store evidence, rule results, and lineage for every decision. |

### 2.5 Key Success Criteria

| Criteria | Measurement |
|---|---|
| Match accuracy | Precision/recall against manually reviewed benchmark invoices. |
| Variance detection | Dollar value and count of identified price variances. |
| Automation rate | Percentage of lines resolved without human review. |
| Explainability | Every decision links to source invoice, contract term, rule results, and evidence. |
| Performance | Batch reconciliation completes within agreed SLA. |
| Governance | Unity Catalog permissions, lineage, and audit requirements are met. |

## 3. High-Level Architecture Overview

The application uses a layered architecture. Structured invoice and contract data enter the lakehouse, are standardized into Silver, mapped into ontology and graph entities, reconciled line by line, and published as Gold outputs for APIs, dashboards, and analyst workflows.

### 3.1 Architecture Layers

| Layer | Purpose | Primary Technology |
|---|---|---|
| Source systems | Provide structured contract, amendment, invoice, item, supplier, eligibility, and dispute data. | ERP, AP, contract lifecycle management, GPO feeds, item master, member roster. |
| Ingestion layer | Load already-parsed structured data into the lakehouse. | Databricks jobs, Lakeflow, Auto Loader, batch interfaces. |
| Raw/landing layer | Preserve raw structured payloads for lineage and replay. | `platform_dev.pspa_bronze` Delta tables. |
| Cleansing and standardization layer | Create conformed business entities and amendment-effective terms. | `platform_dev.pspa_silver` Delta tables. |
| Reconciliation engine | Match invoice lines to effective contract terms and execute validation rules. | Python service, Databricks SQL, deterministic rule engine. |
| Ontology and semantic layer | Define business meaning, policies, semantic relationships, evidence, and audit. | `platform_dev.pspa_ontology` Delta tables. |
| Graph layer | Store nodes and edges for explainability, traversal, lineage, and reasoning. | Ontology node/edge Delta tables, optional graph engine. |
| GenAI/AI layer | Assist semantic retrieval, analyst explanation, recommendation, and summarization. | Embeddings, vector search, LLM service, prompt orchestration. |
| API/service layer | Expose reconciliation, findings, validation, metrics, and graph APIs. | FastAPI, repository abstraction, Databricks SQL connector. |
| UI/consumption layer | Support dashboards, analyst queues, and operational review. | BI dashboards, AP workflow tools, API consumers. |
| Monitoring, governance, security | Operate pipelines, enforce RBAC, track lineage, and monitor SLAs. | Unity Catalog, logs, metrics, Databricks workflows, alerting. |

### 3.2 Architecture Diagram

```mermaid
flowchart LR
    A["Source Systems<br/>ERP, AP, CLM, GPO, Item Master, Member Roster"] --> B["Ingestion Jobs<br/>Structured Feed Load"]
    B --> C["Bronze<br/>platform_dev.pspa_bronze"]
    C --> D["Silver<br/>platform_dev.pspa_silver<br/>Conformed Entities"]
    D --> E["Ontology Builder<br/>Semantic Mapping"]
    E --> F["Ontology Layer<br/>platform_dev.pspa_ontology"]
    F --> G["Graph Layer<br/>Nodes and Edges"]
    D --> H["Reconciliation Engine<br/>Matching and Validation"]
    F --> H
    G --> H
    H --> I["Validation Evidence<br/>Runs, Results, Findings, Audit"]
    I --> F
    I --> J["Gold Layer<br/>platform_dev.pspa_gold"]
    J --> K["Dashboards and Analyst Queues"]
    F --> L["API Service<br/>FastAPI"]
    J --> L
    L --> M["UI / Workflow / Downstream Consumers"]
    N["AI/GenAI Layer<br/>RAG, Explanations, Recommendations"] --> H
    F --> N
    G --> N
    O["Monitoring, Security, Governance"] -.-> B
    O -.-> C
    O -.-> D
    O -.-> F
    O -.-> H
    O -.-> J
```

## 4. End-To-End Data Flow

### 4.1 Processing Flow Summary

```mermaid
sequenceDiagram
    participant Source as Source Systems
    participant Bronze as Bronze Delta
    participant Silver as Silver Delta
    participant Ontology as Ontology Graph
    participant Engine as Reconciliation Engine
    participant Gold as Gold Delta
    participant API as API/UI

    Source->>Bronze: Load structured contract and invoice payloads
    Bronze->>Silver: Standardize parties, items, contracts, invoices
    Silver->>Silver: Resolve amendments into effective terms
    Silver->>Ontology: Build semantic entities and relationships
    API->>Engine: Request reconciliation for invoice
    Engine->>Silver: Read invoice lines and effective terms
    Engine->>Ontology: Read matching policy, graph context, cache
    Engine->>Engine: Match, validate, score, classify
    Engine->>Ontology: Persist run, validation results, findings, audit
    Engine->>Gold: Publish facts, summaries, queues
    API->>Ontology: Read graph and evidence
    API->>Gold: Read serving outputs
```

### 4.2 Step-By-Step Data Flow

| Step | Input | Processing Logic | Output | Key Validations | Error Handling | Dependencies |
|---|---|---|---|---|---|---|
| 1. Source extraction | Structured contract, amendment, invoice, item, supplier, member, eligibility data. | Receive files, API payloads, database extracts, or batch feeds. | Source payloads ready for lakehouse load. | File completeness, schema presence, source timestamp. | Reject malformed files, quarantine failed records, log source batch id. | Source systems and data-sharing agreements. |
| 2. Bronze load | Structured payloads. | Store payload JSON, source record id, hash, load id, and ingestion timestamp. | `platform_dev.pspa_bronze.contract_payload`, `invoice_payload`. | Duplicate hash, required metadata, load id. | Preserve bad records for replay, route schema errors to ops queue. | Databricks job, storage access, Unity Catalog grants. |
| 3. Silver conformance | Bronze payloads. | Parse and standardize party, item, contract, invoice, invoice line, eligibility, tier, and obligation entities. | `platform_dev.pspa_silver` canonical tables. | Required keys, data types, referential integrity, active dates. | Write rejects to quality tables or ops log. | Mapping rules, reference data, domain definitions. |
| 4. Amendment resolution | Contract versions and line terms. | Order base and amendment versions, apply effective dates, materialize final terms. | `effective_contract_line_term`. | No overlapping active terms for same contract/item/date unless allowed. | Mark conflict for review, prevent invalid term publication. | Contract version sequencing and amendment metadata. |
| 5. Ontology mapping | Silver entities. | Create ontology nodes, relationships, semantic labels, synonyms, rule references. | `platform_dev.pspa_ontology.node`, `edge`, policy tables. | Node uniqueness, relationship validity, ontology version. | Put unmapped concepts in stewardship queue. | Ontology definitions and mapping catalog. |
| 6. Runtime mirror refresh | Trusted Silver entities. | Load required API runtime tables into `platform_dev.pspa_ontology`. | Party, item, contract, invoice, and effective-term runtime tables. | Row count reconciliation, freshness, schema alignment. | Retry load, rollback to prior version, invalidate cache on contract changes. | Silver completion and API schema contract. |
| 7. Reconciliation request | Invoice id from API, workflow, or batch job. | Create reconciliation run and read invoice lines. | `reconciliation_run` in running state. | Invoice exists, lines exist, invoice not locked. | Return API error or workflow failure with correlation id. | Runtime tables and service credentials. |
| 8. Candidate matching | Invoice line, supplier, item, service date, eligibility, terms. | Retrieve active terms, normalize UOM, calculate scores, check cache, and read ontology graph match evidence. | Match candidate or manual-review route. | Item, eligibility, date, UOM, price proximity, semantic score, graph support. | No term becomes off-contract finding; ambiguous terms route to review. | Matching policy, effective terms, ontology edges. |
| 9. Rule validation | Candidate match and invoice line. | Execute deterministic rule set. | One validation result per rule per line. | Contract found, item matched, eligibility, amendment validity, UOM, price, quantity. | Failed rules create findings and audit records. | Rule catalog and policy configuration. |
| 10. Finding generation | Validation results. | Convert rule outcomes into business finding types. | Finding rows and line status. | Severity, variance amount, evidence completeness. | Missing evidence marks line for review. | Validation result schema. |
| 11. Gold publication | Runs, results, findings. | Build invoice summary, line fact, dispute queue, recovery opportunity. | `platform_dev.pspa_gold` serving tables. | Count reconciliation, amount reconciliation, status mapping. | Partial publish is retried or rolled back by run id. | Successful reconciliation run. |
| 12. API and dashboard consumption | Ontology and Gold outputs. | Serve health, metrics, graph, reconciliation, findings, and validation details. | User-facing API response, dashboard, analyst queue. | User authorization, data masking, response contract. | Return typed errors and correlation id. | API service, BI semantic model, access grants. |

## 5. Layer-By-Layer Design

### 5.1 Source Systems Layer

| Design Area | Detail |
|---|---|
| Purpose | Supply structured business records required for invoice-to-contract reconciliation. |
| Responsibilities | Provide contracts, amendments, invoice headers, invoice lines, suppliers, members, facilities, item master, UOM, tiers, and eligibility. |
| Data handled | Structured JSON, CSV, database extracts, API responses, or Delta shares. |
| Transformations | None in this layer beyond source-native extraction. |
| Technology considerations | Source systems may include ERP/AP, CLM, GPO contract feeds, supplier catalogs, item masters, and master data systems. |
| Failure scenarios | Missing files, late feeds, schema drift, duplicate source records, partial extracts. |
| Security considerations | Source credentials in secret store, transport encryption, source access audit. |

### 5.2 Ingestion Layer

| Design Area | Detail |
|---|---|
| Purpose | Load already-structured data into governed lakehouse tables. |
| Responsibilities | Schedule loads, capture source metadata, assign load ids, calculate payload hashes, write to Bronze. |
| Data handled | Structured source payloads and metadata. |
| Transformations | Minimal technical transformations only, such as envelope creation and ingestion timestamp. |
| Technology considerations | Databricks Workflows, Lakeflow jobs, Auto Loader, notebooks, or batch jobs. |
| Failure scenarios | Source unavailable, bad payload shape, file permission issue, duplicate load. |
| Security considerations | Least-privilege service principal, encrypted storage, source lineage. |

### 5.3 Bronze Layer

| Design Area | Detail |
|---|---|
| Purpose | Preserve raw structured source records for audit and replay. |
| Responsibilities | Store source system, file name, source record id, payload JSON, hash, ingestion timestamp, and load id. |
| Data handled | Contract payloads, amendment payloads, invoice payloads. |
| Transformations | None beyond technical metadata. |
| Technology considerations | Delta tables with Change Data Feed enabled; partitioning by load date can be added for volume. |
| Failure scenarios | Duplicate payload hash, missing source id, corrupt payload. |
| Security considerations | Engineering write access only; business users should not query Bronze directly. |

### 5.4 Silver Layer

| Design Area | Detail |
|---|---|
| Purpose | Store trusted, conformed, quality-checked business entities. |
| Responsibilities | Standardize parties, items, contracts, contract versions, line terms, effective terms, eligibility, invoices, invoice lines, tiers, rosters, and obligations. |
| Data handled | Canonical entity records with business keys and referential integrity. |
| Transformations | Deduplication, standardization, type conversion, amendment resolution, UOM standardization, date validation. |
| Technology considerations | Delta constraints, expectations, schema evolution controls, slowly changing dimensions where needed. |
| Failure scenarios | Invalid effective dates, duplicate active terms, missing item mapping, orphan invoice lines. |
| Security considerations | Domain data owners and engineering teams manage Silver. Sensitive columns may require masking. |

### 5.5 Ontology And Semantic Layer

| Design Area | Detail |
|---|---|
| Purpose | Define business meaning and the semantic contract used by reconciliation, API, and explainability. |
| Responsibilities | Store nodes, edges, rule catalog, matching policy, runtime mirrors, validation results, findings, audit events, and match cache. |
| Data handled | Semantic entities, relationships, rules, evidence, and operational run state. |
| Transformations | Map canonical entities into ontology objects and graph relationships. |
| Technology considerations | Delta tables for node/edge graph; optional graph engine can be added later. |
| Failure scenarios | Missing semantic mapping, relationship conflicts, stale runtime mirrors, cache invalidation gaps. |
| Security considerations | API service gets read/write access; analysts get controlled read access through views. |

### 5.6 Reconciliation Engine Layer

| Design Area | Detail |
|---|---|
| Purpose | Execute invoice-line matching and validation. |
| Responsibilities | Retrieve candidates, score matches, execute rules, calculate variance, persist evidence, and produce findings. |
| Data handled | Invoice lines, effective terms, eligibility, UOM, matching policy, cache, validation rules. |
| Transformations | UOM normalization, price comparison, route classification, status calculation. |
| Technology considerations | Python service for deterministic logic; Databricks jobs for batch; API for interactive use. |
| Failure scenarios | No matching term, ambiguous candidates, missing UOM conversion, stale contract cache. |
| Security considerations | Write audit evidence; do not expose unrestricted write endpoints to analysts. |

### 5.7 Graph Layer

| Design Area | Detail |
|---|---|
| Purpose | Represent business relationships for traversal, lineage, matching context, and explainability. |
| Responsibilities | Store graph nodes and edges; support relationship queries and explainable paths. |
| Data handled | Contracts, parties, items, invoice lines, rules, findings, eligibility, and evidence relationships. |
| Transformations | Node creation, edge creation, versioned relationship updates. |
| Technology considerations | Node/edge Delta tables; graph queries can be implemented in Spark SQL, GraphFrames, or external graph store if needed. |
| Failure scenarios | Missing edges, duplicate nodes, obsolete relationships. |
| Security considerations | Hide sensitive node attributes through secure views. |

### 5.8 AI/GenAI Layer

| Design Area | Detail |
|---|---|
| Purpose | Assist semantic retrieval, explanation, recommendation, and analyst productivity. |
| Responsibilities | Generate natural-language explanations, retrieve supporting context, recommend next actions, summarize dispute history. |
| Data handled | Approved ontology evidence, graph paths, findings, validation results, contract clauses, notes. |
| Transformations | Embedding generation, retrieval, prompt construction, response generation, evaluation. |
| Technology considerations | Vector search, model serving, prompt templates, guardrail policies, human feedback loop. |
| Failure scenarios | Hallucinated explanation, low retrieval quality, stale embeddings, prompt injection. |
| Security considerations | Use only approved context, redact sensitive data, log prompts/responses where policy allows. |

### 5.9 API And Consumption Layer

| Design Area | Detail |
|---|---|
| Purpose | Expose reconciliation workflows and evidence to users and downstream systems. |
| Responsibilities | Provide health, readiness, metrics, reconciliation, validation result, finding, and graph endpoints. |
| Data handled | API requests, run ids, invoice ids, validation results, findings, graph payloads. |
| Transformations | Convert internal models into response contracts. |
| Technology considerations | FastAPI, OpenAPI, authentication middleware, rate limits, correlation ids. |
| Failure scenarios | Missing invoice, backend unavailable, unauthorized access, timeout. |
| Security considerations | OAuth/service principal integration, RBAC, audit logging, no secrets in responses. |

### 5.10 Monitoring, Governance, And Security Layer

| Design Area | Detail |
|---|---|
| Purpose | Ensure the platform is reliable, secure, compliant, and supportable. |
| Responsibilities | Track pipeline runs, quality checks, model metrics, API health, lineage, grants, and alerts. |
| Data handled | Logs, metrics, audit events, quality results, SLA records. |
| Transformations | Aggregate operational metrics and incident signals. |
| Technology considerations | Databricks workflows, Unity Catalog, structured logs, dashboards, alerting tools. |
| Failure scenarios | SLA miss, failed quality check, unauthorized access, warehouse outage. |
| Security considerations | Environment separation, secrets management, encryption, least privilege. |

## 6. Reconciliation Engine Design

### 6.1 Engine Responsibilities

The reconciliation engine is responsible for converting a structured invoice into line-level outcomes. It does not perform OCR or document parsing. It assumes contracts and invoices are already parsed and structured.

Core responsibilities:

- Select the invoice and invoice lines to reconcile.
- Retrieve active effective contract terms for supplier, item, and service date.
- Normalize UOM and price for fair comparison.
- Check member/facility eligibility.
- Score candidate contract lines.
- Route the line to fast path, deep path, or manual review.
- Execute deterministic validations.
- Create validation evidence and findings.
- Update run status, audit events, and match cache.

### 6.2 Data Matching Strategy

| Matching Dimension | Description | Example |
|---|---|---|
| Supplier match | Invoice supplier must align to contract supplier. | Supplier `SUP-100` maps to contract `CNT-300`. |
| Item match | Invoice item id maps to contract item id. | `ITEM-GLOVE-NITRILE` matches contract line item. |
| Service charge-term match | Invoice service charge context maps to subscription, variable-rate, overage, time-and-materials, or excluded contract terms. | Monthly linen service with no item ID maps to `SUBSCRIPTION` charge term by category and description. |
| Effective date match | Invoice service date must fall in effective term window. | Invoice date after amendment effective date uses amended price. |
| Eligibility match | Member/facility must be eligible for contract/tier. | Member `MEM-900` is active for contract `CNT-300`. |
| UOM requirement/conversion | Invoice UOM must equal or convert to contract UOM for item terms; service charge terms can explicitly mark UOM as optional. | EACH converts to CASE by factor, while a monthly service term can omit UOM. |
| Price comparison | Normalized invoice unit price compared with contract price and tolerance. | Invoice price exceeds contract by $12.00. |
| Semantic similarity | Description tokens support candidate ranking when exact signals are incomplete. | "surgical mask level 3" overlaps contract description. |
| Graph support | Ontology edges confirm invoice-line lineage, contract term membership, item pricing, eligibility, and supplier participation. | Invoice line has `MATCHED_TO`-ready support through `HAS_LINE`, `HAS_TERM`, `PRICES_ITEM`, `ELIGIBLE_FOR`, and `PARTICIPATES_IN` edges. |

### 6.3 Deterministic Rules

| Rule Code | Purpose | Pass Condition | Failure Action |
|---|---|---|---|
| `DATA_QUALITY_SUFFICIENT` | Confirms source quality is reliable enough for financial validation. | Source status is trusted and parse confidence meets policy. | Data quality exception. |
| `CONTRACT_FOUND` | Confirms a valid contract line exists. | Candidate term found. | Off-contract finding. |
| `CONTRACT_CANDIDATE_SELECTED` | Confirms supplier/date contract selection succeeded. | Contract candidate score meets policy. | Contract selection exception. |
| `CHARGE_TERM_CANDIDATE_SELECTED` | Confirms a specific contract charge term was selected. | Term candidate count and score are sufficient. | Charge-term exception. |
| `ITEM_OR_SERVICE_TERM_MATCHED` | Confirms the line maps to an itemized term or service charge term. | Exact item match or service semantic score meets threshold. | Manual review or fail. |
| `CATEGORY_COMPATIBLE` | Confirms invoice and contract categories align. | Categories match or one side is intentionally blank. | Category review. |
| `MEMBER_ELIGIBLE` | Confirms member is eligible. | Active eligibility record covers service date. | Eligibility failure. |
| `AMENDMENT_VERSION_VALID` | Confirms effective term version is valid. | Selected term is active for service date. | Amendment/version failure. |
| `CHARGE_TERM_ALLOWED` | Confirms selected charge term is allowed. | Term is not excluded/disallowed. | Excluded charge exception. |
| `UOM_NOT_REQUIRED_OR_CONVERTIBLE` | Confirms UOM is valid for the term type. | Direct match, conversion factor, or UOM optional for service term. | UOM exception. |
| `PRICE_WITHIN_TOLERANCE` | Confirms price is not above contract tolerance. | Normalized price <= contract price plus tolerance. | Price variance finding. |
| `QUANTITY_LIMIT_VALID` | Confirms quantity complies with term limits. | Quantity is inside min/max thresholds. | Warning or fail based on severity. |
| `FREQUENCY_ALLOWED` | Confirms billing cadence is valid. | Invoice and term frequencies match when provided. | Frequency exception. |
| `SUPPLIER_CONTACT_COMPLETE` | Confirms dispute can be routed. | Supplier contact email and completeness flag are present. | Block dispute draft. |

### 6.4 Probabilistic And Fuzzy Matching

The design supports fuzzy signals while keeping the final validation deterministic.

| Signal | Use | Notes |
|---|---|---|
| Token overlap | Compares invoice and contract descriptions. | Useful for minor description differences. |
| Price proximity | Scores closeness between normalized invoice price and contract price. | Strong signal but not sufficient alone. |
| Embedding similarity | Optional vector similarity between descriptions, item metadata, and clauses. | AI/ML extension for candidate retrieval. |
| Synonym normalization | Maps terms such as supplier/vendor and member/facility. | Governed by ontology. |
| Historical cache | Reuses high-confidence prior matches. | Must be invalidated on contract or item changes. |

### 6.5 Confidence Score Calculation

The matching score is a weighted score:

```text
score =
  exact_item_weight * item_match
+ eligibility_weight * member_eligible
+ date_weight * date_valid
+ uom_weight * uom_convertible
+ price_weight * price_proximity
+ semantic_weight * semantic_similarity
+ graph_weight * graph_support_score
```

Example policy:

| Weight | Example Value |
|---|---|
| Exact item match | 0.35 |
| Eligibility | 0.20 |
| Date validity | 0.15 |
| UOM conversion | 0.10 |
| Price proximity | 0.15 |
| Semantic similarity | 0.05 |
| Graph support | 0.05 |

Routing:

| Route | Condition | Action |
|---|---|---|
| Fast path | Score exceeds high-confidence threshold. | Cache match and run validation. |
| Deep path | Score is acceptable but not high confidence. | Run additional checks and evidence capture. |
| Manual review | Score below threshold or no candidate. | Create review finding and analyst queue item. |

### 6.6 Exception Handling

| Exception | Handling |
|---|---|
| No contract found | Create off-contract finding and fail line. |
| Multiple candidates with similar score | Route to manual review with candidate evidence. |
| Missing UOM conversion | Fail or warn based on rule severity and policy. |
| Ineligible member | Fail line and attach eligibility evidence. |
| Expired term | Fail amendment/version validation. |
| Duplicate invoice line | Detect duplicate signature and route based on policy. |
| Stale cache after amendment | Invalidate cache by contract id and contract version. |

### 6.7 Human-In-The-Loop Review

The application should route uncertain or failed lines to analysts.

| Review Trigger | Analyst Action |
|---|---|
| Low confidence match | Choose correct contract line or mark off-contract. |
| Price variance | Confirm dispute, approve variance, or request credit. |
| UOM exception | Add/approve conversion factor or request item master correction. |
| Eligibility exception | Confirm member roster status or update eligibility. |
| Duplicate invoice | Approve, reject, or link duplicate lines. |

Analyst decisions should be stored as override events, with user id, timestamp, reason, and before/after status.

### 6.8 Duplicate Detection

Duplicate detection uses a combination of:

- Invoice number.
- Supplier id.
- Member/facility id.
- Invoice date.
- Line item id.
- Description normalization.
- Quantity.
- Unit price.
- Extended amount.
- Source document id or hash.

Potential duplicate outcomes:

| Outcome | Description |
|---|---|
| Exact duplicate | Same invoice and line signature already processed. |
| Near duplicate | Similar supplier, member, amount, and item but different invoice number. |
| Not duplicate | Distinct business transaction. |

### 6.9 Survivorship And Golden Record Creation

Golden records are created in Silver, not Gold. Silver owns conformed identity and survivorship rules.

| Entity | Survivorship Approach |
|---|---|
| Party | Prefer mastered party id; merge source aliases into crosswalk. |
| Item | Prefer item master id; preserve manufacturer, supplier, GTIN, and category references. |
| Contract | Prefer CLM/GPO contract id; versions represent base/amendment chronology. |
| Effective term | Materialized from highest-priority active version for date range. |
| Invoice | Prefer AP invoice id and source invoice number; duplicate candidates flagged. |

### 6.10 Audit Trail

Every reconciliation run should capture:

- Reconciliation run id.
- Invoice id.
- Started and completed timestamps.
- Counts by route and result.
- Validation results per line and rule.
- Matched contract references.
- Finding evidence.
- Analyst override events.
- Cache usage and invalidation events.

### 6.11 Reconciliation Status Lifecycle

```mermaid
stateDiagram-v2
    [*] --> RECEIVED
    RECEIVED --> READY_FOR_RECONCILIATION
    READY_FOR_RECONCILIATION --> RUNNING
    RUNNING --> PASS
    RUNNING --> FAIL
    RUNNING --> WARN
    RUNNING --> MANUAL_REVIEW
    FAIL --> DISPUTE_OPENED
    MANUAL_REVIEW --> ANALYST_APPROVED
    MANUAL_REVIEW --> DISPUTE_OPENED
    DISPUTE_OPENED --> RECOVERED
    DISPUTE_OPENED --> WRITTEN_OFF
    PASS --> [*]
    RECOVERED --> [*]
    WRITTEN_OFF --> [*]
```

### 6.12 Reprocessing And Rollback

| Scenario | Approach |
|---|---|
| Contract amendment corrected | Rebuild effective terms, invalidate affected match cache, rerun impacted invoices. |
| Item mapping corrected | Refresh item and UOM mappings, rerun impacted invoice lines. |
| Eligibility roster corrected | Reprocess invoices within affected member/date range. |
| Faulty rule version | Disable rule version, create replacement version, rerun impacted runs. |
| Failed Gold publication | Republish by reconciliation run id after validating ontology evidence. |

## 7. Ontology Layer Design

### 7.1 Purpose

The ontology layer defines shared business meaning across the platform. It connects technical data tables to business concepts such as Supplier, Member, Contract, Amendment, Effective Term, Invoice, Invoice Line, Eligibility, Rule, Finding, and Recovery Opportunity.

The ontology helps by:

- Making relationships explicit.
- Supporting explainability.
- Normalizing terminology.
- Providing a consistent semantic model for APIs and AI.
- Decoupling business meaning from source-system naming differences.

### 7.2 Key Business Entities

| Entity | Definition |
|---|---|
| Party | Organization or facility participating in the transaction. Includes supplier, GPO, member, distributor, manufacturer, and facility. |
| Item | Canonical product or service purchased on an invoice and priced on a contract. |
| Contract | Agreement between supplier/GPO/member context that governs pricing and terms. |
| Contract Version | Base contract or amendment version with effective dates and sequence. |
| Contract Line Term | Version-specific line-level pricing or compliance term. |
| Effective Contract Line Term | Final active term after amendment resolution. |
| Member Eligibility | Membership or facility eligibility for a contract or tier over time. |
| Invoice | AP invoice header. |
| Invoice Line | Line-level charge requiring contract validation. |
| Rule | Validation rule used to determine compliance. |
| Reconciliation Run | Execution instance for an invoice or batch. |
| Validation Result | Rule-level result for an invoice line. |
| Finding | Business outcome such as pass, price variance, off-contract, or manual review. |
| Recovery Opportunity | Gold-level business case for recoverable leakage. |

### 7.3 Semantic Mapping Examples

| Source Field | Canonical Concept | Notes |
|---|---|---|
| `vendor_id`, `supplier_number`, `seller_id` | `Party.party_id` with type `SUPPLIER` | Source aliases stored in crosswalk. |
| `member_id`, `facility_id`, `ship_to` | `Party.party_id` with type `MEMBER` or `FACILITY` | Eligibility rules define valid usage. |
| `contract_num`, `agreement_id` | `Contract.contract_number` | Normalized to governed contract id. |
| `amendment_no`, `version_seq` | `ContractVersion.sequence_number` | Used for amendment ordering. |
| `sku`, `supplier_item`, `mfr_item`, `gtin` | `Item` identifiers | Resolved through item master. |
| `uom`, `unit_of_measure`, `pack` | UOM concept | Normalized using conversion table. |
| `service_date`, `invoice_date` | Time validity concepts | Different roles in validation. |
| `unit_cost`, `unit_price`, `charge_price` | Invoice unit price | Normalized before comparison. |

### 7.4 Terminology Normalization

| Synonym Group | Canonical Term |
|---|---|
| Vendor, supplier, seller | Supplier |
| Buyer, member, health system | Member |
| Location, ship-to, facility | Facility |
| Agreement, contract, GPO contract | Contract |
| Amendment, addendum, revision | Contract Version |
| SKU, item, product, catalog item | Item |
| Unit, package, pack, UOM | Unit of Measure |

### 7.5 Ontology Model Example

```mermaid
classDiagram
    class Party {
      party_id
      party_type
      party_name
      active_flag
    }
    class Contract {
      contract_id
      contract_number
      supplier_id
      gpo_id
      status
      effective_from
      effective_to
    }
    class ContractVersion {
      contract_version_id
      contract_id
      version_type
      sequence_number
    }
    class EffectiveContractLineTerm {
      contract_line_id
      contract_id
      item_id
      unit_price
      contract_uom
      effective_from
      effective_to
    }
    class Invoice {
      invoice_id
      invoice_number
      supplier_id
      member_id
      invoice_date
    }
    class InvoiceLine {
      invoice_line_id
      item_id
      quantity
      invoice_uom
      unit_price
      service_date
    }
    class ValidationResult {
      rule_code
      status
      variance_amount
    }
    class Finding {
      finding_type
      status
      severity
      variance_amount
    }

    Party "1" --> "*" Contract : supplier_for
    Contract "1" --> "*" ContractVersion : has_version
    ContractVersion "1" --> "*" EffectiveContractLineTerm : materializes
    Invoice "1" --> "*" InvoiceLine : has_line
    InvoiceLine "*" --> "0..1" EffectiveContractLineTerm : matched_to
    InvoiceLine "1" --> "*" ValidationResult : validated_by
    InvoiceLine "1" --> "1" Finding : produces
```

### 7.6 Ontology Evolution

Ontology changes should be governed like product features.

| Change Type | Governance |
|---|---|
| New entity | Architecture and data owner approval. |
| New relationship | Define cardinality, source, lifecycle, and security. |
| New synonym | Domain steward approval and regression testing. |
| New rule | Versioned rule catalog entry with severity and parameters. |
| Changed mapping | Impact analysis and backfill plan. |

## 8. Graph Layer And Graph Node Design

### 8.1 Graph Purpose

The graph layer represents business context as nodes and edges. It supports:

- Entity resolution.
- Relationship traversal.
- Lineage.
- Explainability.
- Recommendation.
- AI retrieval context.
- Impact analysis after contract, item, or eligibility changes.

### 8.2 Node Types

| Node Type | Example Properties |
|---|---|
| `PARTY` | `party_id`, `party_type`, `display_name`, `active_flag`. |
| `ITEM` | `item_id`, `description`, `gtin`, `category_code`. |
| `CONTRACT` | `contract_id`, `contract_number`, `status`. |
| `CONTRACT_VERSION` | `version_type`, `sequence_number`, `effective_from`. |
| `CONTRACT_LINE_TERM` | `unit_price`, `contract_uom`, `effective_from`, `effective_to`. |
| `INVOICE` | `invoice_id`, `invoice_number`, `invoice_date`. |
| `INVOICE_LINE` | `line_number`, `quantity`, `unit_price`, `service_date`. |
| `ELIGIBILITY` | `tier_code`, `valid_from`, `valid_to`, `status`. |
| `RULE` | `rule_code`, `severity`, `active_flag`, `version`. |
| `FINDING` | `finding_type`, `status`, `severity`, `variance_amount`. |
| `RECOVERY_OPPORTUNITY` | `recoverable_amount`, `case_status`, `root_cause_code`. |

### 8.3 Edge Types

| Edge Type | From | To | Meaning |
|---|---|---|---|
| `SUPPLIES` | Supplier party | Contract | Supplier owns contract pricing. |
| `GOVERNS` | Contract | Member/facility | Contract governs eligible members. |
| `HAS_VERSION` | Contract | Contract version | Contract has base/amendment version. |
| `AMENDS` | Contract version | Prior version | Amendment supersedes prior version. |
| `HAS_TERM` | Contract version | Contract line term | Version contains line pricing. |
| `PRICES_ITEM` | Contract line term | Item | Term prices an item. |
| `ELIGIBLE_FOR` | Party | Contract | Member eligibility. |
| `HAS_LINE` | Invoice | Invoice line | Invoice contains line. |
| `MATCHED_TO` | Invoice line | Effective contract term | Reconciliation selected term. |
| `VALIDATED_BY` | Invoice line | Rule | Rule evaluated the line. |
| `PRODUCED_FINDING` | Invoice line | Finding | Line produced business outcome. |
| `SUPPORTED_BY` | Finding | Validation result | Finding is backed by evidence. |
| `SIMILAR_TO` | Item | Item | Optional AI/ML item similarity. |

### 8.4 Relationship Properties

| Property | Purpose |
|---|---|
| `relationship_type` | Defines edge semantics. |
| `source_system` | Tracks origin of relationship. |
| `confidence_score` | Supports inferred or AI-assisted edges. |
| `effective_from` and `effective_to` | Supports time-aware relationships. |
| `created_at` | Audit timestamp. |
| `evidence_json` | Stores supporting source or rule evidence. |

### 8.5 Sample Graph Model

```mermaid
flowchart LR
    S["Supplier Party"] -->|SUPPLIES| C["Contract"]
    C -->|HAS_VERSION| V1["Base Version"]
    C -->|HAS_VERSION| V2["Amendment Version"]
    V2 -->|AMENDS| V1
    V2 -->|HAS_TERM| T["Effective Contract Line Term"]
    T -->|PRICES_ITEM| I["Item"]
    M["Member Party"] -->|ELIGIBLE_FOR| C
    INV["Invoice"] -->|HAS_LINE| L["Invoice Line"]
    L -->|MATCHED_TO| T
    L -->|VALIDATED_BY| R["Rule"]
    L -->|PRODUCED_FINDING| F["Finding"]
```

### 8.6 Graph Traversal Patterns

| Use Case | Traversal |
|---|---|
| Explain why a line failed | Invoice line -> validation results -> finding -> matched term -> contract version. |
| Find impacted invoices after amendment | Contract version -> effective terms -> matched invoice lines -> reconciliation runs. |
| Identify supplier leakage | Supplier -> contracts -> findings -> recovery opportunities. |
| Resolve item ambiguity | Invoice line item -> similar items -> contract terms -> prior matches. |
| Verify eligibility | Member/facility -> eligibility edge -> contract -> term -> invoice line. |

### 8.7 Example Graph Queries

Find all findings for an invoice line:

```sql
SELECT e.source_node_id, e.target_node_id, f.*
FROM platform_dev.pspa_ontology.edge e
JOIN platform_dev.pspa_ontology.finding f
  ON f.finding_id = e.target_node_id
WHERE e.relationship_type = 'PRODUCED_FINDING'
  AND e.source_node_id = '<invoice_line_node_id>';
```

Find contract terms impacted by an amendment:

```sql
SELECT e2.target_node_id AS impacted_term_node_id
FROM platform_dev.pspa_ontology.edge e1
JOIN platform_dev.pspa_ontology.edge e2
  ON e2.source_node_id = e1.source_node_id
WHERE e1.relationship_type = 'AMENDS'
  AND e1.source_node_id = '<amendment_version_node_id>'
  AND e2.relationship_type = 'HAS_TERM';
```

Find invoice lines matched to a contract:

```sql
SELECT matched.source_node_id AS invoice_line_node_id
FROM platform_dev.pspa_ontology.edge contract_term
JOIN platform_dev.pspa_ontology.edge matched
  ON matched.target_node_id = contract_term.target_node_id
WHERE contract_term.relationship_type = 'HAS_TERM'
  AND matched.relationship_type = 'MATCHED_TO'
  AND contract_term.source_node_id = '<contract_version_node_id>';
```

## 9. AI/GenAI Layer

### 9.1 Candidate Use Cases

| Use Case | Description | Decision Authority |
|---|---|---|
| Semantic item matching | Retrieve likely contract items when exact identifiers are missing. | Candidate suggestion only. |
| Contract clause explanation | Explain why a rule applied using approved contract context. | Human-readable explanation only. |
| Analyst recommendation | Recommend dispute, approve, request credit, or update master data. | Analyst decision required. |
| Exception summarization | Summarize invoice-level findings and supplier patterns. | Informational. |
| Root cause classification | Classify variance cause such as amendment lag, UOM, eligibility, supplier overcharge. | May prefill case; analyst confirms. |
| Natural language graph query | Let users ask questions over ontology/graph outputs. | Read-only with governed context. |

### 9.2 RAG And Prompt Orchestration

RAG is appropriate for explanations and analyst assistance.

```mermaid
flowchart LR
    A["User Question or Finding"] --> B["Retrieve Context"]
    B --> C["Ontology Evidence"]
    B --> D["Graph Paths"]
    B --> E["Contract Clauses / Rule Catalog"]
    C --> F["Prompt Builder"]
    D --> F
    E --> F
    F --> G["LLM"]
    G --> H["Guardrail Checks"]
    H --> I["Explanation / Recommendation"]
    I --> J["Human Review"]
```

Prompt construction should include:

- User role and allowed scope.
- Invoice line facts.
- Matched contract term.
- Validation results.
- Finding evidence.
- Relevant graph path.
- Instruction to avoid unsupported claims.
- Required output format.

### 9.3 Embedding And Vector Search

Embedding search can support:

- Item description similarity.
- Contract clause retrieval.
- Historical finding similarity.
- Supplier dispute pattern retrieval.

Embedding inputs:

| Input | Example |
|---|---|
| Item text | Item description, manufacturer item number, supplier item number, category. |
| Contract term text | Contract line description, UOM, tier, notes. |
| Clause text | Pricing clauses, rebate terms, exceptions. |
| Finding text | Summary, detail, root cause, resolution. |

### 9.4 Guardrails

| Guardrail | Description |
|---|---|
| Deterministic decision boundary | LLM cannot override financial pass/fail rules. |
| Retrieval-only context | LLM answers must cite approved ontology, graph, or contract context. |
| Role-based access | Prompt context filtered by user role and data grants. |
| PII/PHI protection | Sensitive fields are masked or omitted. |
| Confidence threshold | Low-confidence AI recommendations route to human review. |
| Prompt injection defense | Strip untrusted instructions from source text. |
| Auditability | Store prompt metadata, retrieved context ids, model version, and response id where policy allows. |

### 9.5 Evaluation Metrics

| Metric | Purpose |
|---|---|
| Retrieval precision | Measures whether retrieved contract/rule context is relevant. |
| Recommendation accuracy | Compares AI recommendations to analyst decisions. |
| Explanation faithfulness | Checks whether explanation is supported by evidence. |
| Hallucination rate | Tracks unsupported claims. |
| Analyst acceptance rate | Measures usefulness of AI suggestions. |
| Latency and cost | Tracks operational feasibility. |

### 9.6 Model Monitoring

Monitor:

- Model version.
- Prompt template version.
- Embedding index freshness.
- Retrieval hit rate.
- User feedback.
- Drift in item descriptions and supplier behavior.
- Safety and policy violations.

## 10. API And Integration Design

### 10.1 APIs Exposed

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/health` | Liveness and backend diagnostics. |
| `GET` | `/ready` | Readiness check for orchestration. |
| `GET` | `/metrics` | Repository and table count metrics. |
| `POST` | `/v1/reconciliations` | Reconcile one invoice. |
| `GET` | `/v1/reconciliations/{run_id}/validation-results` | Return rule-level results for a run. |
| `GET` | `/v1/reconciliations/{run_id}/findings` | Return findings for a run. |
| `GET` | `/v1/ontology/graph` | Return graph nodes and edges. |
| `GET` | `/v1/ontology/nodes` | Return ontology nodes. |
| `GET` | `/v1/ontology/edges` | Return ontology edges. |

### 10.2 Reconciliation Request Example

```json
{
  "invoice_id": "INV-1001",
  "correlation_id": "client-demo-001"
}
```

### 10.3 Reconciliation Response Pattern

```json
{
  "run": {
    "reconciliation_run_id": "run-id",
    "invoice_id": "INV-1001",
    "status": "FAIL"
  },
  "invoice": {
    "invoice_id": "INV-1001",
    "invoice_number": "1001"
  },
  "final_status": "FAIL",
  "total_variance": 52.0,
  "line_count": 5,
  "lines": [
    {
      "line_number": "2",
      "status": "FAIL",
      "route": "FAST_PATH",
      "matched_contract_line_id": "CL-MASK-AMD1",
      "finding_type": "PRICE_VARIANCE",
      "variance": 12.0
    }
  ],
  "correlation_id": "client-demo-001"
}
```

### 10.4 Authentication And Authorization

Recommended production controls:

- OAuth 2.0 or enterprise identity provider for user-facing APIs.
- Service principal for workflow and batch integrations.
- Unity Catalog grants for table-level data access.
- Role-based API authorization for reconciliation, review, and admin actions.
- Correlation id propagation for audit.

### 10.5 Batch Vs Real-Time Integration

| Mode | Use Case | Pattern |
|---|---|---|
| Batch | Nightly AP invoice review, supplier scorecards, recovery analysis. | Databricks workflow processes invoice batches and publishes Gold. |
| Near real-time | Pre-payment invoice validation. | API call or event-triggered job per invoice. |
| Interactive | Analyst drill-through and evidence review. | API reads ontology and Gold outputs. |

## 11. Security, Governance, And Compliance

### 11.1 Role-Based Access Control

| Role | Bronze | Silver | Ontology | Gold | Ops |
|---|---|---|---|---|---|
| Data engineering | Write | Write | Limited write | Limited write | Read/write |
| Reconciliation service | No direct or read | Read | Read/write | Write | Write |
| AP analyst | No direct | Limited read through views | Read through views | Read/update workflow views | No direct |
| Sourcing analyst | No direct | Contract/item read | Graph read | Supplier summaries | No direct |
| Finance reader | No direct | No direct | No direct | Read dashboards | No direct |
| Auditor | Controlled read | Controlled read | Read evidence | Read outputs | Read logs |

### 11.2 Data Masking And Sensitive Data

The solution primarily handles commercial and financial data. If member, facility, patient, or employee-related attributes are introduced, masking policies must be applied.

| Data Type | Control |
|---|---|
| Token/secrets | Store in secret manager, never in code. |
| Supplier bank/tax data | Mask or exclude from reconciliation layer unless required. |
| User identifiers | Retain for audit, expose only to authorized roles. |
| PHI/PII | Avoid ingestion; if present, classify and mask. |

### 11.3 Audit Logging And Lineage

Audit evidence includes:

- Source record id and payload hash in Bronze.
- Load id and ingestion timestamp.
- Contract version and effective-term references.
- Reconciliation run id.
- Validation result id.
- Rule code and version.
- Finding id and evidence JSON.
- Analyst override events.

### 11.4 Encryption And Secrets

| Area | Control |
|---|---|
| Storage | Cloud provider encryption and Delta table governance. |
| Transport | TLS for APIs and Databricks SQL. |
| Secrets | Databricks secrets or enterprise vault. |
| Tokens | Service principal token rotation policy. |
| Logs | Redact secrets and sensitive values. |

### 11.5 Environment Separation

Recommended catalogs:

| Environment | Catalog |
|---|---|
| Development | `platform_dev` |
| Test | `platform_test` |
| UAT | `platform_uat` |
| Production | `platform_prod` |

Schema naming remains consistent across environments:

```text
pspa_bronze
pspa_silver
pspa_ontology
pspa_gold
pspa_ops
```

## 12. Deployment And Environment Strategy

### 12.1 Environments

| Environment | Purpose |
|---|---|
| Local | Developer testing using SQLite. |
| Dev | Databricks development and integration testing. |
| Test | Automated regression, data quality, and performance tests. |
| UAT | Business validation and sign-off. |
| Production | Controlled operational execution. |

### 12.2 CI/CD Approach

Recommended pipeline stages:

1. Static checks and unit tests.
2. Package application.
3. Validate SQL DDL.
4. Deploy Databricks Asset Bundle to target workspace.
5. Apply Unity Catalog grants.
6. Run smoke tests.
7. Promote artifacts after approval.

### 12.3 Databricks Asset Bundle Strategy

The repo includes an `asset_bundle` scaffold. Production deployment should include:

- Job definitions for Bronze, Silver, ontology build, reconciliation, Gold publish, and observability.
- Environment-specific variables.
- Cluster or SQL Warehouse configuration.
- Secret references.
- Service principal identity.

### 12.4 Configuration Management

Key environment variables:

| Variable | Purpose |
|---|---|
| `REPOSITORY_BACKEND` | `sqlite` or `databricks`. |
| `SQLITE_DB_PATH` | Local DB path for demo. |
| `DATABRICKS_SERVER_HOSTNAME` | Databricks workspace host. |
| `DATABRICKS_HTTP_PATH` | SQL Warehouse HTTP path. |
| `DATABRICKS_TOKEN` | Service principal or PAT token. |
| `DATABRICKS_CATALOG` | Target catalog, for example `platform_dev`. |
| `DATABRICKS_SCHEMA` | API runtime schema, for example `pspa_ontology`. |

### 12.5 Release And Rollback

| Release Concern | Strategy |
|---|---|
| Code release | Versioned package and deployment artifact. |
| SQL changes | Backward-compatible migrations when possible. |
| Rule changes | Versioned rule catalog and activation flags. |
| Model changes | Model registry and champion/challenger evaluation. |
| Rollback | Revert app version, deactivate new rules, restore prior mapping version, republish Gold by run id. |

## 13. Monitoring And Operations

### 13.1 Pipeline Monitoring

Track:

- Source file arrival.
- Bronze load counts.
- Silver conformance counts.
- Reject counts.
- Ontology node/edge counts.
- Reconciliation run counts.
- Gold publish counts.
- SLA completion time.

### 13.2 Data Quality Checks

| Area | Check |
|---|---|
| Bronze | Required metadata and payload hash. |
| Silver party | Unique party id and valid party type. |
| Silver item | Unique item id and active flag. |
| Contract version | Valid sequence and effective dates. |
| Effective terms | No invalid overlap for same contract/item/date. |
| Invoice line | Quantity and price are non-negative. |
| Eligibility | Date range and status are valid. |
| Ontology graph | Nodes exist for every edge endpoint. |
| Gold | Run counts reconcile to findings and validation results. |

### 13.3 Reconciliation Monitoring

Metrics:

- Pass/fail/warn counts.
- Fast path vs deep path vs manual review counts.
- Total variance.
- Off-contract line count.
- Average match score.
- Cache hit rate.
- Processing time per invoice and per line.
- Top failing rules.

### 13.4 Alerting

| Alert | Trigger |
|---|---|
| Source feed missing | Expected feed not received by SLA. |
| Quality failure spike | Reject count exceeds threshold. |
| Manual review spike | Manual review percentage exceeds baseline. |
| Price variance spike | Variance amount exceeds threshold. |
| API health failure | `/health` returns error or times out. |
| Databricks job failure | Workflow task failed. |
| Model drift | AI retrieval or recommendation metrics degrade. |

### 13.5 Support Process

1. Identify failed job, API error, or quality alert.
2. Use correlation id or reconciliation run id.
3. Check `platform_dev.pspa_ops.pipeline_run_log`.
4. Review `audit_event`, `validation_result`, and `finding`.
5. Determine whether issue is source data, mapping, rule, contract, or platform failure.
6. Apply fix and rerun impacted invoices.
7. Document incident and prevention action.

## 14. Non-Functional Requirements

| Requirement | Design Response |
|---|---|
| Scalability | Delta tables, partitioning strategy, Databricks workflows, batch processing by invoice/date/supplier. |
| Performance | Cache high-confidence matches, optimize key tables, use ZORDER on invoice/contract/date keys. |
| Availability | API health/readiness endpoints; Databricks job retries; separate environments. |
| Reliability | Idempotent loads, run ids, audit events, validation evidence, rollback by run id. |
| Maintainability | Layered repo structure, repository abstraction, documented SQL, focused rule modules. |
| Extensibility | Add new rules, graph edges, entity types, AI use cases, and Gold outputs without redesign. |
| Observability | Structured logs, metrics endpoint, ops table, dashboard-ready Gold outputs. |
| Security | Unity Catalog RBAC, secrets management, environment isolation, data masking. |
| Cost optimization | Batch workloads where possible, right-size SQL Warehouse, cache reuse, optimize tables after data growth. |

## 15. Assumptions, Risks, And Open Questions

| Type | Item | Impact | Mitigation / Next Step |
|---|---|---|---|
| Assumption | Contract and invoice data are already structured and parsed. | Ingestion scope excludes OCR/document extraction. | Confirm upstream parser ownership and output contract. |
| Assumption | Unity Catalog catalog is `platform_dev` for development. | SQL and environment variables use this name. | Confirm test/UAT/prod catalog naming. |
| Assumption | API runtime uses `platform_dev.pspa_ontology`. | Runtime mirror tables must be populated. | Define Silver-to-ontology sync job. |
| Risk | Contract amendments are ambiguous or overlapping. | Incorrect effective term selection. | Add amendment conflict rules and steward review queue. |
| Risk | Item master mappings are incomplete. | Lower match rate and more manual review. | Add item crosswalk, synonym mapping, and optional embeddings. |
| Risk | UOM conversion gaps. | Incorrect price comparison. | Govern UOM table and route missing conversions to stewardship. |
| Risk | AI explanations could overstate evidence. | User trust and compliance risk. | Use retrieval guardrails and cite evidence ids. |
| Risk | High data volumes impact latency. | SLA misses. | Partition workloads, optimize Delta tables, use batch reconciliation. |
| Open Question | Which system owns final supplier and member master data? | Affects survivorship rules. | Confirm MDM/source-of-truth ownership. |
| Open Question | What tolerance levels vary by supplier, contract, or category? | Affects rule parameterization. | Define rule policy hierarchy. |
| Open Question | Should analyst overrides update source systems or remain local? | Affects integration design. | Define workflow integration scope. |
| Open Question | What data retention period applies to audit evidence? | Affects storage and compliance. | Confirm legal/compliance retention policy. |

## 16. Sample Architecture Walkthrough

This walkthrough uses a realistic invoice line for surgical masks.

### Scenario

| Field | Value |
|---|---|
| Invoice | `INV-1001` |
| Invoice number | `1001` |
| Supplier | Medical supply supplier |
| Member | Eligible GPO member |
| Invoice line | Surgical mask level 3 |
| Quantity | Example demo quantity |
| Contract status | Active |
| Amendment | Active amendment updates price |
| Expected outcome | Price variance |

### Walkthrough

| Stage | Flow |
|---|---|
| Source ingestion | AP invoice line and contract amendment records arrive as structured payloads. |
| Bronze | Payloads are stored with source id, payload hash, ingestion timestamp, and load id. |
| Silver standardization | Supplier, member, item, invoice, invoice line, contract, and amendment records are conformed. |
| Amendment resolution | Base and amendment terms are sequenced; active surgical mask term is materialized as an effective contract line term. |
| Ontology mapping | Supplier, contract, amendment, item, invoice, invoice line, rule, and finding concepts are represented as semantic nodes and edges. |
| Graph creation | Edges connect invoice -> line, line -> item, contract -> term, term -> item, member -> eligibility, and line -> matched term. |
| Matching | Engine retrieves active supplier/item/date terms and selects the amended mask term. |
| Validation | Contract found, item, member, amendment, and UOM rules pass; price tolerance rule fails. |
| Finding | A price variance finding is created with expected price, actual price, variance amount, and matched contract line. |
| AI/GenAI output | Optional assistant explains the variance using rule evidence and contract term context. |
| UI/API | API returns final invoice status `FAIL`, line status `FAIL`, matched term id, variance, and failed rule list. |
| Gold | Invoice summary, line fact, exception queue, dispute queue, and recovery opportunity can be published for finance and analyst workflow. |

### Walkthrough Diagram

```mermaid
flowchart TD
    A["Structured Invoice Line<br/>Surgical mask level 3"] --> B["Bronze Payload"]
    B --> C["Silver Invoice Line"]
    D["Contract Amendment"] --> E["Effective Contract Term"]
    C --> F["Ontology Node: Invoice Line"]
    E --> G["Ontology Node: Contract Term"]
    F --> H["Graph Edge: MATCHED_TO"]
    G --> H
    H --> I["Reconciliation Validation"]
    I --> J["PRICE_WITHIN_TOLERANCE = FAIL"]
    J --> K["Finding: Price Variance"]
    K --> L["Gold Line Fact, Exception Queue, and Dispute Queue"]
    K --> M["API / UI Evidence"]
```

## 17. Appendix

### 17.1 Glossary

| Term | Definition |
|---|---|
| Bronze | Raw structured landing layer with source lineage. |
| Silver | Conformed trusted business entity layer. |
| Ontology | Semantic layer that defines business concepts, rules, relationships, evidence, and graph. |
| Gold | Serving layer for analytics, workflow, and business outputs. |
| Effective contract term | Contract line term after applying base contract and amendments by date/version. |
| GPO | Group Purchasing Organization. |
| UOM | Unit of measure. |
| Match cache | Reusable high-confidence prior match result. |
| Finding | Business outcome produced by reconciliation. |
| Recovery opportunity | Potential recoverable amount resulting from variance or leakage. |

### 17.2 Sample Data Model

| Table | Layer | Grain |
|---|---|---|
| `platform_dev.pspa_bronze.contract_payload` | Bronze | One source contract/amendment payload. |
| `platform_dev.pspa_bronze.invoice_payload` | Bronze | One source invoice payload. |
| `platform_dev.pspa_silver.party` | Silver | One conformed party. |
| `platform_dev.pspa_silver.item` | Silver | One canonical item. |
| `platform_dev.pspa_silver.contract` | Silver | One contract header. |
| `platform_dev.pspa_silver.contract_version` | Silver | One contract or amendment version. |
| `platform_dev.pspa_silver.effective_contract_line_term` | Silver | One active term interval. |
| `platform_dev.pspa_silver.invoice` | Silver | One invoice header. |
| `platform_dev.pspa_silver.invoice_line` | Silver | One invoice line. |
| `platform_dev.pspa_ontology.node` | Ontology | One semantic object. |
| `platform_dev.pspa_ontology.edge` | Ontology | One semantic relationship. |
| `platform_dev.pspa_ontology.validation_result` | Ontology | One rule result per invoice line. |
| `platform_dev.pspa_ontology.finding` | Ontology | One business finding. |
| `platform_dev.pspa_gold.invoice_reconciliation_summary` | Gold | One invoice/run summary. |
| `platform_dev.pspa_gold.invoice_reconciliation_line` | Gold | One line-level fact. |

### 17.3 Sample Status Lifecycle

| Status | Meaning |
|---|---|
| `RECEIVED` | Invoice is available for processing. |
| `READY_FOR_RECONCILIATION` | Required data quality checks passed. |
| `RUNNING` | Reconciliation is in progress. |
| `PASS` | All high-severity validations passed. |
| `WARN` | No high-severity failures, but warning-level issue exists. |
| `FAIL` | One or more high-severity validations failed. |
| `MANUAL_REVIEW` | Analyst decision required. |
| `DISPUTE_OPENED` | Exception has been converted to dispute workflow. |
| `RECOVERED` | Recovery completed. |
| `WRITTEN_OFF` | Business accepted no recovery. |

### 17.4 Sample Reconciliation Rules

| Rule | Example Failure |
|---|---|
| Contract found | No active contract term exists for invoice item. |
| Item matched | Invoice item maps to a different contracted item. |
| Member eligible | Member not active for contract on service date. |
| Amendment valid | Invoice was matched to obsolete base term after amendment date. |
| UOM convertible | Invoice UOM cannot convert to contract UOM. |
| Price tolerance | Invoice unit price is above contract price plus tolerance. |
| Quantity limit | Invoice quantity exceeds contract maximum. |

### 17.5 Sample Graph Nodes And Edges

| Node / Edge | Example |
|---|---|
| Party node | Supplier `SUP-100`, Member `MEM-900`. |
| Contract node | Contract `CNT-300`. |
| Contract version node | Amendment `AMD-1`. |
| Item node | Surgical mask item. |
| Invoice line node | Invoice `1001`, line `2`. |
| `HAS_VERSION` edge | Contract -> Amendment. |
| `PRICES_ITEM` edge | Effective term -> Item. |
| `ELIGIBLE_FOR` edge | Member -> Contract. |
| `MATCHED_TO` edge | Invoice line -> Effective contract term. |
| `PRODUCED_FINDING` edge | Invoice line -> Price variance finding. |
