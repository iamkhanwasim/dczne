# Enterprise Architecture Deliverables

## 1. Document Control

| Attribute | Value |
|---|---|
| Solution | Price Assurance Contract-Invoice Reconciliation |
| Domain | Supply Chain / GPO / AP Price Assurance |
| Platform | Databricks Lakehouse with Unity Catalog |
| Architecture Pattern | Medallion Delta Architecture + Ontology Graph Layer |
| Data Assumption | Contract and invoice data are already structured and parsed |
| Runtime Scope | Batch reconciliation, API reconciliation, analyst exception workflow |
| Primary Consumers | AP analysts, sourcing teams, finance operations, contract managers, BI users |

## 2. Executive Summary

The proposed solution is an enterprise-grade Price Assurance platform that reconciles structured invoice lines against structured contract terms. It uses Databricks as the governed backend, Delta tables for Medallion-layer data management, Unity Catalog for security and lineage, and an ontology graph layer for semantic relationships and explainable matching.

The architecture is intentionally split into:

- **Bronze** for raw structured source payloads.
- **Silver** for conformed, deduplicated, normalized business entities.
- **Ontology** for semantic graph relationships, rule metadata, matching policy, and explainability.
- **Gold** for business-ready compliance facts, leakage summaries, dispute workflow, and exception queues.
- **Serving/API** for application, dashboard, and workflow consumption.

The ontology layer does not replace Medallion architecture. It sits over curated Silver entities and Gold outputs to power graph-based reconciliation and application semantics.

## 3. Enterprise Architecture

### 3.1 Enterprise Context

```mermaid
flowchart LR
    A["Contract Lifecycle / Sourcing Systems"] --> D["Databricks Lakehouse"]
    B["AP / ERP Invoice Systems"] --> D
    C["Supplier / Facility / GL Master Data"] --> D
    D --> E["Reconciliation Engine"]
    E --> F["Exception Workflow"]
    E --> G["Gold Analytics"]
    E --> H["Audit and Lineage"]
    F --> I["AP Analysts"]
    G --> J["Finance / Sourcing / Leadership"]
    H --> K["Compliance / Internal Audit"]
```

### 3.2 Enterprise Capabilities

| Capability | Description |
|---|---|
| Contract price validation | Validate invoice line pricing against active contract and amendment terms |
| Contract availability validation | Detect suppliers/invoices with no contract on file |
| Facility scope validation | Confirm contract applies to invoicing facility |
| GL/category alignment | Compare invoice spend category and GL coding to supplier/contract classification |
| UOM normalization | Convert invoice UOM to contract UOM before price comparison |
| Exception detection | Detect rate above contract, unmatched charge, excluded charge, expedite fee, insufficient data, source-quality issues, charge-term mismatches, and supplier-contact blockers |
| Dispute workflow | Manage OOUX exception cases, dispute drafts, disputed lines, supplier messages, and resolution |
| Supplier exposure analytics | Summarize overpayment, prepaid exceptions, in-dispute amount, AP spend |
| Auditability | Persist rule-level validation, findings, graph evidence, and user actions |
| Governance | Use Unity Catalog grants, lineage, audit logs, and tags |

### 3.3 Enterprise Principles

| Principle | Design Implication |
|---|---|
| Raw data must be retained | Bronze stores raw structured payloads with source metadata |
| Business entities must be conformed | Silver owns canonical contracts, invoices, suppliers, facilities, GL, categories |
| Results must be explainable | Each finding links to validation rules, contract terms, graph edges, and evidence |
| Financial validation must be deterministic | Price and quantity validators remain rule-based and reproducible |
| Semantic reasoning should be explicit | Ontology graph stores domain relationships used by matching and workflow |
| Gold is for business consumption | Gold tables serve dashboards, queues, scorecards, and AP workflow |
| Governance is first-class | Unity Catalog controls permissions, lineage, discovery, and audit |

## 4. Solution Architecture

### 4.1 Logical Architecture

```mermaid
flowchart TD
    subgraph Sources["Source Systems"]
        A1["Structured Contract Payloads"]
        A2["Structured Invoice Payloads"]
        A3["Supplier / Facility / GL Master Data"]
        A4["Rule / Policy Config"]
    end

    subgraph Lakehouse["Databricks Lakehouse"]
        B["Bronze Delta Tables"]
        C["Silver Conformed Tables"]
        D["Ontology Graph Layer"]
        E["Reconciliation Engine"]
        F["Silver Validation Detail"]
        G["Gold Serving Tables"]
    end

    subgraph Serving["Serving and Operations"]
        H["API / Databricks App"]
        I["Analyst Exception Queue"]
        J["BI Dashboards"]
        K["Audit / Monitoring"]
    end

    A1 --> B
    A2 --> B
    A3 --> B
    A4 --> D
    B --> C
    C --> D
    C --> E
    D --> E
    E --> F
    F --> D
    F --> G
    G --> H
    G --> I
    G --> J
    D --> H
    E --> K
```

### 4.2 Solution Components

| Component | Responsibility | Primary Storage |
|---|---|---|
| Source ingestion adapter | Receives structured contract, invoice, supplier, rule, dispute payloads | Bronze |
| Silver normalization jobs | Clean, deduplicate, type cast, standardize keys, conform master data | Silver |
| Amendment resolver | Builds active/effective contract term intervals | Silver |
| Ontology graph builder | Creates nodes, edges, bindings, triples, and runtime semantic objects from Silver entities and reconciliation results | Ontology |
| Matching engine | Retrieves and scores itemized contract terms and service/charge-term candidates | Silver + Ontology |
| Validator registry | Runs 14 deterministic OOUX-aware validation rules | Ontology rule catalog + Silver outputs |
| Findings generator | Converts rule failures into findings, exception cases, and dispute drafts | Ontology runtime tables |
| Gold publisher | Creates facts, summaries, exception queues, supplier scorecards | Gold |
| API/app layer | Serves reconciliation, findings, ontology relationships, overrides | Gold + Ontology |
| Observability/audit | Stores run metrics, events, lineage references | Ops + Ontology |

### 4.3 Key Design Decision

The ontology layer should be used to **drive reconciliation**, not only to describe Gold results.

Reason: Matching needs semantic relationships before Gold exists:

- Contract scoped to facility.
- Supplier known aliases.
- Contract line supported by clause.
- Invoice line matched to contract line.
- Rule violated by finding.
- Dispute includes invoice line.

Therefore:

```text
Silver provides trusted entities.
Ontology provides semantic relationships and rule context.
Gold provides business-ready outcomes.
```

## 5. Medallion Architecture

### 5.1 Layer Overview

```mermaid
flowchart LR
    A["Bronze: Raw Structured Payloads"] --> B["Silver: Conformed Domain Entities"]
    B --> C["Ontology: Semantic Graph and Rules"]
    C --> D["Reconciliation Processing"]
    D --> E["Silver: Validation Detail"]
    E --> F["Gold: Business Facts and Queues"]
    F --> G["BI / API / Analyst App"]
```

### 5.2 Bronze Layer

Bronze stores raw structured data with minimal transformation. Since documents are already parsed, Bronze does not perform OCR or PDF/image extraction.

| Table | Grain | Purpose |
|---|---|---|
| `bronze.health_system_raw` | One source health system payload | Preserve health system/facility JSON |
| `bronze.supplier_raw` | One supplier payload | Preserve supplier profile, aliases, AP metrics |
| `bronze.contract_raw` | One contract/amendment payload | Preserve raw structured contract header |
| `bronze.contract_line_raw` | One raw contract line | Preserve raw contract term fields |
| `bronze.invoice_raw` | One invoice header payload | Preserve raw AP invoice header |
| `bronze.invoice_line_raw` | One invoice line payload | Preserve raw invoice line fields |
| `bronze.detection_rule_raw` | One rule payload | Preserve rule config from UI/source |
| `bronze.dispute_raw` | One dispute payload | Preserve dispute and message thread source |

Bronze required metadata:

- `source_system`
- `source_record_id`
- `source_batch_id`
- `payload_json`
- `schema_version`
- `load_status`
- `ingested_at`

### 5.3 Silver Layer

Silver owns trusted, reusable business entities.

| Domain | Silver Tables |
|---|---|
| Organization | `party`, `facility_profile`, `party_relationship`, `party_alias`, `party_contact` |
| Supplier | `supplier_profile`, `supplier_category` |
| Finance classification | `category`, `gl_account` |
| Contract | `contract`, `contract_version`, `contract_line_term`, `effective_contract_line_term`, `contract_clause`, `contract_facility_scope` |
| Invoice | `invoice`, `invoice_line` |
| Reconciliation detail | `reconciliation_run`, `validation_result`, `finding` |
| Users | `application_user`, `application_user_role` |

Silver responsibilities:

- Standardize IDs and keys.
- Normalize supplier aliases.
- Map facilities to health systems.
- Map GL codes and spend categories.
- Resolve amendment precedence.
- Build effective contract term intervals.
- Preserve detailed validation results.

### 5.4 Gold Layer

Gold contains business-ready outputs.

| Table | Purpose |
|---|---|
| `gold.invoice_line_compliance_fact` | Final line-level compliance status, match, variance, remediation |
| `gold.invoice_compliance_summary` | Invoice-level verdict, exception count, total exposure |
| `gold.contract_leakage_summary` | Leakage by supplier, member/facility, contract, category, period |
| `gold.exception_work_queue` | Analyst-facing queue for exceptions and reviews |
| `gold.supplier_price_assurance_summary` | Supplier-level AP spend, overpayment, dispute, prepaid exposure |
| `gold.dispute_case` | Dispute lifecycle |
| `gold.dispute_case_line` | Disputed invoice lines |
| `gold.dispute_message` | Supplier/AP message thread |

Gold consumption:

- BI dashboards.
- AP approval queue.
- Dispute workflow.
- Supplier scorecards.
- Sourcing analytics.
- Finance leadership reporting.

## 6. Ontology Architecture

### 6.1 What Is The Ontology Layer?

The ontology layer is a semantic graph over curated Silver entities and Gold outputs. It describes what the business objects mean and how they relate.

It has four responsibilities:

1. Represent business objects as graph nodes.
2. Represent relationships as graph edges.
3. Bind graph nodes back to physical Delta rows.
4. Store rule, matching, audit, and semantic metadata.

### 6.2 Ontology Storage Model

| Table | Purpose |
|---|---|
| `ontology.node` | Semantic object registry |
| `ontology.edge` | Relationships between objects |
| `ontology.triple` | Optional RDF-style assertions |
| `ontology.entity_binding` | Maps graph node to `catalog.schema.table` row |
| `ontology.rule_catalog` | Rule metadata, trigger, severity, action |
| `ontology.matching_policy` | Matching weights and thresholds |
| `ontology.match_cache` | Fast-path match cache |
| `ontology.reconciliation_run` | Reconciliation execution metadata |
| `ontology.validation_result` | Rule-level validation detail |
| `ontology.finding` | Business-facing line finding |
| `ontology.exception_case` | OOUX exception workflow object with root cause, status, variance, exposure, and remediation |
| `ontology.dispute` | Supplier-facing dispute draft/case linked to an exception |
| `ontology.dispute_line` | Invoice lines included in a dispute |
| `ontology.dispute_message` | Draft, outbound, and inbound dispute communications |
| `ontology.audit_event` | Semantic audit events and user actions |

### 6.3 Core Ontology Objects

| Ontology Object | Backing Table |
|---|---|
| Health System | `silver.party` |
| Facility | `silver.party`, `silver.facility_profile` |
| Supplier | `silver.party`, `silver.supplier_profile` |
| Contract | `silver.contract` |
| Contract Version | `silver.contract_version` |
| Contract Line Term | `silver.contract_line_term` |
| Effective Contract Term | `silver.effective_contract_line_term` |
| Contract Clause | `silver.contract_clause` |
| Invoice | `silver.invoice` |
| Invoice Line | `silver.invoice_line` |
| Rule | `ontology.rule_catalog` |
| Validation Result | `ontology.validation_result` |
| Finding | `ontology.finding` |
| Exception Case (`ExceptionCase`) | `ontology.exception_case` |
| Dispute Draft (`Dispute`) | `ontology.dispute` |
| Dispute Message (`DisputeMessage`) | `ontology.dispute_message` |
| User | `silver.application_user` |

### 6.4 Core Ontology Relationships

```mermaid
flowchart LR
    HS["Health System"] -->|HAS_FACILITY| FAC["Facility"]
    SUP["Supplier"] -->|PARTICIPATES_IN| CON["Contract"]
    CON -->|SCOPED_TO_FACILITY| FAC
    CON -->|HAS_VERSION| CV["Contract Version"]
    CV -->|HAS_TERM| CL["Contract Line Term"]
    CL -->|SUPPORTED_BY_CLAUSE| CC["Contract Clause"]
    CL -->|PRICES_CATEGORY_OR_ITEM| CAT["Category / Item"]
    INV["Invoice"] -->|HAS_LINE| IL["Invoice Line"]
    IL -->|MATCHED_TO| CL
    IL -->|VIOLATES_RULE| RULE["Rule"]
    IL -->|HAS_FINDING| FND["Finding"]
    FND -->|CREATES_EXCEPTION| EX["Exception"]
    EX -->|DISPUTE_FOR| DISP["Dispute Draft / Case"]
    DISP -->|INCLUDES| IL
    DISP -->|HAS_MESSAGE| MSG["Dispute Message"]
    DISP -->|DISPUTE_WITH| SUP
```

### 6.5 How Ontology Helps Reconciliation

| Reconciliation Need | Ontology Support |
|---|---|
| Match supplier aliases | `Supplier HAS_ALIAS Alias` |
| Validate facility-specific contract | `Contract SCOPED_TO_FACILITY Facility` |
| Explain price source | `ContractLine SUPPORTED_BY_CLAUSE ContractClause` |
| Detect excluded charges | Rule and clause relationship marks prohibited terms |
| Route soft exceptions | Rule severity and action metadata |
| Explain finding | Finding links to rule, invoice line, contract line, clause |
| Match service charge terms | Contract and invoice charge-term type, pricing basis, category, frequency, and semantic evidence are explicit |
| Avoid false UOM failures | Service charge terms can mark UOM as optional while itemized supply terms still require conversion |
| Create dispute | Exception case links to invoice line, supplier, dispute draft, dispute lines, and messages |
| Audit override | User/action edges and audit events |

## 7. Data Flow

### 7.1 End-to-End Data Flow

```mermaid
flowchart TD
    A["Structured payloads from upstream systems"] --> B["Bronze raw tables"]
    B --> C["Silver normalization"]
    C --> D["Silver conformed entities"]
    D --> E["Ontology graph build"]
    D --> F["Effective contract term build"]
    E --> G["Candidate graph retrieval"]
    F --> G
    G --> H["Matching and route selection"]
    H --> I["Validation execution"]
    I --> J["Ontology validation_result"]
    I --> K["Ontology finding"]
    K --> K2["Ontology exception_case"]
    K2 --> K3["Ontology dispute draft"]
    J --> L["Gold facts and summaries"]
    K --> L
    K2 --> L
    K3 --> L
    L --> M["API / App / Dashboard"]
```

### 7.2 Data Movement Detail

| Step | Input | Output | Layer |
|---|---|---|---|
| 1 | Structured source records | Raw payload rows | Bronze |
| 2 | Raw payload rows | Typed, conformed entities | Silver |
| 3 | Contract versions/terms | Effective contract line intervals | Silver |
| 4 | Silver entities | Nodes, edges, bindings | Ontology |
| 5 | Invoice lines + graph | Match candidates | Processing |
| 6 | Match candidates + rules | Validation results | Ontology |
| 7 | Validation results | Findings, exception cases, dispute drafts | Ontology |
| 8 | Findings/results/exceptions/disputes | Facts, summaries, queues | Gold |
| 9 | Gold + ontology | API/app responses | Serving |

## 8. Processing Flow

### 8.1 Batch Processing Flow

```mermaid
sequenceDiagram
    participant SRC as Source Systems
    participant B as Bronze
    participant S as Silver Jobs
    participant O as Ontology Builder
    participant R as Reconciliation Engine
    participant G as Gold Publisher
    participant A as App/BI

    SRC->>B: Load structured contract/invoice/rule/dispute payloads
    B->>S: Normalize, dedupe, validate, conform
    S->>S: Resolve amendments and effective terms
    S->>O: Build ontology nodes and edges
    O->>R: Provide semantic relationship graph
    S->>R: Provide invoices and contract terms
    R->>R: Match itemized or service charge term, route, validate
    R->>O: Persist run, validation_result, finding, exception_case, dispute draft
    R->>O: Persist MATCHED_TO / VIOLATES_RULE / HAS_FINDING / DISPUTE_FOR edges
    O->>G: Publish facts, summaries, queues, disputes
    G->>A: Serve dashboards and workflows
```

### 8.2 Invoice Line Reconciliation Flow

```mermaid
flowchart TD
    A["Invoice Line"] --> B{"Required fields present?"}
    B -->|No| C["Fail: Insufficient Data"]
    B -->|Yes| D{"Supplier has active contract?"}
    D -->|No| E["Fail: Unmatched Contract"]
    D -->|Yes| F["Retrieve candidate contract terms"]
    F --> G{"Itemized product or service charge term?"}
    G -->|Itemized| H["Require item/UOM contract evidence"]
    G -->|Service| H2["Allow category/charge-term semantic evidence"]
    H --> I["Score candidate terms"]
    H2 --> I
    I --> J{"Candidate above threshold?"}
    J -->|No| K["Review: Unmatched Charge"]
    J -->|Yes| L["Normalize UOM or mark UOM optional"]
    L --> M["Run 14 OOUX-aware validators"]
    M --> N{"Rule failures?"}
    N -->|No| O["Pass: Good to Pay"]
    N -->|Soft| P["Review: Soft Exception"]
    N -->|Hard| Q["Fail: Block Auto Approval"]
    Q --> R["Create Exception Case / Dispute Draft"]
    P --> R
```

### 8.3 Rule Processing Flow

| Rule Group | Rule Codes | Result |
|---|---|---|
| Data quality and source readiness | `DATA_QUALITY_SUFFICIENT` | Blocks false billing exceptions when parsed/source data is not reliable. |
| Contract and charge-term selection | `CONTRACT_FOUND`, `CONTRACT_CANDIDATE_SELECTED`, `CHARGE_TERM_CANDIDATE_SELECTED` | Routes unmatched or ambiguous contracts/terms to exception workflow. |
| Item/service compatibility | `ITEM_OR_SERVICE_TERM_MATCHED`, `CATEGORY_COMPATIBLE`, `CHARGE_TERM_ALLOWED`, `FREQUENCY_ALLOWED` | Supports both itemized supply terms and service charge terms such as subscriptions, overages, or excluded charges. |
| Eligibility and amendment validity | `MEMBER_ELIGIBLE`, `AMENDMENT_VERSION_VALID` | Confirms member/facility scope and correct effective amendment version. |
| Unit, price, and quantity controls | `UOM_NOT_REQUIRED_OR_CONVERTIBLE`, `PRICE_WITHIN_TOLERANCE`, `QUANTITY_LIMIT_VALID` | Calculates variance and avoids forcing UOM on service terms where UOM is not required. |
| Dispute readiness | `SUPPLIER_CONTACT_COMPLETE` | Allows dispute drafts only when supplier contact data is complete. |

## 9. Component Diagram

```mermaid
flowchart TB
    subgraph Databricks["Databricks Workspace"]
        subgraph UC["Unity Catalog"]
            B["bronze schema"]
            S["silver schema"]
            O["ontology schema"]
            G["gold schema"]
            OPS["ops schema"]
        end

        LF["Lakeflow / Jobs"]
        SQL["SQL Warehouse"]
        NB["Notebooks / Python Jobs"]
        DASH["Dashboards"]
    end

    subgraph App["Application Layer"]
        API["Reconciliation API"]
        UI["Analyst UI / Databricks App"]
        AUTH["Identity / RBAC"]
    end

    subgraph Engine["Reconciliation Engine"]
        REPO["OntologyRepository"]
        MATCH["Matching Engine"]
        VAL["Validator Registry"]
        FIND["Finding / Exception Generator"]
        DISP["Dispute Draft Builder"]
        CACHE["Match Cache"]
    end

    LF --> B
    LF --> S
    LF --> O
    NB --> Engine
    Engine --> S
    Engine --> O
    Engine --> G
    FIND --> DISP
    API --> REPO
    UI --> API
    REPO --> SQL
    SQL --> UC
    DASH --> G
    AUTH --> API
```

## 10. Deployment Diagram

```mermaid
flowchart LR
    subgraph Dev["Development"]
        D1["Git Repo"]
        D2["Unit Tests"]
        D3["Local SQLite Demo"]
    end

    subgraph CICD["CI/CD"]
        C1["Declarative Automation Bundle"]
        C2["Validate"]
        C3["Deploy"]
    end

    subgraph DBX["Databricks Environment"]
        W1["Workspace"]
        UC["Unity Catalog Metastore"]
        JOB["Lakeflow Jobs / Pipelines"]
        WH["SQL Warehouse"]
        APP["Databricks App or API Service"]
        MON["System Tables / Monitoring"]
    end

    subgraph Consumers["Consumers"]
        AP["AP Analysts"]
        BI["BI Dashboards"]
        AUD["Audit / Compliance"]
    end

    D1 --> D2
    D2 --> C1
    C1 --> C2
    C2 --> C3
    C3 --> W1
    W1 --> JOB
    W1 --> WH
    W1 --> APP
    JOB --> UC
    WH --> UC
    APP --> WH
    UC --> MON
    APP --> AP
    WH --> BI
    MON --> AUD
```

### 10.1 Deployment Units

| Unit | Deployment Mechanism |
|---|---|
| SQL schemas/tables | Databricks SQL scripts or bundle resource |
| Batch jobs | Lakeflow Jobs / Spark jobs |
| Pipelines | Lakeflow Spark Declarative Pipelines where appropriate |
| Python engine | Wheel artifact or source deployment |
| API/app | Databricks App, container service, or external FastAPI |
| Dashboards | Databricks dashboards or BI tool |
| Monitoring | System tables, audit logs, custom ops metrics |

## 11. Unity Catalog Design

### 11.1 Catalog Strategy

Recommended catalog:

```text
platform_dev
```

Higher-environment enterprise pattern:

```text
platform_test
platform_prod
```

For regulated or large enterprise environments, use separate catalogs by environment to simplify isolation, grants, and lifecycle controls.

### 11.2 Schema Strategy

| Schema | Owner | Purpose |
|---|---|---|
| `pspa_bronze` | Data engineering | Raw structured payloads |
| `pspa_silver` | Data engineering + domain data owners | Conformed entities and validation detail |
| `pspa_ontology` | Platform/data architecture | Graph, rules, policies, cache, validation evidence, findings, exception cases, dispute drafts, semantic audit |
| `pspa_gold` | Analytics/product owners | Business facts, summaries, exception queues |
| `pspa_ops` | Platform operations | Metrics, run health, monitoring |

Unity Catalog supports `catalog.schema.table`. Because nested schemas such as `platform_dev.pspa.bronze.table` are not supported, the PSPA domain and Medallion layer are combined in the schema name.

### 11.3 Naming Convention

```text
<catalog>.<schema>.<object>
```

Examples:

```text
platform_dev.pspa_bronze.invoice_raw
platform_dev.pspa_silver.effective_contract_line_term
platform_dev.pspa_ontology.edge
platform_dev.pspa_gold.invoice_line_compliance_fact
platform_dev.pspa_ops.reconciliation_metric
```

### 11.4 Securable Object Design

Unity Catalog uses a three-level namespace for tables, views, volumes, functions, models, and services. This solution should use that object model for governance.

| Object Type | Recommendation |
|---|---|
| Catalog | One per environment/domain, for example `platform_dev` |
| Schema | PSPA Medallion schemas: `pspa_bronze`, `pspa_silver`, `pspa_ontology`, `pspa_gold`, `pspa_ops` |
| Table | Delta managed tables for curated data |
| View | Secure views for analyst-facing subsets |
| Volume | Optional landing area for structured source payload snapshots |
| Function | Optional reusable SQL functions for rules or UOM conversion |
| Model/function serving | Optional semantic scoring or model-based matching |

### 11.5 Managed vs External Storage

| Asset | Recommendation |
|---|---|
| Bronze raw Delta tables | Managed tables unless enterprise policy requires external locations |
| Silver/Gold Delta tables | Managed tables preferred |
| External raw payload files | Use external locations and volumes if raw files must remain in cloud storage |
| Application logs/exports | Use governed volumes or managed tables |

### 11.6 Access Control Model

| Persona / Principal | Bronze | Silver | Ontology | Gold | Ops |
|---|---|---|---|---|---|
| Data engineering service principal | Read/write | Read/write | Read/write | Read/write | Read/write |
| Reconciliation job service principal | Read | Read/write validation detail | Read/write graph/cache/audit | Write facts | Write metrics |
| AP analyst | No direct | Limited read | Limited read via views | Read/update exception workflow | No direct |
| Sourcing analyst | No direct | Read contracts/suppliers | Read ontology relationships | Read summaries | No direct |
| Finance leadership | No direct | No direct | No direct | Read dashboards/views | No direct |
| Compliance/audit | Read via controlled views | Read | Read | Read | Read |

### 11.7 Recommended Groups

```text
grp_pspa_data_engineers
grp_pspa_reconciliation_jobs
grp_pspa_ap_analysts
grp_pspa_sourcing_analysts
grp_pspa_finance_readers
grp_pspa_auditors
grp_pspa_admins
```

### 11.8 Table Classification And Tags

Recommended tags:

| Tag | Example Values |
|---|---|
| `domain` | `price_assurance`, `supply_chain`, `ap` |
| `layer` | `bronze`, `silver`, `ontology`, `gold`, `ops` |
| `data_sensitivity` | `internal`, `confidential`, `restricted` |
| `contains_pii` | `true`, `false` |
| `owner` | data owner group |
| `retention_class` | `raw_7_year`, `audit_7_year`, `metric_2_year` |

### 11.9 Lineage And Audit

Unity Catalog should be used with:

- Lineage from Bronze to Silver to Gold.
- Audit logs for table access.
- Audit events for reconciliation actions.
- Rule and policy version captured on every run.
- Dispute and override action history.

### 11.10 Retention Guidance

| Data | Suggested Retention |
|---|---|
| Bronze raw payloads | 7 years or enterprise AP audit policy |
| Silver contracts/invoices | 7 years or contract retention policy |
| Validation results/findings | 7 years |
| Gold facts/summaries | 7 years |
| Dispute messages | 7 years or legal hold policy |
| Ops metrics | 1-2 years |

## 12. Non-Functional Architecture

| Requirement | Design |
|---|---|
| Scalability | Spark/Databricks jobs for batch reconciliation |
| Performance | Gold tables optimized for dashboard/query access; match cache for repeated line patterns |
| Reliability | Idempotent batch IDs, run status, retryable jobs |
| Auditability | Persist raw payload, validation result, finding, audit event, rule version |
| Security | Unity Catalog grants, service principals, secure views |
| Explainability | Ontology edges and clause evidence linked to findings |
| Maintainability | Repository abstraction, rule catalog, matching policy |
| Deployment | Declarative Automation Bundles or equivalent CI/CD |

## 13. Interfaces

### 13.1 Batch Interfaces

| Interface | Direction | Description |
|---|---|---|
| Structured contract payload | Inbound | Contract headers, terms, clauses, amendments |
| Structured invoice payload | Inbound | Invoice headers and lines |
| Supplier/facility master data | Inbound | Supplier profile, aliases, contacts, facility data |
| Rule/policy config | Inbound | Detection rules and thresholds |
| Gold facts | Outbound | Compliance facts and leakage summaries |
| Dispute outcomes | Outbound | Recovery/dispute status to AP workflow |

### 13.2 API Interfaces

| Endpoint | Purpose |
|---|---|
| `POST /reconcile` | Reconcile invoice or invoice batch |
| `GET /reconciliation-runs/{id}` | Retrieve run status |
| `GET /invoices/{id}/findings` | Retrieve invoice findings |
| `GET /invoice-lines/{id}/validations` | Retrieve rule-level validations |
| `GET /suppliers/{id}/summary` | Supplier Price Assurance scorecard |
| `POST /exceptions/{id}/assign` | Assign exception |
| `POST /exceptions/{id}/override` | Override with audit |
| `POST /disputes` | Initiate dispute |
| `POST /disputes/{id}/messages` | Add supplier/AP message |

## 14. Risks And Mitigations

| Risk | Mitigation |
|---|---|
| Source systems send changing schemas | Store raw payload as JSON/VARIANT in Bronze; evolve Silver mapping |
| Supplier aliases cause incorrect matching | Govern aliases in Silver and require confidence/evidence |
| Contract clauses are ambiguous | Store clause evidence and route low-confidence matches to review |
| Rule changes affect historical outcomes | Version rules and store rule version on validation results |
| Cache returns stale contract match | Invalidate cache on contract/amendment/item/UOM/policy changes |
| Analysts need explainability | Link findings to rules, terms, clauses, and graph paths |
| Gold dashboards become slow | Optimize Gold tables and aggregate by period/supplier/category |

## 15. Implementation Roadmap

| Phase | Scope |
|---|---|
| 1 | Create Unity Catalog schemas and tables |
| 2 | Load Bronze structured payloads |
| 3 | Build Silver normalization for suppliers, facilities, contracts, invoices |
| 4 | Build amendment resolver and effective contract terms |
| 5 | Build ontology graph nodes/edges/entity bindings |
| 6 | Implement reconciliation matching and validators on Databricks repository |
| 7 | Publish Gold facts, summaries, exception queue |
| 8 | Add dispute workflow tables and APIs |
| 9 | Add dashboards and analyst UI |
| 10 | Add monitoring, CI/CD bundles, data quality checks, and production grants |

## 16. Reference Implementation Files

| File | Purpose |
|---|---|
| `sql/databricks_lakehouse_schema.sql` | Unified Unity Catalog DDL for Bronze, Silver, Ontology, Gold, Ops, and Price Assurance extensions |
| `docs/DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md` | Delta table grain, ownership, and responsibility documentation |
| `docs/MEDALLION_ONTOLOGY_ARCHITECTURE.md` | Layering rationale |
| `docs/PRICE_ASSURANCE_SEED_GAP_ANALYSIS.md` | Field/entity gap analysis |
| `src/ontology_reconciliation/engine.py` | Demo reconciliation orchestrator |
| `src/ontology_reconciliation/matching.py` | Demo matching algorithm |
| `src/ontology_reconciliation/validators.py` | Demo validation rules |

## 17. External References

- Databricks Medallion Lakehouse Architecture
- Databricks Unity Catalog
- Databricks Declarative Automation Bundles
- Databricks Lakeflow Spark Declarative Pipelines
