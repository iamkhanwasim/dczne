# Low-Level Design: Ontology Reconciliation Engine

## 1. Scope

This document describes the low-level implementation design for the runnable reconciliation engine in this repo and its Databricks production path.

The design covers:

- Package structure
- Data model
- Storage abstraction
- Graph repository behavior
- Matching algorithm
- Validation algorithm
- Findings generation
- API/CLI process flow
- Databricks deployment mapping
- Error handling, audit, and observability

## 2. Repository Structure

```text
databricks-ontology-reconciliation-demo/
  pyproject.toml
  README.md
  run_demo.py
  serve_demo.py
  sql/
    databricks_lakehouse_schema.sql
  docs/
    SOLUTION_ARCHITECTURE.md
    LOW_LEVEL_DESIGN.md
  src/
    ontology_reconciliation/
      __init__.py
      api.py
      cli.py
      databricks_repository.py
      engine.py
      findings.py
      matching.py
      models.py
      repository.py
      seed_data.py
      sqlite_repository.py
      utils.py
      validators.py
  tests/
    test_reconciliation_demo.py
```

## 3. Logical Components

```mermaid
flowchart TD
    A["CLI / API"] --> B["ReconciliationEngine"]
    B --> C["OntologyRepository"]
    C --> D["SQLiteOntologyRepository"]
    C --> E["DatabricksOntologyRepository"]
    B --> F["Matching Module"]
    B --> G["Validators Module"]
    B --> H["Findings Module"]
    F --> C
    G --> C
    H --> C
```

## 4. Core Classes And Files

### 4.1 `models.py`

Contains dataclasses used across the engine.

| Model | Purpose |
|---|---|
| `Party` | Supplier, GPO, member, distributor, manufacturer, facility |
| `Item` | Contracted or invoiced product/service |
| `Contract` | Contract header |
| `ContractVersion` | Base contract or amendment |
| `ContractLineTerm` | Raw contract term from base/amendment |
| `EffectiveContractLineTerm` | Final effective interval after amendment resolution |
| `MemberEligibility` | Member/facility eligibility for contract/tier |
| `Invoice` | Invoice header |
| `InvoiceLine` | Invoice line detail |
| `Node` | Generic ontology graph node |
| `Edge` | Generic ontology graph relationship |
| `RuleCatalogEntry` | Validation rule metadata |
| `MatchingPolicy` | Configurable matching weights and thresholds |
| `MatchCandidate` | Candidate contract term selected for invoice line |
| `ValidationResult` | One rule result for one invoice line |
| `Finding` | User-facing reconciliation outcome |
| `ExceptionCase` | OOUX exception workflow entity for failed or ambiguous line outcomes |
| `Dispute` | Supplier-facing dispute draft linked to an exception case |
| `DisputeLine` | Bridge between dispute and invoice line |
| `DisputeMessage` | Draft/sent/received dispute communication history |
| `ReconciliationRun` | Execution metadata for one reconciliation run |
| `LineOutcome` | In-memory output for one line |
| `ReconciliationSummary` | In-memory output for one invoice |

### 4.2 `repository.py`

Defines `OntologyRepository`, the storage interface. The engine depends only on this interface.

Important methods:

| Method | Purpose |
|---|---|
| `initialize()` | Create tables |
| `reset()` | Clear demo data |
| `add_*()` | Persist ontology entities, graph objects, runs, validations, findings |
| `get_invoice()` | Load invoice header |
| `get_invoice_lines()` | Load invoice lines |
| `get_active_contract_terms()` | Retrieve exact item candidate terms by supplier, item, and service date |
| `get_active_contract_terms_for_supplier()` | Retrieve supplier/date contract terms for service and charge-term fallback |
| `get_candidate_contract_terms()` | Retrieve item candidates first, then service/category candidates when item identity is absent or insufficient |
| `get_supplier_contact()` | Retrieve supplier dispute contact and contact-completeness metadata |
| `is_member_eligible()` | Check member eligibility |
| `get_uom_conversion()` | Retrieve UOM conversion factor |
| `find_cache_match()` | Check persistent fast-path cache |
| `upsert_cache_match()` | Store high-confidence candidate match |
| `invalidate_contract_cache()` | Invalidate matches after contract/amendment change |
| `add_exception_case()` | Persist failed/ambiguous line exception |
| `add_dispute*()` | Persist dispute draft, dispute lines, and dispute message history |

### 4.3 `sqlite_repository.py`

Implements `OntologyRepository` using SQLite. This makes the repo fully runnable without Databricks.

It persists:

- Entity tables
- Graph nodes and edges
- Matching policy
- Rule catalog
- Match cache
- Reconciliation runs
- Validation results
- Findings
- Exception cases
- Dispute drafts, dispute lines, and dispute messages
- Audit events

### 4.4 `databricks_repository.py`

Provides the Databricks SQL connector boundary.

Current design:

- `DatabricksSqlConfig`: reads connection config from environment.
- `DatabricksSqlClient`: executes SQL through Databricks SQL Connector.
- `DatabricksOntologyRepository`: production implementation placeholder.

Production work:

- Implement each `OntologyRepository` method using Databricks SQL statements.
- Keep algorithm modules unchanged.

### 4.5 `matching.py`

Responsible for selecting the best contract term for an invoice line.

Main functions:

| Function | Purpose |
|---|---|
| `invoice_line_signature()` | Builds cache key from description, item, UOM, price |
| `token_overlap_similarity()` | Lightweight semantic similarity for demo |
| `price_proximity()` | Measures closeness of invoice price to contract price |
| `normalize_invoice_unit_price()` | Converts invoice price to contract UOM |
| `service_uom_optional()` | Determines when a service charge term can validly omit UOM |
| `source_quality_sufficient()` | Applies parse/source-quality gate before financial validation |
| `category_compatible()` | Checks invoice and contract category alignment |
| `semantic_similarity()` | Scores item/service/charge-term description overlap |
| `score_candidate()` | Applies matching policy weights |
| `find_best_match()` | Retrieves candidates, checks cache, scores, selects best |

### 4.6 `validators.py`

Runs deterministic validation rules.

Main functions:

| Function | Purpose |
|---|---|
| `validate_line()` | Produces rule-level `ValidationResult` rows |
| `final_status()` | Converts validation results into line status |

Current OOUX-aware rules:

- `DATA_QUALITY_SUFFICIENT`
- `CONTRACT_FOUND`
- `CONTRACT_CANDIDATE_SELECTED`
- `CHARGE_TERM_CANDIDATE_SELECTED`
- `ITEM_OR_SERVICE_TERM_MATCHED`
- `CATEGORY_COMPATIBLE`
- `MEMBER_ELIGIBLE`
- `AMENDMENT_VERSION_VALID`
- `CHARGE_TERM_ALLOWED`
- `UOM_NOT_REQUIRED_OR_CONVERTIBLE`
- `PRICE_WITHIN_TOLERANCE`
- `QUANTITY_LIMIT_VALID`
- `FREQUENCY_ALLOWED`
- `SUPPLIER_CONTACT_COMPLETE`

### 4.7 `findings.py`

Converts validation results into business-facing findings, exception cases, and dispute drafts.

Finding types:

| Type | Meaning |
|---|---|
| `COMPLIANT` | Line passed all rules |
| `PRICE_VARIANCE` | Contract match exists but invoice price is too high |
| `OFF_CONTRACT` | No valid contract term found |
| `VALIDATION_FAILURE` | Other high-severity rule failure |

Additional builders:

| Function | Purpose |
|---|---|
| `build_exception_case()` | Creates an exception workflow object with root cause, variance, annualized exposure, and remediation guidance. |
| `build_dispute_for_exception()` | Creates a supplier-facing dispute draft only when the exception is dispute-ready and supplier contact data is complete. |

### 4.8 `engine.py`

Coordinates the full reconciliation process.

Main class:

```python
class ReconciliationEngine:
    def reconcile_invoice(self, invoice_id: str) -> ReconciliationSummary:
        ...
```

Responsibilities:

- Create a reconciliation run.
- Load invoice lines.
- Call matching for each line.
- Run validators.
- Persist validation results.
- Generate findings.
- Persist findings.
- Persist exception cases for failed or ambiguous lines.
- Persist supplier dispute drafts, lines, and draft messages when dispute-ready.
- Write audit events.
- Complete the run with aggregate counts.

## 5. Table Design

Production Databricks should separate tables into Bronze, Silver, Ontology, and Gold schemas. The local SQLite demo keeps these concepts in one compact database so the demo can run anywhere, but the Databricks implementation should use explicit Medallion layers.

| Production Layer | Responsibility |
|---|---|
| Bronze | Raw structured source payloads with minimal transformation |
| Silver | Conformed contract, item, party, eligibility, invoice, and validation detail |
| Ontology | Graph nodes/edges, semantic relationships, rules, policies, cache, validation evidence, findings, exception cases, dispute drafts |
| Gold | Business-ready compliance facts, summaries, analyst queues, recovery and dispute reporting |

See [Medallion + Ontology Architecture](MEDALLION_ONTOLOGY_ARCHITECTURE.md) for the full production layering.

### 5.1 Core Entity Tables

| Table | Key | Description |
|---|---|---|
| `party` | `party_id` | GPO, supplier, member, distributor, etc. |
| `item` | `item_id` | Product or service master |
| `uom_conversion` | `item_id`, `from_uom`, `to_uom` | UOM conversion facts |
| `contract` | `contract_id` | Contract header |
| `contract_version` | `contract_version_id` | Base contract and amendments |
| `contract_line_term` | `contract_line_id` | Raw contract/amendment line terms |
| `effective_contract_line_term` | `contract_line_id` | Terms after amendment resolution |
| `member_eligibility` | `eligibility_id` | Member/tier eligibility |
| `invoice` | `invoice_id` | Invoice header |
| `invoice_line` | `invoice_line_id` | Invoice line |

### 5.2 Graph Tables

| Table | Key | Description |
|---|---|---|
| `node` | `node_id` | Generic ontology node |
| `edge` | `edge_id` | Generic graph relationship |

Example edges:

| From | Relationship | To |
|---|---|---|
| GPO | `GOVERNS` | Contract |
| Supplier | `PARTICIPATES_IN` | Contract |
| Contract | `HAS_TERM` | Contract line |
| Contract line | `PRICES_ITEM` | Item |
| Member | `ELIGIBLE_FOR` | Contract |
| Invoice | `HAS_LINE` | Invoice line |

### 5.3 Policy And Rule Tables

| Table | Description |
|---|---|
| `rule_catalog` | Rule version, severity, group, parameters |
| `matching_policy` | Matching weights and thresholds |
| `match_cache` | Persistent fast-path cache |

### 5.4 Result And Audit Tables

| Table | Description |
|---|---|
| `reconciliation_run` | One row per invoice reconciliation execution |
| `validation_result` | One row per rule per invoice line |
| `finding` | One business-facing outcome per invoice line |
| `exception_case` | One workflow exception for failed or ambiguous invoice lines |
| `dispute` | Supplier-facing dispute draft/case |
| `dispute_line` | Invoice lines included in a dispute |
| `dispute_message` | Draft, outbound, and response message history for a dispute |
| `audit_event` | System/user audit trail |

## 6. Process Flow

### 6.1 Local Demo Startup

```mermaid
sequenceDiagram
    participant User
    participant CLI
    participant Repo as SQLiteOntologyRepository
    participant Seed as Seed Data
    participant Engine

    User->>CLI: python run_demo.py --reset
    CLI->>Repo: initialize()
    CLI->>Repo: reset()
    CLI->>Seed: seed_demo_data(repo)
    Seed->>Repo: insert ontology entities, graph edges, invoice data
    CLI->>Engine: reconcile_invoice("INV-1001")
```

### 6.2 Reconciliation Sequence

```mermaid
sequenceDiagram
    participant Engine
    participant Repo
    participant Match as Matching
    participant Val as Validators
    participant Find as Findings

    Engine->>Repo: get_invoice(invoice_id)
    Engine->>Repo: get_invoice_lines(invoice_id)
    Engine->>Repo: add_run(RUNNING)
    loop For each invoice line
        Engine->>Match: find_best_match(repo, invoice, line)
        Match->>Repo: get_candidate_contract_terms(supplier, item, service_date)
        Match->>Repo: find_cache_match(signature)
        Match->>Repo: get_graph_match_evidence(invoice, line, candidate_term)
        Match->>Repo: is_member_eligible(contract, member, date)
        Match->>Repo: get_uom_conversion(item, invoice_uom, contract_uom) when UOM is required
        Match-->>Engine: MatchCandidate or None with graph/category/source-quality/charge-term evidence
        Engine->>Val: validate_line(...)
        Val-->>Engine: ValidationResult[]
        Engine->>Repo: add_validation_result(...)
        Engine->>Find: build_finding(...)
        Find-->>Engine: Finding
        Engine->>Repo: add_finding(finding)
        Engine->>Find: build_exception_case(...) when needed
        Find-->>Engine: ExceptionCase or None
        Engine->>Repo: add_exception_case(exception_case)
        Engine->>Find: build_dispute_for_exception(...) when dispute-ready
        Find-->>Engine: Dispute draft, DisputeLine, DisputeMessage or None
        Engine->>Repo: add_dispute objects
        Engine->>Repo: add_audit_event(LINE_RECONCILED)
    end
    Engine->>Repo: complete_run(final status and counts)
```

## 7. Matching Algorithm

### 7.1 Candidate Retrieval

Inputs:

- Supplier from invoice header
- Item from invoice line
- Service date from invoice line

Repository query for itemized supply lines:

```text
effective_contract_line_term
  join contract
where contract.supplier_id = invoice.supplier_id
  and term.item_id = invoice_line.item_id
  and term.effective_from <= service_date
  and (term.effective_to is null or term.effective_to >= service_date)
```

For service or charge-term lines, `get_candidate_contract_terms()` first attempts exact item matching. If the line has no reliable item identity or carries service/category charge-term context, it falls back to supplier/date terms and ranks them using category, charge-term type, pricing basis, billing frequency, description similarity, source quality, and graph support. If an invoice line has a concrete item ID and no service context, the engine does not silently fall back to unrelated service terms; it creates an off-contract exception instead.

The current implementation also reads ontology graph evidence for each candidate through `get_graph_match_evidence()`. This checks whether expected graph relationships exist and are active for the invoice and service date:

- invoice `HAS_LINE` invoice line
- contract `HAS_TERM` contract line term
- contract line term `PRICES_ITEM` item when the term is itemized
- member `ELIGIBLE_FOR` contract
- supplier `PARTICIPATES_IN` contract

Future candidate retrieval can expand through additional graph edges:

- item cross-reference
- substitution
- category contract
- distributor authorization
- member hierarchy
- facility hierarchy

### 7.2 UOM Normalization

If the selected term is an itemized supply term, UOM is required. If invoice UOM equals contract UOM:

```text
normalized_invoice_unit_price = invoice_unit_price
```

If invoice UOM converts to contract UOM:

```text
normalized_invoice_unit_price = invoice_unit_price * conversion_factor
```

Example:

```text
Invoice: 0.95 per EA
Contract: 95.00 per CS
Conversion: 100 EA = 1 CS
Normalized: 0.95 * 100 = 95.00 per CS
```

If the selected term is a service charge term such as `SUBSCRIPTION`, `VARIABLE_RATE`, `OVERAGE`, `TIME_AND_MATERIALS`, or `EXCLUDED`, UOM can be optional. In that case the validator uses `UOM_NOT_REQUIRED_OR_CONVERTIBLE` rather than forcing a product-style conversion failure.

### 7.3 Candidate Score

The score is weighted:

```text
score =
  exact_item_weight     if item matched
+ eligibility_weight    if member eligible
+ date_weight           if date valid
+ uom_weight            if UOM convertible
+ price_weight * price_proximity
+ semantic_weight * semantic_similarity
+ category_weight       if category compatible
+ graph_weight * graph_support_score
```

Default policy:

| Feature | Weight |
|---|---:|
| exact item | 0.35 |
| member eligibility | 0.20 |
| date | 0.15 |
| UOM | 0.10 |
| price proximity | 0.10 |
| semantic similarity | 0.10 |
| category compatibility | policy controlled |
| graph support | 0.05 |

Graph support is calculated from expected ontology relationships. A fully supported candidate has graph support `1.0`; missing relationships reduce the graph contribution and are included in the candidate evidence.

### 7.4 Route Selection

```text
if cached active match exists:
    route = FAST_PATH
elif score >= deep_path_threshold:
    route = DEEP_PATH
else:
    route = MANUAL_REVIEW
```

High-confidence deep-path matches are stored in `match_cache`. When the same line signature appears again, it can use fast path.

## 8. Validation Algorithm

Each rule produces a `ValidationResult`. The current rule order is intentionally staged so data quality and candidate selection are checked before financial variance logic.

| Rule | Pass condition |
|---|---|
| `DATA_QUALITY_SUFFICIENT` | Source quality is trusted and parse confidence is above policy threshold. |
| `CONTRACT_FOUND` | A candidate contract term exists. |
| `CONTRACT_CANDIDATE_SELECTED` | Supplier/date contract selection produced a confident contract candidate. |
| `CHARGE_TERM_CANDIDATE_SELECTED` | A specific charge term was selected from the candidate contract set. |
| `ITEM_OR_SERVICE_TERM_MATCHED` | Either item IDs match or the service/charge-term semantic match exceeds threshold. |
| `CATEGORY_COMPATIBLE` | Invoice and contract category codes are equal, or one side is intentionally blank. |
| `MEMBER_ELIGIBLE` | Active `member_eligibility` covers `contract_id + member_id + service date`. |
| `AMENDMENT_VERSION_VALID` | Selected effective term covers the service date and amendment sequence. |
| `CHARGE_TERM_ALLOWED` | Contract term is not marked excluded or disallowed. |
| `UOM_NOT_REQUIRED_OR_CONVERTIBLE` | UOM converts for item terms, or UOM is optional for the selected service term. |
| `PRICE_WITHIN_TOLERANCE` | Normalized invoice unit price is within configured tolerance. |
| `QUANTITY_LIMIT_VALID` | Invoice quantity respects min/max contractual limits. |
| `FREQUENCY_ALLOWED` | Invoice billing frequency matches the contract charge-term frequency when specified. |
| `SUPPLIER_CONTACT_COMPLETE` | Supplier has dispute contact data when a dispute may need to be initiated. |

For `PRICE_WITHIN_TOLERANCE`, pass if:

```text
normalized_invoice_unit_price <= contract_unit_price * (1 + tolerance_pct)
```

Fail variance:

```text
(normalized_invoice_unit_price - contract_unit_price) * quantity
```

For production quantity and service volume controls, extend `QUANTITY_LIMIT_VALID` to apply:

- min order quantity
- max quantity
- annual commitment
- volume tier
- backorder aggregation

## 9. Findings Logic

Findings convert technical validation output into business outcomes. Exception cases and dispute drafts convert failed line outcomes into actionable workflow objects.

| Condition | Finding Type | Status |
|---|---|---|
| All rules pass | `COMPLIANT` | `PASS` |
| No contract candidate | `OFF_CONTRACT` | `FAIL` |
| Price rule fails | `PRICE_VARIANCE` | `FAIL` |
| Other high-severity rule fails | `VALIDATION_FAILURE` | `FAIL` |

For off-contract findings, the variance amount is the invoice line extended amount.

Exception cases are created for failed or ambiguous lines. Dispute drafts are created only when the exception is dispute-ready, has a supplier-facing amount, and supplier contact information is complete.

For price variance findings, the variance amount is the overcharge amount.

## 10. Demo Data Walkthrough

### 10.1 Contract

Contract:

```text
GPO-2026-001
Supplier: Medline Supply Co.
GPO: Vizient GPO
Effective: 2026-01-01 to 2026-12-31
```

### 10.2 Amendment

Amendment `AMD-001`, effective `2026-06-01`:

- Updates nitrile gloves from `$100.00 / CS` to `$95.00 / CS`
- Adds surgical masks at `$45.00 / BX`

### 10.3 Invoice

Invoice `INV-1001`, dated `2026-06-15`.

| Line | Item | Invoice | Expected Outcome |
|---|---|---|---|
| 1 | Gloves | 10 CS @ 95.00 | Pass; amendment price applied |
| 2 | Masks | 4 BX @ 48.00 | Fail; price variance: `(48 - 45) * 4 = 12` |
| 3 | Syringe | 25 EA @ 2.00 | Pass |
| 4 | Bandage | 8 EA @ 5.00 | Fail; off contract: `40` |
| 5 | Gloves | 100 EA @ 0.95 | Pass; UOM conversion to 1 CS @ 95.00 |

Expected invoice result:

```text
Status: FAIL
Pass lines: 3
Fail lines: 2
Total variance/leakage: 52.00
```

## 11. API Design

### 11.1 Local Demo API

Run:

```powershell
$env:PYTHONPATH = "src"
python serve_demo.py --reset --port 8008
```

Endpoints:

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | Health check |
| `GET` | `/ontology/nodes` | List graph nodes |
| `GET` | `/ontology/edges` | List graph edges |
| `POST` | `/reconcile` | Reconcile invoice |

Request:

```json
{
  "invoice_id": "INV-1001"
}
```

Response shape:

```json
{
  "run": {},
  "invoice": {},
  "final_status": "FAIL",
  "total_variance": 52.0,
  "lines": []
}
```

### 11.2 Production API

Recommended production endpoints:

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/reconcile` | Start sync or async reconciliation |
| `POST` | `/reconcile-batch` | Reconcile many invoices |
| `GET` | `/reconciliation-runs/{id}` | Run status |
| `GET` | `/reconciliation-runs/{id}/findings` | Findings for run |
| `GET` | `/invoice-lines/{id}/validations` | Rule-level details |
| `POST` | `/findings/{id}/override` | Analyst override |
| `GET` | `/ontology/entities/{id}` | Inspect ontology entity |
| `GET` | `/ontology/relationships` | Inspect graph relationships |

## 12. Databricks Production Mapping

### 12.1 Tables

Use `sql/databricks_lakehouse_schema.sql` as the single recommended Unity Catalog schema script for the production Medallion, Ontology, Gold, and Ops layout.

The production implementation should replace SQLite operations with SQL against Bronze/Silver/Ontology/Gold tables. Canonical domain entities should live primarily in Silver:

```text
platform_dev.pspa_bronze.contract_raw
platform_dev.pspa_bronze.invoice_raw
platform_dev.pspa_silver.party
platform_dev.pspa_silver.item
platform_dev.pspa_silver.contract
platform_dev.pspa_silver.contract_version
platform_dev.pspa_silver.contract_line_term
platform_dev.pspa_silver.effective_contract_line_term
platform_dev.pspa_silver.member_eligibility
platform_dev.pspa_silver.invoice
platform_dev.pspa_silver.invoice_line
platform_dev.pspa_ontology.node
platform_dev.pspa_ontology.edge
platform_dev.pspa_ontology.rule_catalog
platform_dev.pspa_ontology.matching_policy
platform_dev.pspa_ontology.match_cache
platform_dev.pspa_silver.reconciliation_run
platform_dev.pspa_silver.validation_result
platform_dev.pspa_silver.finding
platform_dev.pspa_ontology.audit_event
platform_dev.pspa_gold.invoice_line_compliance_fact
platform_dev.pspa_gold.exception_work_queue
```

### 12.2 Batch Execution

Recommended Databricks batch flow:

1. Upstream loads structured contracts/invoices.
2. Job materializes `effective_contract_line_term`.
3. Job reconciles open invoice batches.
4. Job writes validation results and findings.
5. Job refreshes Gold compliance facts and exception queue.

### 12.3 Interactive Execution

Recommended API/service flow:

1. API receives invoice ID or invoice payload.
2. API calls repository backed by Databricks SQL Warehouse.
3. Engine reconciles invoice.
4. API returns summary and run ID.
5. UI fetches findings and validations from Databricks.

## 13. Cache Design

Fast-path cache key:

```text
normalized_description | item_id | invoice_uom | unit_price
```

Cache value:

- Contract ID
- Contract version ID
- Contract line ID
- Candidate score/evidence
- Validators to run, in a production extension
- Status
- Hit count
- Invalidation reason

Invalidation triggers:

- Contract updated
- Amendment added/changed
- Item cross-reference changed
- UOM conversion changed
- Member eligibility changed
- Matching policy changed

## 14. Audit Design

Audit events should be written for:

- Data load
- Reconciliation started
- Line reconciled
- Reconciliation completed
- Finding override
- Rule version change
- Matching policy change
- Cache invalidation
- Semantic/LLM fallback decision, if enabled

Each audit row should include:

- Event type
- Entity type and ID
- Reconciliation run ID
- Actor
- Timestamp
- Previous/new values for user changes
- Trace ID/request ID

## 15. Error Handling

| Error | Handling |
|---|---|
| Invoice not found | Return 404 / fail run before processing |
| Missing invoice lines | Fail run with validation error |
| No contract candidate | Create off-contract finding |
| Missing UOM conversion | Fail `UOM_NOT_REQUIRED_OR_CONVERTIBLE` for itemized terms; allow UOM absence only for eligible service terms |
| Missing member eligibility | Fail `MEMBER_ELIGIBLE` |
| Conflicting amendments | Create amendment conflict finding |
| Databricks SQL timeout | Retry with backoff; mark run recoverable if still failing |
| Duplicate request | Use idempotency key in production |

## 16. Observability Design

Production metrics:

| Metric | Description |
|---|---|
| `reconciliation.duration_ms` | Runtime per invoice or batch |
| `reconciliation.lines_processed` | Number of lines processed |
| `reconciliation.fast_path_count` | Cached route count |
| `reconciliation.deep_path_count` | Scored route count |
| `reconciliation.manual_review_count` | Exception route count |
| `validation.rule_fail_count` | Failures by rule |
| `variance.price_amount` | Price overcharge amount |
| `variance.off_contract_amount` | Off-contract spend |
| `cache.hit_rate` | Fast-path cache efficiency |
| `api.error_count` | API failures by type |

## 17. Testing Strategy

Current tests:

| Test | Purpose |
|---|---|
| `test_seed_creates_graph` | Validates ontology graph seed |
| `test_reconciliation_outputs_expected_findings` | Validates pass/fail/variance results |
| `test_second_run_uses_fast_path_cache` | Validates cache behavior |

Production test additions:

- Databricks SQL integration tests
- Amendment overlap tests
- Member hierarchy tests
- Item substitution tests
- UOM conversion edge cases
- High-volume batch tests
- API security tests
- Idempotency tests
- Cache invalidation tests

## 18. Deployment Checklist

1. Create Unity Catalog catalog/schema.
2. Run `sql/databricks_lakehouse_schema.sql`.
3. Load structured contract and invoice data.
4. Implement full `DatabricksOntologyRepository`.
5. Configure API/service credentials.
6. Configure job/workflow for batch reconciliation.
7. Configure audit retention and table permissions.
8. Add dashboards over Gold tables.
9. Add exception workflow for analysts.
10. Run load and regression tests.

## 19. Design Decisions

| Decision | Rationale |
|---|---|
| Structured input only | User confirmed parsing/ingestion is out of scope |
| Repository abstraction | Allows local demo and Databricks production backend |
| Deterministic validators | Required for financial auditability |
| Ontology graph | Handles relationships, amendments, eligibility, item mapping, evidence |
| Persistent validation rows | Enables explainability and analytics |
| Fast-path cache | Improves repeated line-pattern performance |
| Semantic/LLM fallback as extension | Avoids nondeterministic core financial controls |

## 20. Future Enhancements

- Full Databricks repository implementation.
- AI Search for semantic item/term candidate retrieval.
- Rule DSL or visual rule editor.
- Analyst review UI.
- Override workflow with approval chain.
- Gold leakage summary tables.
- Delta Change Data Feed based cache invalidation.
- Multi-tenant support.
- Prompt/model audit for LLM-assisted ambiguity resolution.
