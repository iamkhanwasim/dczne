# Medallion + Ontology Architecture

## 1. Short Answer

The production solution should use **both**:

1. **Medallion Delta architecture** for data engineering and governed data quality.
2. **Ontology / graph semantic layer** for business meaning, relationships, matching, validation, and application serving.

The runnable demo currently focuses on the ontology/reconciliation engine. For production Databricks, the design should be organized as:

```text
Bronze -> Silver -> Gold -> Ontology/API serving
                  \-> Ontology graph used by reconciliation
```

Important nuance: the ontology should not be only a thin layer over Gold. For this use case, the ontology must also sit over curated **Silver** domain entities because reconciliation needs contract, item, member, amendment, and eligibility relationships before Gold outputs exist. Gold then stores the business-ready reconciliation results.

## 2. Recommended Layering

```mermaid
flowchart TD
    A["Upstream Structured Contract / Invoice Data"] --> B["Bronze Delta Tables"]
    B --> C["Silver Conformed Delta Tables"]
    C --> D["Ontology Graph and Semantic Layer"]
    D --> E["Reconciliation Engine"]
    E --> F["Silver Validation Detail"]
    F --> G["Gold Business Facts"]
    C --> G
    G --> H["Ontology Serving Objects"]
    D --> H
    H --> I["API / App / BI / Exception Workflow"]
```

## 3. What Each Layer Does

| Layer | Purpose | Example Tables |
|---|---|---|
| Bronze | Immutable raw structured data as received from upstream systems | `bronze.contract_raw`, `bronze.contract_line_raw`, `bronze.invoice_raw`, `bronze.invoice_line_raw` |
| Silver | Cleaned, normalized, deduplicated, conformed domain entities | `silver.contract`, `silver.contract_version`, `silver.contract_line_term`, `silver.effective_contract_line_term`, `silver.invoice`, `silver.invoice_line`, `silver.party`, `silver.item` |
| Ontology | Semantic graph and business relationships over curated entities | `ontology.node`, `ontology.edge`, `ontology.triple`, `ontology.rule_catalog`, `ontology.matching_policy` |
| Silver validation | Detailed rule execution output, still granular and auditable | `silver.validation_result`, `silver.reconciliation_run`, `silver.finding` |
| Gold | Business-ready facts, summaries, and exception queues | `gold.invoice_line_compliance_fact`, `gold.invoice_compliance_summary`, `gold.contract_leakage_summary`, `gold.exception_work_queue` |
| Ontology serving | Application-facing object model over Silver + Gold | Contract object, Invoice object, Finding object, Exception object, relationship APIs |

## 4. Why Ontology Should Not Be Only On Gold

Gold tables are usually aggregated or business-serving outputs. They are excellent for dashboards, exception queues, and AP/finance workflows.

However, reconciliation requires reasoning over data that exists before Gold is produced:

- Which contract version is effective?
- Which amendment supersedes which term?
- Which member or facility is eligible?
- Which item maps to which manufacturer/distributor/customer identifier?
- Is a substitute item authorized?
- Is UOM conversion valid?
- Which graph path explains the match?

Those are **Silver + ontology graph** questions. If the ontology only sits on Gold, it can explain final results, but it cannot drive the matching and validation process cleanly.

The best pattern is:

```text
Silver = trusted business entities
Ontology = semantic relationships and graph over trusted entities
Gold = business results produced by reconciliation
Ontology serving = application object layer exposing both entities and results
```

## 5. Bronze Layer Design

Bronze stores structured source payloads with minimal transformation.

| Table | Grain | Purpose |
|---|---|---|
| `bronze.contract_raw` | One contract/amendment document or payload | Preserve upstream contract header payload |
| `bronze.contract_line_raw` | One source contract line | Preserve raw source line fields |
| `bronze.invoice_raw` | One invoice header payload | Preserve upstream invoice header |
| `bronze.invoice_line_raw` | One source invoice line | Preserve raw source line fields |

Bronze should include:

- Source system
- Source file/message ID
- Source record ID
- Ingest timestamp
- Batch ID
- Raw payload JSON
- Schema version
- Load status

## 6. Silver Layer Design

Silver converts raw source records into conformed canonical entities.

| Silver Table | Purpose |
|---|---|
| `silver.party` | GPO, supplier, manufacturer, distributor, member, facility |
| `silver.party_relationship` | Member hierarchy, facility ownership, distributor authorization |
| `silver.item` | Canonical item/product/service |
| `silver.item_cross_reference` | Manufacturer, supplier, distributor, customer SKU mapping |
| `silver.uom_conversion` | UOM and pack-size normalization |
| `silver.contract` | Contract header |
| `silver.contract_version` | Base contract and amendment version events |
| `silver.contract_line_term` | Raw contractual terms by version |
| `silver.effective_contract_line_term` | Final effective terms after amendment resolution |
| `silver.member_eligibility` | Member/facility contract eligibility and tier |
| `silver.invoice` | Invoice header |
| `silver.invoice_line` | Invoice line |
| `silver.reconciliation_run` | Reconciliation execution metadata |
| `silver.validation_result` | One validation rule result per invoice line |
| `silver.finding` | Detailed findings per invoice line |

## 7. Ontology Layer Design

The ontology layer is a graph/semantic layer over Silver entities and Gold results.

| Ontology Table | Purpose |
|---|---|
| `ontology.node` | Registers every semantic object, such as contract, invoice, party, item, finding |
| `ontology.edge` | Stores relationships like `ELIGIBLE_FOR`, `HAS_TERM`, `PRICES_ITEM`, `MATCHED_TO` |
| `ontology.triple` | Optional RDF-style flexible assertions |
| `ontology.rule_catalog` | Rule metadata, severity, version, parameters |
| `ontology.matching_policy` | Matching weights and thresholds |
| `ontology.match_cache` | Fast-path cache linked to contract version and line signature |
| `ontology.entity_binding` | Maps ontology objects to physical Silver/Gold table rows |

Example ontology edges:

| From | Relationship | To |
|---|---|---|
| Supplier | `PARTICIPATES_IN` | Contract |
| GPO | `GOVERNS` | Contract |
| Contract | `HAS_VERSION` | Contract version |
| Contract version | `HAS_TERM` | Contract line term |
| Contract line term | `PRICES_ITEM` | Item |
| Member | `ELIGIBLE_FOR` | Contract |
| Invoice | `HAS_LINE` | Invoice line |
| Invoice line | `MATCHED_TO` | Contract line term |
| Finding | `SUPPORTED_BY` | Validation result |

## 8. Gold Layer Design

Gold stores business-ready outputs.

| Gold Table | Purpose |
|---|---|
| `gold.invoice_line_compliance_fact` | One row per invoice line with final status, matched contract, variance |
| `gold.invoice_compliance_summary` | One row per invoice with pass/fail counts and total variance |
| `gold.contract_leakage_summary` | Spend leakage by supplier, member, contract, category, period |
| `gold.exception_work_queue` | Analyst-facing queue for failed or ambiguous lines |
| `gold.supplier_scorecard` | Supplier compliance and leakage metrics |
| `gold.member_savings_opportunity` | Member-level recovery and savings opportunities |

Gold is where reporting, finance workflows, and exception management should primarily read from.

## 9. Reconciliation Flow With Medallion

```mermaid
sequenceDiagram
    participant B as Bronze
    participant S as Silver
    participant O as Ontology
    participant R as Reconciliation Engine
    participant G as Gold
    participant A as App/API

    B->>S: Normalize raw structured contract/invoice records
    S->>S: Resolve amendments into effective contract terms
    S->>O: Build nodes and edges over curated entities
    O->>R: Provide graph-based candidate relationships
    S->>R: Provide invoice lines and effective terms
    R->>S: Persist validation results and detailed findings
    R->>O: Persist MATCHED_TO and SUPPORTED_BY relationships
    S->>G: Aggregate compliance facts and exception queue
    O->>A: Serve semantic object relationships
    G->>A: Serve business-ready results
```

## 10. How This Changes The Current Demo Repo

The current demo repo is intentionally compact:

- It has local SQLite tables that combine Silver, ontology, and result concepts.
- It has Databricks DDL for `ontology` and `gold`.
- It proves the reconciliation algorithm and ontology graph behavior.

For production, split those concepts into explicit medallion schemas:

| Current Demo Concept | Production Placement |
|---|---|
| `party`, `item`, `contract`, `invoice` | `silver.*` |
| `effective_contract_line_term` | `silver.effective_contract_line_term` |
| `node`, `edge`, `triple` | `ontology.*` |
| `rule_catalog`, `matching_policy`, `match_cache` | `ontology.*` |
| `validation_result`, `finding`, `reconciliation_run` | `silver.*`, with ontology links |
| final line status and variance | `gold.invoice_line_compliance_fact` |
| exceptions | `gold.exception_work_queue` |

## 11. Final Recommendation

Use this target stack:

```text
Bronze:
  raw structured contract/invoice payloads

Silver:
  normalized contract, amendment, item, party, eligibility, invoice, validation detail

Ontology:
  graph nodes/edges, semantic relationships, rule catalog, matching policy, cache

Gold:
  compliance facts, leakage summaries, exception work queue

Serving Ontology/API:
  business object layer over Silver + Ontology + Gold
```

This gives the benefits of the medallion architecture without losing the graph/ontology reasoning needed for contract-invoice reconciliation.
