# Solution Architecture: Databricks Ontology Reconciliation Engine

## 1. Purpose

This solution reconciles structured supplier invoice lines against structured GPO/supply-chain contract data. It validates whether each invoice line is contract-compliant, identifies price leakage and off-contract spend, and produces explainable findings with an audit trail.

The system assumes that contract and invoice data has already been parsed and structured by an upstream process. This repo intentionally does not perform PDF/image ingestion, OCR, or document extraction.

## 2. Business Problem

In supply chain and GPO environments, invoice validation is difficult because contract terms are not just flat prices. A correct validation often depends on:

- Which member, facility, supplier, distributor, GPO, and manufacturer are involved.
- Which contract version or amendment is effective on the invoice/service date.
- Whether the invoiced item maps to a manufacturer item, distributor SKU, customer item, substitute item, or category.
- Whether the member is eligible for the contract and tier.
- Whether UOM and pack-size conversion is valid.
- Whether pricing, rebates, admin fees, taxes, freight, and quantity rules apply.

A simple relational join can validate easy cases, but it becomes brittle when amendments, hierarchies, substitutions, aliases, and evidence are involved. The ontology layer solves this by making domain objects and relationships explicit.

## 3. Target Architecture

The production architecture is a **Medallion Delta architecture with an ontology graph layer**. Bronze, Silver, and Gold handle data quality and serving maturity. The ontology layer adds semantic meaning and relationships over those curated tables.

```text
Bronze -> Silver -> Ontology graph/reconciliation -> Gold -> Ontology serving/API
```

The ontology is not a replacement for Bronze/Silver/Gold. It is the semantic layer that helps the engine understand how contracts, amendments, parties, items, eligibility, invoices, validations, and findings relate to one another.

```mermaid
flowchart LR
    A["Structured Contract Data"] --> B["Bronze Raw Delta"]
    C["Structured Invoice Data"] --> B
    B --> D["Silver Conformed Entities"]
    D --> E["Effective Contract Terms"]
    D --> F["Ontology Graph: Nodes and Edges"]
    E --> G["Graph Repository"]
    F --> G
    G --> H["Candidate Retrieval"]
    H --> I["Matching Policy and Score"]
    I --> J["Routing: Fast Path / Deep Path / Manual Review"]
    J --> K["Validator Registry"]
    K --> L["Silver Validation Results and Findings"]
    L --> M["Gold Compliance Facts / Exception Queue"]
    F --> N["Ontology Serving Layer"]
    M --> N
    N --> O["API, App, BI, Audit"]
```

For a deeper explanation of this layering, see [Medallion + Ontology Architecture](MEDALLION_ONTOLOGY_ARCHITECTURE.md).

## 4. Runtime Modes

| Mode | Backend | Purpose |
|---|---|---|
| Local demo | SQLite | Fully runnable local demo, tests, and developer validation |
| Production | Databricks Delta + Unity Catalog | Governed storage, scalable reconciliation jobs, lineage, security, serving |
| API/service | FastAPI or Databricks App | Interactive reconciliation, findings, override workflow |

The algorithm does not depend directly on SQLite or Databricks. It depends on the `OntologyRepository` interface. This keeps the business logic portable.

## 5. Major Components

| Component | Code Location | Responsibility |
|---|---|---|
| Domain models | `src/ontology_reconciliation/models.py` | Defines parties, items, contracts, invoice lines, graph nodes, matches, validations, findings |
| Repository interface | `src/ontology_reconciliation/repository.py` | Storage contract used by the engine |
| SQLite repository | `src/ontology_reconciliation/sqlite_repository.py` | Local working backend for demo and tests |
| Databricks adapter | `src/ontology_reconciliation/databricks_repository.py` | Production connection boundary for Databricks SQL |
| Seed data | `src/ontology_reconciliation/seed_data.py` | Demo contract, amendment, eligibility, UOM conversion, invoice |
| Matching | `src/ontology_reconciliation/matching.py` | Candidate retrieval, UOM normalization, scoring, route selection |
| Validators | `src/ontology_reconciliation/validators.py` | Deterministic rule-level validation |
| Findings | `src/ontology_reconciliation/findings.py` | Converts validations into user-facing findings |
| Engine | `src/ontology_reconciliation/engine.py` | Orchestrates end-to-end reconciliation |
| CLI | `src/ontology_reconciliation/cli.py` | Runs the local demo |
| API | `src/ontology_reconciliation/api.py` | Lightweight demo HTTP API |
| Databricks schema | `sql/databricks_lakehouse_schema.sql` | Unified Delta table definitions for Bronze, Silver, Ontology, Gold, Ops, and Price Assurance extensions |

## 6. What Is The Ontology Layer?

The ontology layer is the domain model represented as governed entities and relationships.

In this solution, the ontology has two complementary forms:

1. **Typed entity tables**

   These are strongly modeled business objects such as:

   - `party`
   - `item`
   - `contract`
   - `contract_version`
   - `contract_line_term`
   - `effective_contract_line_term`
   - `member_eligibility`
   - `invoice`
   - `invoice_line`
   - `validation_result`
   - `finding`

2. **Graph nodes and edges**

   These represent relationships between business objects:

   - GPO `GOVERNS` contract
   - Supplier `PARTICIPATES_IN` contract
   - Contract `HAS_TERM` contract line
   - Contract line `PRICES_ITEM` item
   - Member `ELIGIBLE_FOR` contract
   - Invoice `HAS_LINE` invoice line
   - Invoice line `MATCHED_TO` contract line, in a production extension

## 7. Why Ontology Helps

| Challenge | Without Ontology | With Ontology |
|---|---|---|
| Amendments | Hard-coded joins and date logic scattered across code | Contract versions and amendment edges make precedence explicit |
| Member eligibility | Separate lookup logic for each use case | Member, facility, and eligibility relationships are queryable |
| Item matching | Fragile SKU joins | Item, SKU, substitution, category, and cross-reference relationships can coexist |
| UOM conversion | One-off conversion rules | UOM conversion becomes a governed ontology fact |
| Evidence and audit | Results are hard to explain | Every result can cite nodes, edges, terms, rules, and source evidence |
| Rule evolution | Policy embedded in code | Rule catalog and matching policy can be versioned |
| Analytics | Output only shows final pass/fail | Gold facts can explain leakage by contract, supplier, member, category, rule |

The ontology turns reconciliation from a set of ad hoc joins into graph-guided reasoning over contract, invoice, item, party, and rule relationships.

## 8. Data Flow

```mermaid
sequenceDiagram
    participant U as Upstream Structured Data
    participant O as Ontology Tables
    participant G as Graph Repository
    participant M as Matching Engine
    participant V as Validators
    participant F as Finding Generator
    participant S as Serving Layer

    U->>O: Load contracts, amendments, invoice headers, invoice lines
    O->>O: Build effective contract line terms
    O->>G: Create/update graph nodes and edges
    G->>M: Retrieve candidates for each invoice line
    M->>M: Score candidate terms and choose route
    M->>V: Send selected match and invoice line
    V->>O: Persist rule-level validation results
    V->>F: Send validation outcomes
    F->>O: Persist findings and audit events
    O->>S: Publish compliance facts and exception queue
```

## 9. Reconciliation Flow

For each invoice:

1. Create a `reconciliation_run`.
2. Load invoice header and invoice lines.
3. For each line:
   - Retrieve active contract terms for supplier, item, and service date.
   - Check member eligibility.
   - Normalize invoice UOM to contract UOM.
   - Score candidate terms using matching policy.
   - Select route: fast path, deep path, or manual review.
   - Run deterministic validators.
   - Persist `validation_result` rows.
   - Generate and persist a `finding`.
   - Add audit events.
4. Aggregate line results into invoice-level status.
5. Persist final `reconciliation_run` metrics.
6. Publish results to Gold/serving tables.

## 10. Matching Strategy

The matching score combines multiple facts:

| Match Feature | Meaning |
|---|---|
| Exact item match | Invoice item maps to contract item |
| Eligibility | Invoice member is eligible for the contract |
| Date validity | Invoice/service date is inside the effective term interval |
| UOM compatibility | Invoice UOM equals or converts to contract UOM |
| Price proximity | Invoice price is close to contract price |
| Semantic similarity | Description resembles contract term/item description |

Current demo weights live in `MatchingPolicy`:

| Feature | Default Weight |
|---|---:|
| Exact item | 0.35 |
| Eligibility | 0.20 |
| Date | 0.15 |
| UOM | 0.10 |
| Price | 0.10 |
| Semantic | 0.10 |

In production, these weights should be stored in `ontology.matching_policy` so they can be tuned without code changes.

## 11. Routing Strategy

| Route | When Used | Behavior |
|---|---|---|
| Fast path | A line pattern has a high-confidence cached match | Skip expensive matching and reuse known contract line |
| Deep path | Candidate exists but needs scoring | Use graph facts, scoring, and optional semantic search |
| Manual review | No candidate or low confidence | Create exception/finding for analyst review |

The demo shows fast path on the second run when `--twice` is used.

## 12. Validation Rules

Every invoice line receives rule-level validation results.

| Rule | Purpose |
|---|---|
| `DATA_QUALITY_SUFFICIENT` | Source quality and parse confidence are sufficient for financial validation |
| `CONTRACT_FOUND` | Active contract line exists |
| `CONTRACT_CANDIDATE_SELECTED` | Contract-level candidate selection is explainable and above threshold |
| `CHARGE_TERM_CANDIDATE_SELECTED` | A specific contract charge term is selected |
| `ITEM_OR_SERVICE_TERM_MATCHED` | Invoice line maps to either an itemized supply term or a service charge term |
| `CATEGORY_COMPATIBLE` | Invoice and contract categories are compatible |
| `MEMBER_ELIGIBLE` | Member/facility is eligible |
| `AMENDMENT_VERSION_VALID` | Correct effective contract version/amendment is applied |
| `CHARGE_TERM_ALLOWED` | Selected charge term is allowed and not excluded |
| `UOM_NOT_REQUIRED_OR_CONVERTIBLE` | UOM converts for itemized terms or is optional for eligible service terms |
| `PRICE_WITHIN_TOLERANCE` | Invoice price is not above contract price plus tolerance |
| `QUANTITY_LIMIT_VALID` | Quantity is within contractual bounds |
| `FREQUENCY_ALLOWED` | Billing frequency is compatible with the contract term |
| `SUPPLIER_CONTACT_COMPLETE` | Supplier contact is complete when dispute workflow is needed |

Each validation result stores:

- Rule code
- Pass/fail/skip status
- Severity
- Expected value
- Actual value
- Variance amount
- Matched contract information
- Evidence JSON

## 13. Amendment Handling

Amendments are modeled as contract versions.

```mermaid
flowchart TD
    A["Base Contract"] --> B["Contract Version: BASE"]
    B --> C["Base Contract Line Terms"]
    A --> D["Contract Version: AMENDMENT AMD-001"]
    D --> E["Updated / Added / Terminated Terms"]
    C --> F["Effective Contract Line Terms"]
    E --> F
    F --> G["Invoice Line Matching"]
```

The demo has:

- Base contract price for nitrile gloves: `$100.00 / CS`
- Amendment effective `2026-06-01`: updated glove price to `$95.00 / CS`
- Invoice dated `2026-06-15`
- Result: invoice line matches the amended term, not the base term

## 14. Databricks Production View

In Databricks, the same model should be implemented as Delta tables under Unity Catalog:

```mermaid
flowchart LR
    A["Unity Catalog"] --> B["bronze schema"]
    A --> C["silver schema"]
    A --> D["ontology schema"]
    A --> E["gold schema"]
    B --> F["Raw Structured Payloads"]
    C --> G["Conformed Domain Entities"]
    C --> H["Validation Detail"]
    D --> I["Nodes, Edges, Rules, Policies"]
    E --> J["Compliance Facts and Exceptions"]
```

Recommended schemas:

| Schema | Purpose |
|---|---|
| `bronze` | Raw structured contract/invoice payloads from upstream systems |
| `silver` | Cleaned and conformed domain entities plus detailed validation outputs |
| `ontology` | Entity, graph, rule, policy, cache, validation, audit tables |
| `gold` | Business-serving compliance and exception facts |
| `ops` | Metrics, run health, operational monitoring |

In the refined production design, `ontology` should not own every table. Canonical entities such as `contract`, `invoice`, and `item` belong in `silver`; graph relationships, rule metadata, matching policy, and semantic bindings belong in `ontology`; business facts and exception queues belong in `gold`.

## 15. API Surface

Minimum production API:

| Endpoint | Purpose |
|---|---|
| `POST /reconcile` | Reconcile one invoice or invoice batch |
| `GET /reconciliation-runs/{id}` | Run status and summary |
| `GET /invoices/{id}/findings` | Line-level findings |
| `GET /invoice-lines/{id}/validations` | Rule-level results |
| `GET /ontology/nodes/{id}` | Inspect ontology object |
| `GET /ontology/edges?entity_id=...` | Inspect graph relationships |
| `POST /findings/{id}/override` | Analyst override with audit event |

The local demo provides:

- `GET /health`
- `GET /ontology/nodes`
- `GET /ontology/edges`
- `POST /reconcile`

## 16. Security And Governance

For production:

- Use Unity Catalog permissions for table-level governance.
- Use service principals or OAuth for API-to-Databricks access.
- Log every reconciliation request and analyst override.
- Store audit events in immutable or append-only form.
- Restrict rule and matching policy changes to authorized users.
- Track rule versions used for each run.

## 17. Observability

Recommended metrics:

- Reconciliation latency
- Lines processed per run
- Fast path vs deep path ratio
- Manual review rate
- Rule failure counts
- Price variance total
- Off-contract spend total
- Cache hit/miss rate
- Databricks job failures
- API errors and retries

## 18. Production Extension Points

| Extension | Where It Fits |
|---|---|
| Databricks AI Search | Semantic candidate retrieval for weak item descriptions |
| LLM adjudication | Only for ambiguous deep-path cases, never for deterministic price math |
| Rule DSL | Future rule authoring when rule count grows |
| Analyst UI | Gold exception queue and finding override workflow |
| ERP/AP integration | Export approved/rejected findings and recovery opportunities |

## 19. Current Demo Limitations

The repo is functional and production-shaped, but the local demo intentionally keeps scope small:

- SQLite is used only for local execution.
- The Databricks repository class is a connector boundary, not a full implementation of all repository methods.
- No external authentication is included in the lightweight standard-library API.
- No PDF/image parsing is included because structured input is assumed.
- Semantic/vector search is represented as an extension point, not enabled by default.

## 20. Summary

The solution combines:

- Databricks for governed storage and scalable execution.
- An ontology layer for explicit domain relationships.
- Graph-guided matching for complex contract/invoice relationships.
- Deterministic validation for auditability.
- Persistent findings, audit, and cache for production readiness.

This approach gives a working local demo today and a clear path to Databricks-backed production deployment.
