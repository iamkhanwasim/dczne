# Solution Schematic And C4 Architecture Diagrams

## 1. Purpose

This document provides a diagram pack for the Contract Reconciliation Lakehouse solution. It is based on the current production-grade reference application, including:

- Databricks Lakehouse backend with Unity Catalog catalog `platform_dev`.
- Medallion schemas: `pspa_bronze`, `pspa_silver`, `pspa_ontology`, `pspa_gold`, and `pspa_ops`.
- Ontology-based graph model using `node` and `edge`.
- Graph-aware and service-aware invoice-line matching and validation.
- OOUX Board 15 charge-term logic for service lines, category compatibility, billing frequency, UOM-optional terms, source quality, exception cases, and dispute drafts.
- Local SQLite demo backend and production Databricks SQL backend.
- FastAPI, CLI, reconciliation service, matching engine, validation engine, repository abstraction, and Gold outputs.

The diagrams use Mermaid syntax so they can be rendered in Markdown tools, Confluence, GitHub-compatible viewers, draw.io Mermaid import, or documentation pipelines.

## 2. Scope And Assumptions

| Area | Assumption |
|---|---|
| Input data | Contract, amendment, invoice, item, party, eligibility, and UOM data is already parsed and structured. |
| Ingestion | No PDF/image ingestion pipeline is included in the runtime design. Structured payload loading can be handled separately. |
| Backend | Production backend is Databricks SQL over Delta tables in Unity Catalog. |
| Demo backend | SQLite mirrors the ontology repository contract for local demos and tests. |
| Ontology | Ontology entities and graph relationships are built from trusted Silver entities and stored in the Ontology schema. |
| Reconciliation | Matching and validation use Silver entities, Ontology policies, cache, graph edges, charge-term taxonomy, source-quality gates, and rule catalog. |
| AI/LLM | AI is optional and advisory only. Deterministic rules remain the financial decision boundary. |

## 3. Solution Schematic Architecture

```mermaid
flowchart LR
    subgraph Users["Business And Technical Users"]
        AP["AP Analyst"]
        PA["Price Assurance Analyst"]
        CM["Contract Manager"]
        DE["Data Engineer"]
        GOV["Data Governance / Security"]
    end

    subgraph Sources["Structured Source Data"]
        ERP["ERP / AP Invoice Data"]
        CLM["Contract Lifecycle / GPO Data"]
        MDM["Item Master / Supplier Master"]
        ELIG["Member Eligibility / Roster"]
    end

    subgraph Databricks["Databricks Lakehouse - Unity Catalog platform_dev"]
        Bronze["pspa_bronze<br/>Raw structured payloads<br/>lineage and replay"]
        Silver["pspa_silver<br/>Conformed entities<br/>effective contract terms"]
        Ontology["pspa_ontology<br/>semantic entities, graph, rules,<br/>matching policy, cache, evidence,<br/>exception cases, dispute drafts, audit"]
        Gold["pspa_gold<br/>business-ready facts,<br/>summaries, disputes, recoveries"]
        Ops["pspa_ops<br/>workflow logs, metrics, SLA tracking"]
    end

    subgraph Runtime["Contract Reconciliation Application Runtime"]
        API["FastAPI Service<br/>serve_demo.py"]
        CLI["CLI / Batch Runner<br/>run_demo.py"]
        Service["ReconciliationService<br/>workflows/service.py"]
        Engine["ReconciliationEngine<br/>ontology/engine.py"]
        Matching["Service-Aware Graph Matching Engine<br/>matching/matching.py"]
        Validation["OOUX-Aware Validation Engine<br/>validation/validators.py"]
        Findings["Findings / Exception / Dispute Builder<br/>ontology/findings.py"]
        ExceptionCases["Exception Case Persistence<br/>ExceptionCase ontology entity"]
        DisputeDrafts["Dispute Draft Persistence<br/>Dispute, DisputeLine, DisputeMessage"]
        Repo["OntologyRepository Interface<br/>ontology/repository.py"]
    end

    subgraph StorageAdapters["Repository Implementations"]
        SQLite["SQLite Demo Repository<br/>ontology/sqlite_repository.py"]
        DBSQL["Databricks SQL Repository<br/>ontology/databricks_repository.py"]
    end

    subgraph Consumption["Consumption And Actions"]
        BI["Dashboards / BI"]
        Queue["Analyst Exception Queue"]
        APIConsumers["Downstream API Consumers"]
        Recovery["Dispute Draft / Recovery Workflow"]
    end

    subgraph AI["Optional AI / GenAI Assist"]
        Embeddings["Semantic Retrieval / Embeddings"]
        LLM["LLM Explanations / Recommendations"]
    end

    Sources --> Bronze
    Bronze --> Silver
    Silver --> Ontology
    Silver --> Engine
    Ontology --> Engine
    Engine --> Ontology
    Engine --> Gold
    Engine --> Ops

    API --> Service
    CLI --> Service
    Service --> Engine
    Engine --> Matching
    Engine --> Validation
    Engine --> Findings
    Engine --> ExceptionCases
    Engine --> DisputeDrafts
    Matching --> Repo
    Validation --> Repo
    Findings --> Repo
    ExceptionCases --> Repo
    DisputeDrafts --> Repo
    Engine --> Repo
    Repo --> SQLite
    Repo --> DBSQL
    DBSQL --> Databricks
    SQLite -. local demo .-> Runtime

    Gold --> BI
    Gold --> Queue
    Gold --> Recovery
    API --> APIConsumers
    AP --> Queue
    PA --> BI
    CM --> BI
    DE --> Ops
    GOV --> Databricks

    Ontology --> Embeddings
    Gold --> Embeddings
    Embeddings --> LLM
    LLM -. advisory only .-> Queue
```

## 4. C1 System Context Diagram

The C1 view shows the reconciliation application as one system and highlights the people, external systems, and platform services around it.

```mermaid
flowchart TB
    subgraph People["People"]
        AP["AP Analyst<br/>Reviews failed invoice lines"]
        PA["Price Assurance Analyst<br/>Tracks leakage and recovery"]
        CM["Contract Manager<br/>Reviews amendment and term issues"]
        DE["Data Engineer<br/>Operates jobs, tables, and deployments"]
        GOV["Governance / Security<br/>Approves access and controls"]
    end

    subgraph External["External Enterprise Systems"]
        ERP["ERP / AP System<br/>Invoices and payment context"]
        CLM["CLM / GPO Platform<br/>Contracts, amendments, tiers"]
        MDM["MDM / Item Master<br/>items, suppliers, UOM"]
        ELIG["Eligibility Source<br/>members, facilities, roster"]
        IDP["Identity Provider<br/>SSO / groups"]
    end

    App["Contract Reconciliation Lakehouse Application<br/>Matches invoice lines to contract terms,<br/>validates rules, stores evidence, publishes outcomes"]

    subgraph Platform["Databricks Platform"]
        UC["Unity Catalog<br/>governance, grants, lineage"]
        Delta["Delta Lake Tables<br/>Bronze, Silver, Ontology, Gold, Ops"]
        DBSQL["Databricks SQL Warehouse<br/>runtime query backend"]
        Jobs["Databricks Workflows / Jobs<br/>scheduled processing"]
    end

    subgraph Consumers["Output Consumers"]
        BI["Dashboards / Scorecards"]
        Queue["Analyst Exception Queue"]
        Downstream["Downstream Finance / Recovery Systems"]
        OptionalAI["Optional AI Assistant<br/>explanations and recommendations"]
    end

    ERP --> App
    CLM --> App
    MDM --> App
    ELIG --> App
    App --> Delta
    App --> DBSQL
    App --> Jobs
    UC --> Delta
    IDP --> UC

    AP --> App
    PA --> App
    CM --> App
    DE --> App
    GOV --> UC

    App --> BI
    App --> Queue
    App --> Downstream
    App --> OptionalAI
    OptionalAI -. approved evidence only .-> App
```

## 5. C2 Container Diagram

The C2 view decomposes the application into deployable/runtime containers and primary data stores.

```mermaid
flowchart LR
    subgraph ClientSide["Users And Clients"]
        Browser["Browser / API Client"]
        Scheduler["Batch Scheduler / Databricks Workflow"]
        CLIUser["Developer / Demo CLI"]
    end

    subgraph App["Contract Reconciliation Application"]
        FastAPI["API Container<br/>FastAPI endpoints<br/>health, reconcile, graph,<br/>findings, exceptions, disputes, metrics"]
        CLI["CLI Container<br/>local demo and batch execution"]
        Service["Application Service<br/>request orchestration and response shaping"]
        Engine["Reconciliation Engine<br/>run lifecycle, line loop, persistence"]
        Match["Matching Engine<br/>candidate retrieval, service fallback,<br/>graph scoring, cache"]
        Rules["Validation Engine<br/>14 deterministic OOUX-aware checks"]
        Findings["Findings / Exception Component<br/>line-level outcome generation"]
        Disputes["Dispute Draft Component<br/>supplier-contact gated drafts"]
        Schemas["Response Schema Mapper<br/>API payload shaping"]
    end

    subgraph Repository["Repository Boundary"]
        RepoInterface["OntologyRepository<br/>storage contract"]
        SQLiteRepo["SQLite Repository<br/>local runnable demo"]
        DatabricksRepo["Databricks Repository<br/>production SQL adapter"]
        DBSQLClient["Databricks SQL Client"]
    end

    subgraph DataStores["Data Stores"]
        SQLiteDB["SQLite DB<br/>data/*.db"]
        Bronze["Delta: platform_dev.pspa_bronze"]
        Silver["Delta: platform_dev.pspa_silver"]
        Ontology["Delta: platform_dev.pspa_ontology<br/>node, edge, rules, policy, cache,<br/>runs, validation, findings,<br/>exception_case, dispute, dispute_line,<br/>dispute_message, audit"]
        Gold["Delta: platform_dev.pspa_gold"]
        Ops["Delta: platform_dev.pspa_ops"]
    end

    subgraph Outputs["Serving Outputs"]
        Dashboards["Dashboards"]
        WorkQueue["Exception Cases / Dispute Drafts"]
        APIOutput["JSON API Response"]
    end

    Browser --> FastAPI
    Scheduler --> FastAPI
    CLIUser --> CLI
    FastAPI --> Service
    CLI --> Service
    Service --> Engine
    Service --> Schemas
    Engine --> Match
    Engine --> Rules
    Engine --> Findings
    Engine --> Disputes
    Match --> RepoInterface
    Rules --> RepoInterface
    Findings --> RepoInterface
    Disputes --> RepoInterface
    Engine --> RepoInterface

    RepoInterface <--> SQLiteRepo
    RepoInterface <--> DatabricksRepo
    SQLiteRepo <--> SQLiteDB
    DatabricksRepo <--> DBSQLClient
    DBSQLClient <--> Bronze
    DBSQLClient <--> Silver
    DBSQLClient <--> Ontology
    DBSQLClient <--> Gold
    DBSQLClient <--> Ops

    Schemas --> APIOutput
    Gold --> Dashboards
    Gold --> WorkQueue
    APIOutput --> Browser
```

## 6. C3 Component Diagram

The C3 view focuses on the internal components used during a reconciliation request.

```mermaid
flowchart TB
    subgraph Entry["Entry Points"]
        APIEndpoint["FastAPI Endpoint<br/>POST /v1/reconciliations"]
        CLIEntry["CLI Runner<br/>run_demo.py"]
    end

    subgraph ServiceLayer["Workflow Service Layer"]
        ReconciliationService["ReconciliationService<br/>select invoice, correlation id,<br/>call engine, map response"]
        SchemaMapper["summary_to_dict / graph_to_dict<br/>serialize dataclasses and graph evidence"]
    end

    subgraph EngineLayer["Reconciliation Engine Layer"]
        RunLifecycle["Run Lifecycle<br/>create run, complete run,<br/>audit start and finish"]
        LineProcessor["Line Processor<br/>iterate invoice lines"]
        MatchOrchestrator["Match Orchestrator<br/>find_best_match"]
        ValidationOrchestrator["Validation Orchestrator<br/>validate_line"]
        FindingOrchestrator["Finding / Exception / Dispute Orchestrator<br/>build_finding, build_exception_case,<br/>build_dispute_for_exception"]
    end

    subgraph MatchingLayer["Matching Engine Components"]
        CandidateLookup["Candidate Lookup<br/>active effective contract terms<br/>item exact or supplier/date service fallback"]
        CacheLookup["Fast-Path Cache Lookup<br/>candidate contract ids + signature"]
        BatchGraph["Batch Graph Evidence Lookup<br/>node/edge relationships per line"]
        ScoreCandidate["Score Candidate<br/>item/service, category, source quality,<br/>eligibility, date, UOM, price,<br/>charge-term semantics, graph"]
        CacheWriter["Cache Writer<br/>persist high-confidence match"]
    end

    subgraph ValidationLayer["Validation Engine Components"]
        RuleOrder["Rule Catalog Order<br/>14 deterministic OOUX-aware rules"]
        RuleChecks["Rule Checks<br/>source quality, contract, charge term,<br/>item/service, category, eligibility,<br/>amendment, UOM, price, quantity,<br/>frequency, supplier contact"]
        EvidenceBuilder["Validation Evidence Builder<br/>match score, reason, graph support"]
        FinalStatus["Final Status Resolver<br/>PASS / WARN / FAIL"]
    end

    subgraph RepositoryLayer["Repository Components"]
        RepositoryContract["OntologyRepository Interface"]
        SQLiteRepository["SQLiteOntologyRepository<br/>local SQL and indexes"]
        DatabricksRepository["DatabricksOntologyRepository<br/>Databricks SQL queries"]
        GraphEvidence["Graph Evidence Helpers<br/>graph_match_expectations,<br/>build_graph_match_evidence"]
    end

    subgraph Tables["Primary Tables Used"]
        InvoiceTables["invoice, invoice_line"]
        ContractTables["contract, contract_version,<br/>effective_contract_line_term"]
        EligibilityTables["member_eligibility, uom_conversion"]
        GraphTables["node, edge"]
        RuntimeTables["matching_policy, match_cache,<br/>reconciliation_run, validation_result,<br/>finding, exception_case,<br/>dispute, dispute_line, dispute_message,<br/>audit_event"]
    end

    APIEndpoint --> ReconciliationService
    CLIEntry --> ReconciliationService
    ReconciliationService --> RunLifecycle
    ReconciliationService --> SchemaMapper
    RunLifecycle --> LineProcessor
    LineProcessor --> MatchOrchestrator
    LineProcessor --> ValidationOrchestrator
    LineProcessor --> FindingOrchestrator

    MatchOrchestrator --> CandidateLookup
    MatchOrchestrator --> CacheLookup
    MatchOrchestrator --> BatchGraph
    MatchOrchestrator --> ScoreCandidate
    MatchOrchestrator --> CacheWriter

    ValidationOrchestrator --> RuleOrder
    ValidationOrchestrator --> RuleChecks
    ValidationOrchestrator --> EvidenceBuilder
    ValidationOrchestrator --> FinalStatus

    CandidateLookup --> RepositoryContract
    CacheLookup --> RepositoryContract
    BatchGraph --> RepositoryContract
    CacheWriter --> RepositoryContract
    RuleChecks --> RepositoryContract
    RunLifecycle --> RepositoryContract
    FindingOrchestrator --> RepositoryContract

    RepositoryContract --> SQLiteRepository
    RepositoryContract --> DatabricksRepository
    RepositoryContract --> GraphEvidence

    SQLiteRepository --> InvoiceTables
    SQLiteRepository --> ContractTables
    SQLiteRepository --> EligibilityTables
    SQLiteRepository --> GraphTables
    SQLiteRepository --> RuntimeTables
    DatabricksRepository --> InvoiceTables
    DatabricksRepository --> ContractTables
    DatabricksRepository --> EligibilityTables
    DatabricksRepository --> GraphTables
    DatabricksRepository --> RuntimeTables
```

### C3 Implementation Mapping

| Component | Primary implementation |
|---|---|
| API endpoint | `serve_demo.py` |
| Application service | `workflows/service.py` |
| Response mapping | `workflows/schemas.py` |
| Reconciliation engine | `ontology/engine.py` |
| Matching engine | `matching/matching.py` |
| Validation engine | `validation/validators.py` |
| Finding, exception, and dispute generation | `ontology/findings.py` |
| Repository contract | `ontology/repository.py` |
| SQLite repository | `ontology/sqlite_repository.py` |
| Databricks repository | `ontology/databricks_repository.py` |
| Domain models | `ontology/models.py` |
| Databricks DDL | `sql/databricks_lakehouse_schema.sql` |

## 7. C4 Code / Class Diagram

The C4 view shows the key classes, dataclasses, repository implementations, and module-level collaborators used by the current codebase.

```mermaid
classDiagram
    class ReconciliationService {
      +repo: OntologyRepository
      +engine: ReconciliationEngine
      +health()
      +ready()
      +reconcile(invoice_id, correlation_id)
      +ontology_graph()
      +validation_results(run_id)
      +findings(run_id)
      +exception_cases(run_id)
      +disputes(run_id)
      +metrics()
    }

    class ReconciliationEngine {
      +repo: OntologyRepository
      +reconcile_invoice(invoice_id) ReconciliationSummary
    }

    class OntologyRepository {
      <<abstract>>
      +initialize()
      +reset()
      +get_invoice(invoice_id) Invoice
      +get_invoice_lines(invoice_id) InvoiceLine[]
      +get_active_contract_terms(supplier_id, item_id, service_date) EffectiveContractLineTerm[]
      +get_active_contract_terms_for_supplier(supplier_id, service_date) EffectiveContractLineTerm[]
      +get_candidate_contract_terms(supplier_id, item_id, service_date) EffectiveContractLineTerm[]
      +get_supplier_contact(supplier_id) dict
      +is_member_eligible(contract_id, member_id, on_date) bool
      +get_uom_conversion(item_id, from_uom, to_uom) float
      +get_graph_match_evidence_for_terms(invoice, line, terms) dict
      +find_cache_match_for_contracts(contract_ids, signature, version_id) MatchCandidate
      +upsert_cache_match(signature, candidate)
      +add_validation_result(result)
      +add_finding(finding)
      +add_exception_case(exception_case)
      +add_dispute(dispute)
      +add_dispute_line(dispute_line)
      +add_dispute_message(dispute_message)
      +add_audit_event(event_type, entity_type, entity_id, run_id, detail)
    }

    class SQLiteOntologyRepository {
      +conn
      +initialize()
      +get_graph_match_evidence_for_terms(invoice, line, terms)
      +find_cache_match(contract_id, signature, version_id)
      +metrics()
    }

    class DatabricksOntologyRepository {
      +client: DatabricksSqlClient
      +catalog
      +schema
      +initialize()
      +get_graph_match_evidence_for_terms(invoice, line, terms)
      +find_cache_match(contract_id, signature, version_id)
      +metrics()
    }

    class DatabricksSqlClient {
      +execute(statement, parameters)
      +execute_script(script_path)
      +close()
    }

    class MatchingModule {
      <<module>>
      +find_best_match(repo, invoice, line)
      +score_candidate(repo, invoice, line, term, policy, graph_evidence)
      +invoice_line_signature(line)
      +normalize_invoice_unit_price(repo, line, term)
      +semantic_similarity(line, term)
      +source_quality_sufficient(line, policy)
    }

    class ValidationModule {
      <<module>>
      +validate_line(repo, run_id, invoice, line, candidate)
      +final_status(results)
    }

    class FindingsModule {
      <<module>>
      +build_finding(run_id, invoice, line, candidate, results, status)
      +build_exception_case(run_id, invoice, line, candidate, results, finding)
      +build_dispute_for_exception(exception_case, invoice, line, supplier_contact)
    }

    class RepositoryGraphHelpers {
      <<module>>
      +graph_match_expectations(invoice, line, term)
      +build_graph_match_evidence(edges, invoice, line, term)
    }

    class Invoice {
      +invoice_id
      +invoice_number
      +invoice_date
      +supplier_id
      +member_id
      +currency_code
      +total_amount
      +payment_status
      +po_type
      +interception_status
    }

    class InvoiceLine {
      +invoice_line_id
      +invoice_id
      +line_number
      +item_id
      +quantity
      +invoice_uom
      +unit_price
      +service_date
      +category_code
      +charge_term_text
      +billing_frequency
      +parse_confidence
      +source_quality_status
    }

    class EffectiveContractLineTerm {
      +contract_line_id
      +contract_version_id
      +contract_id
      +item_id
      +contract_uom
      +unit_price
      +effective_from
      +effective_to
      +sequence_number
      +category_code
      +charge_term_type
      +pricing_basis
      +billing_frequency
      +charge_term_allowed
    }

    class MatchingPolicy {
      +exact_item_weight
      +eligibility_weight
      +date_weight
      +uom_weight
      +price_weight
      +semantic_weight
      +graph_weight
      +category_weight
      +semantic_match_threshold
      +source_quality_confidence_threshold
      +fast_path_threshold
      +deep_path_threshold
      +price_tolerance_pct
    }

    class MatchCandidate {
      +invoice_line_id
      +contract_line_id
      +contract_id
      +contract_version_id
      +score
      +route
      +price_proximity
      +semantic_similarity
      +graph_support_score
      +graph_evidence
      +match_status
      +contract_selection_score
      +contract_candidate_count
      +term_candidate_count
      +category_compatible
      +charge_term_type
      +pricing_basis
      +uom_required
      +uom_absent_accepted
      +data_quality_sufficient
    }

    class ValidationResult {
      +validation_result_id
      +rule_code
      +status
      +severity
      +expected_value
      +actual_value
      +variance_amount
      +evidence
    }

    class Finding {
      +finding_id
      +finding_type
      +status
      +severity
      +summary
      +detail
      +variance_amount
      +evidence
    }

    class ExceptionCase {
      +exception_case_id
      +reconciliation_run_id
      +invoice_line_id
      +exception_type
      +status
      +variance_amount
      +annualized_exposure
      +root_cause
      +remediation
      +dispute_ready
    }

    class Dispute {
      +dispute_id
      +exception_case_id
      +supplier_id
      +status
      +disputed_amount
      +supplier_contact_email
      +template_code
      +message_subject
      +message_body
    }

    class DisputeLine {
      +dispute_id
      +invoice_line_id
    }

    class DisputeMessage {
      +dispute_message_id
      +dispute_id
      +direction
      +subject
      +body
      +created_at
    }

    class ReconciliationRun {
      +reconciliation_run_id
      +invoice_id
      +status
      +started_at
      +completed_at
      +fast_path_count
      +deep_path_count
      +manual_review_count
    }

    class ReconciliationSummary {
      +run
      +invoice
      +line_outcomes
      +total_variance
      +final_status
    }

    class Node {
      +node_id
      +entity_type
      +entity_id
      +display_name
      +properties
    }

    class Edge {
      +edge_id
      +from_node_id
      +to_node_id
      +relationship_type
      +valid_from
      +valid_to
      +evidence
    }

    ReconciliationService --> ReconciliationEngine
    ReconciliationService --> OntologyRepository
    ReconciliationEngine --> OntologyRepository
    ReconciliationEngine --> MatchingModule : find_best_match
    ReconciliationEngine --> ValidationModule : validate_line
    ReconciliationEngine --> FindingsModule : build_finding
    OntologyRepository <|.. SQLiteOntologyRepository
    OntologyRepository <|.. DatabricksOntologyRepository
    DatabricksOntologyRepository --> DatabricksSqlClient
    MatchingModule --> OntologyRepository
    MatchingModule --> MatchingPolicy
    MatchingModule --> MatchCandidate
    MatchingModule --> RepositoryGraphHelpers
    ValidationModule --> ValidationResult
    ValidationModule --> MatchCandidate
    FindingsModule --> Finding
    FindingsModule --> ExceptionCase
    FindingsModule --> Dispute
    RepositoryGraphHelpers --> Node
    RepositoryGraphHelpers --> Edge
    ReconciliationSummary --> ReconciliationRun
    ReconciliationSummary --> Invoice
    ReconciliationSummary --> InvoiceLine
    ReconciliationSummary --> MatchCandidate
    ReconciliationSummary --> ExceptionCase
    ReconciliationSummary --> Dispute
    MatchCandidate --> EffectiveContractLineTerm
```

## 8. Reconciliation Processing Flow

This flow summarizes how the runtime processes one invoice using the current implementation.

```mermaid
sequenceDiagram
    autonumber
    participant Client as API / CLI Client
    participant Service as ReconciliationService
    participant Engine as ReconciliationEngine
    participant Repo as OntologyRepository
    participant Match as Matching Engine
    participant Validate as Validation Engine
    participant Findings as Findings Builder
    participant Store as SQLite or Databricks Delta

    Client->>Service: reconcile(invoice_id, correlation_id)
    Service->>Engine: reconcile_invoice(invoice_id)
    Engine->>Repo: get_invoice(invoice_id)
    Repo->>Store: read invoice
    Engine->>Repo: get_invoice_lines(invoice_id)
    Repo->>Store: read invoice lines
    Engine->>Repo: add_run and audit start
    Repo->>Store: write reconciliation_run and audit_event

    loop each invoice line
        Engine->>Match: find_best_match(repo, invoice, line)
        Match->>Repo: get_candidate_contract_terms(supplier, item, service_date)
        Repo->>Store: read effective contract terms
        Match->>Repo: find_cache_match_for_contracts(candidate contract ids, signature)
        Repo->>Store: read match_cache
        Match->>Repo: get_graph_match_evidence_for_terms(invoice, line, terms)
        Repo->>Store: batch read ontology edge
        Match->>Repo: is_member_eligible and get_uom_conversion as needed
        Repo->>Store: read eligibility and UOM
        Match-->>Engine: best MatchCandidate with graph, category, source-quality, and charge-term evidence
        Engine->>Validate: validate_line(run_id, invoice, line, candidate)
        Validate-->>Engine: ValidationResult list
        Engine->>Repo: add_validation_result
        Repo->>Store: write validation_result
        Engine->>Findings: build_finding(...)
        Findings-->>Engine: Finding
        Engine->>Findings: build_exception_case(...) when status fails
        Findings-->>Engine: ExceptionCase or None
        Engine->>Repo: add_exception_case
        Repo->>Store: write exception_case
        Engine->>Findings: build_dispute_for_exception(...) when dispute-ready
        Findings-->>Engine: Dispute + DisputeLine + DisputeMessage or None
        Engine->>Repo: add_dispute / add_dispute_line / add_dispute_message
        Repo->>Store: write dispute draft tables
        Engine->>Repo: add_finding and audit LINE_RECONCILED
        Repo->>Store: write finding and audit_event
    end

    Engine->>Repo: complete_run and audit completion
    Repo->>Store: update run and audit_event
    Engine-->>Service: ReconciliationSummary
    Service-->>Client: JSON response with line results, graph evidence, findings, exceptions, disputes, variance
```

## 9. Key Runtime Responsibilities

| Layer / Component | Responsibility |
|---|---|
| Bronze | Preserve structured raw payloads and lineage for replay. |
| Silver | Store trusted conformed entities and amendment-effective contract terms. |
| Ontology | Store semantic nodes, edges, policies, rule catalog, match cache, validation evidence, findings, exception cases, dispute drafts, and audit events. |
| Matching engine | Select candidate contract or service charge term and compute explainable score using item/service identity, category, source quality, eligibility, date, UOM, price, charge-term semantics, and graph support. |
| Validation engine | Execute 14 deterministic OOUX-aware controls and produce pass/fail/warn/skipped rule evidence. |
| Gold | Publish business-ready reconciliation facts, summaries, dispute queues, and recovery opportunities. |
| Ops | Track operational execution metrics, workflow logs, and support diagnostics. |

## 10. Graph Relationships Used By Matching

```mermaid
flowchart LR
    Invoice["Invoice"] -->|"HAS_LINE"| InvoiceLine["Invoice Line"]
    Contract["Contract"] -->|"HAS_TERM"| Term["Effective Contract Line Term"]
    Term -->|"PRICES_ITEM when itemized"| Item["Item"]
    Term -. "service terms may match by category / charge-term semantics" .-> InvoiceLine
    Member["Member / Facility"] -->|"ELIGIBLE_FOR"| Contract
    Supplier["Supplier"] -->|"PARTICIPATES_IN"| Contract
    InvoiceLine -. "candidate match scored against" .-> Term
```

The current graph-aware matching score uses the following expected relationships:

| Relationship | Purpose | Matching weight |
|---|---|---:|
| `HAS_LINE` | Confirms the invoice-to-line graph path exists. | 0.15 |
| `HAS_TERM` | Confirms the selected contract owns the effective line term. | 0.25 |
| `PRICES_ITEM` | Confirms the contract term prices the same item. Skipped for service terms without item identity. | 0.25 |
| `ELIGIBLE_FOR` | Confirms the member/facility eligibility path to the contract. | 0.20 |
| `PARTICIPATES_IN` | Confirms the supplier participates in the selected contract. | 0.15 |
