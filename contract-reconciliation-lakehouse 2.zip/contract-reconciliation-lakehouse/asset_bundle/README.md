# Asset Bundle

Purpose: Databricks Declarative Automation Bundle placeholder for deploying jobs, SQL, Python tasks, and permissions.

See `databricks.yml` for a starter bundle layout.

