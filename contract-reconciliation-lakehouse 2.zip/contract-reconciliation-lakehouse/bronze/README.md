# Bronze Layer

Purpose: retain raw structured source payloads from upstream contract, invoice, supplier, rule, and dispute systems.

Primary tables are defined in the unified Databricks schema:

- `../sql/databricks_lakehouse_schema.sql`

Representative tables:

- `platform_dev.pspa_bronze.contract_raw`
- `platform_dev.pspa_bronze.contract_line_raw`
- `platform_dev.pspa_bronze.invoice_raw`
- `platform_dev.pspa_bronze.invoice_line_raw`
- `platform_dev.pspa_bronze.supplier_raw`
- `platform_dev.pspa_bronze.health_system_raw`
- `platform_dev.pspa_bronze.detection_rule_raw`
- `platform_dev.pspa_bronze.dispute_raw`
