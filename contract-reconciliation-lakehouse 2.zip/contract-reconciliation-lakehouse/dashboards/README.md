# Dashboards

Purpose: dashboard definitions and BI design notes.

Recommended dashboards:

- Supplier Price Assurance summary.
- Invoice exception queue.
- Contract leakage summary.
- Dispute aging and recovery.
- Rule failure trends.
- AP payment deadline risk.

