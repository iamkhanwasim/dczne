# Data Directory

This folder is used by the local SQLite demo and API runtime.

The package includes this README so the `data/` folder is visible after extraction. SQLite database files are generated at runtime and are intentionally not bundled.

Common generated files:

- `demo_reconciliation.db`: created by `python run_demo.py --reset --twice`
- `reconciliation.db`: created by the local API when `SQLITE_DB_PATH=data/reconciliation.db`
- `*.db-wal` and `*.db-shm`: SQLite write-ahead-log support files
- `test_work/`: temporary test database folder

Create or refresh the local demo database:

```powershell
$env:PYTHONPATH = "."
python run_demo.py --reset --twice
```

Create or refresh the local API database:

```powershell
$env:REPOSITORY_BACKEND = "sqlite"
$env:SQLITE_DB_PATH = "data/reconciliation.db"
$env:SEED_ON_STARTUP = "true"
contract-reconcile-api --host 127.0.0.1 --port 8008 --reset
```
