# Production Runbook

## Runtime Modes

| Mode | Backend | Use Case |
|---|---|---|
| Local CLI | SQLite | Developer validation and rule debugging |
| Local API | SQLite | Frontend/API integration testing |
| Container API | SQLite or Databricks | Packaged service deployment |
| Databricks Workflow | Unity Catalog Delta | Batch reconciliation and Gold publication |

## Local CLI

```powershell
$env:PYTHONPATH="."
python run_demo.py --reset --twice
python run_demo.py --json
python -m workflows.cli --metrics
```

## Local API

Install the API extra and start the service:

```powershell
pip install -e ".[api]"
$env:REPOSITORY_BACKEND="sqlite"
$env:SQLITE_DB_PATH="data/reconciliation.db"
$env:SEED_ON_STARTUP="true"
contract-reconcile-api --host 127.0.0.1 --port 8008 --reset
```

Smoke-test endpoints:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/health
Invoke-RestMethod http://127.0.0.1:8008/ready
Invoke-RestMethod -Method Post http://127.0.0.1:8008/v1/reconciliations `
  -ContentType "application/json" `
  -Body '{"invoice_id":"INV-1001","correlation_id":"smoke-001"}'
Invoke-RestMethod http://127.0.0.1:8008/v1/ontology/graph
```

## Container

```powershell
cd deployment
docker compose up --build
```

The service exposes:

- `GET /health`
- `GET /ready`
- `GET /metrics`
- `POST /v1/reconciliations`
- `GET /v1/reconciliations/{run_id}/validation-results`
- `GET /v1/reconciliations/{run_id}/findings`
- `GET /v1/ontology/graph`

## Databricks Setup

1. Create or select a Unity Catalog metastore.
2. Create a SQL Warehouse or Jobs compute with service-principal access.
3. Execute the unified SQL asset:
   - `sql/databricks_lakehouse_schema.sql`
4. Confirm Unity Catalog namespace:
   - Catalog: `platform_dev`
   - Schemas: `pspa_bronze`, `pspa_silver`, `pspa_ontology`, `pspa_gold`, `pspa_ops`
5. Review table responsibilities:
   - `docs/DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md`
6. Grant least-privilege access:
   - Application service principal: `SELECT`, `INSERT`, `UPDATE`, `DELETE` on `platform_dev.pspa_ontology` and `platform_dev.pspa_gold` tables.
   - Analysts: `SELECT` on `platform_dev.pspa_gold` tables and approved views only.
   - Pipeline owners: write access to `platform_dev.pspa_bronze` and `platform_dev.pspa_silver`.
7. Configure environment variables:

```text
REPOSITORY_BACKEND=databricks
DATABRICKS_SERVER_HOSTNAME=<workspace-host>
DATABRICKS_HTTP_PATH=<sql-warehouse-http-path>
DATABRICKS_TOKEN=<service-principal-token>
DATABRICKS_CATALOG=platform_dev
DATABRICKS_SCHEMA=pspa_ontology
```

## Release Checklist

| Check | Command or Evidence |
|---|---|
| Unit tests pass | `python -m unittest discover -s tests -v` |
| CLI smoke test passes | `python run_demo.py --reset --twice` |
| API starts | `contract-reconcile-api --reset` |
| Health endpoint returns ok | `GET /health` |
| DDL applied | Unity Catalog tables exist |
| Secrets externalized | No tokens committed to repo |
| Service identity scoped | UC grants reviewed |
| Observability configured | JSON logs and `/metrics` available |

## Operational Notes

- The ontology graph is the semantic contract between matching, validation, audit, and analytics.
- Gold tables should be treated as serving products for BI, recovery queues, and dispute workflows.
- For amendment-heavy contracts, refresh effective terms before reconciliation and invalidate match cache for changed contracts.
- For high-volume execution, run reconciliation in partitioned invoice batches and publish run-level metrics to `platform_dev.pspa_ops.pipeline_run_log`.
