# Deployment

Deployment assets for the production-grade reconciliation application.

| File | Purpose |
|---|---|
| `Dockerfile` | Builds the FastAPI service image |
| `docker-compose.yml` | Runs the service locally with persistent SQLite storage |
| `PRODUCTION_RUNBOOK.md` | End-to-end deployment, smoke test, and Databricks setup guide |

Recommended flow:

1. Execute Unity Catalog DDL from `sql/`.
2. Package or containerize the Python app.
3. Configure service identity and environment variables.
4. Start the API or Databricks workflow.
5. Run the smoke tests in `PRODUCTION_RUNBOOK.md`.
