from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parents[1]

DOCS = [
    (
        ROOT / "architecture" / "ENTERPRISE_ARCHITECTURE_DELIVERABLES.md",
        ROOT / "docs" / "Enterprise_Architecture_Deliverables.docx",
        "Enterprise Architecture Deliverables",
    ),
    (
        ROOT / "docs" / "MEDALLION_ONTOLOGY_RECONCILIATION_FLOW.md",
        ROOT / "docs" / "Medallion_Ontology_Reconciliation_Flow.docx",
        "Medallion, Ontology, and Reconciliation Flow",
    ),
]


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin_name, value in {
        "top": top,
        "start": start,
        "bottom": bottom,
        "end": end,
    }.items():
        node = tc_mar.find(qn(f"w:{margin_name}"))
        if node is None:
            node = OxmlElement(f"w:{margin_name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths: list[int]) -> None:
    table.autofit = False
    tbl = table._tbl
    tbl_pr = tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(sum(widths)))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")

    grid = tbl.tblGrid
    if grid is None:
        grid = OxmlElement("w:tblGrid")
        tbl.insert(0, grid)
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            cell.width = Pt(widths[idx] / 20)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def clear_and_set_cell_text(cell, text: str, bold: bool = False) -> None:
    paragraph = cell.paragraphs[0]
    paragraph.text = ""
    paragraph.paragraph_format.space_after = Pt(0)
    paragraph.paragraph_format.line_spacing = 1.08
    run = paragraph.add_run(clean_inline(text))
    run.bold = bold
    run.font.name = "Calibri"
    run.font.size = Pt(9)


def clean_inline(text: str) -> str:
    text = text.strip()
    text = re.sub(r"\*\*(.*?)\*\*", r"\1", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = text.replace("<br/>", " / ")
    return text


def table_widths(column_count: int) -> list[int]:
    if column_count == 1:
        return [9360]
    if column_count == 2:
        return [2400, 6960]
    if column_count == 3:
        return [2100, 3330, 3930]
    if column_count == 4:
        return [1600, 2500, 2600, 2660]
    if column_count == 5:
        return [1400, 1700, 2000, 2200, 2060]
    base = 9360 // column_count
    widths = [base] * column_count
    widths[-1] += 9360 - sum(widths)
    return widths


def apply_styles(doc: Document) -> None:
    section = doc.sections[0]
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.25

    title = doc.styles["Title"]
    title.font.name = "Calibri"
    title.font.size = Pt(22)
    title.font.bold = True
    title.font.color.rgb = RGBColor(31, 58, 95)
    title.paragraph_format.space_after = Pt(10)

    for name, size, color, before, after in [
        ("Heading 1", 16, "2E74B5", 18, 10),
        ("Heading 2", 13, "2E74B5", 14, 7),
        ("Heading 3", 12, "1F4D78", 10, 5),
    ]:
        style = doc.styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = RGBColor.from_string(color)
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)

    for name in ["List Bullet", "List Number"]:
        style = doc.styles[name]
        style.font.name = "Calibri"
        style.font.size = Pt(11)
        style.paragraph_format.left_indent = Inches(0.375)
        style.paragraph_format.first_line_indent = Inches(-0.188)
        style.paragraph_format.space_after = Pt(4)
        style.paragraph_format.line_spacing = 1.25

    code = doc.styles.add_style("CompactCode", 1)
    code.font.name = "Courier New"
    code.font.size = Pt(8)
    code.paragraph_format.space_before = Pt(2)
    code.paragraph_format.space_after = Pt(2)
    code.paragraph_format.line_spacing = 1.0


def add_code_block(doc: Document, lines: list[str], language: str | None) -> None:
    label = "Diagram definition" if language == "mermaid" else "Code block"
    caption = doc.add_paragraph(label, style="Caption")
    caption.runs[0].font.bold = True
    for line in lines:
        paragraph = doc.add_paragraph(style="CompactCode")
        run = paragraph.add_run(line if line else " ")
        run.font.name = "Courier New"
        run.font.size = Pt(8)


def parse_markdown_table(lines: list[str], start: int) -> tuple[list[list[str]], int]:
    rows: list[list[str]] = []
    index = start
    while index < len(lines) and lines[index].strip().startswith("|"):
        raw_cells = [cell.strip() for cell in lines[index].strip().strip("|").split("|")]
        is_separator = all(re.fullmatch(r":?-{3,}:?", cell or "") for cell in raw_cells)
        if not is_separator:
            rows.append(raw_cells)
        index += 1
    return rows, index


def add_markdown_table(doc: Document, rows: list[list[str]]) -> None:
    if not rows:
        return
    columns = max(len(row) for row in rows)
    widths = table_widths(columns)
    table = doc.add_table(rows=len(rows), cols=columns)
    table.style = "Table Grid"
    set_table_geometry(table, widths)
    set_repeat_table_header(table.rows[0])
    for row_idx, row in enumerate(rows):
        for col_idx in range(columns):
            text = row[col_idx] if col_idx < len(row) else ""
            cell = table.cell(row_idx, col_idx)
            clear_and_set_cell_text(cell, text, bold=row_idx == 0)
            if row_idx == 0:
                set_cell_shading(cell, "E8EEF5")
    doc.add_paragraph()


def build_docx(source: Path, target: Path, title: str) -> None:
    text = source.read_text(encoding="utf-8")
    lines = text.splitlines()
    doc = Document()
    apply_styles(doc)

    first_title_added = False
    code_lines: list[str] = []
    code_language: str | None = None
    in_code = False
    paragraph_buffer: list[str] = []

    def flush_paragraph() -> None:
        nonlocal paragraph_buffer
        if paragraph_buffer:
            paragraph = doc.add_paragraph(clean_inline(" ".join(paragraph_buffer)))
            paragraph.paragraph_format.keep_together = False
            paragraph_buffer = []

    i = 0
    while i < len(lines):
        raw = lines[i]
        stripped = raw.strip()

        if in_code:
            if stripped.startswith("```"):
                add_code_block(doc, code_lines, code_language)
                code_lines = []
                code_language = None
                in_code = False
            else:
                code_lines.append(raw.rstrip())
            i += 1
            continue

        if stripped.startswith("```"):
            flush_paragraph()
            in_code = True
            code_language = stripped.strip("`").strip() or None
            code_lines = []
            i += 1
            continue

        if not stripped:
            flush_paragraph()
            i += 1
            continue

        if stripped.startswith("|"):
            flush_paragraph()
            rows, next_index = parse_markdown_table(lines, i)
            add_markdown_table(doc, rows)
            i = next_index
            continue

        heading = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if heading:
            flush_paragraph()
            level = len(heading.group(1))
            heading_text = clean_inline(heading.group(2))
            if level == 1 and not first_title_added:
                p = doc.add_paragraph(heading_text, style="Title")
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                first_title_added = True
            elif level == 1:
                doc.add_paragraph(heading_text, style="Heading 1")
            elif level == 2:
                doc.add_paragraph(heading_text, style="Heading 2")
            else:
                doc.add_paragraph(heading_text, style="Heading 3")
            i += 1
            continue

        if stripped.startswith("- "):
            flush_paragraph()
            doc.add_paragraph(clean_inline(stripped[2:]), style="List Bullet")
            i += 1
            continue

        numbered = re.match(r"^\d+\.\s+(.*)$", stripped)
        if numbered:
            flush_paragraph()
            doc.add_paragraph(clean_inline(numbered.group(1)), style="List Number")
            i += 1
            continue

        paragraph_buffer.append(stripped)
        i += 1

    flush_paragraph()

    doc.core_properties.title = title
    doc.core_properties.subject = "Contract reconciliation lakehouse architecture"
    doc.core_properties.keywords = "Databricks, Medallion, Ontology, Reconciliation, OOUX"
    doc.save(target)


def main() -> None:
    for source, target, title in DOCS:
        build_docx(source, target, title)
        print(f"wrote {target}")


if __name__ == "__main__":
    main()
