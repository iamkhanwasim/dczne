from __future__ import annotations

import os
import runpy
import shutil
import sys
import tempfile
import uuid
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_TMP = ROOT / "docx_render_qa" / "safe_tmp"
RENDERER = Path(
    r"C:\Users\nshrivas\.codex\plugins\cache\openai-primary-runtime\documents\26.630.12135\skills\documents\render_docx.py"
)


class SafeTemporaryDirectory:
    def __init__(self, suffix=None, prefix=None, dir=None, ignore_cleanup_errors=False):
        self.prefix = prefix or "tmp_"
        self.name = str(BASE_TMP / f"{self.prefix}{uuid.uuid4().hex}")

    def __enter__(self):
        os.makedirs(self.name, exist_ok=False)
        return self.name

    def __exit__(self, exc_type, exc, tb):
        shutil.rmtree(self.name, ignore_errors=True)
        return False

    def cleanup(self):
        shutil.rmtree(self.name, ignore_errors=True)


def main() -> None:
    BASE_TMP.mkdir(parents=True, exist_ok=True)
    tempfile.TemporaryDirectory = SafeTemporaryDirectory
    runpy.run_path(str(RENDERER), run_name="__main__")


if __name__ == "__main__":
    main()
