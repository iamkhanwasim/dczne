# Delta Table Roles And Responsibilities

## Purpose

This document explains the responsibility of each Delta table created by:

```text
sql/databricks_lakehouse_schema.sql
```

The table design follows this dependency:

```text
Bronze -> Silver -> Ontology + Reconciliation -> Gold -> API / BI / Workflow
```

Unity Catalog namespace:

```text
platform_dev.pspa_bronze
platform_dev.pspa_silver
platform_dev.pspa_ontology
platform_dev.pspa_gold
platform_dev.pspa_ops
```

Unity Catalog does not support nested schemas such as `platform_dev.pspa.bronze.table`, so this solution uses `pspa_<layer>` schemas under the `platform_dev` catalog.

The ontology is built from Silver because Silver is the first trusted and conformed entity layer. Gold is produced after reconciliation and should serve analytics, exception workflows, and recovery tracking.

## Layer Responsibility Summary

| Layer | Responsibility | Primary Producer | Primary Consumer |
|---|---|---|---|
| Bronze | Preserve structured source payloads with lineage and replay support. | Source ingestion job or upstream feed. | Silver normalization jobs. |
| Silver | Store conformed and quality-checked business entities. | Bronze-to-Silver transformation jobs. | Ontology builder and reconciliation engine. |
| Ontology | Store semantic graph, policies, cache, validation evidence, findings, and audit. | Ontology builder and reconciliation engine. | Reconciliation engine, API, explainability services. |
| Gold | Store business-ready facts, summaries, queues, and recovery opportunities. | Gold publishing jobs after reconciliation. | BI dashboards, AP workflow, analyst work queues. |
| Ops | Store pipeline and workflow observability metadata. | Databricks workflows and Lakeflow jobs. | Platform operations and support teams. |

## Bronze Tables

| Table | Grain | Responsibility | Should Not Do |
|---|---|---|---|
| `platform_dev.pspa_bronze.contract_payload` | One source contract/amendment payload or record. | Preserve raw structured contract payloads, source record id, file name, payload hash, load id, and ingestion timestamp. | Do not apply matching, amendment resolution, or business rules. |
| `platform_dev.pspa_bronze.invoice_payload` | One source invoice payload or record. | Preserve raw structured invoice header and line payloads with lineage and replay support. | Do not calculate compliance, variance, or reconciliation status. |

## Silver Tables

| Table | Grain | Responsibility | Key Consumers |
|---|---|---|---|
| `platform_dev.pspa_silver.party` | One business party. | Conformed party master for GPOs, suppliers, members, facilities, distributors, and manufacturers. | Ontology node builder, eligibility logic. |
| `platform_dev.pspa_silver.item` | One canonical item. | Standard item identity for matching invoice lines to contract terms. | Matching engine, ontology node builder. |
| `platform_dev.pspa_silver.uom_conversion` | One item/UOM conversion. | Normalize invoice UOM into contract UOM and support pack-size conversion. | Matching and price validation. |
| `platform_dev.pspa_silver.contract` | One contract header. | Trusted contract header with GPO, supplier, status, and date range. | Effective-term builder, ontology builder. |
| `platform_dev.pspa_silver.contract_version` | One base contract or amendment version. | Orders base contract and amendment events. | Amendment resolution, audit. |
| `platform_dev.pspa_silver.contract_line_term` | One versioned contract line term. | Stores contract pricing/compliance terms before amendment-effective materialization. | Effective-term builder. |
| `platform_dev.pspa_silver.effective_contract_line_term` | One final effective contract term for a date range. | Primary contract input for reconciliation after amendment resolution. | Matching engine and validation engine. |
| `platform_dev.pspa_silver.member_eligibility` | One member/contract/tier eligibility interval. | Determines if a member or facility is eligible for a contract and tier. | Matching and validation. |
| `platform_dev.pspa_silver.invoice` | One invoice header. | Trusted invoice header and reconciliation subject. | Reconciliation engine, Gold summary. |
| `platform_dev.pspa_silver.invoice_line` | One invoice line. | Trusted line-level invoice evidence for contract matching. | Reconciliation engine. |
| `platform_dev.pspa_silver.contract_tier` | One contract tier. | Stores GPO pricing tier thresholds, rank, and effective dates. | Eligibility and pricing logic. |
| `platform_dev.pspa_silver.member_roster` | One member/facility roster record. | Enriches member identity, facility, HIN, DEA, GLN, and class of trade. | Eligibility, analytics, ontology enrichment. |
| `platform_dev.pspa_silver.contract_compliance_obligation` | One contract obligation. | Stores obligation type, expected value, tolerance, severity, and active flag. | Rule catalog enrichment and validation. |

## Ontology Tables

| Table | Grain | Responsibility | Key Consumers |
|---|---|---|---|
| `platform_dev.pspa_ontology.node` | One semantic object. | Registers contracts, parties, items, invoices, invoice lines, findings, and rules as ontology objects. | API, graph traversal, explainability. |
| `platform_dev.pspa_ontology.edge` | One semantic relationship. | Stores relationships such as `GOVERNS`, `HAS_TERM`, `PRICES_ITEM`, `ELIGIBLE_FOR`, `HAS_LINE`, `MATCHED_TO`, and `SUPPORTED_BY`. | Reconciliation, API, explainability. |
| `platform_dev.pspa_ontology.rule_catalog` | One rule version. | Governs validation rule metadata, severity, group, active flag, and parameters. | Validation engine. |
| `platform_dev.pspa_ontology.matching_policy` | One matching policy. | Stores scoring weights, thresholds, tolerance, and route policy. | Matching engine. |
| `platform_dev.pspa_ontology.match_cache` | One cached line signature. | Stores high-confidence matches for fast-path reuse with contract/version awareness. | Matching engine. |
| `platform_dev.pspa_ontology.reconciliation_run` | One reconciliation run. | Stores run lifecycle, status, line counts, route counts, and result counts. | API, Gold publisher, ops reporting. |
| `platform_dev.pspa_ontology.validation_result` | One rule result per line. | Stores detailed expected, actual, status, severity, variance, and evidence for every rule execution. | Findings, API, audit, Gold publisher. |
| `platform_dev.pspa_ontology.finding` | One finding per invoice line. | Stores compliant, variance, off-contract, warning, and manual-review outcomes. | Gold publisher, API, analyst workflow. |
| `platform_dev.pspa_ontology.audit_event` | One audit event. | Stores operational and business trace events. | Audit, support, observability. |

## Ontology Compatibility Mirrors

The unified SQL also creates compatibility mirror tables in `platform_dev.pspa_ontology` for canonical entities such as `party`, `item`, `contract`, `invoice`, and `effective_contract_line_term`.

These are not intended to replace Silver as the governed source of truth. They exist so the current API repository implementation can operate against an ontology schema while the production implementation evolves toward direct Silver-backed queries.

| Compatibility Table Pattern | Responsibility |
|---|---|
| `platform_dev.pspa_ontology.party` and similar entity mirrors | Operational mirror loaded from Silver for repository runtime compatibility. |
| Silver source table | Governed source of truth for conformed business entity data. |

## Gold Tables

| Table | Grain | Responsibility | Consumers |
|---|---|---|---|
| `platform_dev.pspa_gold.invoice_reconciliation_summary` | One invoice/run summary. | BI-ready invoice-level status, variance, and pass/fail/warn counts. | Dashboards, AP, Finance. |
| `platform_dev.pspa_gold.invoice_reconciliation_line` | One invoice-line reconciliation fact. | Final line status, matched contract, route, match score, variance, and finding summary. | Dashboards, recovery analysis, supplier scorecards. |
| `platform_dev.pspa_gold.dispute_case_queue` | One exception or dispute case. | Analyst work queue for price variances, off-contract lines, and ambiguous lines. | Price Assurance analysts, AP workflow. |
| `platform_dev.pspa_gold.price_assurance_recovery_opportunity` | One recovery opportunity. | Tracks recoverable amount, root cause, case status, and contract/invoice lineage. | Recovery operations, finance reporting. |

## Ops Tables

| Table | Grain | Responsibility | Consumers |
|---|---|---|---|
| `platform_dev.pspa_ops.pipeline_run_log` | One workflow task run. | Captures status, start/end timestamps, input/output counts, and error messages for pipeline observability. | Platform operations, support, SLA monitoring. |

## Governance Guidance

| Concern | Recommendation |
|---|---|
| Source of truth | Bronze for raw payloads, Silver for conformed entities, Ontology for semantic relationships and evidence, Gold for serving outputs. |
| Access control | Analysts should primarily read Gold and approved views. Engineering jobs write Bronze/Silver/Ontology. APIs read Ontology and Gold. |
| Data quality | Apply expectations before Silver publication. Reconciliation should reject or route low-quality Silver records to review. |
| Lineage | Preserve `source_record_id`, `load_id`, payload hash, reconciliation run id, validation evidence, and audit events. |
| AI/LLM usage | AI may assist candidate retrieval or explanation, but deterministic validation owns final financial decisions. |
| Cache invalidation | Invalidate match cache when contract versions, effective terms, item mappings, or eligibility records change. |
