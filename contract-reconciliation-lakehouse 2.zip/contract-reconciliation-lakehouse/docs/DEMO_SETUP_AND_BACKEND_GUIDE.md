# Demo Setup And Backend Configuration Guide

## Purpose

This guide explains how to configure, run, and demo the Contract Reconciliation Lakehouse solution.

It covers three demo paths:

1. Local command-line demo using SQLite.
2. Local FastAPI demo using SQLite.
3. Databricks-backed demo using Unity Catalog Delta tables.

For the fastest business walkthrough, start with the local SQLite demo. For the architecture walkthrough, show the Databricks SQL schema and explain how the API is pointed to `platform_dev.pspa_ontology`.

## Current Namespace

Databricks Unity Catalog uses a three-level namespace:

```text
catalog.schema.table
```

The solution is configured with:

| Layer | Unity Catalog Location |
|---|---|
| Catalog | `platform_dev` |
| Bronze | `platform_dev.pspa_bronze` |
| Silver | `platform_dev.pspa_silver` |
| Ontology | `platform_dev.pspa_ontology` |
| Gold | `platform_dev.pspa_gold` |
| Ops | `platform_dev.pspa_ops` |

Because Unity Catalog does not support nested schemas such as `platform_dev.pspa.bronze.table`, the PSPA domain and Medallion layer are combined in schema names such as `pspa_bronze` and `pspa_ontology`.

## Repository Location

Run commands from the project root:

```powershell
cd C:\Users\nshrivas\Documents\Codex\2026-06-03\can-you-share-me-in-tablular\outputs\contract-reconciliation-lakehouse
```

The package includes `data/README.md` so the runtime data folder is visible after extraction. SQLite database files are generated when you run the CLI or API demo and are not bundled in the zip.

## Backend Options

| Backend | Use Case | Storage | Required Dependencies |
|---|---|---|---|
| SQLite CLI | Fast local reconciliation demo. | Local `.db` file under `data/`. | Python 3.11. |
| SQLite API | API and UI integration demo. | Local `.db` file under `data/`. | `fastapi`, `uvicorn`. |
| Docker SQLite API | Containerized local demo. | Docker volume. | Docker Desktop. |
| Databricks SQL | Enterprise backend demo. | Unity Catalog Delta tables. | Databricks SQL Warehouse, token/service principal, `databricks-sql-connector`. |

## Step 1: Prerequisites

Install or confirm:

| Tool | Required For | Check Command |
|---|---|---|
| Python 3.11 or higher | Local CLI and API | `python --version` |
| pip | Installing API/Databricks extras | `python -m pip --version` |
| Docker Desktop | Optional container demo | `docker --version` |
| Databricks SQL Warehouse | Databricks backend | Databricks workspace UI |
| Databricks access token or service principal token | Databricks backend | Enterprise secret store or workspace token |

## Step 2: Create A Local Python Environment

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

For CLI-only demo, the core code has no external runtime dependency.

For API demo, install the API extra:

```powershell
pip install -e ".[api]"
```

For Databricks backend demo, install both API and Databricks extras:

```powershell
pip install -e ".[api,databricks]"
```

## Step 3: Run The Fast Local CLI Demo

Set the Python path and reset seed data:

```powershell
$env:PYTHONPATH = "."
python run_demo.py --reset --twice
```

What this does:

| Action | Detail |
|---|---|
| Creates SQLite backend | Default file: `data/demo_reconciliation.db`. |
| Loads demo seed data | Parties, items, contracts, amendments, eligibility, invoice, ontology graph, matching policy. |
| Reconciles invoice | Default invoice id: `INV-1001`. |
| Runs twice | First run builds match cache; second run demonstrates fast-path cache reuse. |

Expected business result:

| Field | Expected Value |
|---|---|
| Invoice number | `1001` |
| Final status | `FAIL` |
| Total variance | `$52.00` |
| Line 1 | Pass |
| Line 2 | Price variance |
| Line 3 | Pass |
| Line 4 | Off contract |
| Line 5 | Pass |

To print JSON instead of the text table:

```powershell
python run_demo.py --reset --json
```

To view repository metrics:

```powershell
python -m workflows.cli --db data/demo_reconciliation.db --metrics
```

## Step 4: Run The Local API Demo With SQLite

Use this mode when you want to show API endpoints, Swagger UI, graph output, validation results, and findings.

Start the API:

```powershell
$env:PYTHONPATH = "."
$env:REPOSITORY_BACKEND = "sqlite"
$env:SQLITE_DB_PATH = "data/reconciliation.db"
$env:SEED_ON_STARTUP = "true"
$env:LOG_LEVEL = "INFO"
contract-reconcile-api --host 127.0.0.1 --port 8008 --reset
```

Keep this terminal running.

Open a second PowerShell terminal for smoke tests.

Health check:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/health
```

Readiness check:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/ready
```

Metrics:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/metrics
```

Run reconciliation:

```powershell
$response = Invoke-RestMethod -Method Post http://127.0.0.1:8008/v1/reconciliations `
  -ContentType "application/json" `
  -Body '{"invoice_id":"INV-1001","correlation_id":"demo-001"}'

$response.final_status
$response.total_variance
$runId = $response.run.reconciliation_run_id
```

Get validation details:

```powershell
Invoke-RestMethod "http://127.0.0.1:8008/v1/reconciliations/$runId/validation-results"
```

Get findings:

```powershell
Invoke-RestMethod "http://127.0.0.1:8008/v1/reconciliations/$runId/findings"
```

Get ontology graph:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/v1/ontology/graph
```

Swagger UI:

```text
http://127.0.0.1:8008/docs
```

If port `8008` is already in use, start the API on another port:

```powershell
contract-reconcile-api --host 127.0.0.1 --port 8010 --reset
```

## Step 5: Run The Container Demo

Use this when you want a packaged API demo without activating a local Python virtual environment.

```powershell
cd deployment
docker compose up --build
```

The container starts the API at:

```text
http://127.0.0.1:8008
```

Smoke test from another terminal:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/health
Invoke-RestMethod -Method Post http://127.0.0.1:8008/v1/reconciliations `
  -ContentType "application/json" `
  -Body '{"invoice_id":"INV-1001","correlation_id":"docker-demo-001"}'
```

Stop the container:

```powershell
docker compose down
```

Return to project root:

```powershell
cd ..
```

## Step 6: Configure The Databricks Backend

Use this mode when you want the API to operate against Unity Catalog Delta tables.

### 6.1 Create The Unity Catalog Tables

In Databricks SQL Editor, a Databricks notebook, or a Databricks deployment job, run:

```text
sql/databricks_lakehouse_schema.sql
```

This creates:

| Schema | Responsibility |
|---|---|
| `platform_dev.pspa_bronze` | Raw structured payload preservation. |
| `platform_dev.pspa_silver` | Conformed business entities and amendment-effective terms. |
| `platform_dev.pspa_ontology` | API runtime ontology graph, matching policy, match cache, validation evidence, findings, and audit. |
| `platform_dev.pspa_gold` | BI-ready summaries, line facts, dispute queue, and recovery opportunities. |
| `platform_dev.pspa_ops` | Pipeline and workflow run logs. |

### 6.2 Grant Access

Use enterprise-approved groups and service principals. At minimum:

| Principal | Required Access |
|---|---|
| Reconciliation API service principal | Use catalog, use schema, read/write `platform_dev.pspa_ontology`. |
| Reconciliation jobs | Read Silver, write Ontology, write Gold, write Ops. |
| Data engineering jobs | Write Bronze and Silver. |
| Analysts | Read Gold and approved views. |

Example grant pattern:

```sql
GRANT USE CATALOG ON CATALOG platform_dev TO `grp_pspa_reconciliation_jobs`;
GRANT USE SCHEMA ON SCHEMA platform_dev.pspa_ontology TO `grp_pspa_reconciliation_jobs`;
GRANT SELECT, MODIFY ON SCHEMA platform_dev.pspa_ontology TO `grp_pspa_reconciliation_jobs`;
GRANT SELECT ON SCHEMA platform_dev.pspa_gold TO `grp_pspa_ap_analysts`;
```

Adjust group names and privileges to match your Unity Catalog policy.

### 6.3 Load Structured Data

The ingestion/parsing step is out of scope for this demo because contract and invoice data are assumed to already be structured.

For Databricks backend execution, the reconciliation API needs these runtime tables populated in `platform_dev.pspa_ontology`:

| Table | Why It Is Needed |
|---|---|
| `party` | Supplier, member, GPO, facility identity. |
| `item` | Canonical item identity. |
| `uom_conversion` | Unit-of-measure normalization. |
| `contract` | Contract header and supplier relationship. |
| `contract_version` | Base contract and amendment versioning. |
| `contract_line_term` | Versioned line-level pricing terms. |
| `effective_contract_line_term` | Amendment-resolved active terms used for matching. |
| `member_eligibility` | Member/facility eligibility for contract and tier. |
| `invoice` | Invoice header to reconcile. |
| `invoice_line` | Invoice lines to match and validate. |
| `node` and `edge` | Ontology graph endpoint and explainability. |
| `matching_policy` | Matching weights, thresholds, and price tolerance. |

The reconciliation API writes these result tables:

| Table | Written By API |
|---|---|
| `reconciliation_run` | Run lifecycle and counts. |
| `validation_result` | Rule-level result for each invoice line. |
| `finding` | Line-level compliance, variance, off-contract, or review outcome. |
| `audit_event` | Run and line-level audit events. |
| `match_cache` | High-confidence match reuse cache. |

Recommended Databricks data flow:

```text
platform_dev.pspa_bronze
  -> platform_dev.pspa_silver
  -> platform_dev.pspa_ontology runtime mirrors and graph
  -> reconciliation API / job
  -> platform_dev.pspa_ontology evidence
  -> platform_dev.pspa_gold serving tables
```

For a simple Databricks demo, copy conformed Silver entities into the ontology runtime mirror tables after Silver is built:

```sql
INSERT INTO platform_dev.pspa_ontology.party
SELECT * FROM platform_dev.pspa_silver.party;

INSERT INTO platform_dev.pspa_ontology.item
SELECT * FROM platform_dev.pspa_silver.item;

INSERT INTO platform_dev.pspa_ontology.uom_conversion
SELECT * FROM platform_dev.pspa_silver.uom_conversion;

INSERT INTO platform_dev.pspa_ontology.contract
SELECT * FROM platform_dev.pspa_silver.contract;

INSERT INTO platform_dev.pspa_ontology.contract_version
SELECT * FROM platform_dev.pspa_silver.contract_version;

INSERT INTO platform_dev.pspa_ontology.contract_line_term
SELECT * FROM platform_dev.pspa_silver.contract_line_term;

INSERT INTO platform_dev.pspa_ontology.effective_contract_line_term
SELECT * FROM platform_dev.pspa_silver.effective_contract_line_term;

INSERT INTO platform_dev.pspa_ontology.member_eligibility
SELECT * FROM platform_dev.pspa_silver.member_eligibility;

INSERT INTO platform_dev.pspa_ontology.invoice
SELECT * FROM platform_dev.pspa_silver.invoice;

INSERT INTO platform_dev.pspa_ontology.invoice_line
SELECT * FROM platform_dev.pspa_silver.invoice_line;
```

For production, use `MERGE INTO` or Lakeflow jobs instead of blind inserts so the load is idempotent.

### 6.4 Set Databricks API Environment Variables

```powershell
$env:REPOSITORY_BACKEND = "databricks"
$env:DATABRICKS_SERVER_HOSTNAME = "<workspace-host>"
$env:DATABRICKS_HTTP_PATH = "<sql-warehouse-http-path>"
$env:DATABRICKS_TOKEN = "<service-principal-token>"
$env:DATABRICKS_CATALOG = "platform_dev"
$env:DATABRICKS_SCHEMA = "pspa_ontology"
$env:SEED_ON_STARTUP = "false"
$env:LOG_LEVEL = "INFO"
```

Important:

| Setting | Why |
|---|---|
| `DATABRICKS_CATALOG=platform_dev` | Catalog where all PSPA schemas live. |
| `DATABRICKS_SCHEMA=pspa_ontology` | Runtime schema used by the API repository adapter. |
| `SEED_ON_STARTUP=false` | Databricks data should be loaded by pipelines, not local seed code. |

### 6.5 Start API Against Databricks

```powershell
contract-reconcile-api --host 127.0.0.1 --port 8008
```

Health check:

```powershell
Invoke-RestMethod http://127.0.0.1:8008/health
```

Expected repository section:

```json
{
  "status": "ok",
  "backend": "databricks",
  "catalog": "platform_dev",
  "schema": "pspa_ontology"
}
```

Run reconciliation against an invoice that exists in `platform_dev.pspa_ontology.invoice`:

```powershell
Invoke-RestMethod -Method Post http://127.0.0.1:8008/v1/reconciliations `
  -ContentType "application/json" `
  -Body '{"invoice_id":"INV-1001","correlation_id":"databricks-demo-001"}'
```

If no default invoice is configured, `invoice_id` is required in the request.

## Step 7: Demo Narrative

Use this sequence for stakeholders:

| Step | What To Show | Message |
|---|---|---|
| 1 | `sql/databricks_lakehouse_schema.sql` | The solution is lakehouse-native with Bronze, Silver, Ontology, Gold, and Ops schemas. |
| 2 | `docs/DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md` | Each Delta table has a clear owner, grain, responsibility, and consumer. |
| 3 | CLI demo | The engine can reconcile a structured invoice deterministically. |
| 4 | API `/v1/reconciliations` | Same engine is exposed as a backend service. |
| 5 | API `/v1/ontology/graph` | Ontology provides explainable entities and relationships. |
| 6 | Findings endpoint | Price variance and off-contract outcomes are transparent. |
| 7 | Databricks namespace | Production backend uses `platform_dev.pspa_ontology` for runtime evidence and `platform_dev.pspa_gold` for analytics. |

## Step 8: What Reconciliation Logic Runs

The demo engine performs deterministic line-level reconciliation:

| Stage | Logic |
|---|---|
| Candidate retrieval | Finds active effective contract terms for supplier, item, and service date. |
| Matching score | Scores exact item match, member eligibility, date validity, UOM conversion, price proximity, and semantic text similarity. |
| Route selection | Uses matching policy thresholds for fast path, deep path, or manual review. |
| Validation | Runs contract found, item matched, member eligible, amendment version valid, UOM convertible, price within tolerance, and quantity limit rules. |
| Findings | Converts rule outcomes into pass, price variance, off-contract, or review findings. |
| Audit | Persists run and line-level audit events. |
| Cache | Stores high-confidence matches and reuses them on later runs. |

No LLM is required for the core financial decision. AI/LLM services can be added later for explanation, semantic retrieval, or analyst assistant workflows, but deterministic validation should remain the system of record for pass/fail financial outcomes.

## Step 9: Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| `contract-reconcile-api` not found | Package not installed in active environment. | Run `pip install -e ".[api]"` in the active venv. |
| `ModuleNotFoundError` for local packages | `PYTHONPATH` not set or wrong working directory. | Run from project root and set `$env:PYTHONPATH="."`. |
| Port already in use | Another service is using `8008`. | Start with `--port 8010`. |
| API returns invoice not found | Invoice id does not exist in backend. | Use `INV-1001` for seeded SQLite or load invoice into Databricks. |
| Databricks health returns error | Missing token, hostname, HTTP path, or warehouse access. | Recheck Databricks env vars and service principal permissions. |
| Databricks reconciliation fails on missing table | Unified SQL was not applied or wrong schema is configured. | Run `sql/databricks_lakehouse_schema.sql` and set `DATABRICKS_SCHEMA=pspa_ontology`. |
| Duplicate Databricks data after demo load | Used repeated `INSERT INTO` loads. | Use `MERGE INTO` or truncate demo runtime tables before reload. |

## Step 10: Clean Reset

Reset local SQLite demo:

```powershell
python run_demo.py --reset
```

Reset local API database:

```powershell
contract-reconcile-api --host 127.0.0.1 --port 8008 --reset
```

For Databricks, do not casually delete governed data. For a demo-only workspace, reset only the runtime output tables if approved:

```sql
DELETE FROM platform_dev.pspa_ontology.audit_event;
DELETE FROM platform_dev.pspa_ontology.finding;
DELETE FROM platform_dev.pspa_ontology.validation_result;
DELETE FROM platform_dev.pspa_ontology.reconciliation_run;
DELETE FROM platform_dev.pspa_ontology.match_cache;
```

Keep Silver source tables intact unless the data engineering owner approves a full reload.
