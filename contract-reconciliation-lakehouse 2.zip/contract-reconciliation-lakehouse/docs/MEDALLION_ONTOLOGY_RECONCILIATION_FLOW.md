# Medallion, Ontology, and Reconciliation Flow

## 1. Executive Summary

The ontology layer should be created primarily from the Silver layer, not from the Gold layer. Silver contains trusted, conformed, entity-level contract, invoice, item, party, member eligibility, UOM, and amendment data. That is the level of detail required to perform matching and validation. Gold is a downstream serving layer that should store the results of reconciliation, such as compliance facts, invoice summaries, leakage metrics, and dispute queues.

The recommended pattern is:

```text
Bronze -> Silver -> Ontology + Reconciliation -> Gold
                  \                         /
                   \-> semantic graph -----/
```

The ontology is built from Silver before reconciliation, then enriched during and after reconciliation with relationships and runtime entities such as `MATCHED_TO`, `FAILED_RULE`, `HAS_FINDING`, `SUPPORTED_BY`, `ExceptionCase`, `Dispute`, `DisputeLine`, and `DisputeMessage`. Gold consumes the reconciliation results and publishes business-ready analytics and operational queues.

## 2. Why Ontology Is Built From Silver, Not Gold

| Reason | Explanation | Risk If Built Only From Gold |
|---|---|---|
| Reconciliation needs pre-Gold data | Matching invoice lines to contracts requires contract versions, amendments, effective terms, member eligibility, item mappings, UOM conversions, and service dates before final results exist. | Gold cannot drive reconciliation because Gold is produced after reconciliation. |
| Avoids circular dependency | The reconciliation engine uses ontology relationships to produce validation results and Gold facts. | If ontology depends on Gold, and Gold depends on ontology-driven reconciliation, the design becomes circular. |
| Preserves line-level granularity | Silver keeps invoice-line and contract-line detail. Gold often aggregates or reshapes data for reporting. | Important evidence and contract lineage can be lost or flattened. |
| Supports amendment logic | Amendment resolution needs base contract, amendment sequence, effective date windows, superseded terms, and retroactive flags. | Gold usually has only final compliance results, not the full amendment decision path. |
| Supports explainability | Ontology edges can show why a line matched a term: item, eligibility, date, price, UOM, and amendment path. | Gold can show the answer but may not contain enough evidence to explain the answer. |
| Improves cache invalidation | Match cache can be invalidated when a Silver contract version or effective term changes. | Gold refreshes would lag behind the actual contract change and may invalidate too broadly. |
| Keeps layer responsibilities clean | Silver is the trusted entity layer, ontology is the semantic relationship layer, and Gold is the serving result layer. | Gold becomes overloaded with semantic, operational, and reporting responsibilities. |

Gold can still be connected to the ontology after reconciliation. For example, a Gold exception case can become an ontology node, and a finding can be related to validation evidence. The key point is that Gold should not be the primary source for the pre-reconciliation semantic graph.

## 3. Layer Responsibilities

| Layer | Primary Responsibility | Data Grain | Key Responsibilities | Example Tables |
|---|---|---|---|---|
| Bronze | Preserve raw structured source payloads. | Source record or payload. | Store parsed invoice and contract payloads as received, keep source metadata, preserve lineage, capture schema version, keep load status, support replay. | `bronze.contract_payload`, `bronze.invoice_payload` |
| Silver | Produce trusted conformed business entities. | Entity and line level. | Standardize IDs, normalize dates/currency/UOM, deduplicate, validate required fields, resolve item and party references, materialize amendment-aware effective terms, create conformed invoice lines. | `silver.contract`, `silver.contract_version`, `silver.contract_line_term`, `silver.effective_contract_line_term`, `silver.invoice`, `silver.invoice_line`, `silver.party`, `silver.item`, `silver.member_eligibility`, `silver.uom_conversion` |
| Ontology | Represent business meaning and relationships as a graph. | Semantic object and relationship. | Create nodes and edges from Silver entities, store rule catalog, matching policy, graph relationships, entity bindings, cache, explainability evidence, exception cases, and dispute drafts. | `ontology.node`, `ontology.edge`, `ontology.rule_catalog`, `ontology.matching_policy`, `ontology.match_cache`, `ontology.exception_case`, `ontology.dispute`, `ontology.dispute_line`, `ontology.dispute_message`, `ontology.audit_event` |
| Reconciliation Result Detail | Store granular operational outputs. | One run, invoice line, rule result, finding, exception, or dispute object. | Persist reconciliation run metadata, per-rule validation results, match evidence, findings, exception cases, dispute drafts, and audit events. In this implementation the runtime detail lives in the Ontology schema because it is part of the explainable graph-backed application state. | `ontology.reconciliation_run`, `ontology.validation_result`, `ontology.finding`, `ontology.exception_case`, `ontology.dispute`, `ontology.dispute_line`, `ontology.dispute_message`, `ontology.audit_event` |
| Gold | Publish business-ready outputs. | Fact, summary, queue, KPI. | Publish invoice compliance facts, line-level matched outcomes, recovery opportunities, supplier scorecards, dispute queues, and BI-ready summaries from the ontology reconciliation detail. | `gold.invoice_reconciliation_summary`, `gold.invoice_reconciliation_line`, `gold.dispute_case_queue`, `gold.price_assurance_recovery_opportunity` |
| Serving/API | Expose application-ready views and APIs. | Business object or API payload. | Serve reconciliation status, findings, graph relationships, validation evidence, operational metrics, and downstream workflow payloads. | API endpoints, Databricks SQL views, dashboard datasets |

## 4. End-to-End Data And Logic Flow

### Step 1: Source Data Arrives

Contract and invoice data are already structured and parsed before this solution starts. The source may provide JSON, CSV, database extracts, EDI-derived records, or API payloads.

Inputs include:

- Contract headers
- Contract versions and amendments
- Contract line terms
- Supplier, GPO, member, and facility entities
- Member eligibility and tier data
- Item master and cross-reference data
- UOM conversion data
- Invoice headers and invoice lines

### Step 2: Bronze Landing

Bronze stores the data as received with minimal transformation. The main purpose is lineage, replay, and audit.

Bronze actions:

1. Load structured contract and invoice payloads.
2. Add source metadata such as source system, file name, source record id, load id, ingestion timestamp, and payload hash.
3. Preserve raw payload JSON or raw column values.
4. Flag obviously unreadable or malformed records for quarantine.

Bronze does not perform reconciliation. Bronze should not apply business matching logic.

### Step 3: Bronze To Silver Quality And Normalization

Silver converts raw source data into canonical business entities.

Silver actions:

1. Standardize identifiers for contract, supplier, GPO, member, facility, item, and invoice.
2. Normalize dates, currency codes, UOM values, quantity fields, and price fields.
3. Deduplicate repeated records using source keys and payload hash.
4. Resolve item cross-references such as supplier SKU, manufacturer item number, GTIN, and internal item id.
5. Resolve party relationships such as GPO, supplier, distributor, member, and facility.
6. Validate required fields and referential integrity.
7. Create conformed invoice header and invoice line records.

### Step 4: Contract Amendment Resolution In Silver

Contract amendments must be resolved before reconciliation.

Silver contract logic:

1. Read base contract versions and amendment versions.
2. Order versions by contract id, amendment sequence, effective date, and retroactive flag.
3. Apply amendment actions such as add term, update price, change UOM, terminate line, extend term, or change tier.
4. Create `silver.effective_contract_line_term` with the final term that is valid for a date range.
5. Preserve links back to the originating contract version and amendment.

This step is critical because invoice service date matching must use the effective contract term, not just the latest loaded contract row.

### Step 5: Build Ontology From Silver

The ontology layer is built after Silver entities are conformed and before reconciliation runs.

Ontology build actions:

1. Create nodes for parties, items, contracts, contract versions, contract line terms, invoices, and invoice lines.
2. Create relationship edges such as `GOVERNS`, `PARTICIPATES_IN`, `HAS_VERSION`, `HAS_TERM`, `PRICES_ITEM`, `ELIGIBLE_FOR`, and `HAS_LINE`. Service terms without item identity can still participate in graph scoring through supplier, contract, term, category, and charge-term evidence.
3. Bind ontology nodes back to physical Silver rows for lineage.
4. Load rule catalog and matching policy.
5. Prepare match cache structures for fast-path reconciliation.

This produces the semantic graph needed by the matching and validation engines.

### Step 6: Reconciliation Starts

Reconciliation begins after Silver normalization, effective term materialization, and ontology graph construction.

The reconciliation engine reads:

- Silver invoice lines
- Silver effective contract terms
- Silver member eligibility
- Silver UOM conversions
- Ontology relationships
- Ontology matching policy
- Ontology rule catalog
- Ontology match cache
- Ontology charge-term, category, source-quality, exception, and dispute metadata

Reconciliation should not read Bronze directly. It should also not require Gold as an input.

### Step 7: Candidate Retrieval

For each invoice line, the engine retrieves candidate contract terms.

Candidate retrieval uses:

1. Supplier id
2. Item id, service category, or charge-term context
3. Invoice service date
4. Effective contract date range
5. Member eligibility
6. Contract tier
7. Optional ontology graph relationships
8. Optional semantic similarity or vector search for ambiguous item or service descriptions

The current application implementation first retrieves active exact item terms when a reliable item ID exists. If the line has no item ID or has service/category charge-term context, it falls back to supplier/date candidate terms and scores service charge terms using category, charge-term type, pricing basis, billing frequency, description similarity, source quality, and graph evidence. If a concrete item line has no exact candidate and no service context, it remains an off-contract exception instead of silently matching an unrelated service term.

### Step 8: Matching Logic

The current production-grade application uses deterministic weighted scoring. The implemented matching signals are:

| Signal | Purpose |
|---|---|
| Exact item match | Confirms invoice item maps to contract item. |
| Service or charge-term match | Supports subscription, variable-rate, overage, time-and-materials, and excluded charge terms when item identity is absent. |
| Category compatibility | Confirms invoice and contract category alignment where available. |
| Member eligibility | Confirms member or facility is eligible for the contract and tier. |
| Date validity | Confirms invoice service date falls inside the effective contract term date range. |
| UOM requirement or convertibility | Confirms invoice UOM equals/converts for item terms, or marks UOM as not required for eligible service terms. |
| Price proximity | Measures how close invoice unit price is to contract unit price. |
| Source quality | Blocks false financial validation when source quality or parse confidence is insufficient. |
| Semantic similarity | Uses token overlap today; can be upgraded to embeddings/vector search. |

The engine produces a score and route:

| Route | Meaning |
|---|---|
| `FAST_PATH` | High-confidence match; may use cache for repeated patterns. |
| `DEEP_PATH` | Candidate exists but requires deeper validation or review logic. |
| `MANUAL_REVIEW` | No candidate or low confidence; send to exception workflow. |

### Step 9: Validation Logic

After the best candidate is selected, deterministic validation rules execute.

Current validation rules:

| Rule | Purpose |
|---|---|
| `DATA_QUALITY_SUFFICIENT` | Source quality and parse confidence are sufficient for financial validation. |
| `CONTRACT_FOUND` | A valid contract line exists for the invoice line. |
| `CONTRACT_CANDIDATE_SELECTED` | Contract-level candidate selection is explainable and above policy threshold. |
| `CHARGE_TERM_CANDIDATE_SELECTED` | Specific contract charge term was selected from candidate terms. |
| `ITEM_OR_SERVICE_TERM_MATCHED` | Invoice line matches either an itemized supply term or a service/charge-term semantic candidate. |
| `CATEGORY_COMPATIBLE` | Invoice and contract category are compatible. |
| `MEMBER_ELIGIBLE` | Member/facility is eligible for the selected contract. |
| `AMENDMENT_VERSION_VALID` | Selected term is effective for the invoice service date and amendment sequence. |
| `CHARGE_TERM_ALLOWED` | Selected charge term is allowed and not explicitly excluded. |
| `UOM_NOT_REQUIRED_OR_CONVERTIBLE` | Invoice UOM converts for item terms, or UOM is optional for the selected service term. |
| `PRICE_WITHIN_TOLERANCE` | Invoice unit price is within configured tolerance. |
| `QUANTITY_LIMIT_VALID` | Invoice quantity is inside contract min/max limits. |
| `FREQUENCY_ALLOWED` | Invoice billing frequency is compatible with contract charge-term frequency. |
| `SUPPLIER_CONTACT_COMPLETE` | Supplier contact data is sufficient when a dispute may be created. |

Validation produces per-rule pass, fail, warn, or skip results with evidence.

### Step 10: Persist Reconciliation Detail

The engine stores detailed results before Gold aggregation.

Persisted detail includes:

- Reconciliation run
- Match candidate and route
- Validation results
- Findings
- Exception cases
- Dispute drafts, dispute lines, and dispute messages
- Variance amount
- Audit events
- Evidence JSON

These details support audit, explainability, replay, and dispute resolution.

### Step 11: Enrich Ontology With Reconciliation Results

After reconciliation, the ontology can be enriched with result relationships.

Examples:

| From | Relationship | To |
|---|---|---|
| Invoice line | `MATCHED_TO` | Contract line term |
| Invoice line | `HAS_FINDING` | Finding |
| Finding | `CREATES_EXCEPTION` | Exception case |
| Exception case | `DISPUTE_FOR` | Dispute |
| Dispute | `INCLUDES` | Invoice line |
| Dispute | `HAS_MESSAGE` | Dispute message |
| Finding | `SUPPORTED_BY` | Validation result |
| Reconciliation run | `PRODUCED` | Finding |
| Contract line term | `EXPLAINS_PRICE_FOR` | Invoice line |

This post-reconciliation enrichment is different from building ontology only from Gold. The core pre-reconciliation graph still comes from Silver.

### Step 12: Publish Gold

Gold is populated after reconciliation detail exists.

Gold actions:

1. Create line-level compliance facts.
2. Create invoice-level reconciliation summary.
3. Create supplier, member, category, and contract leakage metrics.
4. Create analyst-ready exception queues and dispute/recovery case queues from ontology exception/dispute detail.
5. Publish BI and dashboard-ready views.
6. Expose finance and AP workflow outputs.

Gold is the right layer for analytics and business consumption, but not the right source for pre-reconciliation ontology.

## 5. Where Reconciliation Comes Into Picture

Reconciliation starts after Silver and ontology are ready and before Gold is published.

```text
Bronze
  -> raw structured payload preservation

Silver
  -> normalization, conformance, amendment-effective terms

Ontology
  -> semantic graph, relationships, policies, rules

Reconciliation
  -> match invoice lines to itemized contract terms or service charge terms
  -> run 14 deterministic OOUX-aware validation rules
  -> create findings, exception cases, dispute drafts, and audit evidence

Gold
  -> publish facts, summaries, leakage analytics, exception queues
```

In other words:

- Bronze prepares traceable source data.
- Silver prepares trusted business entities.
- Ontology provides semantic relationships and matching context.
- Reconciliation uses Silver plus Ontology.
- Gold stores the business-ready outputs of reconciliation.

## 6. AI, LLM, And Deterministic Logic Strategy

The recommended production approach is deterministic-first, AI-assisted.

Financial reconciliation should not depend on an LLM to make final pass/fail or payable amount decisions. The final decision should be produced by deterministic matching, validation rules, tolerance policies, and auditable evidence.

### Current Implemented Logic

The current application uses:

1. Deterministic candidate retrieval from effective contract terms.
2. Weighted scoring using exact item match, eligibility, date validity, UOM convertibility, price proximity, and semantic text overlap.
3. Deterministic OOUX-aware validation rules.
4. Fast-path cache for high-confidence repeated matches.
5. Manual review routing for unmatched or low-confidence lines.
6. Exception-case creation for failed or ambiguous lines.
7. Supplier-contact-gated dispute draft creation.

This is production-appropriate for financial controls because every result can be explained and audited.

### Recommended AI/LLM Enhancements

| Capability | Recommended Service | Where It Fits | Decision Authority |
|---|---|---|---|
| Item and contract-line semantic matching | Databricks Mosaic AI embeddings, Databricks Vector Search, Azure OpenAI embeddings, or OpenAI embeddings | Candidate retrieval before deterministic scoring | Assistive only |
| Service charge-term semantic matching | Databricks Mosaic AI embeddings, Databricks Vector Search, Azure OpenAI embeddings, or OpenAI embeddings | Supplier/date candidate retrieval for service/category lines | Assistive only |
| Ambiguous item description normalization | LLM or embedding model behind MLflow Model Serving | Silver enrichment or deep-path candidate retrieval | Human or rule-confirmed |
| Contract clause interpretation | LLM extraction only if semi-structured clauses are introduced later | Bronze/Silver enrichment before ontology build | Human or deterministic rule-confirmed |
| Explanation narrative | LLM summarization | After validation results and findings exist | Assistive only |
| Analyst case summary | LLM summarization | Gold dispute queue and workflow | Assistive only |

### Recommended AI/LLM Guardrails

1. Do not allow the LLM to decide final compliance status by itself.
2. Do not allow the LLM to calculate final recoverable amount by itself.
3. Store model inputs, outputs, prompt version, model version, and confidence score.
4. Use LLM output only as a candidate signal or explanation.
5. Require deterministic validation to confirm any AI-suggested match.
6. Route low-confidence or high-dollar exceptions to manual review.
7. Keep model calls behind a service boundary such as MLflow Model Serving or an AI gateway.
8. Persist AI evidence in ontology or ops tables for audit.

### Recommended Target AI Architecture

```text
Silver item/contract/invoice text
  -> embedding generation
  -> Delta feature table / Vector Search index
  -> top-k candidate retrieval
  -> deterministic weighted scoring
  -> deterministic validation rules
  -> findings and Gold outputs
```

LLM usage should be optional and bounded. The core reconciliation engine must continue to work without LLM calls.

## 7. Recommended Physical Placement

| Data Product | Recommended Schema | Reason |
|---|---|---|
| Raw structured contract payload | `bronze` | Replay and lineage |
| Raw structured invoice payload | `bronze` | Replay and lineage |
| Canonical parties, items, contracts, invoices | `silver` | Trusted entity layer |
| Effective contract terms | `silver` | Required before reconciliation |
| Ontology nodes and edges | `ontology` | Semantic relationship layer |
| Rule catalog and matching policy | `ontology` | Business semantics and execution policy |
| Match cache | `ontology` or `ops` | Operational acceleration with contract-version awareness |
| Reconciliation run and validation result | `ontology` | Detailed operational result with evidence and graph context |
| Finding and exception case | `ontology` | Runtime application state used for explainability and workflow routing |
| Dispute draft, lines, and messages | `ontology`, then published to `gold` | Draft workflow state with supplier contact gate and audit trail |
| Invoice reconciliation summary | `gold` | BI and finance serving |
| Invoice reconciliation line fact | `gold` | BI and exception analytics |
| Dispute case queue | `gold` | Analyst workflow |

## 8. Final Recommendation

Build the ontology from Silver because Silver is the first layer where data is trusted, conformed, granular, and ready for business reasoning. Use the ontology to drive reconciliation, persist detailed validation evidence, create OOUX exception cases and dispute drafts, then publish Gold as the business-serving result layer.

The correct dependency direction is:

```text
Silver -> Ontology -> Reconciliation -> Gold
```

The incorrect dependency direction is:

```text
Gold -> Ontology -> Reconciliation
```

The second pattern is incorrect because Gold is an output of reconciliation, not the trusted semantic input needed to perform reconciliation.
