# PA OOUX Board 15 Logic Gap Analysis

## 1. Purpose

This document compares the attached `PA_OOUX_v0.16_Board_15.pdf` against the current `contract-reconciliation-lakehouse` implementation.

The PDF is a Price Assurance OOUX reference board. It is not a final specification, but it captures important object-model assumptions, backend flow, constraints, and open questions. This analysis identifies which logic is already present in the current solution and which logic is missing or only partially represented.

## 2. Executive Summary

The current solution already covers the core lakehouse and reconciliation engine flow shown on the board:

- Cache check.
- Ontology graph traversal.
- Candidate scoring.
- Rule validation.
- Findings.
- Audit event.
- Gold output.
- Contract version/amendment-effective matching.
- Line-level validation evidence.
- Databricks Medallion and Ontology architecture.

However, the current implementation is more oriented to structured GPO supply-chain item matching with item IDs, UOMs, and contract line terms. The OOUX board is broader and more Price Assurance/service-oriented. The main missing logic areas are:

1. Service-oriented semantic matching when no item master or SKU exists.
2. UOM-absent behavior that avoids false exceptions.
3. Explicit two-level matching: supplier-to-contract first, then contract-to-charge-term.
4. First-class Exception object and exception taxonomy.
5. First-class Dispute lifecycle with line-level grouping and message history.
6. Contact-data gating before dispute initiation.
7. Status taxonomy separation between match status, payment status, exception status, and engine route.
8. Parse-failure versus billing-violation distinction.
9. ChargeTermOntology taxonomy for service charge term types.
10. Annualized exposure and frequency violation logic.
11. Category-at-line-level matching and reporting.
12. Multi-line or compound matching.

## 3. What The Current Solution Already Covers

| OOUX / Board Concept | Current Coverage | Evidence In Current Repo | Assessment |
|---|---|---|---|
| Backend flow: cache -> graph traversal -> scoring -> validation -> findings -> audit -> Gold | Implemented | `matching/matching.py`, `ontology/repository.py`, `validation/validators.py`, `ontology/findings.py`, `sql/databricks_lakehouse_schema.sql` | Covered |
| Contract versioning / amendments | Implemented through `ContractVersion` and `EffectiveContractLineTerm` | `ontology/models.py`, `sample_data/seed_data.py`, `sql/databricks_lakehouse_schema.sql` | Covered |
| Candidate graph relationships | Implemented with `node`, `edge`, and graph-aware evidence | `ontology/repository.py`, `ontology/sqlite_repository.py`, `ontology/databricks_repository.py` | Covered |
| Deterministic rule validation | Implemented with seven rules | `validation/validators.py` | Covered, with different rule count than board |
| Audit events | Implemented | `ontology/engine.py`, repository implementations | Covered |
| Findings | Implemented as line-level `Finding` | `ontology/findings.py`, `ontology/models.py` | Partially covers Exception use cases |
| Gold dispute/recovery serving tables | Present as Gold output tables/design placeholders | `sql/databricks_lakehouse_schema.sql`, `gold/README.md` | Partially covered |
| Supplier/member/contract/item/invoice/invoice-line ontology | Implemented | `ontology/models.py`, `sample_data/seed_data.py` | Covered for GPO/item model |
| UOM conversion | Implemented and expanded | `UomConversion`, `normalize_invoice_unit_price`, `UOM_NOT_REQUIRED_OR_CONVERTIBLE` rule | Covered for itemized supply terms and service terms with optional UOM |
| Semantic text similarity | Basic token-overlap scoring | `matching/matching.py` | Partially covered |

## 4. Missing Or Partial Logic

### 4.1 Service-Oriented Matching Without Item Master

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| No item master / no SKU | Purchased services may have no SKUs. All matching may be semantic. | `InvoiceLine.item_id` and `ContractLineTerm.item_id` are required. Candidate lookup filters by exact item ID before scoring. | High-priority gap |

Current code:

- `InvoiceLine.item_id` is required.
- `ContractLineTerm.item_id` is required.
- `find_best_match()` calls `get_active_contract_terms(invoice.supplier_id, line.item_id, line.service_date)`.
- This means a line with no item ID will not reach semantic matching.

Recommended logic:

1. Allow nullable or placeholder item IDs for service lines.
2. Add `charge_term_description`, `category_code`, `service_code`, and optional `source_line_text`.
3. Add candidate retrieval by supplier + active contract + service date before item filtering.
4. Rank candidate charge terms by semantic similarity, category, clause metadata, price pattern, and graph context.
5. Use vector search or embedding retrieval for production semantic candidate selection.

Recommended new rules:

- `SERVICE_TERM_CANDIDATE_FOUND`
- `SEMANTIC_TERM_MATCH_CONFIDENT`
- `CATEGORY_COMPATIBLE`

### 4.2 UOM-Absent Handling

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| No standard UOM | Services may have no UOM. Missing UOM must not produce false exceptions. | Implemented through service-aware `UOM_NOT_REQUIRED_OR_CONVERTIBLE` logic. | Implemented |

Recommended logic:

1. Make UOM optional in the service matching path.
2. Introduce `pricing_basis`: `UNIT`, `FLAT_FEE`, `MONTHLY`, `ANNUAL`, `PER_EVENT`, `PERCENT_OF_SPEND`, `UNKNOWN`.
3. If both invoice and contract are service/flat-fee with no UOM, skip UOM validation rather than fail.
4. If one side has UOM and the other does not, route to manual review with `INSUFFICIENT_DATA`, not a hard price exception.
5. Add evidence field `uom_absence_reason`.

Recommended rule behavior:

| Scenario | Recommended Status |
|---|---|
| Product line with required UOM missing | `FAIL` or `WARN` depending source quality |
| Service line with both UOM absent | `SKIP` UOM rule, continue semantic/price validation |
| Service line with one UOM absent | `WARN` or manual review |
| Conversion missing for product line | `FAIL` |

### 4.3 Explicit Two-Level Matching

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Two-level matching | First select correct contract for supplier, then select correct charge term within that contract. | Candidate query directly filters supplier + item + date and returns terms. | Medium-high gap |

The current implementation can handle multiple candidate terms across supplier contracts, but it does not expose contract selection as a separate explainable step.

Recommended logic:

1. Add `ContractCandidate` object with score/evidence.
2. Stage 1: rank contracts by supplier, facility/member, date, status, legal entity, category, contract reference, and graph relationships.
3. Stage 2: within selected contracts, rank charge terms by semantic/price/category/term-type evidence.
4. Persist both contract match evidence and term match evidence.

Recommended output additions:

- `matched_contract_score`
- `matched_contract_reason`
- `contract_candidate_count`
- `term_candidate_count`
- `contract_selection_evidence`

### 4.4 ChargeTermOntology Taxonomy

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| ChargeTermOntology | Types: `SUBSCRIPTION`, `VARIABLE_RATE`, `OVERAGE`, `TIME_AND_MATERIALS`, `EXCLUDED`. | Contract terms have `action_type`, UOM, price, min/max, description. | Medium-high gap |

Recommended additions:

- Add `charge_term_type` or `pricing_model` to `ContractLineTerm` and `EffectiveContractLineTerm`.
- Add ontology node type `charge_term_type`.
- Add edge `TERM_HAS_TYPE`.
- Add rule behavior by term type.

Example validation differences:

| Charge term type | Validation behavior |
|---|---|
| `SUBSCRIPTION` | Check period, frequency, recurring amount. |
| `VARIABLE_RATE` | Check rate basis and variable metric. |
| `OVERAGE` | Check threshold, included amount, overage rate. |
| `TIME_AND_MATERIALS` | Check hours/units and allowed labor/material rate. |
| `EXCLUDED` | Route billed amount to unauthorized/unmapped exception. |

### 4.5 First-Class Exception Object

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Exception | Object on `InvoiceLine` with type, status, variance, annualized exposure, explanation, remediation, dismissal reason, human decision. | Current `Finding` summarizes result but does not model full exception lifecycle. | High-priority gap |

Board exception types:

- `Rate Above Contract`
- `Unmapped Charge`
- `Unmatched Line`
- `Expedite Fee`
- `Insufficient Data`
- `Frequency Violation`
- `Unauthorized Line Item`
- `Tax Charge on Tax-Exempt Entity`

Current finding types:

- `COMPLIANT`
- `OFF_CONTRACT`
- `PRICE_VARIANCE`
- `VALIDATION_FAILURE`

Recommended additions:

1. Add `ExceptionCase` ontology model/table.
2. Add `exception_type`, `exception_status`, `detected_at`, `annualized_exposure`, `explanation`, `remediation_suggestion`, `dismissal_reason`, `human_decision`.
3. Map validation/finding outcomes into OOUX exception taxonomy.
4. Add lifecycle transitions: `OPEN`, `DISMISSED`, `INVESTIGATING`, `DISPUTED`, `RESOLVED`, `CLOSED`.
5. Add Gold `exception_work_queue` as a real table, not only a README placeholder.

### 4.6 Annualized Exposure And Frequency Violation

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Annualized exposure | Compute projected annual overpayment from variance and invoice frequency. | Current logic computes one-line variance only. | Medium gap |
| Frequency violation | Requires invoice frequency data source. | No invoice frequency model. | Medium gap |

Recommended additions:

- Add `invoice_frequency` or `billing_frequency` source field.
- Add `AnnualizedExposure` calculation:
  `projected_annual_overpayment = variance_amount * expected_periods_per_year`
- Add `FREQUENCY_ALLOWED` rule.
- Add `billing_period_start`, `billing_period_end`, `billing_frequency`, and `recurrence_key`.

### 4.7 First-Class Dispute Lifecycle

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Dispute | Formal challenge at invoice-line level with many line IDs, supplier email metadata, status, template, sent/responded/resolution fields. | Gold `dispute_case_queue` exists, but runtime model lacks `Dispute` and `DisputeMessage`. | High-priority gap if workflow demo must include disputes |

Recommended additions:

1. Add `Dispute` model/table.
2. Add `DisputeLine` or bridge table to support multiple invoice lines in one dispute.
3. Add `DisputeMessage` table for email/message history.
4. Add line-level grouping logic: same supplier, same root cause, same invoice or eligible bundle.
5. Add dispute status transitions:
   `DRAFT`, `READY_TO_SEND`, `SENT`, `SUPPLIER_RESPONDED`, `ACCEPTED`, `REJECTED`, `CREDIT_PENDING`, `CLOSED`.

### 4.8 Contact Data Gating

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Contact data required | `supplier.contactEmail` must be populated before dispute initiation. | Supplier is represented as generic `Party` without contact fields. Gold queue has no gating logic. | High-priority for dispute workflow |

Recommended logic:

- Add supplier profile/contact table:
  - `supplier_id`
  - `contact_email`
  - `contact_name`
  - `contact_phone`
  - `contact_data_complete`
  - `last_verified_at`
- Add validation:
  - `SUPPLIER_CONTACT_COMPLETE`
- If missing contact data:
  - create exception/work queue item
  - block dispute send
  - route to data stewardship

### 4.9 Status Taxonomy Separation

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Match status vs exception type vs payment status | Board warns these are separate concepts. | Current solution has `Route`, `ValidationStatus`, `Finding.status`, `finding_type`, and `ReconciliationRun.status`; no invoice payment status or OOUX match status taxonomy. | Medium-high gap |

Recommended additions:

| Status Concept | Proposed Field | Example Values |
|---|---|---|
| Engine route | `route` | `FAST_PATH`, `DEEP_PATH`, `MANUAL_REVIEW` |
| Match outcome | `match_status` | `MATCHED`, `UNMATCHED`, `PARTIAL_MATCH`, `REJECTED`, `NO_MATCH`, `EXCEPTION` |
| Validation result | `validation_status` | `PASS`, `FAIL`, `WARN`, `SKIP` |
| Exception lifecycle | `exception_status` | `OPEN`, `DISMISSED`, `INVESTIGATING`, `DISPUTED`, `CLOSED` |
| Payment status | `payment_status` | `PAID`, `PENDING_APPROVAL`, `REJECTED`, etc. |
| Dispute status | `dispute_status` | `DRAFT`, `SENT`, `RESPONDED`, `RESOLVED`, `CLOSED` |

### 4.10 Parse-Failure Versus Billing-Violation Reject

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| REJECT distinction | Board says parse-failure reject must not be confused with billing violation. | Current input assumption is structured/parsed data, so parsing quality is not modeled. | Medium gap |

Even though the current solution no longer ingests PDFs/images, source quality still matters. If upstream parsing feeds structured data, the reconciliation engine needs to know whether a line is trusted enough for financial validation.

Recommended additions:

- Add `source_quality_status` and `parse_confidence` to Bronze/Silver invoice line.
- Add `DATA_QUALITY_SUFFICIENT` rule before financial rules.
- If parse/source quality is poor, route to `INSUFFICIENT_DATA` or `DATA_QUALITY_REJECT`, not `PRICE_VARIANCE`.
- Add finding root cause `PARSE_FAILURE` or `SOURCE_DATA_QUALITY`.

### 4.11 Category At Line Level

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Category at line level | Both `ContractLine` and `InvoiceLine` carry category. Category is not only at contract/invoice level. | `Item.category_code` exists; line-level dataclasses do not carry category. SQL line tables also do not expose category columns. | Medium gap |

Recommended additions:

- Add `category_code` to `InvoiceLine`, `ContractLineTerm`, and `EffectiveContractLineTerm`.
- Add ontology edge `LINE_IN_CATEGORY`.
- Add rule `CATEGORY_COMPATIBLE`.
- Use category in candidate retrieval and Gold analytics.

### 4.12 Multi-Line / Compound Matching

| Area | Board Open Item | Current Behavior | Gap |
|---|---|---|---|
| Many contract lines to one invoice line | Architecture unresolved in board. | Current logic is one invoice line to one contract term. | Future-state gap |

Recommended additions:

- Add candidate grouping strategy.
- Support `MatchCandidateGroup`.
- Add bridge table `invoice_line_match_component`.
- Support allocation methods: amount split, quantity split, service bundle, clause bundle.

### 4.13 Payment Status And Interception Status

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| Invoice payment status / interception status | Invoice has `paymentStatus`, `poType`, `interceptionStatus`. | Current `Invoice` has no payment/interception fields. | Medium gap |

Recommended additions:

- Add `payment_status`, `po_type`, `interception_status`.
- Add workflow routing:
  - pre-payment prevention
  - post-payment recovery
  - informational analytics only

### 4.14 Supplier / Facility / Health System Shape

| Area | Board Expectation | Current Behavior | Gap |
|---|---|---|---|
| HealthSystem, Facility, Supplier, User | Board models these as explicit PA objects. | Current `Party` can represent them generically but lacks PA-specific attributes. | Low-medium gap |

Recommended additions:

- Extend `Party` through `party_profile` or specialized tables:
  - `health_system_profile`
  - `facility_profile`
  - `supplier_profile`
  - `user_profile`
- Add fields such as `gl_code`, `primary_facility_id`, `contact_data_complete`, `total_ap_spend`, `invoice_count`.

## 5. Priority Recommendations

| Priority | Recommendation | Why It Matters |
|---|---|---|
| P0 | Add service-friendly matching path when `item_id` is missing or unreliable. | The board says PA services may have no SKU/item master. Current exact item lookup will miss these. |
| P0 | Make UOM validation context-aware and do not fail service lines when UOM is absent. | Prevents false exceptions, explicitly called out by the board. |
| P0 | Add first-class Exception model and taxonomy. | Board centers exception workflow on `InvoiceLine`; current `Finding` is not enough for lifecycle management. |
| P1 | Add explicit two-stage contract then charge-term matching. | Needed for explainability when one supplier has multiple active contracts. |
| P1 | Add Dispute and DisputeMessage runtime tables/models. | Gold queue alone is not enough for workflow demo or lifecycle audit. |
| P1 | Add contact-data completeness gate before dispute creation/sending. | Board says supplier contact email is required. |
| P1 | Separate match status, payment status, exception status, route, validation status, and dispute status. | Prevents the `Rejected` ambiguity called out in the board. |
| P2 | Add annualized exposure and invoice frequency logic. | Needed for PA impact sizing and frequency violation exception type. |
| P2 | Add category at line level and category-compatible rule. | Board says category belongs on lines. |
| P2 | Add parse/source-quality status even if ingestion is external. | Avoids treating upstream parse failure as a billing violation. |

## 6. Suggested Data Model Additions

### 6.1 Silver Additions

| Table | Additions |
|---|---|
| `pspa_silver.invoice` | `payment_status`, `po_type`, `interception_status` |
| `pspa_silver.invoice_line` | nullable `item_id`, `category_code`, `charge_term_text`, `billing_period_start`, `billing_period_end`, `billing_frequency`, `parse_confidence`, `source_quality_status` |
| `pspa_silver.contract_line_term` | nullable `item_id`, `category_code`, `charge_term_type`, `pricing_basis`, `frequency`, `included_quantity`, `overage_rate`, `exclusion_flag` |
| `pspa_silver.effective_contract_line_term` | same term additions after amendment materialization |
| `pspa_silver.supplier_profile` | `supplier_id`, `contact_email`, `contact_data_complete`, `primary_facility_id`, `gl_code` |

### 6.2 Ontology Additions

| Table / Object | Purpose |
|---|---|
| `exception_case` | First-class exception lifecycle at invoice-line level. |
| `exception_type_catalog` | Governed list of PA exception types and rule mappings. |
| `dispute` | Formal supplier challenge header. |
| `dispute_line` | Bridge from dispute to many invoice lines. |
| `dispute_message` | Email/message history and supplier responses. |
| `charge_term_type` | Charge term ontology taxonomy. |
| `contract_candidate_evidence` | Stage-1 contract selection evidence. |
| `term_candidate_evidence` | Stage-2 term selection evidence. |

### 6.3 Gold Additions

| Table | Purpose |
|---|---|
| `exception_work_queue` | Analyst queue with exception state, owner, SLA, and action. |
| `dispute_case` | Formal dispute case serving table. |
| `dispute_case_line` | Line-level dispute grouping. |
| `dispute_message` | Supplier communication history. |
| `supplier_price_assurance_summary` | Rollup by supplier, category, exception type, recovery status. |

## 7. Recommended Algorithm Updates

### 7.1 Current Matching Flow

```text
invoice line -> supplier + item + service date -> candidate effective terms
candidate -> eligibility + date + UOM + price + semantic + graph score
best candidate -> validation -> finding
```

### 7.2 Recommended OOUX-Aligned Matching Flow

```text
invoice line
  -> source quality gate
  -> supplier/facility/member/date contract candidate retrieval
  -> contract candidate scoring
  -> charge term candidate retrieval within selected contracts
  -> item/SKU match if available
  -> semantic charge term match if SKU missing
  -> category compatibility
  -> pricing-basis-specific UOM/price/frequency checks
  -> graph support evidence
  -> deterministic validation
  -> ExceptionCase creation when failed or ambiguous
  -> Dispute readiness gate
  -> Gold queue and recovery outputs
```

## 8. Recommended New Validation Rules

| Rule | Purpose |
|---|---|
| `DATA_QUALITY_SUFFICIENT` | Prevent parse/source-quality failures from becoming false billing exceptions. |
| `CONTRACT_CANDIDATE_SELECTED` | Explicitly validates stage-1 contract selection. |
| `CHARGE_TERM_CANDIDATE_SELECTED` | Explicitly validates stage-2 term selection. |
| `SEMANTIC_TERM_MATCH_CONFIDENT` | Handles service matching when item ID is missing. |
| `CATEGORY_COMPATIBLE` | Enforces line-level category compatibility. |
| `UOM_NOT_REQUIRED_OR_CONVERTIBLE` | Replaces hard UOM failure for service lines. |
| `FREQUENCY_ALLOWED` | Supports frequency violation exceptions. |
| `CHARGE_TERM_ALLOWED` | Supports unauthorized charge and excluded terms. |
| `SUPPLIER_CONTACT_COMPLETE` | Blocks dispute initiation when supplier contact data is incomplete. |
| `TAX_EXEMPT_VALIDATION` | Supports tax-on-tax-exempt exception. |

## 9. Bottom Line

The current solution is strong as a Databricks-backed, ontology-aware GPO supply-chain contract reconciliation engine. It has the right architectural foundation and already covers much of the backend flow shown on the OOUX board.

The main missing work is to add the Price Assurance workflow layer on top of the reconciliation foundation:

- Service/charge-term semantic matching.
- Context-aware UOM handling.
- Exception lifecycle.
- Dispute lifecycle.
- Contact-data gate.
- Status taxonomy cleanup.
- Annualized exposure/frequency logic.
- Source-quality differentiation.

These additions should be modeled in Silver and Ontology first, then projected into Gold work queues and dashboards.
