# Price Assurance Seed Gap Analysis

Source analyzed:

```text
outputs/Entity/priceAssuranceSeed.ts
```

## 1. Executive Summary

The `priceAssuranceSeed.ts` file contains a richer Price Assurance / AP workflow domain than the current reconciliation demo schema. Our current solution covers the core reconciliation engine:

- Supplier/member/facility as parties
- Contracts and contract lines
- Invoices and invoice lines
- Matching
- Rule-level validation results
- Findings
- Ontology graph nodes/edges
- Gold compliance facts and exception queue

However, the seed file includes additional entities and fields needed for a production Price Assurance application:

- Health system and facility hierarchy
- Supplier profile, aliases, category, GL coding, AP spend metrics
- Contract clause evidence and renewal terms
- Invoice payment workflow fields
- Invoice line exception fields and remediation copy
- Detection rule trigger/action metadata
- User/persona information
- Dispute lifecycle and message thread
- Demo/walkthrough configuration

These should be incorporated into the Medallion architecture as Bronze raw fields, Silver conformed entities, Ontology graph relationships, and Gold serving facts.

## 2. Exported Entities In Seed File

| Export | Meaning | Production Placement |
|---|---|---|
| `healthSystem` | Health system with facilities and AP contact | Silver party/facility model + ontology hierarchy |
| `suppliers` | Supplier profile and AP summary metrics | Silver party/supplier profile + Gold supplier scorecard |
| `contracts` | Contract headers and contract line terms | Silver contract, contract version, contract line term |
| `invoices` | Invoice headers and invoice lines with seeded results | Bronze raw, Silver invoice/line, Silver validation/finding, Gold facts |
| `detectionRules` | Rule catalog used by UI/reconciliation | Ontology rule catalog |
| `paUsers` | Analyst/team-leader personas | Silver user/role or application identity table |
| `demoFlow` | Demo walkthrough metadata | App/demo config, not core data model |
| `disputes` | Supplier dispute cases and message threads | Gold exception/dispute workflow + ontology relationships |

## 3. Field Inventory And Recommended Placement

### 3.1 Health System

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `healthSystem.id` | Health system ID | `silver.party.party_id` with `party_type = HEALTH_SYSTEM` | Covered generically, but not explicitly seeded |
| `healthSystem.name` | Health system name | `silver.party.party_name` | Covered |
| `healthSystem.apContact` | AP dispute contact email | `silver.party_contact` or `silver.health_system_profile` | Missing |
| `facilities[].id` | Facility ID | `silver.party.party_id` with `party_type = FACILITY` | Covered generically |
| `facilities[].name` | Facility name | `silver.party.party_name` | Covered |
| `facilities[].city` | Facility city | `silver.facility_profile.city` | Missing |
| `facilities[].state` | Facility state | `silver.facility_profile.state` | Missing |

Recommended additions:

- `silver.facility_profile`
- `silver.party_contact`
- Ontology edge: `HEALTH_SYSTEM HAS_FACILITY FACILITY`

### 3.2 Suppliers

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id`, `name`, `legalEntityName` | Supplier identity | `silver.party`, `silver.supplier_profile` | Legal entity profile missing |
| `knownAliases[]` | Supplier aliases | `silver.party_alias` | Missing |
| `categories[]` | Supplier categories | `silver.supplier_category`, `silver.category` | Missing dedicated category mapping |
| `glCode`, `glDescription` | GL classification | `silver.gl_account`, supplier/category mapping | Missing |
| `facility`, `facilityId` | Primary facility association | `silver.party_relationship` | Relationship covered, facility profile missing |
| `contractOnFile` | Contract availability indicator | `silver.supplier_profile.contract_on_file` or Gold scorecard | Missing |
| `contractCount`, `invoiceCount` | Supplier aggregate counts | Gold supplier scorecard | Missing |
| `contractExpiry` | Nearest contract expiry | Gold supplier scorecard or derived from Silver contracts | Missing as materialized metric |
| `paymentDeadline`, `daysUntilPayment` | AP payment timing | Gold supplier/AP exposure fact | Missing |
| `contactName`, `contactEmail` | Supplier contact | `silver.party_contact` | Missing |
| `accountManagerName`, `accountManagerPhone` | Supplier account manager | `silver.party_contact` | Missing |
| `potentialOverpayments` | Risk/exposure metric | `gold.supplier_price_assurance_summary` | Missing |
| `prePaidExceptions` | AP exposure metric | `gold.supplier_price_assurance_summary` | Missing |
| `inDispute` | Open dispute amount | `gold.supplier_price_assurance_summary` or dispute rollup | Missing |
| `totalAPSpend`, `totalInvoicedSpend` | Spend metrics | `gold.supplier_price_assurance_summary` | Missing |
| `status` | Supplier status | `silver.supplier_profile.status` | Missing |
| `exceptionCount` | Exception count | Gold supplier scorecard | Missing |
| `notes` | Analyst notes | `silver.supplier_profile.notes` or `ontology.audit_event` | Missing |
| `sourceMethod` | How supplier/data was sourced | Bronze metadata / Silver profile | Missing |

Recommended additions:

- `silver.supplier_profile`
- `silver.party_alias`
- `silver.party_contact`
- `silver.category`
- `silver.gl_account`
- `silver.supplier_category`
- `gold.supplier_price_assurance_summary`

### 3.3 Contracts

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id` | Contract ID | `silver.contract.contract_id` | Covered |
| `supplierId`, `supplierName` | Supplier reference | `silver.contract.supplier_id`, party join | Covered |
| `category` | Contract category | `silver.contract.category_code` or category bridge | Missing |
| `glCode` | GL classification | `silver.contract.gl_code` / `silver.gl_account` | Missing |
| `facility`, `facilityId` | Facility scope | `silver.contract_facility_scope` or party relationship | Missing dedicated scope |
| `effectiveDate`, `expirationDate` | Contract term | `silver.contract` | Covered |
| `renewalTerms` | Renewal language | `silver.contract.renewal_terms` | Missing |
| `status` | Contract status | `silver.contract.contract_status` | Covered |
| `lineCount` | Count of lines | Derived metric | Not needed as base field |
| `contractLines[].id` | Contract line ID | `silver.contract_line_term.contract_line_id` | Covered |
| `contractLines[].description` | Contract line description | `silver.contract_line_term.description` | Covered |
| `contractLines[].uom` | Contract UOM | `silver.contract_line_term.contract_uom` | Covered |
| `contractLines[].unitPrice` | Contract unit price | `silver.contract_line_term.unit_price` | Covered |
| `contractLines[].category` | Line category | `silver.contract_line_term.category_code` | Missing |
| `contractLines[].clauseNumber` | Clause reference | `silver.contract_clause.clause_number` | Missing |
| `contractLines[].clauseTitle` | Clause title | `silver.contract_clause.clause_title` | Missing |
| `contractLines[].fullLanguage` | Contract evidence text | `silver.contract_clause.full_language`, `ontology.triple` evidence | Missing |

Recommended additions:

- `silver.contract.category_code`
- `silver.contract.gl_code`
- `silver.contract.renewal_terms`
- `silver.contract_facility_scope`
- `silver.contract_clause`
- Ontology edges: `CONTRACT SCOPED_TO FACILITY`, `CONTRACT_LINE SUPPORTED_BY CLAUSE`

### 3.4 Invoices

Seed invoice header fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id` | Invoice ID | `silver.invoice.invoice_id` | Covered |
| `supplierId`, `supplierName` | Supplier reference | `silver.invoice.supplier_id`, party join | Covered |
| `invoiceNumber` | Invoice number | `silver.invoice.invoice_number` | Covered |
| `invoiceDate` | Invoice date | `silver.invoice.invoice_date` | Covered |
| `invoiceFrequency` | Monthly/quarterly/etc. | `silver.invoice.invoice_frequency` | Missing |
| `category` | Spend category | `silver.invoice.category_code` | Missing |
| `glCode` | GL account | `silver.invoice.gl_code` | Missing |
| `facility`, `facilityId` | Facility association | `silver.invoice.facility_id` | Missing explicit field |
| `totalAmount` | Invoice total | `silver.invoice.total_amount` | Covered |
| `paymentStatus` | AP payment state | `silver.invoice.payment_status` | Missing |
| `paymentDeadline` | AP deadline | `silver.invoice.payment_deadline` | Missing |
| `daysUntilPayment` | Derived timing metric | Gold AP queue metric | Missing |
| `matchStatus` | Overall match state | `gold.invoice_compliance_summary.match_status` | Missing |
| `verdict` | Good to Pay / Needs Review | `gold.invoice_compliance_summary.verdict` | Missing |
| `exceptionCount` | Count of exceptions | Gold summary | Missing |

Recommended additions:

- Add invoice AP/workflow fields to `silver.invoice`
- Add business summary fields to `gold.invoice_compliance_summary`

### 3.5 Invoice Lines

Seed line fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id` | Invoice line ID | `silver.invoice_line.invoice_line_id` | Covered |
| `description` | Line description | `silver.invoice_line.description` | Covered |
| `uom` | Invoice UOM | `silver.invoice_line.invoice_uom` | Covered |
| `quantity` | Quantity | `silver.invoice_line.quantity` | Covered |
| `billedPrice` | Invoice unit price | `silver.invoice_line.unit_price` | Covered |
| `billedTotal` | Extended amount | `silver.invoice_line.extended_amount` | Covered |
| `matchedContractId` | Matched contract output | `silver.validation_result` / `gold.invoice_line_compliance_fact` | Covered as result, not source |
| `matchedLineId` | Matched contract line output | `silver.validation_result` / Gold fact | Covered as result, not source |
| `contractedRate` | Expected contract rate | Gold fact / validation result evidence | Covered partially |
| `variance` | Variance amount | `silver.validation_result`, Gold fact | Covered |
| `matchStatus` | Matched/Rejected/Unmatched/etc. | Gold line fact | Missing explicit `match_status` |
| `matchConfidenceScore` | Confidence score | `silver.invoice_line_contract_match` or Gold fact | Missing |
| `exceptionType` | Business exception type | `silver.finding.finding_type` / Gold exception queue | Covered partially |
| `severity` | Hard/soft | `silver.finding.severity` | Covered but enum needs hard/soft mapping |
| `status` | OK/Exception/Review/Unmatched | Gold line fact / exception queue | Missing exact field |
| `explanation` | Analyst-facing explanation | `silver.finding.detail` | Covered |
| `remediation` | Recommended action | `gold.exception_work_queue.recommended_action` | Covered |

Important design note:

The seed file stores some fields as if reconciliation already happened. In production, these should not be trusted as source-of-truth outputs unless they come from an upstream adjudication system. Store them in Bronze raw payload; generate authoritative match/exception fields in Silver/Gold.

### 3.6 Detection Rules

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id` | Rule ID | `ontology.rule_catalog.rule_catalog_id` | Covered |
| `name` | Rule name | `ontology.rule_catalog.rule_name` | Missing |
| `type` | Exception/rule type | `ontology.rule_catalog.rule_code` or `exception_type` | Covered partially |
| `severity` | hard/soft | `ontology.rule_catalog.severity` | Covered, enum mapping needed |
| `description` | Rule description | `ontology.rule_catalog.description` | Covered |
| `trigger` | Trigger expression | `ontology.rule_catalog.rule_condition_sql` or expression DSL | Covered |
| `action` | Action/remediation behavior | `ontology.rule_catalog.action` | Missing |
| `enabled` | Active flag | `ontology.rule_catalog.active_flag` | Covered |

Recommended additions:

- `rule_name`
- `exception_type`
- `action`
- `block_auto_approval_flag`
- `requires_review_flag`

### 3.7 Users

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `paUsers.analyst.id` | User ID | `silver.application_user.user_id` | Missing |
| `name` | User name | `silver.application_user.display_name` | Missing |
| `initials` | UI initials | `silver.application_user.initials` | Missing |
| `title` | Job title | `silver.application_user.title` | Missing |
| key `analyst` / `team-leader` | Role/persona | `silver.application_user_role` | Missing |

Recommended additions:

- `silver.application_user`
- `silver.application_user_role`

### 3.8 Demo Flow

Seed fields:

- `startPage`
- `entryInvoiceId`
- `entrySupplierId`
- `entryContractId`
- `steps[]`
- `steps[].page`
- `steps[].action`
- `steps[].invoiceId`
- `steps[].supplierId`

Recommendation:

This is demo/UI configuration, not core reconciliation data. Store outside the Medallion data model unless the application needs guided walkthroughs.

Potential table:

- `app.demo_flow_config`

### 3.9 Disputes

Seed fields:

| Seed Field | Meaning | Target Layer/Table | Current Gap |
|---|---|---|---|
| `id` | Dispute ID | `gold.dispute_case.dispute_id` | Missing |
| `invoiceId` | Invoice reference | `gold.dispute_case.invoice_id` | Missing |
| `supplierId` | Supplier reference | `gold.dispute_case.supplier_id` | Missing |
| `disputedLineIds[]` | Disputed invoice lines | `gold.dispute_case_line` | Missing |
| `status` | Dispute state | `gold.dispute_case.status` | Missing |
| `initiatedAt` | Initiated timestamp | `gold.dispute_case.initiated_at` | Missing |
| `resolvedAt` | Resolved timestamp | `gold.dispute_case.resolved_at` | Missing |
| `resolutionType` | Credit memo/write-off/etc. | `gold.dispute_case.resolution_type` | Missing |
| `dismissalReason` | Why dismissed | `gold.dispute_case.dismissal_reason` | Missing |
| `thread[].id` | Message ID | `gold.dispute_message.message_id` | Missing |
| `thread[].from`, `to` | Message participants | `gold.dispute_message` | Missing |
| `thread[].subject`, `body` | Message content | `gold.dispute_message` | Missing |
| `thread[].sentAt` | Sent timestamp | `gold.dispute_message.sent_at` | Missing |
| `thread[].direction` | inbound/outbound | `gold.dispute_message.direction` | Missing |

Recommended additions:

- `gold.dispute_case`
- `gold.dispute_case_line`
- `gold.dispute_message`
- Ontology edges: `DISPUTE_FOR INVOICE`, `DISPUTE_INCLUDES INVOICE_LINE`, `DISPUTE_WITH SUPPLIER`

## 4. Missing Entities To Add

| Entity | Layer | Why Needed |
|---|---|---|
| `facility_profile` | Silver | Facility city/state and operational metadata |
| `party_alias` | Silver | Supplier matching by known aliases |
| `party_contact` | Silver | Supplier/AP contact and account manager |
| `supplier_profile` | Silver | Supplier-specific attributes not suitable for generic party |
| `category` | Silver | Spend category/service category dimension |
| `gl_account` | Silver | GL code and description dimension |
| `supplier_category` | Silver | Many-to-many supplier/category relationship |
| `contract_facility_scope` | Silver | Contracts may be facility-specific or health-system-wide |
| `contract_clause` | Silver | Clause number/title/full language evidence |
| `application_user` | Silver | Analyst/team leader identity |
| `application_user_role` | Silver | Persona/role mapping |
| `dispute_case` | Gold | Dispute lifecycle for exceptions |
| `dispute_case_line` | Gold | Link dispute to invoice lines |
| `dispute_message` | Gold | Dispute communication thread |
| `supplier_price_assurance_summary` | Gold | Supplier-level exposure, AP spend, exception metrics |
| `invoice_compliance_summary` enhancements | Gold | Verdict, match status, exception count, payment workflow |

## 5. Missing Fields To Add To Existing Tables

### `silver.contract`

Add:

- `category_code`
- `gl_code`
- `facility_id`
- `renewal_terms`

### `silver.contract_line_term`

Add:

- `category_code`
- `clause_id`
- `clause_number`
- `clause_title`
- `source_language`

Better normalized option:

- Store clause details in `silver.contract_clause` and reference `clause_id`.

### `silver.invoice`

Add:

- `invoice_frequency`
- `category_code`
- `gl_code`
- `facility_id`
- `payment_status`
- `payment_deadline`

Optional derived field:

- `days_until_payment`, preferably calculated in Gold.

### `silver.invoice_line`

Add if source system sends them:

- `source_match_status`
- `source_exception_type`
- `source_explanation`
- `source_remediation`

But authoritative generated fields should remain in:

- `silver.validation_result`
- `silver.finding`
- `gold.invoice_line_compliance_fact`
- `gold.exception_work_queue`

### `ontology.rule_catalog`

Add:

- `rule_name`
- `exception_type`
- `action`
- `block_auto_approval_flag`
- `requires_review_flag`

### `gold.invoice_line_compliance_fact`

Add:

- `match_status`
- `match_confidence_score`
- `exception_type`
- `exception_severity`
- `explanation`
- `remediation`

### `gold.invoice_compliance_summary`

Add or ensure:

- `payment_status`
- `payment_deadline`
- `days_until_payment`
- `match_status`
- `verdict`
- `exception_count`

## 6. Ontology Relationships To Add

| Relationship | From | To |
|---|---|---|
| `HAS_FACILITY` | Health system | Facility |
| `PRIMARY_FACILITY_FOR` | Facility | Supplier |
| `HAS_ALIAS` | Supplier | Alias |
| `HAS_CONTACT` | Supplier or health system | Contact |
| `CLASSIFIED_AS` | Supplier/contract/invoice line | Category |
| `CHARGED_TO_GL` | Supplier/contract/invoice | GL account |
| `SCOPED_TO_FACILITY` | Contract | Facility |
| `SUPPORTED_BY_CLAUSE` | Contract line term | Contract clause |
| `MATCHED_TO` | Invoice line | Contract line term |
| `VIOLATES_RULE` | Invoice line/finding | Detection rule |
| `HAS_FINDING` | Invoice line | Finding |
| `RECOMMENDS_ACTION` | Finding | Remediation/action |
| `DISPUTE_FOR` | Dispute case | Invoice |
| `DISPUTE_INCLUDES` | Dispute case | Invoice line |
| `DISPUTE_WITH` | Dispute case | Supplier |
| `MESSAGE_IN_THREAD` | Dispute case | Dispute message |
| `ASSIGNED_TO` | Exception/dispute | Application user |

## 7. Layer-by-Layer Target Mapping

### Bronze

Store every object from the TypeScript seed as raw JSON:

- `bronze.health_system_raw`
- `bronze.supplier_raw`
- `bronze.contract_raw`
- `bronze.contract_line_raw`
- `bronze.invoice_raw`
- `bronze.invoice_line_raw`
- `bronze.detection_rule_raw`
- `bronze.dispute_raw`

### Silver

Conformed, normalized entities:

- `silver.party`
- `silver.facility_profile`
- `silver.supplier_profile`
- `silver.party_alias`
- `silver.party_contact`
- `silver.category`
- `silver.gl_account`
- `silver.contract`
- `silver.contract_facility_scope`
- `silver.contract_clause`
- `silver.contract_line_term`
- `silver.invoice`
- `silver.invoice_line`
- `silver.application_user`
- `silver.application_user_role`

### Ontology

Semantic graph and rules:

- `ontology.node`
- `ontology.edge`
- `ontology.triple`
- `ontology.entity_binding`
- `ontology.rule_catalog`
- `ontology.matching_policy`
- `ontology.match_cache`
- `ontology.audit_event`

### Gold

Business outputs:

- `gold.invoice_line_compliance_fact`
- `gold.invoice_compliance_summary`
- `gold.supplier_price_assurance_summary`
- `gold.contract_leakage_summary`
- `gold.exception_work_queue`
- `gold.dispute_case`
- `gold.dispute_case_line`
- `gold.dispute_message`

## 8. Priority Recommendations

### Must Add For Price Assurance MVP

1. `silver.facility_profile`
2. `silver.supplier_profile`
3. `silver.party_alias`
4. `silver.party_contact`
5. `silver.category`
6. `silver.gl_account`
7. `silver.contract_clause`
8. Invoice AP workflow fields: payment status/deadline/frequency
9. Gold invoice line fields: match status, confidence, exception type, explanation, remediation
10. `gold.supplier_price_assurance_summary`
11. `gold.dispute_case`, `gold.dispute_case_line`, `gold.dispute_message`

### Should Add Next

1. `silver.application_user`
2. `silver.application_user_role`
3. `silver.contract_facility_scope`
4. `ontology.rule_catalog.action`
5. `ontology` edges for disputes and clause evidence

### Can Stay App/Demo-Only

1. `demoFlow`
2. UI page names
3. Demo walkthrough step actions

## 9. Final Design Guidance

The TypeScript seed is not just sample data; it reveals that the target app is broader than invoice-to-contract price validation. It is a Price Assurance workflow platform.

Therefore:

- Keep raw seed-like structures in Bronze.
- Normalize parties, facilities, suppliers, categories, GL accounts, contracts, clauses, invoices, and users in Silver.
- Use the ontology layer for graph relationships, rule metadata, matching policy, and audit semantics.
- Store final compliance, supplier exposure, exception queue, and disputes in Gold.

This keeps the Medallion architecture clean while still giving the ontology layer enough semantic richness to power matching, explanations, disputes, and analyst workflows.
