# Production Application Guide

## What Changed From Demo To Application

| Area | Demo | Production Application |
|---|---|---|
| Runtime | Script-oriented local run | CLI, API, container, and Databricks workflow entry points |
| Configuration | Command-line flags | Environment-backed `AppConfig` with validation |
| API | Minimal HTTP handler | FastAPI app factory with health, readiness, metrics, graph, reconciliation, findings, and validation endpoints |
| Persistence | SQLite only | Repository abstraction with SQLite and Databricks SQL implementations |
| Observability | Console prints | Structured JSON logs, audit events, and metrics endpoint |
| Validation | Basic rule execution | Enforced quantity min/max, amendment-aware terms, cache-aware matching, and full validation result payload |
| Deployment | Placeholder notes | Dockerfile, compose file, Databricks SQL DDL, bundle scaffold, and runbook |
| Testing | Demo behavior tests | Demo plus service/config/metrics/run-id tests |

## Runtime Components

| Component | Module | Responsibility |
|---|---|---|
| Configuration | `workflows.config` | Reads and validates environment-driven runtime settings |
| Logging | `workflows.logging_config` | Emits JSON logs suitable for Databricks, containers, and log aggregation |
| Repository Factory | `workflows.repository_factory` | Builds SQLite or Databricks repository implementations |
| Service Layer | `workflows.service` | Owns application use cases and response contracts |
| API | `workflows.api` | Exposes the production HTTP interface |
| CLI | `workflows.cli` | Supports local/batch reconciliation and metrics output |
| Engine | `ontology.engine` | Coordinates matching, validation, findings, and audit events |
| Matching | `matching.matching` | Scores candidate contract terms and uses fast-path cache |
| Validation | `validation.validators` | Applies deterministic line-level rules |
| Ontology Repository | `ontology.repository` | Storage interface for semantic entities and operational results |

## API Surface

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | Liveness and backend diagnostics |
| `GET` | `/ready` | Readiness check for orchestration |
| `GET` | `/metrics` | Table counts and repository metrics |
| `POST` | `/v1/reconciliations` | Reconcile one invoice |
| `GET` | `/v1/reconciliations/{run_id}/validation-results` | Return validation details for a run |
| `GET` | `/v1/reconciliations/{run_id}/findings` | Return findings and exceptions for a run |
| `GET` | `/v1/ontology/graph` | Return ontology nodes and edges |
| `GET` | `/v1/ontology/nodes` | Return ontology nodes |
| `GET` | `/v1/ontology/edges` | Return ontology edges |

Example reconciliation request:

```json
{
  "invoice_id": "INV-1001",
  "correlation_id": "external-trace-id-001"
}
```

## Backend Modes

### SQLite

Use for local development, demos, and deterministic unit tests.

```text
REPOSITORY_BACKEND=sqlite
SQLITE_DB_PATH=data/reconciliation.db
SEED_ON_STARTUP=true
```

### Databricks

Use for production execution against Unity Catalog Delta tables.

```text
REPOSITORY_BACKEND=databricks
DATABRICKS_SERVER_HOSTNAME=<workspace-host>
DATABRICKS_HTTP_PATH=<sql-warehouse-http-path>
DATABRICKS_TOKEN=<token>
DATABRICKS_CATALOG=platform_dev
DATABRICKS_SCHEMA=pspa_ontology
```

The Databricks repository implements the same storage contract as SQLite and expects tables created by `sql/databricks_lakehouse_schema.sql`.

## Reconciliation Flow

1. The API or CLI receives an invoice id.
2. `ReconciliationService` assigns or propagates a correlation id.
3. `ReconciliationEngine` creates a unique reconciliation run.
4. Each invoice line is matched against active effective contract terms.
5. The matching engine evaluates item, eligibility, date, UOM, price, semantic, and ontology graph relationship signals.
6. The validation engine executes deterministic rules.
7. Findings are generated for compliant, price variance, off-contract, and review outcomes.
8. Validation results, findings, run metrics, and audit events are persisted.
9. Gold tables or downstream consumers can use the run payload and findings for analytics and dispute workflow.

## Production Controls

| Control | Implementation |
|---|---|
| Unique run ids | Run id includes timestamp and UUID token |
| Health/readiness | `/health` and `/ready` |
| Metrics | `/metrics` plus repository table counts |
| Auditability | `audit_event`, validation result evidence, finding evidence |
| Cache control | Match cache plus contract-level invalidation |
| Amendment handling | Effective contract term table and `AMENDMENT_VERSION_VALID` rule |
| Quantity compliance | `QUANTITY_LIMIT_VALID` enforces contract min/max |
| Backend isolation | All persistence behind `OntologyRepository` |
| Deployment | Docker and Databricks asset bundle scaffolds |

## Validation

Run the full local test suite:

```powershell
$env:PYTHONPATH="."
python -m unittest discover -s tests -v
```

Run the CLI smoke test:

```powershell
python run_demo.py --reset --twice
```
