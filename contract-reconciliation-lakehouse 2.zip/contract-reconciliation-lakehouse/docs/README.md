# Documentation Index

| Document | Purpose |
|---|---|
| [Application Architecture And Flow Design](../architecture/APPLICATION_ARCHITECTURE_AND_FLOW_DESIGN.md) | Client-facing application architecture, data flow, reconciliation, ontology, graph, AI/GenAI, API, security, deployment, and operations design |
| [Application Architecture And Flow Design - Word](../architecture/APPLICATION_ARCHITECTURE_AND_FLOW_DESIGN.docx) | Word-formatted version of the application architecture and flow design document |
| [Enterprise Architecture Deliverables](../architecture/ENTERPRISE_ARCHITECTURE_DELIVERABLES.md) | Consolidated enterprise architecture, solution architecture, Medallion, ontology, data/process flows, diagrams, deployment, and Unity Catalog design |
| [Enhancement Summary From PSPA Prototype](ENHANCEMENT_SUMMARY_FROM_PSPA_PROTOTYPE.md) | Detailed comparison between the original `pspa-reconciliation-prototype-main.zip` and the upgraded Databricks lakehouse solution |
| [Medallion + Ontology Architecture](../architecture/MEDALLION_ONTOLOGY_ARCHITECTURE.md) | Clarifies Bronze/Silver/Gold layer ownership and where the ontology graph belongs |
| [Medallion, Ontology, and Reconciliation Flow](MEDALLION_ONTOLOGY_RECONCILIATION_FLOW.md) | Detailed justification for building ontology from Silver, layer responsibilities, data/logic flow, reconciliation timing, and AI/LLM strategy |
| [Medallion, Ontology, and Reconciliation Flow - Word](Medallion_Ontology_Reconciliation_Flow.docx) | Shareable Word version of the Medallion, ontology, reconciliation, and AI/LLM strategy document |
| [Solution Architecture](../architecture/SOLUTION_ARCHITECTURE.md) | End-to-end architecture, ontology explanation, Databricks production view, reconciliation process |
| [Low-Level Design](../architecture/LOW_LEVEL_DESIGN.md) | Component-level design, classes, tables, algorithms, process flow, API, cache, audit, testing |
| [Production Application Guide](PRODUCTION_APPLICATION_GUIDE.md) | Runtime modes, API surface, backend configuration, reconciliation flow, and production controls |
| [Demo Setup And Backend Configuration Guide](DEMO_SETUP_AND_BACKEND_GUIDE.md) | Step-by-step guide to configure, run, smoke test, and demo the local SQLite, container, and Databricks backends |
| [Delta Table Roles And Responsibilities](DELTA_TABLE_ROLES_AND_RESPONSIBILITIES.md) | Delta table grain, responsibility, source-of-truth ownership, consumers, and governance guidance |
| [Price Assurance Seed Gap Analysis](PRICE_ASSURANCE_SEED_GAP_ANALYSIS.md) | Maps `priceAssuranceSeed.ts` fields to Bronze/Silver/Ontology/Gold and identifies missing entities/fields |
| [Enterprise Architecture Word Document](Enterprise_Architecture_Deliverables.docx) | Word-formatted architecture deliverable |
