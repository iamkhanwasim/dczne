# Gold Layer

Purpose: publish business-ready facts, summaries, scorecards, exception queues, and dispute workflow tables.

Representative tables:

- `platform_dev.pspa_gold.invoice_line_compliance_fact`
- `platform_dev.pspa_gold.invoice_compliance_summary`
- `platform_dev.pspa_gold.contract_leakage_summary`
- `platform_dev.pspa_gold.exception_work_queue`
- `platform_dev.pspa_gold.supplier_price_assurance_summary`
- `platform_dev.pspa_gold.dispute_case`
- `platform_dev.pspa_gold.dispute_case_line`
- `platform_dev.pspa_gold.dispute_message`

