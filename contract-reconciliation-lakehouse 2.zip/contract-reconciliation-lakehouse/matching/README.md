# Matching

Purpose: retrieve candidate contract terms and select the best match for each invoice line.

Current local implementation:

- `matching.py`

Production extensions:

- Add item cross-reference and supplier alias traversal.
- Add facility-scope matching.
- Add Databricks Vector Search / AI Search for ambiguous text-only lines.
- Persist match candidates and confidence scores.

