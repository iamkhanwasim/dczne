from __future__ import annotations

import math
from typing import Any

from ontology.models import (
    EffectiveContractLineTerm,
    Invoice,
    InvoiceLine,
    MatchStatus,
    MatchCandidate,
    MatchingPolicy,
    Route,
)
from ontology.repository import OntologyRepository
from ontology.utils import normalize_text


def invoice_line_signature(line: InvoiceLine) -> str:
    return "|".join(
        [
            normalize_text(line.description),
            normalize_text(line.charge_term_text),
            line.item_id,
            line.category_code,
            line.invoice_uom.upper(),
            f"{line.unit_price:.6f}",
        ]
    )


def token_overlap_similarity(left: str, right: str) -> float:
    left_tokens = set(normalize_text(left).split())
    right_tokens = set(normalize_text(right).split())
    if not left_tokens or not right_tokens:
        return 0.0
    return len(left_tokens & right_tokens) / len(left_tokens | right_tokens)


def price_proximity(invoice_unit_price: float | None, contract_unit_price: float) -> float:
    if invoice_unit_price is None or invoice_unit_price <= 0 or contract_unit_price <= 0:
        return 0.0
    relative_diff = abs(invoice_unit_price - contract_unit_price) / max(
        abs(invoice_unit_price), abs(contract_unit_price)
    )
    return max(0.0, 1.0 - relative_diff)


def is_blank_uom(uom: str | None) -> bool:
    return not uom or uom.strip().upper() in {"NA", "N/A", "NONE", "UNKNOWN", "UNSPECIFIED"}


def service_uom_optional(term: EffectiveContractLineTerm) -> bool:
    return term.charge_term_type.upper() in {
        "SUBSCRIPTION",
        "VARIABLE_RATE",
        "OVERAGE",
        "TIME_AND_MATERIALS",
        "EXCLUDED",
    } or term.pricing_basis.upper() in {
        "FLAT_FEE",
        "SERVICE",
        "MONTHLY",
        "ANNUAL",
        "PER_EVENT",
        "VARIABLE_RATE",
    }


def source_quality_sufficient(line: InvoiceLine, policy: MatchingPolicy) -> bool:
    trusted_statuses = {"TRUSTED", "VALID", "HIGH_CONFIDENCE", "STRUCTURED", "PARSED"}
    status_ok = line.source_quality_status.upper() in trusted_statuses
    confidence_ok = (
        line.parse_confidence is None
        or line.parse_confidence >= policy.source_quality_confidence_threshold
    )
    return status_ok and confidence_ok


def category_compatible(line: InvoiceLine, term: EffectiveContractLineTerm) -> bool:
    if not line.category_code or not term.category_code:
        return True
    return line.category_code == term.category_code


def semantic_similarity(line: InvoiceLine, term: EffectiveContractLineTerm) -> float:
    line_text = " ".join(
        value
        for value in [line.description, line.charge_term_text, line.category_code, line.item_id]
        if value
    )
    term_text = " ".join(
        value
        for value in [
            term.description,
            term.category_code,
            term.charge_term_type,
            term.pricing_basis,
            term.item_id,
        ]
        if value
    )
    return max(
        token_overlap_similarity(line_text, term_text),
        token_overlap_similarity(line.description, term.description),
        token_overlap_similarity(line.description, line.item_id.replace("-", " ")) if line.item_id else 0.0,
    )


def normalize_invoice_unit_price(
    repo: OntologyRepository,
    line: InvoiceLine,
    term: EffectiveContractLineTerm,
) -> tuple[float | None, bool, float | None, bool, bool]:
    uom_required = not service_uom_optional(term)
    if is_blank_uom(line.invoice_uom) and is_blank_uom(term.contract_uom) and not uom_required:
        return line.unit_price, True, None, False, True
    if (is_blank_uom(line.invoice_uom) or is_blank_uom(term.contract_uom)) and not uom_required:
        return None, False, None, False, False

    if line.invoice_uom == term.contract_uom:
        return line.unit_price, True, 1.0, True, False

    factor = repo.get_uom_conversion(line.item_id, line.invoice_uom, term.contract_uom)
    if factor is None or math.isclose(factor, 0.0):
        return None, False, None, uom_required, False

    return line.unit_price * factor, True, factor, uom_required, False


def contract_selection_evidence(
    invoice: Invoice,
    line: InvoiceLine,
    term: EffectiveContractLineTerm,
    member_eligible: bool,
) -> dict[str, Any]:
    checks = {
        "supplier_candidate": True,
        "member_eligible": member_eligible,
        "service_date_in_term": term.effective_from <= line.service_date
        and (term.effective_to is None or term.effective_to >= line.service_date),
        "contract_reference_available": bool(invoice.contract_number_reference),
    }
    score = sum(1 for value in checks.values() if value) / len(checks)
    return {
        "score": round(score, 4),
        "checks": checks,
        "billing_frequency": term.billing_frequency,
        "charge_term_type": term.charge_term_type,
        "pricing_basis": term.pricing_basis,
    }


def score_candidate(
    repo: OntologyRepository,
    invoice: Invoice,
    line: InvoiceLine,
    term: EffectiveContractLineTerm,
    policy: MatchingPolicy,
    graph_evidence: dict[str, Any] | None = None,
    contract_candidate_count: int = 0,
    term_candidate_count: int = 0,
) -> MatchCandidate:
    exact_item_match = bool(line.item_id and term.item_id and line.item_id == term.item_id)
    member_eligible = repo.is_member_eligible(term.contract_id, invoice.member_id, line.service_date)
    date_valid = term.effective_from <= line.service_date and (
        term.effective_to is None or term.effective_to >= line.service_date
    )
    normalized_price, uom_convertible, conversion_factor, uom_required, uom_absent_accepted = (
        normalize_invoice_unit_price(repo, line, term)
    )
    price_score = price_proximity(normalized_price, term.unit_price)
    if graph_evidence is None:
        graph_evidence = repo.get_graph_match_evidence(invoice, line, term)
    graph_available = bool(graph_evidence.get("available"))
    graph_support_score = float(graph_evidence.get("support_score", 0.0)) if graph_available else 0.0
    semantic = semantic_similarity(line, term)
    category_ok = category_compatible(line, term)
    data_quality_ok = source_quality_sufficient(line, policy)
    contract_evidence = contract_selection_evidence(invoice, line, term, member_eligible)

    base_score = (
        (policy.exact_item_weight if exact_item_match else 0.0)
        + (policy.eligibility_weight if member_eligible else 0.0)
        + (policy.date_weight if date_valid else 0.0)
        + (policy.uom_weight if uom_convertible else 0.0)
        + (policy.price_weight * price_score)
        + (policy.semantic_weight * semantic)
        + (policy.category_weight if category_ok else 0.0)
    )
    base_weight = (
        policy.exact_item_weight
        + policy.eligibility_weight
        + policy.date_weight
        + policy.uom_weight
        + policy.price_weight
        + policy.semantic_weight
        + policy.category_weight
    )
    graph_weight = policy.graph_weight if graph_available else 0.0
    score = (
        (base_score + graph_weight * graph_support_score) / (base_weight + graph_weight)
        if base_weight + graph_weight
        else 0.0
    )

    route = Route.DEEP_PATH
    if score < policy.deep_path_threshold:
        route = Route.MANUAL_REVIEW

    service_semantic_match = (
        not exact_item_match
        and semantic >= policy.semantic_match_threshold
        and bool(term.description)
    )
    match_status = MatchStatus.MATCHED
    if not data_quality_ok:
        match_status = MatchStatus.REJECTED
        route = Route.MANUAL_REVIEW
    elif not exact_item_match and service_semantic_match:
        match_status = MatchStatus.PARTIAL_MATCH
    elif not exact_item_match and not service_semantic_match:
        match_status = MatchStatus.NO_MATCH
        route = Route.MANUAL_REVIEW

    graph_reason = (
        f"; graph={graph_support_score:.3f} "
        f"({graph_evidence.get('matched_relationships', 0)}/"
        f"{graph_evidence.get('expected_relationships', 0)})"
        if graph_available
        else "; graph=unavailable"
    )
    reason = (
        f"score={score:.3f}; item={exact_item_match}; eligible={member_eligible}; "
        f"date={date_valid}; uom={uom_convertible}; price={price_score:.3f}; "
        f"semantic={semantic:.3f}; category={category_ok}; "
        f"charge_term_type={term.charge_term_type}; uom_required={uom_required}; "
        f"conversion={conversion_factor}{graph_reason}"
    )

    return MatchCandidate(
        invoice_line_id=line.invoice_line_id,
        contract_line_id=term.contract_line_id,
        contract_id=term.contract_id,
        contract_version_id=term.contract_version_id,
        score=round(score, 4),
        route=route,
        exact_item_match=exact_item_match,
        member_eligible=member_eligible,
        date_valid=date_valid,
        uom_convertible=uom_convertible,
        price_proximity=round(price_score, 4),
        semantic_similarity=round(semantic, 4),
        normalized_invoice_unit_price=(
            round(normalized_price, 6) if normalized_price is not None else None
        ),
        contract_unit_price=term.unit_price,
        reason=reason,
        contract_min_quantity=term.min_quantity,
        contract_max_quantity=term.max_quantity,
        graph_support_score=round(graph_support_score, 4),
        graph_evidence=graph_evidence,
        contract_selection_score=contract_evidence["score"],
        contract_selection_evidence=contract_evidence,
        contract_candidate_count=contract_candidate_count,
        term_candidate_count=term_candidate_count,
        match_status=match_status,
        category_compatible=category_ok,
        charge_term_type=term.charge_term_type,
        pricing_basis=term.pricing_basis,
        charge_term_allowed=term.charge_term_allowed,
        uom_required=uom_required,
        uom_absent_accepted=uom_absent_accepted,
        data_quality_sufficient=data_quality_ok,
    )


def find_best_match(
    repo: OntologyRepository,
    invoice: Invoice,
    line: InvoiceLine,
) -> MatchCandidate | None:
    policy = repo.get_matching_policy()
    terms: list[EffectiveContractLineTerm] = []
    if line.item_id:
        terms = repo.get_active_contract_terms(invoice.supplier_id, line.item_id, line.service_date)
    if not terms:
        service_fallback_allowed = bool(line.category_code or line.charge_term_text or not line.item_id)
        if not service_fallback_allowed:
            return None
        terms = repo.get_active_contract_terms_for_supplier(
            invoice.supplier_id,
            line.service_date,
            line.category_code,
        )
    if not terms:
        return None

    signature = invoice_line_signature(line)
    cached = repo.find_cache_match_for_contracts(
        [term.contract_id for term in terms],
        signature,
    )
    if cached is not None:
        return cached

    graph_evidence_by_term = repo.get_graph_match_evidence_for_terms(invoice, line, terms)
    contract_candidate_count = len({term.contract_id for term in terms})
    term_candidate_count = len(terms)
    candidates = [
        score_candidate(
            repo,
            invoice,
            line,
            term,
            policy,
            graph_evidence_by_term.get(term.contract_line_id),
            contract_candidate_count,
            term_candidate_count,
        )
        for term in terms
    ]
    candidates.sort(key=lambda candidate: candidate.score, reverse=True)
    best = candidates[0]

    if best.score >= policy.fast_path_threshold:
        repo.upsert_cache_match(signature, best)

    return best
