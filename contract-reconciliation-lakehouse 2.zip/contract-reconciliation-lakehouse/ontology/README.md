# Ontology Layer

Purpose: provide the semantic graph and repository abstraction used by reconciliation.

This folder contains the local runnable ontology repository and engine code:

- `models.py`
- `repository.py`
- `sqlite_repository.py`
- `databricks_repository.py`
- `engine.py`
- `findings.py`
- `utils.py`

Production ontology tables:

- `platform_dev.pspa_ontology.node`
- `platform_dev.pspa_ontology.edge`
- `platform_dev.pspa_ontology.triple`
- `platform_dev.pspa_ontology.entity_binding`
- `platform_dev.pspa_ontology.rule_catalog`
- `platform_dev.pspa_ontology.matching_policy`
- `platform_dev.pspa_ontology.match_cache`
- `platform_dev.pspa_ontology.audit_event`

