from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

from ontology.models import (
    Contract,
    ContractLineTerm,
    ContractVersion,
    Dispute,
    DisputeLine,
    DisputeMessage,
    Edge,
    EffectiveContractLineTerm,
    ExceptionCase,
    Finding,
    Invoice,
    InvoiceLine,
    Item,
    MatchCandidate,
    MatchingPolicy,
    MemberEligibility,
    Node,
    Party,
    ReconciliationRun,
    Route,
    RuleCatalogEntry,
    Severity,
    UomConversion,
    ValidationResult,
    ValidationStatus,
)
from ontology.repository import (
    OntologyRepository,
    build_graph_match_evidence,
    graph_match_expectations,
)
from ontology.utils import date_to_str, from_json, now_iso, parse_date, stable_id, to_json


@dataclass(frozen=True)
class DatabricksSqlConfig:
    server_hostname: str
    http_path: str
    access_token: str
    catalog: str
    schema: str

    @classmethod
    def from_env(cls) -> "DatabricksSqlConfig":
        return cls(
            server_hostname=os.environ["DATABRICKS_SERVER_HOSTNAME"],
            http_path=os.environ["DATABRICKS_HTTP_PATH"],
            access_token=os.environ["DATABRICKS_TOKEN"],
            catalog=os.environ.get("DATABRICKS_CATALOG", "platform_dev"),
            schema=os.environ.get("DATABRICKS_SCHEMA", "pspa_ontology"),
        )


class DatabricksSqlClient:
    """Small Databricks SQL wrapper used by production repositories."""

    def __init__(self, config: DatabricksSqlConfig) -> None:
        try:
            from databricks import sql
        except ImportError as exc:
            raise RuntimeError(
                "Install the Databricks extra first: pip install .[databricks]"
            ) from exc

        self.config = config
        self.connection = sql.connect(
            server_hostname=config.server_hostname,
            http_path=config.http_path,
            access_token=config.access_token,
        )

    def execute(self, statement: str, parameters: tuple[Any, ...] | None = None) -> list[dict]:
        with self.connection.cursor() as cursor:
            cursor.execute(statement, parameters or ())
            if cursor.description is None:
                return []
            columns = [column[0] for column in cursor.description]
            return [dict(zip(columns, row)) for row in cursor.fetchall()]

    def execute_script(self, script_path: str | Path) -> None:
        script = Path(script_path).read_text(encoding="utf-8")
        statements = [part.strip() for part in script.split(";") if part.strip()]
        for statement in statements:
            self.execute(statement)

    def close(self) -> None:
        self.connection.close()


class DatabricksOntologyRepository(OntologyRepository):
    """Databricks SQL / Unity Catalog Delta implementation of the ontology repository."""

    def __init__(self, client: DatabricksSqlClient, catalog: str | None = None, schema: str | None = None) -> None:
        self.client = client
        self.catalog = catalog or client.config.catalog
        self.schema = schema or client.config.schema

    def _table(self, name: str) -> str:
        return f"{self.catalog}.{self.schema}.{name}"

    def _replace(self, table: str, key_columns: tuple[str, ...], values: dict[str, Any]) -> None:
        where_clause = " AND ".join(f"{column} = ?" for column in key_columns)
        self.client.execute(
            f"DELETE FROM {self._table(table)} WHERE {where_clause}",
            tuple(values[column] for column in key_columns),
        )
        columns = list(values)
        placeholders = ", ".join("?" for _ in columns)
        self.client.execute(
            f"INSERT INTO {self._table(table)} ({', '.join(columns)}) VALUES ({placeholders})",
            tuple(values[column] for column in columns),
        )

    def initialize(self) -> None:
        self.client.execute(f"CREATE CATALOG IF NOT EXISTS {self.catalog}")
        self.client.execute(f"CREATE SCHEMA IF NOT EXISTS {self.catalog}.{self.schema}")

    def initialize_from_script(self, script_path: str | Path) -> None:
        self.client.execute_script(script_path)

    def close(self) -> None:
        self.client.close()

    def reset(self) -> None:
        tables = [
            "audit_event",
            "dispute_message",
            "dispute_line",
            "dispute",
            "exception_case",
            "finding",
            "validation_result",
            "reconciliation_run",
            "match_cache",
            "matching_policy",
            "rule_catalog",
            "edge",
            "node",
            "invoice_line",
            "invoice",
            "member_eligibility",
            "effective_contract_line_term",
            "contract_line_term",
            "contract_version",
            "contract",
            "uom_conversion",
            "item",
            "party",
        ]
        for table in tables:
            self.client.execute(f"DELETE FROM {self._table(table)}")

    def healthcheck(self) -> dict[str, Any]:
        try:
            self.client.execute("SELECT 1")
            return {
                "status": "ok",
                "backend": "databricks",
                "catalog": self.catalog,
                "schema": self.schema,
            }
        except Exception as exc:  # pragma: no cover - requires Databricks
            return {
                "status": "error",
                "backend": "databricks",
                "catalog": self.catalog,
                "schema": self.schema,
                "error": str(exc),
            }

    def metrics(self) -> dict[str, Any]:
        table_names = [
            "party",
            "item",
            "contract",
            "contract_version",
            "effective_contract_line_term",
            "invoice",
            "invoice_line",
            "node",
            "edge",
            "reconciliation_run",
            "validation_result",
            "finding",
            "exception_case",
            "dispute",
            "dispute_line",
            "dispute_message",
            "audit_event",
            "match_cache",
        ]
        counts = {}
        for table in table_names:
            row = self.client.execute(f"SELECT COUNT(*) AS count FROM {self._table(table)}")[0]
            counts[table] = int(row["count"])
        return {
            "backend": "databricks",
            "catalog": self.catalog,
            "schema": self.schema,
            "table_counts": counts,
        }

    def add_party(self, party: Party) -> None:
        self._replace(
            "party",
            ("party_id",),
            {
                "party_id": party.party_id,
                "party_type": party.party_type,
                "party_name": party.party_name,
                "active_flag": party.active_flag,
                "contact_email": party.contact_email,
                "contact_data_complete": party.contact_data_complete,
                "primary_facility_id": party.primary_facility_id,
                "gl_code": party.gl_code,
            },
        )

    def add_item(self, item: Item) -> None:
        self._replace(
            "item",
            ("item_id",),
            {
                "item_id": item.item_id,
                "description": item.description,
                "manufacturer_item_number": item.manufacturer_item_number,
                "supplier_item_number": item.supplier_item_number,
                "gtin": item.gtin,
                "category_code": item.category_code,
                "active_flag": item.active_flag,
            },
        )

    def add_uom_conversion(self, conversion: UomConversion) -> None:
        self._replace(
            "uom_conversion",
            ("item_id", "from_uom", "to_uom"),
            {
                "item_id": conversion.item_id,
                "from_uom": conversion.from_uom,
                "to_uom": conversion.to_uom,
                "conversion_factor": conversion.conversion_factor,
            },
        )

    def add_contract(self, contract: Contract) -> None:
        self._replace(
            "contract",
            ("contract_id",),
            {
                "contract_id": contract.contract_id,
                "contract_number": contract.contract_number,
                "contract_name": contract.contract_name,
                "gpo_id": contract.gpo_id,
                "supplier_id": contract.supplier_id,
                "effective_date": date_to_str(contract.effective_date),
                "expiration_date": date_to_str(contract.expiration_date),
                "status": contract.status,
            },
        )

    def add_contract_version(self, version: ContractVersion) -> None:
        self._replace(
            "contract_version",
            ("contract_version_id",),
            {
                "contract_version_id": version.contract_version_id,
                "contract_id": version.contract_id,
                "version_type": version.version_type,
                "sequence_number": version.sequence_number,
                "effective_date": date_to_str(version.effective_date),
                "expiration_date": date_to_str(version.expiration_date),
                "amendment_number": version.amendment_number,
                "retroactive_flag": version.retroactive_flag,
            },
        )

    def add_contract_line_term(self, term: ContractLineTerm) -> None:
        self._replace(
            "contract_line_term",
            ("contract_line_id",),
            {
                "contract_line_id": term.contract_line_id,
                "contract_version_id": term.contract_version_id,
                "contract_id": term.contract_id,
                "item_id": term.item_id,
                "action_type": term.action_type,
                "contract_uom": term.contract_uom,
                "unit_price": term.unit_price,
                "currency_code": term.currency_code,
                "tier_id": term.tier_id,
                "effective_from": date_to_str(term.effective_from),
                "effective_to": date_to_str(term.effective_to),
                "min_quantity": term.min_quantity,
                "max_quantity": term.max_quantity,
                "description": term.description,
                "category_code": term.category_code,
                "charge_term_type": term.charge_term_type,
                "pricing_basis": term.pricing_basis,
                "billing_frequency": term.billing_frequency,
                "charge_term_allowed": term.charge_term_allowed,
            },
        )

    def add_effective_contract_line_term(self, term: EffectiveContractLineTerm) -> None:
        self._replace(
            "effective_contract_line_term",
            ("contract_line_id",),
            {
                "contract_line_id": term.contract_line_id,
                "contract_version_id": term.contract_version_id,
                "contract_id": term.contract_id,
                "item_id": term.item_id,
                "contract_uom": term.contract_uom,
                "unit_price": term.unit_price,
                "currency_code": term.currency_code,
                "tier_id": term.tier_id,
                "effective_from": date_to_str(term.effective_from),
                "effective_to": date_to_str(term.effective_to),
                "min_quantity": term.min_quantity,
                "max_quantity": term.max_quantity,
                "description": term.description,
                "sequence_number": term.sequence_number,
                "category_code": term.category_code,
                "charge_term_type": term.charge_term_type,
                "pricing_basis": term.pricing_basis,
                "billing_frequency": term.billing_frequency,
                "charge_term_allowed": term.charge_term_allowed,
            },
        )

    def add_member_eligibility(self, eligibility: MemberEligibility) -> None:
        self._replace(
            "member_eligibility",
            ("eligibility_id",),
            {
                "eligibility_id": eligibility.eligibility_id,
                "contract_id": eligibility.contract_id,
                "party_id": eligibility.party_id,
                "tier_id": eligibility.tier_id,
                "valid_from": date_to_str(eligibility.valid_from),
                "valid_to": date_to_str(eligibility.valid_to),
                "status": eligibility.status,
            },
        )

    def add_invoice(self, invoice: Invoice) -> None:
        self._replace(
            "invoice",
            ("invoice_id",),
            {
                "invoice_id": invoice.invoice_id,
                "invoice_number": invoice.invoice_number,
                "invoice_date": date_to_str(invoice.invoice_date),
                "supplier_id": invoice.supplier_id,
                "member_id": invoice.member_id,
                "currency_code": invoice.currency_code,
                "total_amount": invoice.total_amount,
                "contract_number_reference": invoice.contract_number_reference,
                "payment_status": invoice.payment_status,
                "po_type": invoice.po_type,
                "interception_status": invoice.interception_status,
            },
        )

    def add_invoice_line(self, line: InvoiceLine) -> None:
        self._replace(
            "invoice_line",
            ("invoice_line_id",),
            {
                "invoice_line_id": line.invoice_line_id,
                "invoice_id": line.invoice_id,
                "line_number": line.line_number,
                "item_id": line.item_id,
                "description": line.description,
                "quantity": line.quantity,
                "invoice_uom": line.invoice_uom,
                "unit_price": line.unit_price,
                "extended_amount": line.extended_amount,
                "service_date": date_to_str(line.service_date),
                "category_code": line.category_code,
                "charge_term_text": line.charge_term_text,
                "billing_frequency": line.billing_frequency,
                "billing_period_start": date_to_str(line.billing_period_start),
                "billing_period_end": date_to_str(line.billing_period_end),
                "parse_confidence": line.parse_confidence,
                "source_quality_status": line.source_quality_status,
            },
        )

    def add_node(self, node: Node) -> None:
        self._replace(
            "node",
            ("node_id",),
            {
                "node_id": node.node_id,
                "entity_type": node.entity_type,
                "entity_id": node.entity_id,
                "display_name": node.display_name,
                "properties_json": to_json(node.properties),
            },
        )

    def add_edge(self, edge: Edge) -> None:
        self._replace(
            "edge",
            ("edge_id",),
            {
                "edge_id": edge.edge_id,
                "from_node_id": edge.from_node_id,
                "to_node_id": edge.to_node_id,
                "relationship_type": edge.relationship_type,
                "valid_from": date_to_str(edge.valid_from),
                "valid_to": date_to_str(edge.valid_to),
                "evidence_json": to_json(edge.evidence),
            },
        )

    def add_rule(self, rule: RuleCatalogEntry) -> None:
        self._replace(
            "rule_catalog",
            ("rule_code",),
            {
                "rule_code": rule.rule_code,
                "rule_version": rule.rule_version,
                "rule_group": rule.rule_group,
                "severity": rule.severity.value,
                "description": rule.description,
                "active_flag": rule.active_flag,
                "parameters_json": to_json(rule.parameters),
            },
        )

    def set_matching_policy(self, policy: MatchingPolicy) -> None:
        self._replace(
            "matching_policy",
            ("policy_id",),
            {"policy_id": policy.policy_id, "policy_json": to_json(policy)},
        )

    def get_matching_policy(self) -> MatchingPolicy:
        rows = self.client.execute(f"SELECT policy_json FROM {self._table('matching_policy')} LIMIT 1")
        if not rows:
            return MatchingPolicy()
        return MatchingPolicy(**from_json(rows[0]["policy_json"]))

    def get_invoice(self, invoice_id: str) -> Invoice:
        rows = self.client.execute(
            f"SELECT * FROM {self._table('invoice')} WHERE invoice_id = ?",
            (invoice_id,),
        )
        if not rows:
            raise KeyError(f"Invoice not found: {invoice_id}")
        row = rows[0]
        return Invoice(
            invoice_id=row["invoice_id"],
            invoice_number=row["invoice_number"],
            invoice_date=parse_date(row["invoice_date"]),
            supplier_id=row["supplier_id"],
            member_id=row["member_id"],
            currency_code=row["currency_code"],
            total_amount=row["total_amount"],
            contract_number_reference=row.get("contract_number_reference") or "",
            payment_status=row.get("payment_status") or "",
            po_type=row.get("po_type") or "",
            interception_status=row.get("interception_status") or "",
        )

    def get_invoice_lines(self, invoice_id: str) -> list[InvoiceLine]:
        rows = self.client.execute(
            f"""
            SELECT * FROM {self._table('invoice_line')}
            WHERE invoice_id = ?
            ORDER BY CAST(line_number AS INT)
            """,
            (invoice_id,),
        )
        return [
            InvoiceLine(
                invoice_line_id=row["invoice_line_id"],
                invoice_id=row["invoice_id"],
                line_number=row["line_number"],
                item_id=row["item_id"],
                description=row["description"],
                quantity=row["quantity"],
                invoice_uom=row["invoice_uom"],
                unit_price=row["unit_price"],
                extended_amount=row["extended_amount"],
                service_date=parse_date(row["service_date"]),
                category_code=row.get("category_code") or "",
                charge_term_text=row.get("charge_term_text") or "",
                billing_frequency=row.get("billing_frequency") or "",
                billing_period_start=parse_date(row.get("billing_period_start")),
                billing_period_end=parse_date(row.get("billing_period_end")),
                parse_confidence=row.get("parse_confidence"),
                source_quality_status=row.get("source_quality_status") or "TRUSTED",
            )
            for row in rows
        ]

    def get_item(self, item_id: str) -> Item | None:
        rows = self.client.execute(f"SELECT * FROM {self._table('item')} WHERE item_id = ?", (item_id,))
        if not rows:
            return None
        row = rows[0]
        return Item(
            item_id=row["item_id"],
            description=row["description"],
            manufacturer_item_number=row.get("manufacturer_item_number") or "",
            supplier_item_number=row.get("supplier_item_number") or "",
            gtin=row.get("gtin") or "",
            category_code=row.get("category_code") or "",
            active_flag=bool(row["active_flag"]),
        )

    def get_active_contract_terms(
        self,
        supplier_id: str,
        item_id: str,
        service_date: date,
    ) -> list[EffectiveContractLineTerm]:
        service_date_text = date_to_str(service_date)
        rows = self.client.execute(
            f"""
            SELECT ect.*
            FROM {self._table('effective_contract_line_term')} ect
            JOIN {self._table('contract')} c ON c.contract_id = ect.contract_id
            WHERE c.supplier_id = ?
              AND ect.item_id = ?
              AND ect.effective_from <= CAST(? AS DATE)
              AND (ect.effective_to IS NULL OR ect.effective_to >= CAST(? AS DATE))
            ORDER BY ect.sequence_number DESC, ect.effective_from DESC
            """,
            (supplier_id, item_id, service_date_text, service_date_text),
        )
        return [self._effective_term_from_row(row) for row in rows]

    def get_active_contract_terms_for_supplier(
        self,
        supplier_id: str,
        service_date: date,
        category_code: str = "",
    ) -> list[EffectiveContractLineTerm]:
        service_date_text = date_to_str(service_date)
        category_clause = ""
        params: list[Any] = [supplier_id, service_date_text, service_date_text]
        if category_code:
            category_clause = "AND (ect.category_code = ? OR ect.category_code IS NULL OR ect.category_code = '')"
            params.append(category_code)
        rows = self.client.execute(
            f"""
            SELECT ect.*
            FROM {self._table('effective_contract_line_term')} ect
            JOIN {self._table('contract')} c ON c.contract_id = ect.contract_id
            WHERE c.supplier_id = ?
              AND ect.effective_from <= CAST(? AS DATE)
              AND (ect.effective_to IS NULL OR ect.effective_to >= CAST(? AS DATE))
              {category_clause}
            ORDER BY ect.sequence_number DESC, ect.effective_from DESC
            """,
            tuple(params),
        )
        return [self._effective_term_from_row(row) for row in rows]

    def is_member_eligible(self, contract_id: str, member_id: str, on_date: date) -> bool:
        on_date_text = date_to_str(on_date)
        rows = self.client.execute(
            f"""
            SELECT 1 AS found
            FROM {self._table('member_eligibility')}
            WHERE contract_id = ?
              AND party_id = ?
              AND status = 'ACTIVE'
              AND valid_from <= CAST(? AS DATE)
              AND (valid_to IS NULL OR valid_to >= CAST(? AS DATE))
            LIMIT 1
            """,
            (contract_id, member_id, on_date_text, on_date_text),
        )
        return bool(rows)

    def get_uom_conversion(self, item_id: str, from_uom: str, to_uom: str) -> float | None:
        if from_uom == to_uom:
            return 1.0
        rows = self.client.execute(
            f"""
            SELECT conversion_factor
            FROM {self._table('uom_conversion')}
            WHERE item_id = ? AND from_uom = ? AND to_uom = ?
            """,
            (item_id, from_uom, to_uom),
        )
        return float(rows[0]["conversion_factor"]) if rows else None

    def get_supplier_contact(self, supplier_id: str) -> dict[str, Any]:
        rows = self.client.execute(
            f"""
            SELECT party_id, contact_email, contact_data_complete
            FROM {self._table('party')}
            WHERE party_id = ?
            """,
            (supplier_id,),
        )
        if not rows:
            return super().get_supplier_contact(supplier_id)
        contact_email = rows[0].get("contact_email") or ""
        return {
            "supplier_id": supplier_id,
            "contact_email": contact_email,
            "contact_data_complete": bool(rows[0].get("contact_data_complete")) and bool(contact_email),
        }

    def get_graph_match_evidence(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        term: EffectiveContractLineTerm,
    ) -> dict[str, Any]:
        expectations = graph_match_expectations(invoice, line, term)
        clauses = []
        params: list[str] = []
        for expectation in expectations:
            clauses.append("(relationship_type = ? AND from_node_id = ? AND to_node_id = ?)")
            params.extend(
                [
                    expectation["relationship_type"],
                    expectation["from_node_id"],
                    expectation["to_node_id"],
                ]
            )

        rows = self.client.execute(
            f"SELECT * FROM {self._table('edge')} WHERE {' OR '.join(clauses)}",
            tuple(params),
        )
        return build_graph_match_evidence(rows, invoice, line, term)

    def get_graph_match_evidence_for_terms(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        terms: list[EffectiveContractLineTerm],
    ) -> dict[str, dict[str, Any]]:
        if not terms:
            return {}

        expectations = [
            expectation
            for term in terms
            for expectation in graph_match_expectations(invoice, line, term)
        ]
        relationship_types = sorted({expectation["relationship_type"] for expectation in expectations})
        from_node_ids = sorted({expectation["from_node_id"] for expectation in expectations})
        to_node_ids = sorted({expectation["to_node_id"] for expectation in expectations})

        relationship_placeholders = ", ".join("?" for _ in relationship_types)
        from_placeholders = ", ".join("?" for _ in from_node_ids)
        to_placeholders = ", ".join("?" for _ in to_node_ids)
        params = tuple(relationship_types + from_node_ids + to_node_ids)

        rows = self.client.execute(
            f"""
            SELECT *
            FROM {self._table('edge')}
            WHERE relationship_type IN ({relationship_placeholders})
              AND from_node_id IN ({from_placeholders})
              AND to_node_id IN ({to_placeholders})
            """,
            params,
        )
        return {
            term.contract_line_id: build_graph_match_evidence(rows, invoice, line, term)
            for term in terms
        }

    def find_cache_match(
        self,
        contract_id: str,
        invoice_line_signature: str,
        contract_version_id: str | None = None,
    ) -> MatchCandidate | None:
        rows = self.client.execute(
            f"""
            SELECT *
            FROM {self._table('match_cache')}
            WHERE contract_id = ?
              AND invoice_line_signature = ?
              AND cache_status = 'ACTIVE'
              AND (? IS NULL OR contract_version_id = ?)
            LIMIT 1
            """,
            (contract_id, invoice_line_signature, contract_version_id, contract_version_id),
        )
        if not rows:
            return None
        self.client.execute(
            f"""
            UPDATE {self._table('match_cache')}
            SET hit_count = hit_count + 1, last_hit_at = CAST(? AS TIMESTAMP)
            WHERE invoice_line_signature = ?
            """,
            (now_iso(), invoice_line_signature),
        )
        data = from_json(rows[0]["candidate_json"])
        data["route"] = Route.FAST_PATH
        return MatchCandidate(**data)

    def upsert_cache_match(self, signature: str, candidate: MatchCandidate) -> None:
        rows = self.client.execute(
            f"""
            SELECT hit_count
            FROM {self._table('match_cache')}
            WHERE invoice_line_signature = ?
            """,
            (signature,),
        )
        hit_count = int(rows[0]["hit_count"]) if rows else 0
        self._replace(
            "match_cache",
            ("invoice_line_signature",),
            {
                "invoice_line_signature": signature,
                "contract_id": candidate.contract_id,
                "contract_version_id": candidate.contract_version_id,
                "contract_line_id": candidate.contract_line_id,
                "candidate_json": to_json(candidate),
                "cache_status": "ACTIVE",
                "created_at": now_iso(),
                "invalidated_at": None,
                "invalidation_reason": None,
                "hit_count": hit_count,
                "last_hit_at": None,
            },
        )

    def invalidate_contract_cache(self, contract_id: str, reason: str) -> int:
        rows = self.client.execute(
            f"""
            SELECT invoice_line_signature
            FROM {self._table('match_cache')}
            WHERE contract_id = ? AND cache_status = 'ACTIVE'
            """,
            (contract_id,),
        )
        self.client.execute(
            f"""
            UPDATE {self._table('match_cache')}
            SET cache_status = 'INVALIDATED',
                invalidated_at = CAST(? AS TIMESTAMP),
                invalidation_reason = ?
            WHERE contract_id = ? AND cache_status = 'ACTIVE'
            """,
            (now_iso(), reason, contract_id),
        )
        return len(rows)

    def add_run(self, run: ReconciliationRun) -> None:
        self._replace(
            "reconciliation_run",
            ("reconciliation_run_id",),
            {
                "reconciliation_run_id": run.reconciliation_run_id,
                "invoice_id": run.invoice_id,
                "status": run.status,
                "started_at": run.started_at,
                "completed_at": run.completed_at,
                "invoice_line_count": run.invoice_line_count,
                "fast_path_count": run.fast_path_count,
                "deep_path_count": run.deep_path_count,
                "manual_review_count": run.manual_review_count,
                "pass_count": run.pass_count,
                "fail_count": run.fail_count,
                "warning_count": run.warning_count,
            },
        )

    def complete_run(self, run: ReconciliationRun) -> None:
        self.add_run(run)

    def add_validation_result(self, result: ValidationResult) -> None:
        self._replace(
            "validation_result",
            ("validation_result_id",),
            {
                "validation_result_id": result.validation_result_id,
                "reconciliation_run_id": result.reconciliation_run_id,
                "invoice_id": result.invoice_id,
                "invoice_line_id": result.invoice_line_id,
                "rule_code": result.rule_code,
                "status": result.status.value,
                "severity": result.severity.value,
                "matched_contract_id": result.matched_contract_id,
                "matched_contract_version_id": result.matched_contract_version_id,
                "matched_contract_line_id": result.matched_contract_line_id,
                "expected_value": result.expected_value,
                "actual_value": result.actual_value,
                "variance_amount": result.variance_amount,
                "evidence_json": to_json(result.evidence),
            },
        )

    def add_finding(self, finding: Finding) -> None:
        self._replace(
            "finding",
            ("finding_id",),
            {
                "finding_id": finding.finding_id,
                "reconciliation_run_id": finding.reconciliation_run_id,
                "invoice_id": finding.invoice_id,
                "invoice_line_id": finding.invoice_line_id,
                "finding_type": finding.finding_type,
                "status": finding.status,
                "severity": finding.severity.value,
                "summary": finding.summary,
                "detail": finding.detail,
                "variance_amount": finding.variance_amount,
                "matched_contract_id": finding.matched_contract_id,
                "matched_contract_line_id": finding.matched_contract_line_id,
                "evidence_json": to_json(finding.evidence),
            },
        )

    def add_exception_case(self, exception_case: ExceptionCase) -> None:
        self._replace(
            "exception_case",
            ("exception_id",),
            {
                "exception_id": exception_case.exception_id,
                "reconciliation_run_id": exception_case.reconciliation_run_id,
                "invoice_id": exception_case.invoice_id,
                "invoice_line_id": exception_case.invoice_line_id,
                "exception_type": exception_case.exception_type,
                "exception_status": exception_case.exception_status.value,
                "severity": exception_case.severity.value,
                "detected_at": exception_case.detected_at,
                "variance_amount": exception_case.variance_amount,
                "annualized_exposure": exception_case.annualized_exposure,
                "explanation": exception_case.explanation,
                "remediation_suggestion": exception_case.remediation_suggestion,
                "dismissal_reason": exception_case.dismissal_reason,
                "human_decision": exception_case.human_decision,
                "source_quality_status": exception_case.source_quality_status,
                "contact_data_complete": exception_case.contact_data_complete,
                "dispute_ready": exception_case.dispute_ready,
                "evidence_json": to_json(exception_case.evidence),
            },
        )

    def add_dispute(self, dispute: Dispute) -> None:
        self._replace(
            "dispute",
            ("dispute_id",),
            {
                "dispute_id": dispute.dispute_id,
                "reconciliation_run_id": dispute.reconciliation_run_id,
                "invoice_id": dispute.invoice_id,
                "supplier_id": dispute.supplier_id,
                "status": dispute.status.value,
                "to_email": dispute.to_email,
                "from_email": dispute.from_email,
                "cc_email": dispute.cc_email,
                "subject": dispute.subject,
                "body": dispute.body,
                "email_template": dispute.email_template,
                "variable_data_json": to_json(dispute.variable_data),
                "contact_data_complete": dispute.contact_data_complete,
                "created_at": dispute.created_at,
                "sent_at": dispute.sent_at,
                "responded_at": dispute.responded_at,
                "resolution_type": dispute.resolution_type,
                "delivery_method": dispute.delivery_method,
            },
        )

    def add_dispute_line(self, dispute_line: DisputeLine) -> None:
        self._replace(
            "dispute_line",
            ("dispute_id", "invoice_line_id"),
            {
                "dispute_id": dispute_line.dispute_id,
                "invoice_line_id": dispute_line.invoice_line_id,
            },
        )

    def add_dispute_message(self, dispute_message: DisputeMessage) -> None:
        self._replace(
            "dispute_message",
            ("dispute_message_id",),
            {
                "dispute_message_id": dispute_message.dispute_message_id,
                "dispute_id": dispute_message.dispute_id,
                "from_email": dispute_message.from_email,
                "to_email": dispute_message.to_email,
                "sent_timestamp": dispute_message.sent_timestamp,
                "subject": dispute_message.subject,
                "body": dispute_message.body,
                "direction": dispute_message.direction,
            },
        )

    def add_audit_event(
        self,
        event_type: str,
        entity_type: str,
        entity_id: str,
        reconciliation_run_id: str | None = None,
        detail: str = "",
    ) -> None:
        self.client.execute(
            f"""
            INSERT INTO {self._table('audit_event')}
            (audit_event_id, reconciliation_run_id, event_type, entity_type, entity_id, detail, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                stable_id("audit", event_type, entity_type, entity_id, uuid.uuid4().hex),
                reconciliation_run_id,
                event_type,
                entity_type,
                entity_id,
                detail,
                now_iso(),
            ),
        )

    def list_nodes(self) -> list[dict]:
        return self.client.execute(
            f"SELECT * FROM {self._table('node')} ORDER BY entity_type, display_name"
        )

    def list_edges(self) -> list[dict]:
        return self.client.execute(f"SELECT * FROM {self._table('edge')} ORDER BY relationship_type")

    def list_validation_results(self, reconciliation_run_id: str) -> list[dict]:
        return self.client.execute(
            f"""
            SELECT *
            FROM {self._table('validation_result')}
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id, rule_code
            """,
            (reconciliation_run_id,),
        )

    def list_findings(self, reconciliation_run_id: str) -> list[dict]:
        return self.client.execute(
            f"""
            SELECT *
            FROM {self._table('finding')}
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id
            """,
            (reconciliation_run_id,),
        )

    def list_exception_cases(self, reconciliation_run_id: str) -> list[dict]:
        return self.client.execute(
            f"""
            SELECT *
            FROM {self._table('exception_case')}
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id
            """,
            (reconciliation_run_id,),
        )

    def list_disputes(self, reconciliation_run_id: str) -> list[dict]:
        return self.client.execute(
            f"""
            SELECT d.*, CONCAT_WS(',', COLLECT_LIST(dl.invoice_line_id)) AS invoice_line_ids
            FROM {self._table('dispute')} d
            LEFT JOIN {self._table('dispute_line')} dl ON dl.dispute_id = d.dispute_id
            WHERE d.reconciliation_run_id = ?
            GROUP BY d.dispute_id, d.reconciliation_run_id, d.invoice_id, d.supplier_id,
                     d.status, d.to_email, d.from_email, d.cc_email, d.subject, d.body,
                     d.email_template, d.variable_data_json, d.contact_data_complete,
                     d.created_at, d.sent_at, d.responded_at, d.resolution_type, d.delivery_method
            ORDER BY d.created_at, d.dispute_id
            """,
            (reconciliation_run_id,),
        )

    @staticmethod
    def _effective_term_from_row(row: dict[str, Any]) -> EffectiveContractLineTerm:
        return EffectiveContractLineTerm(
            contract_line_id=row["contract_line_id"],
            contract_version_id=row["contract_version_id"],
            contract_id=row["contract_id"],
            item_id=row["item_id"],
            contract_uom=row["contract_uom"],
            unit_price=row["unit_price"],
            currency_code=row["currency_code"],
            tier_id=row["tier_id"],
            effective_from=parse_date(row["effective_from"]),
            effective_to=parse_date(row.get("effective_to")),
            min_quantity=row.get("min_quantity"),
            max_quantity=row.get("max_quantity"),
            description=row.get("description") or "",
            sequence_number=row["sequence_number"],
            category_code=row.get("category_code") or "",
            charge_term_type=row.get("charge_term_type") or "UNIT",
            pricing_basis=row.get("pricing_basis") or "UNIT",
            billing_frequency=row.get("billing_frequency") or "",
            charge_term_allowed=bool(row.get("charge_term_allowed", True)),
        )
