from __future__ import annotations

import uuid
from dataclasses import replace

from ontology.findings import build_dispute_for_exception, build_exception_case, build_finding
from matching.matching import find_best_match
from ontology.models import (
    LineOutcome,
    ReconciliationRun,
    ReconciliationSummary,
    Route,
    ValidationStatus,
)
from ontology.repository import OntologyRepository
from ontology.utils import now_iso, stable_id
from validation.validators import final_status, validate_line


class ReconciliationEngine:
    def __init__(self, repo: OntologyRepository) -> None:
        self.repo = repo

    def reconcile_invoice(self, invoice_id: str) -> ReconciliationSummary:
        invoice = self.repo.get_invoice(invoice_id)
        lines = self.repo.get_invoice_lines(invoice_id)
        started_at = now_iso()
        run_id = stable_id("run", invoice_id, started_at, uuid.uuid4().hex)
        run = ReconciliationRun(
            reconciliation_run_id=run_id,
            invoice_id=invoice_id,
            status="RUNNING",
            started_at=started_at,
            invoice_line_count=len(lines),
        )
        self.repo.add_run(run)
        self.repo.add_audit_event("RECONCILIATION_STARTED", "invoice", invoice_id, run_id)

        outcomes: list[LineOutcome] = []
        fast_path_count = 0
        deep_path_count = 0
        manual_review_count = 0
        pass_count = 0
        fail_count = 0
        warning_count = 0

        for line in lines:
            candidate = find_best_match(self.repo, invoice, line)
            route = candidate.route if candidate else Route.MANUAL_REVIEW
            if route == Route.FAST_PATH:
                fast_path_count += 1
            elif route == Route.DEEP_PATH:
                deep_path_count += 1
            else:
                manual_review_count += 1

            validation_results = validate_line(self.repo, run_id, invoice, line, candidate)
            for result in validation_results:
                self.repo.add_validation_result(result)

            line_status = final_status(validation_results)
            if line_status == "PASS":
                pass_count += 1
            elif line_status == "WARN":
                warning_count += 1
            else:
                fail_count += 1

            finding = build_finding(run_id, invoice, line, candidate, validation_results, line_status)
            self.repo.add_finding(finding)
            supplier_contact = self.repo.get_supplier_contact(invoice.supplier_id)
            exception_case = build_exception_case(
                run_id,
                invoice,
                line,
                candidate,
                validation_results,
                line_status,
                supplier_contact,
            )
            dispute = None
            if exception_case:
                self.repo.add_exception_case(exception_case)
                dispute, dispute_line = build_dispute_for_exception(
                    run_id,
                    invoice,
                    line,
                    exception_case,
                    supplier_contact,
                )
                if dispute and dispute_line:
                    self.repo.add_dispute(dispute)
                    self.repo.add_dispute_line(dispute_line)
            self.repo.add_audit_event(
                "LINE_RECONCILED",
                "invoice_line",
                line.invoice_line_id,
                run_id,
                detail=f"{line_status} via {route.value}",
            )

            outcomes.append(
                LineOutcome(
                    invoice_line=line,
                    candidate=candidate,
                    route=route,
                    final_status=line_status,
                    validation_results=validation_results,
                    finding=finding,
                    exception_case=exception_case,
                    dispute=dispute,
                )
            )

        final = "PASS"
        if fail_count:
            final = "FAIL"
        elif warning_count:
            final = "WARN"

        completed_run = replace(
            run,
            status=final,
            completed_at=now_iso(),
            fast_path_count=fast_path_count,
            deep_path_count=deep_path_count,
            manual_review_count=manual_review_count,
            pass_count=pass_count,
            fail_count=fail_count,
            warning_count=warning_count,
        )
        self.repo.complete_run(completed_run)
        self.repo.add_audit_event("RECONCILIATION_COMPLETED", "invoice", invoice_id, run_id, final)

        total_variance = round(
            sum(
                result.variance_amount
                for outcome in outcomes
                for result in outcome.validation_results
                if result.status == ValidationStatus.FAIL
            )
            + sum(
                outcome.invoice_line.extended_amount
                for outcome in outcomes
                if outcome.candidate is None
            ),
            2,
        )

        return ReconciliationSummary(
            run=completed_run,
            invoice=invoice,
            line_outcomes=outcomes,
            total_variance=total_variance,
            final_status=final,
        )
