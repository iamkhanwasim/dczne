from __future__ import annotations

from ontology.models import (
    Dispute,
    DisputeLine,
    DisputeStatus,
    ExceptionCase,
    ExceptionStatus,
    Finding,
    Invoice,
    InvoiceLine,
    MatchCandidate,
    Severity,
    ValidationResult,
    ValidationStatus,
)
from ontology.utils import now_iso, stable_id


FREQUENCY_MULTIPLIER = {
    "WEEKLY": 52,
    "MONTHLY": 12,
    "QUARTERLY": 4,
    "ANNUAL": 1,
    "YEARLY": 1,
}


def _annualized_exposure(line: InvoiceLine, variance: float) -> float:
    multiplier = FREQUENCY_MULTIPLIER.get(line.billing_frequency.upper(), 1)
    return round(variance * multiplier, 2)


def _enum_value(value: object) -> str:
    return getattr(value, "value", str(value))


def _exception_type(results: list[ValidationResult], candidate: MatchCandidate | None) -> str:
    failed_rules = {result.rule_code for result in results if result.status == ValidationStatus.FAIL}
    if "DATA_QUALITY_SUFFICIENT" in failed_rules:
        return "INSUFFICIENT_DATA"
    if "CHARGE_TERM_ALLOWED" in failed_rules:
        return "UNAUTHORIZED_LINE_ITEM"
    if "PRICE_WITHIN_TOLERANCE" in failed_rules:
        return "RATE_ABOVE_CONTRACT"
    if "FREQUENCY_ALLOWED" in failed_rules:
        return "FREQUENCY_VIOLATION"
    if "CONTRACT_FOUND" in failed_rules:
        return "UNMATCHED_LINE"
    if "ITEM_OR_SERVICE_TERM_MATCHED" in failed_rules:
        return "UNMAPPED_CHARGE"
    if candidate and _enum_value(candidate.match_status) == "REJECTED":
        return "INSUFFICIENT_DATA"
    return "VALIDATION_FAILURE"


def _remediation(exception_type: str) -> str:
    return {
        "RATE_ABOVE_CONTRACT": "Review contracted rate and request supplier credit or dispute.",
        "UNMAPPED_CHARGE": "Review service description and update charge-term mapping or supplemental data.",
        "UNMATCHED_LINE": "Confirm whether supplier line is off contract or missing from contract source data.",
        "INSUFFICIENT_DATA": "Correct source parsing or structured feed quality before financial adjudication.",
        "FREQUENCY_VIOLATION": "Validate billing period and expected invoice frequency.",
        "UNAUTHORIZED_LINE_ITEM": "Confirm excluded or unauthorized charge and route to dispute if applicable.",
    }.get(exception_type, "Review failed validation evidence and assign to analyst queue.")


def build_finding(
    reconciliation_run_id: str,
    invoice: Invoice,
    line: InvoiceLine,
    candidate: MatchCandidate | None,
    results: list[ValidationResult],
    final_status: str,
) -> Finding:
    failed = [result for result in results if result.status == ValidationStatus.FAIL]
    variance = round(sum(result.variance_amount for result in results), 2)

    if final_status == "PASS":
        severity = Severity.INFO
        finding_type = "COMPLIANT"
        summary = f"Line {line.line_number} passed all validation rules"
        detail = "The invoice line matched the contract, eligibility, UOM, amendment, and price rules."
    elif candidate is None:
        severity = Severity.HIGH
        finding_type = "OFF_CONTRACT"
        summary = f"Line {line.line_number} is off contract"
        detail = "No active contract line could be found for this supplier, item, and service date."
        variance = line.extended_amount
    elif any(result.rule_code == "PRICE_WITHIN_TOLERANCE" for result in failed):
        severity = Severity.HIGH
        finding_type = "PRICE_VARIANCE"
        summary = f"Line {line.line_number} has a price variance"
        detail = "The normalized invoice unit price is above the contracted unit price plus tolerance."
    else:
        severity = Severity.HIGH
        finding_type = "VALIDATION_FAILURE"
        summary = f"Line {line.line_number} failed validation"
        detail = "; ".join(f"{result.rule_code}: {result.actual_value}" for result in failed)

    return Finding(
        finding_id=stable_id(reconciliation_run_id, line.invoice_line_id, "finding"),
        reconciliation_run_id=reconciliation_run_id,
        invoice_id=invoice.invoice_id,
        invoice_line_id=line.invoice_line_id,
        finding_type=finding_type,
        status=final_status,
        severity=severity,
        summary=summary,
        detail=detail,
        variance_amount=variance,
        matched_contract_id=candidate.contract_id if candidate else None,
        matched_contract_line_id=candidate.contract_line_id if candidate else None,
        evidence={
            "failed_rules": [result.rule_code for result in failed],
            "matched_contract_line_id": candidate.contract_line_id if candidate else None,
            "match_reason": candidate.reason if candidate else "No candidate",
        },
    )


def build_exception_case(
    reconciliation_run_id: str,
    invoice: Invoice,
    line: InvoiceLine,
    candidate: MatchCandidate | None,
    results: list[ValidationResult],
    final_status: str,
    supplier_contact: dict,
) -> ExceptionCase | None:
    if final_status == "PASS":
        return None

    failed = [result for result in results if result.status == ValidationStatus.FAIL]
    variance = round(sum(result.variance_amount for result in results), 2)
    if candidate is None:
        variance = line.extended_amount
    exception_type = _exception_type(results, candidate)
    contact_complete = bool(supplier_contact.get("contact_data_complete", False))
    dispute_ready = contact_complete and exception_type not in {"INSUFFICIENT_DATA"}

    return ExceptionCase(
        exception_id=stable_id(reconciliation_run_id, line.invoice_line_id, "exception"),
        reconciliation_run_id=reconciliation_run_id,
        invoice_id=invoice.invoice_id,
        invoice_line_id=line.invoice_line_id,
        exception_type=exception_type,
        exception_status=ExceptionStatus.OPEN,
        severity=Severity.HIGH if any(result.severity == Severity.HIGH for result in failed) else Severity.MEDIUM,
        detected_at=now_iso(),
        variance_amount=variance,
        annualized_exposure=_annualized_exposure(line, variance),
        explanation="; ".join(f"{result.rule_code}: {result.actual_value}" for result in failed),
        remediation_suggestion=_remediation(exception_type),
        source_quality_status=line.source_quality_status,
        contact_data_complete=contact_complete,
        dispute_ready=dispute_ready,
        evidence={
            "failed_rules": [result.rule_code for result in failed],
            "match_status": _enum_value(candidate.match_status) if candidate else "NO_MATCH",
            "matched_contract_line_id": candidate.contract_line_id if candidate else None,
            "supplier_contact": supplier_contact,
        },
    )


def build_dispute_for_exception(
    reconciliation_run_id: str,
    invoice: Invoice,
    line: InvoiceLine,
    exception_case: ExceptionCase,
    supplier_contact: dict,
) -> tuple[Dispute, DisputeLine] | tuple[None, None]:
    if not exception_case.dispute_ready:
        return None, None

    dispute_id = stable_id(reconciliation_run_id, invoice.supplier_id, line.invoice_line_id, "dispute")
    subject = f"Price Assurance dispute for invoice {invoice.invoice_number}, line {line.line_number}"
    body = (
        f"Invoice line {line.line_number} triggered {exception_case.exception_type}. "
        f"Variance: {exception_case.variance_amount:.2f}. "
        f"Evidence: {exception_case.explanation}"
    )
    dispute = Dispute(
        dispute_id=dispute_id,
        reconciliation_run_id=reconciliation_run_id,
        invoice_id=invoice.invoice_id,
        supplier_id=invoice.supplier_id,
        status=DisputeStatus.READY_TO_SEND,
        to_email=supplier_contact.get("contact_email", ""),
        from_email="price-assurance@example.com",
        cc_email="",
        subject=subject,
        body=body,
        email_template="generic_price_assurance_dispute",
        variable_data={
            "invoice_id": invoice.invoice_id,
            "invoice_line_id": line.invoice_line_id,
            "exception_type": exception_case.exception_type,
            "variance_amount": exception_case.variance_amount,
        },
        contact_data_complete=True,
        created_at=now_iso(),
        delivery_method="EMAIL",
    )
    return dispute, DisputeLine(dispute_id=dispute_id, invoice_line_id=line.invoice_line_id)
