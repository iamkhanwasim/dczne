from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from enum import Enum
from typing import Any


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class Route(str, Enum):
    FAST_PATH = "FAST_PATH"
    DEEP_PATH = "DEEP_PATH"
    MANUAL_REVIEW = "MANUAL_REVIEW"


class ValidationStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARN = "WARN"
    SKIP = "SKIP"


class Severity(str, Enum):
    INFO = "INFO"
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class MatchStatus(str, Enum):
    MATCHED = "MATCHED"
    UNMATCHED = "UNMATCHED"
    PARTIAL_MATCH = "PARTIAL_MATCH"
    REJECTED = "REJECTED"
    NO_MATCH = "NO_MATCH"
    EXCEPTION = "EXCEPTION"


class ExceptionStatus(str, Enum):
    OPEN = "OPEN"
    DISMISSED = "DISMISSED"
    INVESTIGATING = "INVESTIGATING"
    DISPUTED = "DISPUTED"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class DisputeStatus(str, Enum):
    DRAFT = "DRAFT"
    READY_TO_SEND = "READY_TO_SEND"
    SENT = "SENT"
    SUPPLIER_RESPONDED = "SUPPLIER_RESPONDED"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


@dataclass(frozen=True)
class Party:
    party_id: str
    party_type: str
    party_name: str
    active_flag: bool = True
    contact_email: str = ""
    contact_data_complete: bool = False
    primary_facility_id: str = ""
    gl_code: str = ""


@dataclass(frozen=True)
class Item:
    item_id: str
    description: str
    manufacturer_item_number: str = ""
    supplier_item_number: str = ""
    gtin: str = ""
    category_code: str = ""
    active_flag: bool = True


@dataclass(frozen=True)
class UomConversion:
    item_id: str
    from_uom: str
    to_uom: str
    conversion_factor: float


@dataclass(frozen=True)
class Contract:
    contract_id: str
    contract_number: str
    contract_name: str
    gpo_id: str
    supplier_id: str
    effective_date: date
    expiration_date: date
    status: str = "ACTIVE"


@dataclass(frozen=True)
class ContractVersion:
    contract_version_id: str
    contract_id: str
    version_type: str
    sequence_number: int
    effective_date: date
    expiration_date: date | None = None
    amendment_number: str = ""
    retroactive_flag: bool = False


@dataclass(frozen=True)
class ContractLineTerm:
    contract_line_id: str
    contract_version_id: str
    contract_id: str
    item_id: str
    action_type: str
    contract_uom: str
    unit_price: float
    currency_code: str
    tier_id: str
    effective_from: date
    effective_to: date | None = None
    min_quantity: float | None = None
    max_quantity: float | None = None
    description: str = ""
    category_code: str = ""
    charge_term_type: str = "UNIT"
    pricing_basis: str = "UNIT"
    billing_frequency: str = ""
    charge_term_allowed: bool = True


@dataclass(frozen=True)
class EffectiveContractLineTerm:
    contract_line_id: str
    contract_version_id: str
    contract_id: str
    item_id: str
    contract_uom: str
    unit_price: float
    currency_code: str
    tier_id: str
    effective_from: date
    effective_to: date | None
    min_quantity: float | None = None
    max_quantity: float | None = None
    description: str = ""
    sequence_number: int = 0
    category_code: str = ""
    charge_term_type: str = "UNIT"
    pricing_basis: str = "UNIT"
    billing_frequency: str = ""
    charge_term_allowed: bool = True


@dataclass(frozen=True)
class MemberEligibility:
    eligibility_id: str
    contract_id: str
    party_id: str
    tier_id: str
    valid_from: date
    valid_to: date | None = None
    status: str = "ACTIVE"


@dataclass(frozen=True)
class Invoice:
    invoice_id: str
    invoice_number: str
    invoice_date: date
    supplier_id: str
    member_id: str
    currency_code: str
    total_amount: float
    contract_number_reference: str = ""
    payment_status: str = ""
    po_type: str = ""
    interception_status: str = ""


@dataclass(frozen=True)
class InvoiceLine:
    invoice_line_id: str
    invoice_id: str
    line_number: str
    item_id: str
    description: str
    quantity: float
    invoice_uom: str
    unit_price: float
    extended_amount: float
    service_date: date
    category_code: str = ""
    charge_term_text: str = ""
    billing_frequency: str = ""
    billing_period_start: date | None = None
    billing_period_end: date | None = None
    parse_confidence: float | None = None
    source_quality_status: str = "TRUSTED"


@dataclass(frozen=True)
class Node:
    node_id: str
    entity_type: str
    entity_id: str
    display_name: str
    properties: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Edge:
    edge_id: str
    from_node_id: str
    to_node_id: str
    relationship_type: str
    valid_from: date | None = None
    valid_to: date | None = None
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RuleCatalogEntry:
    rule_code: str
    rule_version: str
    rule_group: str
    severity: Severity
    description: str
    active_flag: bool = True
    parameters: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MatchingPolicy:
    policy_id: str = "default"
    exact_item_weight: float = 0.35
    eligibility_weight: float = 0.20
    date_weight: float = 0.15
    uom_weight: float = 0.10
    price_weight: float = 0.10
    semantic_weight: float = 0.10
    graph_weight: float = 0.05
    category_weight: float = 0.05
    fast_path_threshold: float = 0.93
    deep_path_threshold: float = 0.65
    ambiguity_delta: float = 0.08
    price_tolerance_pct: float = 0.005
    semantic_match_threshold: float = 0.45
    source_quality_confidence_threshold: float = 0.80


@dataclass(frozen=True)
class MatchCandidate:
    invoice_line_id: str
    contract_line_id: str
    contract_id: str
    contract_version_id: str
    score: float
    route: Route
    exact_item_match: bool
    member_eligible: bool
    date_valid: bool
    uom_convertible: bool
    price_proximity: float
    semantic_similarity: float
    normalized_invoice_unit_price: float | None
    contract_unit_price: float
    reason: str
    contract_min_quantity: float | None = None
    contract_max_quantity: float | None = None
    graph_support_score: float = 0.0
    graph_evidence: dict[str, Any] = field(default_factory=dict)
    contract_selection_score: float = 0.0
    contract_selection_evidence: dict[str, Any] = field(default_factory=dict)
    contract_candidate_count: int = 0
    term_candidate_count: int = 0
    match_status: MatchStatus = MatchStatus.MATCHED
    category_compatible: bool = True
    charge_term_type: str = "UNIT"
    pricing_basis: str = "UNIT"
    charge_term_allowed: bool = True
    uom_required: bool = True
    uom_absent_accepted: bool = False
    data_quality_sufficient: bool = True


@dataclass(frozen=True)
class ValidationResult:
    validation_result_id: str
    reconciliation_run_id: str
    invoice_id: str
    invoice_line_id: str
    rule_code: str
    status: ValidationStatus
    severity: Severity
    matched_contract_id: str | None = None
    matched_contract_version_id: str | None = None
    matched_contract_line_id: str | None = None
    expected_value: str = ""
    actual_value: str = ""
    variance_amount: float = 0.0
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Finding:
    finding_id: str
    reconciliation_run_id: str
    invoice_id: str
    invoice_line_id: str
    finding_type: str
    status: str
    severity: Severity
    summary: str
    detail: str
    variance_amount: float = 0.0
    matched_contract_id: str | None = None
    matched_contract_line_id: str | None = None
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExceptionCase:
    exception_id: str
    reconciliation_run_id: str
    invoice_id: str
    invoice_line_id: str
    exception_type: str
    exception_status: ExceptionStatus
    severity: Severity
    detected_at: str
    variance_amount: float = 0.0
    annualized_exposure: float = 0.0
    explanation: str = ""
    remediation_suggestion: str = ""
    dismissal_reason: str = ""
    human_decision: str = ""
    source_quality_status: str = ""
    contact_data_complete: bool = False
    dispute_ready: bool = False
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class Dispute:
    dispute_id: str
    reconciliation_run_id: str
    invoice_id: str
    supplier_id: str
    status: DisputeStatus
    to_email: str
    from_email: str
    cc_email: str
    subject: str
    body: str
    email_template: str
    variable_data: dict[str, Any] = field(default_factory=dict)
    contact_data_complete: bool = False
    created_at: str = ""
    sent_at: str | None = None
    responded_at: str | None = None
    resolution_type: str = ""
    delivery_method: str = "EMAIL"


@dataclass(frozen=True)
class DisputeLine:
    dispute_id: str
    invoice_line_id: str


@dataclass(frozen=True)
class DisputeMessage:
    dispute_message_id: str
    dispute_id: str
    from_email: str
    to_email: str
    sent_timestamp: str
    subject: str
    body: str
    direction: str


@dataclass(frozen=True)
class ReconciliationRun:
    reconciliation_run_id: str
    invoice_id: str
    status: str
    started_at: str
    completed_at: str | None = None
    invoice_line_count: int = 0
    fast_path_count: int = 0
    deep_path_count: int = 0
    manual_review_count: int = 0
    pass_count: int = 0
    fail_count: int = 0
    warning_count: int = 0


@dataclass(frozen=True)
class LineOutcome:
    invoice_line: InvoiceLine
    candidate: MatchCandidate | None
    route: Route
    final_status: str
    validation_results: list[ValidationResult]
    finding: Finding
    exception_case: ExceptionCase | None = None
    dispute: Dispute | None = None


@dataclass(frozen=True)
class ReconciliationSummary:
    run: ReconciliationRun
    invoice: Invoice
    line_outcomes: list[LineOutcome]
    total_variance: float
    final_status: str
