from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Any

from ontology.models import (
    Contract,
    ContractLineTerm,
    ContractVersion,
    Dispute,
    DisputeLine,
    DisputeMessage,
    Edge,
    EffectiveContractLineTerm,
    ExceptionCase,
    Finding,
    Invoice,
    InvoiceLine,
    Item,
    MatchCandidate,
    MatchingPolicy,
    MemberEligibility,
    Node,
    Party,
    ReconciliationRun,
    RuleCatalogEntry,
    UomConversion,
    ValidationResult,
)
from ontology.utils import parse_date


GRAPH_MATCH_EXPECTED_RELATIONSHIPS: tuple[tuple[str, str, float], ...] = (
    ("invoice_has_line", "HAS_LINE", 0.15),
    ("contract_has_term", "HAS_TERM", 0.25),
    ("term_prices_item", "PRICES_ITEM", 0.25),
    ("member_eligible_for_contract", "ELIGIBLE_FOR", 0.20),
    ("supplier_participates_in_contract", "PARTICIPATES_IN", 0.15),
)


def _node_id(entity_id: str) -> str:
    return f"node-{entity_id}"


def graph_match_expectations(
    invoice: Invoice,
    line: InvoiceLine,
    term: EffectiveContractLineTerm,
) -> list[dict[str, Any]]:
    """Return the ontology graph relationships expected for a candidate match."""

    weights = {name: weight for name, _, weight in GRAPH_MATCH_EXPECTED_RELATIONSHIPS}
    expectations = [
        {
            "name": "invoice_has_line",
            "relationship_type": "HAS_LINE",
            "from_node_id": _node_id(invoice.invoice_id),
            "to_node_id": _node_id(line.invoice_line_id),
            "on_date": invoice.invoice_date,
            "weight": weights["invoice_has_line"],
        },
        {
            "name": "contract_has_term",
            "relationship_type": "HAS_TERM",
            "from_node_id": _node_id(term.contract_id),
            "to_node_id": _node_id(term.contract_line_id),
            "on_date": line.service_date,
            "weight": weights["contract_has_term"],
        },
        {
            "name": "member_eligible_for_contract",
            "relationship_type": "ELIGIBLE_FOR",
            "from_node_id": _node_id(invoice.member_id),
            "to_node_id": _node_id(term.contract_id),
            "on_date": line.service_date,
            "weight": weights["member_eligible_for_contract"],
        },
        {
            "name": "supplier_participates_in_contract",
            "relationship_type": "PARTICIPATES_IN",
            "from_node_id": _node_id(invoice.supplier_id),
            "to_node_id": _node_id(term.contract_id),
            "on_date": line.service_date,
            "weight": weights["supplier_participates_in_contract"],
        },
    ]
    if term.item_id:
        expectations.insert(
            2,
            {
                "name": "term_prices_item",
                "relationship_type": "PRICES_ITEM",
                "from_node_id": _node_id(term.contract_line_id),
                "to_node_id": _node_id(term.item_id),
                "on_date": line.service_date,
                "weight": weights["term_prices_item"],
            },
        )
    return expectations


def _edge_value(edge: dict[str, Any], *names: str) -> Any:
    for name in names:
        if name in edge:
            return edge[name]
    return None


def _edge_is_active(edge: dict[str, Any], on_date: date | None) -> bool:
    if on_date is None:
        return True
    valid_from = parse_date(_edge_value(edge, "valid_from"))
    valid_to = parse_date(_edge_value(edge, "valid_to"))
    return (valid_from is None or valid_from <= on_date) and (
        valid_to is None or valid_to >= on_date
    )


def build_graph_match_evidence(
    edges: list[dict[str, Any]],
    invoice: Invoice,
    line: InvoiceLine,
    term: EffectiveContractLineTerm,
) -> dict[str, Any]:
    """Calculate graph support evidence for a candidate invoice-line match."""

    expectations = graph_match_expectations(invoice, line, term)
    checks: list[dict[str, Any]] = []
    matched_weight = 0.0
    total_weight = sum(expectation["weight"] for expectation in expectations)

    for expectation in expectations:
        matching_edges = [
            edge
            for edge in edges
            if _edge_value(edge, "relationship_type") == expectation["relationship_type"]
            and _edge_value(edge, "from_node_id", "source_node_id") == expectation["from_node_id"]
            and _edge_value(edge, "to_node_id", "target_node_id") == expectation["to_node_id"]
            and _edge_is_active(edge, expectation["on_date"])
        ]
        found = bool(matching_edges)
        if found:
            matched_weight += expectation["weight"]
        checks.append(
            {
                "name": expectation["name"],
                "relationship_type": expectation["relationship_type"],
                "from_node_id": expectation["from_node_id"],
                "to_node_id": expectation["to_node_id"],
                "found": found,
                "weight": expectation["weight"],
                "edge_id": _edge_value(matching_edges[0], "edge_id") if found else None,
            }
        )

    support_score = matched_weight / total_weight if total_weight else 0.0
    return {
        "available": bool(edges),
        "support_score": round(support_score, 4),
        "matched_relationships": sum(1 for check in checks if check["found"]),
        "expected_relationships": len(checks),
        "matched_weight": round(matched_weight, 4),
        "total_weight": round(total_weight, 4),
        "checks": checks,
    }


class OntologyRepository(ABC):
    """Storage contract used by reconciliation algorithms.

    Production implementations can target Databricks SQL/Delta. The local demo
    implementation uses SQLite with the same method contract.
    """

    @abstractmethod
    def initialize(self) -> None:
        """Create required tables if they do not exist."""

    @abstractmethod
    def reset(self) -> None:
        """Remove demo data from all tables."""

    def close(self) -> None:
        """Release repository resources."""

    def healthcheck(self) -> dict[str, Any]:
        """Return lightweight repository diagnostics."""
        return {"status": "unknown", "backend": type(self).__name__}

    def metrics(self) -> dict[str, Any]:
        """Return operational counters suitable for health dashboards."""
        return {"backend": type(self).__name__, "metrics_available": False}

    @abstractmethod
    def add_party(self, party: Party) -> None: ...

    @abstractmethod
    def add_item(self, item: Item) -> None: ...

    @abstractmethod
    def add_uom_conversion(self, conversion: UomConversion) -> None: ...

    @abstractmethod
    def add_contract(self, contract: Contract) -> None: ...

    @abstractmethod
    def add_contract_version(self, version: ContractVersion) -> None: ...

    @abstractmethod
    def add_contract_line_term(self, term: ContractLineTerm) -> None: ...

    @abstractmethod
    def add_effective_contract_line_term(self, term: EffectiveContractLineTerm) -> None: ...

    @abstractmethod
    def add_member_eligibility(self, eligibility: MemberEligibility) -> None: ...

    @abstractmethod
    def add_invoice(self, invoice: Invoice) -> None: ...

    @abstractmethod
    def add_invoice_line(self, line: InvoiceLine) -> None: ...

    @abstractmethod
    def add_node(self, node: Node) -> None: ...

    @abstractmethod
    def add_edge(self, edge: Edge) -> None: ...

    @abstractmethod
    def add_rule(self, rule: RuleCatalogEntry) -> None: ...

    @abstractmethod
    def set_matching_policy(self, policy: MatchingPolicy) -> None: ...

    @abstractmethod
    def get_matching_policy(self) -> MatchingPolicy: ...

    @abstractmethod
    def get_invoice(self, invoice_id: str) -> Invoice: ...

    @abstractmethod
    def get_invoice_lines(self, invoice_id: str) -> list[InvoiceLine]: ...

    @abstractmethod
    def get_item(self, item_id: str) -> Item | None: ...

    @abstractmethod
    def get_active_contract_terms(
        self,
        supplier_id: str,
        item_id: str,
        service_date: date,
    ) -> list[EffectiveContractLineTerm]: ...

    def get_active_contract_terms_for_supplier(
        self,
        supplier_id: str,
        service_date: date,
        category_code: str = "",
    ) -> list[EffectiveContractLineTerm]:
        """Return active supplier terms when no reliable item identifier is available."""

        return []

    def get_candidate_contract_terms(
        self,
        supplier_id: str,
        item_id: str,
        service_date: date,
        category_code: str = "",
    ) -> list[EffectiveContractLineTerm]:
        """Retrieve terms for item-based or service/semantic matching."""

        if item_id:
            item_terms = self.get_active_contract_terms(supplier_id, item_id, service_date)
            if item_terms:
                return item_terms
        return self.get_active_contract_terms_for_supplier(supplier_id, service_date, category_code)

    @abstractmethod
    def is_member_eligible(self, contract_id: str, member_id: str, on_date: date) -> bool: ...

    @abstractmethod
    def get_uom_conversion(self, item_id: str, from_uom: str, to_uom: str) -> float | None: ...

    def get_supplier_contact(self, supplier_id: str) -> dict[str, Any]:
        """Return supplier contact readiness used by dispute gating."""

        return {
            "supplier_id": supplier_id,
            "contact_email": "",
            "contact_data_complete": False,
        }

    @abstractmethod
    def find_cache_match(
        self,
        contract_id: str,
        invoice_line_signature: str,
        contract_version_id: str | None = None,
    ) -> MatchCandidate | None: ...

    @abstractmethod
    def upsert_cache_match(self, signature: str, candidate: MatchCandidate) -> None: ...

    @abstractmethod
    def invalidate_contract_cache(self, contract_id: str, reason: str) -> int: ...

    @abstractmethod
    def add_run(self, run: ReconciliationRun) -> None: ...

    @abstractmethod
    def complete_run(self, run: ReconciliationRun) -> None: ...

    @abstractmethod
    def add_validation_result(self, result: ValidationResult) -> None: ...

    @abstractmethod
    def add_finding(self, finding: Finding) -> None: ...

    def add_exception_case(self, exception_case: ExceptionCase) -> None:
        """Persist a PA/OOUX exception case when supported by the repository."""

    def add_dispute(self, dispute: Dispute) -> None:
        """Persist a draft or sent dispute when supported by the repository."""

    def add_dispute_line(self, dispute_line: DisputeLine) -> None:
        """Persist line-level dispute membership when supported by the repository."""

    def add_dispute_message(self, dispute_message: DisputeMessage) -> None:
        """Persist dispute communication history when supported by the repository."""

    @abstractmethod
    def add_audit_event(
        self,
        event_type: str,
        entity_type: str,
        entity_id: str,
        reconciliation_run_id: str | None = None,
        detail: str = "",
    ) -> None: ...

    @abstractmethod
    def list_nodes(self) -> list[dict]: ...

    @abstractmethod
    def list_edges(self) -> list[dict]: ...

    def get_graph_match_evidence(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        term: EffectiveContractLineTerm,
    ) -> dict[str, Any]:
        """Return ontology graph evidence supporting a candidate match.

        Implementations can override this with optimized graph queries. The
        default uses the graph edge listing so custom repositories can opt in
        without implementing a new query immediately.
        """

        return build_graph_match_evidence(self.list_edges(), invoice, line, term)

    def get_graph_match_evidence_for_terms(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        terms: list[EffectiveContractLineTerm],
    ) -> dict[str, dict[str, Any]]:
        """Return graph evidence for all candidate terms for one invoice line.

        The default implementation preserves compatibility for custom
        repositories. Production repositories override this to fetch the
        required edge set once per invoice line.
        """

        return {
            term.contract_line_id: self.get_graph_match_evidence(invoice, line, term)
            for term in terms
        }

    def find_cache_match_for_contracts(
        self,
        contract_ids: list[str],
        invoice_line_signature: str,
        contract_version_id: str | None = None,
    ) -> MatchCandidate | None:
        """Find the first active fast-path cache hit across candidate contracts."""

        for contract_id in dict.fromkeys(contract_ids):
            cached = self.find_cache_match(contract_id, invoice_line_signature, contract_version_id)
            if cached is not None:
                return cached
        return None

    @abstractmethod
    def list_validation_results(self, reconciliation_run_id: str) -> list[dict]: ...

    @abstractmethod
    def list_findings(self, reconciliation_run_id: str) -> list[dict]: ...

    def list_exception_cases(self, reconciliation_run_id: str) -> list[dict]:
        return []

    def list_disputes(self, reconciliation_run_id: str) -> list[dict]:
        return []
