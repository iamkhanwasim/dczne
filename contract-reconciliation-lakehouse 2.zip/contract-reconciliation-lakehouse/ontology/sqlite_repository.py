from __future__ import annotations

import sqlite3
import uuid
from datetime import date
from pathlib import Path
from typing import Any

from ontology.models import (
    Contract,
    ContractLineTerm,
    ContractVersion,
    Dispute,
    DisputeLine,
    DisputeMessage,
    Edge,
    EffectiveContractLineTerm,
    ExceptionCase,
    Finding,
    Invoice,
    InvoiceLine,
    Item,
    MatchCandidate,
    MatchingPolicy,
    MemberEligibility,
    Node,
    Party,
    ReconciliationRun,
    Route,
    RuleCatalogEntry,
    Severity,
    UomConversion,
    ValidationResult,
    ValidationStatus,
)
from ontology.repository import (
    OntologyRepository,
    build_graph_match_evidence,
    graph_match_expectations,
)
from ontology.utils import date_to_str, from_json, now_iso, parse_date, stable_id, to_json


class SQLiteOntologyRepository(OntologyRepository):
    """Local repository used for the runnable demo.

    The schema intentionally mirrors the Databricks Delta table design. This
    gives developers a lightweight execution path while keeping migration to
    Databricks SQL straightforward.
    """

    def __init__(self, db_path: str | Path = "demo_reconciliation.db") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.db_path, timeout=30.0, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.execute("PRAGMA busy_timeout = 30000")

    def initialize(self) -> None:
        statements = [
            """
            CREATE TABLE IF NOT EXISTS party (
              party_id TEXT PRIMARY KEY,
              party_type TEXT NOT NULL,
              party_name TEXT NOT NULL,
              active_flag INTEGER NOT NULL,
              contact_email TEXT,
              contact_data_complete INTEGER NOT NULL DEFAULT 0,
              primary_facility_id TEXT,
              gl_code TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS item (
              item_id TEXT PRIMARY KEY,
              description TEXT NOT NULL,
              manufacturer_item_number TEXT,
              supplier_item_number TEXT,
              gtin TEXT,
              category_code TEXT,
              active_flag INTEGER NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS uom_conversion (
              item_id TEXT NOT NULL,
              from_uom TEXT NOT NULL,
              to_uom TEXT NOT NULL,
              conversion_factor REAL NOT NULL,
              PRIMARY KEY (item_id, from_uom, to_uom)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS contract (
              contract_id TEXT PRIMARY KEY,
              contract_number TEXT NOT NULL,
              contract_name TEXT NOT NULL,
              gpo_id TEXT NOT NULL,
              supplier_id TEXT NOT NULL,
              effective_date TEXT NOT NULL,
              expiration_date TEXT NOT NULL,
              status TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS contract_version (
              contract_version_id TEXT PRIMARY KEY,
              contract_id TEXT NOT NULL,
              version_type TEXT NOT NULL,
              sequence_number INTEGER NOT NULL,
              effective_date TEXT NOT NULL,
              expiration_date TEXT,
              amendment_number TEXT,
              retroactive_flag INTEGER NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS contract_line_term (
              contract_line_id TEXT PRIMARY KEY,
              contract_version_id TEXT NOT NULL,
              contract_id TEXT NOT NULL,
              item_id TEXT NOT NULL,
              action_type TEXT NOT NULL,
              contract_uom TEXT NOT NULL,
              unit_price REAL NOT NULL,
              currency_code TEXT NOT NULL,
              tier_id TEXT NOT NULL,
              effective_from TEXT NOT NULL,
              effective_to TEXT,
              min_quantity REAL,
              max_quantity REAL,
              description TEXT,
              category_code TEXT,
              charge_term_type TEXT,
              pricing_basis TEXT,
              billing_frequency TEXT,
              charge_term_allowed INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS effective_contract_line_term (
              contract_line_id TEXT PRIMARY KEY,
              contract_version_id TEXT NOT NULL,
              contract_id TEXT NOT NULL,
              item_id TEXT NOT NULL,
              contract_uom TEXT NOT NULL,
              unit_price REAL NOT NULL,
              currency_code TEXT NOT NULL,
              tier_id TEXT NOT NULL,
              effective_from TEXT NOT NULL,
              effective_to TEXT,
              min_quantity REAL,
              max_quantity REAL,
              description TEXT,
              sequence_number INTEGER NOT NULL,
              category_code TEXT,
              charge_term_type TEXT,
              pricing_basis TEXT,
              billing_frequency TEXT,
              charge_term_allowed INTEGER NOT NULL DEFAULT 1
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS member_eligibility (
              eligibility_id TEXT PRIMARY KEY,
              contract_id TEXT NOT NULL,
              party_id TEXT NOT NULL,
              tier_id TEXT NOT NULL,
              valid_from TEXT NOT NULL,
              valid_to TEXT,
              status TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS invoice (
              invoice_id TEXT PRIMARY KEY,
              invoice_number TEXT NOT NULL,
              invoice_date TEXT NOT NULL,
              supplier_id TEXT NOT NULL,
              member_id TEXT NOT NULL,
              currency_code TEXT NOT NULL,
              total_amount REAL NOT NULL,
              contract_number_reference TEXT,
              payment_status TEXT,
              po_type TEXT,
              interception_status TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS invoice_line (
              invoice_line_id TEXT PRIMARY KEY,
              invoice_id TEXT NOT NULL,
              line_number TEXT NOT NULL,
              item_id TEXT NOT NULL,
              description TEXT NOT NULL,
              quantity REAL NOT NULL,
              invoice_uom TEXT NOT NULL,
              unit_price REAL NOT NULL,
              extended_amount REAL NOT NULL,
              service_date TEXT NOT NULL,
              category_code TEXT,
              charge_term_text TEXT,
              billing_frequency TEXT,
              billing_period_start TEXT,
              billing_period_end TEXT,
              parse_confidence REAL,
              source_quality_status TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS node (
              node_id TEXT PRIMARY KEY,
              entity_type TEXT NOT NULL,
              entity_id TEXT NOT NULL,
              display_name TEXT NOT NULL,
              properties_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS edge (
              edge_id TEXT PRIMARY KEY,
              from_node_id TEXT NOT NULL,
              to_node_id TEXT NOT NULL,
              relationship_type TEXT NOT NULL,
              valid_from TEXT,
              valid_to TEXT,
              evidence_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS rule_catalog (
              rule_code TEXT PRIMARY KEY,
              rule_version TEXT NOT NULL,
              rule_group TEXT NOT NULL,
              severity TEXT NOT NULL,
              description TEXT NOT NULL,
              active_flag INTEGER NOT NULL,
              parameters_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS matching_policy (
              policy_id TEXT PRIMARY KEY,
              policy_json TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS match_cache (
              invoice_line_signature TEXT PRIMARY KEY,
              contract_id TEXT NOT NULL,
              contract_version_id TEXT,
              contract_line_id TEXT NOT NULL,
              candidate_json TEXT NOT NULL,
              cache_status TEXT NOT NULL,
              created_at TEXT NOT NULL,
              invalidated_at TEXT,
              invalidation_reason TEXT,
              hit_count INTEGER NOT NULL,
              last_hit_at TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS reconciliation_run (
              reconciliation_run_id TEXT PRIMARY KEY,
              invoice_id TEXT NOT NULL,
              status TEXT NOT NULL,
              started_at TEXT NOT NULL,
              completed_at TEXT,
              invoice_line_count INTEGER NOT NULL,
              fast_path_count INTEGER NOT NULL,
              deep_path_count INTEGER NOT NULL,
              manual_review_count INTEGER NOT NULL,
              pass_count INTEGER NOT NULL,
              fail_count INTEGER NOT NULL,
              warning_count INTEGER NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS validation_result (
              validation_result_id TEXT PRIMARY KEY,
              reconciliation_run_id TEXT NOT NULL,
              invoice_id TEXT NOT NULL,
              invoice_line_id TEXT NOT NULL,
              rule_code TEXT NOT NULL,
              status TEXT NOT NULL,
              severity TEXT NOT NULL,
              matched_contract_id TEXT,
              matched_contract_version_id TEXT,
              matched_contract_line_id TEXT,
              expected_value TEXT,
              actual_value TEXT,
              variance_amount REAL NOT NULL,
              evidence_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS finding (
              finding_id TEXT PRIMARY KEY,
              reconciliation_run_id TEXT NOT NULL,
              invoice_id TEXT NOT NULL,
              invoice_line_id TEXT NOT NULL,
              finding_type TEXT NOT NULL,
              status TEXT NOT NULL,
              severity TEXT NOT NULL,
              summary TEXT NOT NULL,
              detail TEXT NOT NULL,
              variance_amount REAL NOT NULL,
              matched_contract_id TEXT,
              matched_contract_line_id TEXT,
              evidence_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS exception_case (
              exception_id TEXT PRIMARY KEY,
              reconciliation_run_id TEXT NOT NULL,
              invoice_id TEXT NOT NULL,
              invoice_line_id TEXT NOT NULL,
              exception_type TEXT NOT NULL,
              exception_status TEXT NOT NULL,
              severity TEXT NOT NULL,
              detected_at TEXT NOT NULL,
              variance_amount REAL NOT NULL,
              annualized_exposure REAL NOT NULL,
              explanation TEXT,
              remediation_suggestion TEXT,
              dismissal_reason TEXT,
              human_decision TEXT,
              source_quality_status TEXT,
              contact_data_complete INTEGER NOT NULL,
              dispute_ready INTEGER NOT NULL,
              evidence_json TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS dispute (
              dispute_id TEXT PRIMARY KEY,
              reconciliation_run_id TEXT NOT NULL,
              invoice_id TEXT NOT NULL,
              supplier_id TEXT NOT NULL,
              status TEXT NOT NULL,
              to_email TEXT,
              from_email TEXT,
              cc_email TEXT,
              subject TEXT,
              body TEXT,
              email_template TEXT,
              variable_data_json TEXT,
              contact_data_complete INTEGER NOT NULL,
              created_at TEXT NOT NULL,
              sent_at TEXT,
              responded_at TEXT,
              resolution_type TEXT,
              delivery_method TEXT
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS dispute_line (
              dispute_id TEXT NOT NULL,
              invoice_line_id TEXT NOT NULL,
              PRIMARY KEY (dispute_id, invoice_line_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS dispute_message (
              dispute_message_id TEXT PRIMARY KEY,
              dispute_id TEXT NOT NULL,
              from_email TEXT,
              to_email TEXT,
              sent_timestamp TEXT NOT NULL,
              subject TEXT,
              body TEXT,
              direction TEXT NOT NULL
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS audit_event (
              audit_event_id TEXT PRIMARY KEY,
              reconciliation_run_id TEXT,
              event_type TEXT NOT NULL,
              entity_type TEXT NOT NULL,
              entity_id TEXT NOT NULL,
              detail TEXT,
              created_at TEXT NOT NULL
            )
            """,
            "CREATE INDEX IF NOT EXISTS idx_invoice_line_invoice ON invoice_line(invoice_id)",
            "CREATE INDEX IF NOT EXISTS idx_contract_supplier ON contract(supplier_id, contract_id)",
            """
            CREATE INDEX IF NOT EXISTS idx_effective_terms_lookup
            ON effective_contract_line_term(contract_id, item_id, effective_from, effective_to)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_effective_terms_item_date
            ON effective_contract_line_term(item_id, effective_from, effective_to, contract_id)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_member_eligibility_lookup
            ON member_eligibility(contract_id, party_id, valid_from, valid_to, status)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_edge_lookup
            ON edge(relationship_type, from_node_id, to_node_id, valid_from, valid_to)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_match_cache_lookup
            ON match_cache(contract_id, invoice_line_signature, cache_status, contract_version_id)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_match_cache_signature
            ON match_cache(invoice_line_signature, cache_status)
            """,
            """
            CREATE INDEX IF NOT EXISTS idx_validation_result_run
            ON validation_result(reconciliation_run_id, invoice_line_id)
            """,
            "CREATE INDEX IF NOT EXISTS idx_finding_run ON finding(reconciliation_run_id)",
            "CREATE INDEX IF NOT EXISTS idx_exception_case_run ON exception_case(reconciliation_run_id, invoice_line_id)",
            "CREATE INDEX IF NOT EXISTS idx_dispute_run ON dispute(reconciliation_run_id, supplier_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_event_run ON audit_event(reconciliation_run_id)",
        ]
        for statement in statements:
            self.conn.execute(statement)
        self._ensure_schema_columns()
        self.conn.commit()

    def _ensure_schema_columns(self) -> None:
        additions = {
            "party": {
                "contact_email": "TEXT",
                "contact_data_complete": "INTEGER NOT NULL DEFAULT 0",
                "primary_facility_id": "TEXT",
                "gl_code": "TEXT",
            },
            "contract_line_term": {
                "category_code": "TEXT",
                "charge_term_type": "TEXT",
                "pricing_basis": "TEXT",
                "billing_frequency": "TEXT",
                "charge_term_allowed": "INTEGER NOT NULL DEFAULT 1",
            },
            "effective_contract_line_term": {
                "category_code": "TEXT",
                "charge_term_type": "TEXT",
                "pricing_basis": "TEXT",
                "billing_frequency": "TEXT",
                "charge_term_allowed": "INTEGER NOT NULL DEFAULT 1",
            },
            "invoice": {
                "payment_status": "TEXT",
                "po_type": "TEXT",
                "interception_status": "TEXT",
            },
            "invoice_line": {
                "category_code": "TEXT",
                "charge_term_text": "TEXT",
                "billing_frequency": "TEXT",
                "billing_period_start": "TEXT",
                "billing_period_end": "TEXT",
                "parse_confidence": "REAL",
                "source_quality_status": "TEXT",
            },
        }
        for table, columns in additions.items():
            existing = {
                row["name"]
                for row in self.conn.execute(f"PRAGMA table_info({table})").fetchall()
            }
            for column, definition in columns.items():
                if column not in existing:
                    self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def close(self) -> None:
        self.conn.close()

    def healthcheck(self) -> dict:
        try:
            self.conn.execute("SELECT 1").fetchone()
            return {
                "status": "ok",
                "backend": "sqlite",
                "database": str(self.db_path),
            }
        except sqlite3.Error as exc:
            return {
                "status": "error",
                "backend": "sqlite",
                "database": str(self.db_path),
                "error": str(exc),
            }

    def metrics(self) -> dict:
        tables = [
            "party",
            "item",
            "contract",
            "contract_version",
            "effective_contract_line_term",
            "invoice",
            "invoice_line",
            "node",
            "edge",
            "reconciliation_run",
            "validation_result",
            "finding",
            "exception_case",
            "dispute",
            "dispute_line",
            "dispute_message",
            "audit_event",
            "match_cache",
        ]
        counts = {}
        for table in tables:
            row = self.conn.execute(f"SELECT COUNT(*) AS count FROM {table}").fetchone()
            counts[table] = int(row["count"])
        return {
            "backend": "sqlite",
            "database": str(self.db_path),
            "table_counts": counts,
        }

    def reset(self) -> None:
        tables = [
            "audit_event",
            "dispute_message",
            "dispute_line",
            "dispute",
            "exception_case",
            "finding",
            "validation_result",
            "reconciliation_run",
            "match_cache",
            "matching_policy",
            "rule_catalog",
            "edge",
            "node",
            "invoice_line",
            "invoice",
            "member_eligibility",
            "effective_contract_line_term",
            "contract_line_term",
            "contract_version",
            "contract",
            "uom_conversion",
            "item",
            "party",
        ]
        for table in tables:
            self.conn.execute(f"DELETE FROM {table}")
        self.conn.commit()

    def add_party(self, party: Party) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO party (
              party_id, party_type, party_name, active_flag,
              contact_email, contact_data_complete, primary_facility_id, gl_code
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                party.party_id,
                party.party_type,
                party.party_name,
                int(party.active_flag),
                party.contact_email,
                int(party.contact_data_complete),
                party.primary_facility_id,
                party.gl_code,
            ),
        )
        self.conn.commit()

    def add_item(self, item: Item) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO item VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                item.item_id,
                item.description,
                item.manufacturer_item_number,
                item.supplier_item_number,
                item.gtin,
                item.category_code,
                int(item.active_flag),
            ),
        )
        self.conn.commit()

    def add_uom_conversion(self, conversion: UomConversion) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO uom_conversion VALUES (?, ?, ?, ?)",
            (
                conversion.item_id,
                conversion.from_uom,
                conversion.to_uom,
                conversion.conversion_factor,
            ),
        )
        self.conn.commit()

    def add_contract(self, contract: Contract) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO contract VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                contract.contract_id,
                contract.contract_number,
                contract.contract_name,
                contract.gpo_id,
                contract.supplier_id,
                date_to_str(contract.effective_date),
                date_to_str(contract.expiration_date),
                contract.status,
            ),
        )
        self.conn.commit()

    def add_contract_version(self, version: ContractVersion) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO contract_version VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                version.contract_version_id,
                version.contract_id,
                version.version_type,
                version.sequence_number,
                date_to_str(version.effective_date),
                date_to_str(version.expiration_date),
                version.amendment_number,
                int(version.retroactive_flag),
            ),
        )
        self.conn.commit()

    def add_contract_line_term(self, term: ContractLineTerm) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO contract_line_term (
              contract_line_id, contract_version_id, contract_id, item_id, action_type,
              contract_uom, unit_price, currency_code, tier_id, effective_from, effective_to,
              min_quantity, max_quantity, description, category_code, charge_term_type,
              pricing_basis, billing_frequency, charge_term_allowed
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                term.contract_line_id,
                term.contract_version_id,
                term.contract_id,
                term.item_id,
                term.action_type,
                term.contract_uom,
                term.unit_price,
                term.currency_code,
                term.tier_id,
                date_to_str(term.effective_from),
                date_to_str(term.effective_to),
                term.min_quantity,
                term.max_quantity,
                term.description,
                term.category_code,
                term.charge_term_type,
                term.pricing_basis,
                term.billing_frequency,
                int(term.charge_term_allowed),
            ),
        )
        self.conn.commit()

    def add_effective_contract_line_term(self, term: EffectiveContractLineTerm) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO effective_contract_line_term (
              contract_line_id, contract_version_id, contract_id, item_id, contract_uom,
              unit_price, currency_code, tier_id, effective_from, effective_to,
              min_quantity, max_quantity, description, sequence_number, category_code,
              charge_term_type, pricing_basis, billing_frequency, charge_term_allowed
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                term.contract_line_id,
                term.contract_version_id,
                term.contract_id,
                term.item_id,
                term.contract_uom,
                term.unit_price,
                term.currency_code,
                term.tier_id,
                date_to_str(term.effective_from),
                date_to_str(term.effective_to),
                term.min_quantity,
                term.max_quantity,
                term.description,
                term.sequence_number,
                term.category_code,
                term.charge_term_type,
                term.pricing_basis,
                term.billing_frequency,
                int(term.charge_term_allowed),
            ),
        )
        self.conn.commit()

    def add_member_eligibility(self, eligibility: MemberEligibility) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO member_eligibility VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                eligibility.eligibility_id,
                eligibility.contract_id,
                eligibility.party_id,
                eligibility.tier_id,
                date_to_str(eligibility.valid_from),
                date_to_str(eligibility.valid_to),
                eligibility.status,
            ),
        )
        self.conn.commit()

    def add_invoice(self, invoice: Invoice) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO invoice (
              invoice_id, invoice_number, invoice_date, supplier_id, member_id,
              currency_code, total_amount, contract_number_reference,
              payment_status, po_type, interception_status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                invoice.invoice_id,
                invoice.invoice_number,
                date_to_str(invoice.invoice_date),
                invoice.supplier_id,
                invoice.member_id,
                invoice.currency_code,
                invoice.total_amount,
                invoice.contract_number_reference,
                invoice.payment_status,
                invoice.po_type,
                invoice.interception_status,
            ),
        )
        self.conn.commit()

    def add_invoice_line(self, line: InvoiceLine) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO invoice_line (
              invoice_line_id, invoice_id, line_number, item_id, description,
              quantity, invoice_uom, unit_price, extended_amount, service_date,
              category_code, charge_term_text, billing_frequency, billing_period_start,
              billing_period_end, parse_confidence, source_quality_status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                line.invoice_line_id,
                line.invoice_id,
                line.line_number,
                line.item_id,
                line.description,
                line.quantity,
                line.invoice_uom,
                line.unit_price,
                line.extended_amount,
                date_to_str(line.service_date),
                line.category_code,
                line.charge_term_text,
                line.billing_frequency,
                date_to_str(line.billing_period_start),
                date_to_str(line.billing_period_end),
                line.parse_confidence,
                line.source_quality_status,
            ),
        )
        self.conn.commit()

    def add_node(self, node: Node) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO node VALUES (?, ?, ?, ?, ?)",
            (node.node_id, node.entity_type, node.entity_id, node.display_name, to_json(node.properties)),
        )
        self.conn.commit()

    def add_edge(self, edge: Edge) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO edge VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                edge.edge_id,
                edge.from_node_id,
                edge.to_node_id,
                edge.relationship_type,
                date_to_str(edge.valid_from),
                date_to_str(edge.valid_to),
                to_json(edge.evidence),
            ),
        )
        self.conn.commit()

    def add_rule(self, rule: RuleCatalogEntry) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO rule_catalog VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                rule.rule_code,
                rule.rule_version,
                rule.rule_group,
                rule.severity.value,
                rule.description,
                int(rule.active_flag),
                to_json(rule.parameters),
            ),
        )
        self.conn.commit()

    def set_matching_policy(self, policy: MatchingPolicy) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO matching_policy VALUES (?, ?)",
            (policy.policy_id, to_json(policy)),
        )
        self.conn.commit()

    def get_matching_policy(self) -> MatchingPolicy:
        row = self.conn.execute("SELECT policy_json FROM matching_policy LIMIT 1").fetchone()
        if not row:
            return MatchingPolicy()
        data = from_json(row["policy_json"])
        return MatchingPolicy(**data)

    def get_invoice(self, invoice_id: str) -> Invoice:
        row = self.conn.execute("SELECT * FROM invoice WHERE invoice_id = ?", (invoice_id,)).fetchone()
        if not row:
            raise KeyError(f"Invoice not found: {invoice_id}")
        return Invoice(
            invoice_id=row["invoice_id"],
            invoice_number=row["invoice_number"],
            invoice_date=parse_date(row["invoice_date"]),
            supplier_id=row["supplier_id"],
            member_id=row["member_id"],
            currency_code=row["currency_code"],
            total_amount=row["total_amount"],
            contract_number_reference=row["contract_number_reference"] or "",
            payment_status=self._row_value(row, "payment_status", "") or "",
            po_type=self._row_value(row, "po_type", "") or "",
            interception_status=self._row_value(row, "interception_status", "") or "",
        )

    def get_invoice_lines(self, invoice_id: str) -> list[InvoiceLine]:
        rows = self.conn.execute(
            "SELECT * FROM invoice_line WHERE invoice_id = ? ORDER BY CAST(line_number AS INTEGER)",
            (invoice_id,),
        ).fetchall()
        return [
            InvoiceLine(
                invoice_line_id=row["invoice_line_id"],
                invoice_id=row["invoice_id"],
                line_number=row["line_number"],
                item_id=row["item_id"],
                description=row["description"],
                quantity=row["quantity"],
                invoice_uom=row["invoice_uom"],
                unit_price=row["unit_price"],
                extended_amount=row["extended_amount"],
                service_date=parse_date(row["service_date"]),
                category_code=self._row_value(row, "category_code", "") or "",
                charge_term_text=self._row_value(row, "charge_term_text", "") or "",
                billing_frequency=self._row_value(row, "billing_frequency", "") or "",
                billing_period_start=parse_date(self._row_value(row, "billing_period_start")),
                billing_period_end=parse_date(self._row_value(row, "billing_period_end")),
                parse_confidence=self._row_value(row, "parse_confidence"),
                source_quality_status=self._row_value(row, "source_quality_status", "TRUSTED") or "TRUSTED",
            )
            for row in rows
        ]

    def get_item(self, item_id: str) -> Item | None:
        row = self.conn.execute("SELECT * FROM item WHERE item_id = ?", (item_id,)).fetchone()
        if not row:
            return None
        return Item(
            item_id=row["item_id"],
            description=row["description"],
            manufacturer_item_number=row["manufacturer_item_number"] or "",
            supplier_item_number=row["supplier_item_number"] or "",
            gtin=row["gtin"] or "",
            category_code=row["category_code"] or "",
            active_flag=bool(row["active_flag"]),
        )

    def get_active_contract_terms(
        self,
        supplier_id: str,
        item_id: str,
        service_date: date,
    ) -> list[EffectiveContractLineTerm]:
        service_date_text = date_to_str(service_date)
        rows = self.conn.execute(
            """
            SELECT ect.*
            FROM effective_contract_line_term ect
            JOIN contract c ON c.contract_id = ect.contract_id
            WHERE c.supplier_id = ?
              AND ect.item_id = ?
              AND ect.effective_from <= ?
              AND (ect.effective_to IS NULL OR ect.effective_to >= ?)
            ORDER BY ect.sequence_number DESC, ect.effective_from DESC
            """,
            (supplier_id, item_id, service_date_text, service_date_text),
        ).fetchall()
        return [self._effective_term_from_row(row) for row in rows]

    def get_active_contract_terms_for_supplier(
        self,
        supplier_id: str,
        service_date: date,
        category_code: str = "",
    ) -> list[EffectiveContractLineTerm]:
        service_date_text = date_to_str(service_date)
        params: list[Any] = [supplier_id, service_date_text, service_date_text]
        category_clause = ""
        if category_code:
            category_clause = "AND (ect.category_code = ? OR ect.category_code IS NULL OR ect.category_code = '')"
            params.append(category_code)
        rows = self.conn.execute(
            f"""
            SELECT ect.*
            FROM effective_contract_line_term ect
            JOIN contract c ON c.contract_id = ect.contract_id
            WHERE c.supplier_id = ?
              AND ect.effective_from <= ?
              AND (ect.effective_to IS NULL OR ect.effective_to >= ?)
              {category_clause}
            ORDER BY ect.sequence_number DESC, ect.effective_from DESC
            """,
            tuple(params),
        ).fetchall()
        return [self._effective_term_from_row(row) for row in rows]

    def is_member_eligible(self, contract_id: str, member_id: str, on_date: date) -> bool:
        on_date_text = date_to_str(on_date)
        row = self.conn.execute(
            """
            SELECT 1
            FROM member_eligibility
            WHERE contract_id = ?
              AND party_id = ?
              AND status = 'ACTIVE'
              AND valid_from <= ?
              AND (valid_to IS NULL OR valid_to >= ?)
            LIMIT 1
            """,
            (contract_id, member_id, on_date_text, on_date_text),
        ).fetchone()
        return row is not None

    def get_uom_conversion(self, item_id: str, from_uom: str, to_uom: str) -> float | None:
        if from_uom == to_uom:
            return 1.0
        row = self.conn.execute(
            """
            SELECT conversion_factor
            FROM uom_conversion
            WHERE item_id = ? AND from_uom = ? AND to_uom = ?
            """,
            (item_id, from_uom, to_uom),
        ).fetchone()
        return float(row["conversion_factor"]) if row else None

    def get_supplier_contact(self, supplier_id: str) -> dict[str, Any]:
        row = self.conn.execute(
            """
            SELECT party_id, contact_email, contact_data_complete
            FROM party
            WHERE party_id = ?
            """,
            (supplier_id,),
        ).fetchone()
        if not row:
            return super().get_supplier_contact(supplier_id)
        contact_email = self._row_value(row, "contact_email", "") or ""
        return {
            "supplier_id": supplier_id,
            "contact_email": contact_email,
            "contact_data_complete": bool(self._row_value(row, "contact_data_complete", 0))
            and bool(contact_email),
        }

    def get_graph_match_evidence(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        term: EffectiveContractLineTerm,
    ) -> dict[str, Any]:
        expectations = graph_match_expectations(invoice, line, term)
        clauses = []
        params: list[str] = []
        for expectation in expectations:
            clauses.append("(relationship_type = ? AND from_node_id = ? AND to_node_id = ?)")
            params.extend(
                [
                    expectation["relationship_type"],
                    expectation["from_node_id"],
                    expectation["to_node_id"],
                ]
            )

        rows = self.conn.execute(
            f"SELECT * FROM edge WHERE {' OR '.join(clauses)}",
            tuple(params),
        ).fetchall()
        return build_graph_match_evidence([dict(row) for row in rows], invoice, line, term)

    def get_graph_match_evidence_for_terms(
        self,
        invoice: Invoice,
        line: InvoiceLine,
        terms: list[EffectiveContractLineTerm],
    ) -> dict[str, dict[str, Any]]:
        if not terms:
            return {}

        expectations = [
            expectation
            for term in terms
            for expectation in graph_match_expectations(invoice, line, term)
        ]
        relationship_types = sorted({expectation["relationship_type"] for expectation in expectations})
        from_node_ids = sorted({expectation["from_node_id"] for expectation in expectations})
        to_node_ids = sorted({expectation["to_node_id"] for expectation in expectations})

        relationship_placeholders = ", ".join("?" for _ in relationship_types)
        from_placeholders = ", ".join("?" for _ in from_node_ids)
        to_placeholders = ", ".join("?" for _ in to_node_ids)
        params = tuple(relationship_types + from_node_ids + to_node_ids)

        rows = self.conn.execute(
            f"""
            SELECT *
            FROM edge
            WHERE relationship_type IN ({relationship_placeholders})
              AND from_node_id IN ({from_placeholders})
              AND to_node_id IN ({to_placeholders})
            """,
            params,
        ).fetchall()
        edges = [dict(row) for row in rows]
        return {
            term.contract_line_id: build_graph_match_evidence(edges, invoice, line, term)
            for term in terms
        }

    def find_cache_match(
        self,
        contract_id: str,
        invoice_line_signature: str,
        contract_version_id: str | None = None,
    ) -> MatchCandidate | None:
        row = self.conn.execute(
            """
            SELECT * FROM match_cache
            WHERE contract_id = ?
              AND invoice_line_signature = ?
              AND cache_status = 'ACTIVE'
              AND (? IS NULL OR contract_version_id = ?)
            """,
            (contract_id, invoice_line_signature, contract_version_id, contract_version_id),
        ).fetchone()
        if not row:
            return None
        self.conn.execute(
            """
            UPDATE match_cache
            SET hit_count = hit_count + 1, last_hit_at = ?
            WHERE invoice_line_signature = ?
            """,
            (now_iso(), invoice_line_signature),
        )
        self.conn.commit()
        data = from_json(row["candidate_json"])
        data["route"] = Route.FAST_PATH
        return MatchCandidate(**data)

    def upsert_cache_match(self, signature: str, candidate: MatchCandidate) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO match_cache
            VALUES (?, ?, ?, ?, ?, 'ACTIVE', ?, NULL, NULL, COALESCE(
              (SELECT hit_count FROM match_cache WHERE invoice_line_signature = ?), 0
            ), NULL)
            """,
            (
                signature,
                candidate.contract_id,
                candidate.contract_version_id,
                candidate.contract_line_id,
                to_json(candidate),
                now_iso(),
                signature,
            ),
        )
        self.conn.commit()

    def invalidate_contract_cache(self, contract_id: str, reason: str) -> int:
        now = now_iso()
        cursor = self.conn.execute(
            """
            UPDATE match_cache
            SET cache_status = 'INVALIDATED', invalidated_at = ?, invalidation_reason = ?
            WHERE contract_id = ? AND cache_status = 'ACTIVE'
            """,
            (now, reason, contract_id),
        )
        self.conn.commit()
        return cursor.rowcount

    def add_run(self, run: ReconciliationRun) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO reconciliation_run
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                run.reconciliation_run_id,
                run.invoice_id,
                run.status,
                run.started_at,
                run.completed_at,
                run.invoice_line_count,
                run.fast_path_count,
                run.deep_path_count,
                run.manual_review_count,
                run.pass_count,
                run.fail_count,
                run.warning_count,
            ),
        )
        self.conn.commit()

    def complete_run(self, run: ReconciliationRun) -> None:
        self.add_run(run)

    def add_validation_result(self, result: ValidationResult) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO validation_result
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                result.validation_result_id,
                result.reconciliation_run_id,
                result.invoice_id,
                result.invoice_line_id,
                result.rule_code,
                result.status.value,
                result.severity.value,
                result.matched_contract_id,
                result.matched_contract_version_id,
                result.matched_contract_line_id,
                result.expected_value,
                result.actual_value,
                result.variance_amount,
                to_json(result.evidence),
            ),
        )
        self.conn.commit()

    def add_finding(self, finding: Finding) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO finding
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                finding.finding_id,
                finding.reconciliation_run_id,
                finding.invoice_id,
                finding.invoice_line_id,
                finding.finding_type,
                finding.status,
                finding.severity.value,
                finding.summary,
                finding.detail,
                finding.variance_amount,
                finding.matched_contract_id,
                finding.matched_contract_line_id,
                to_json(finding.evidence),
            ),
        )
        self.conn.commit()

    def add_exception_case(self, exception_case: ExceptionCase) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO exception_case (
              exception_id, reconciliation_run_id, invoice_id, invoice_line_id,
              exception_type, exception_status, severity, detected_at,
              variance_amount, annualized_exposure, explanation, remediation_suggestion,
              dismissal_reason, human_decision, source_quality_status,
              contact_data_complete, dispute_ready, evidence_json
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                exception_case.exception_id,
                exception_case.reconciliation_run_id,
                exception_case.invoice_id,
                exception_case.invoice_line_id,
                exception_case.exception_type,
                exception_case.exception_status.value,
                exception_case.severity.value,
                exception_case.detected_at,
                exception_case.variance_amount,
                exception_case.annualized_exposure,
                exception_case.explanation,
                exception_case.remediation_suggestion,
                exception_case.dismissal_reason,
                exception_case.human_decision,
                exception_case.source_quality_status,
                int(exception_case.contact_data_complete),
                int(exception_case.dispute_ready),
                to_json(exception_case.evidence),
            ),
        )
        self.conn.commit()

    def add_dispute(self, dispute: Dispute) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO dispute (
              dispute_id, reconciliation_run_id, invoice_id, supplier_id, status,
              to_email, from_email, cc_email, subject, body, email_template,
              variable_data_json, contact_data_complete, created_at, sent_at,
              responded_at, resolution_type, delivery_method
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                dispute.dispute_id,
                dispute.reconciliation_run_id,
                dispute.invoice_id,
                dispute.supplier_id,
                dispute.status.value,
                dispute.to_email,
                dispute.from_email,
                dispute.cc_email,
                dispute.subject,
                dispute.body,
                dispute.email_template,
                to_json(dispute.variable_data),
                int(dispute.contact_data_complete),
                dispute.created_at,
                dispute.sent_at,
                dispute.responded_at,
                dispute.resolution_type,
                dispute.delivery_method,
            ),
        )
        self.conn.commit()

    def add_dispute_line(self, dispute_line: DisputeLine) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO dispute_line VALUES (?, ?)",
            (dispute_line.dispute_id, dispute_line.invoice_line_id),
        )
        self.conn.commit()

    def add_dispute_message(self, dispute_message: DisputeMessage) -> None:
        self.conn.execute(
            """
            INSERT OR REPLACE INTO dispute_message
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                dispute_message.dispute_message_id,
                dispute_message.dispute_id,
                dispute_message.from_email,
                dispute_message.to_email,
                dispute_message.sent_timestamp,
                dispute_message.subject,
                dispute_message.body,
                dispute_message.direction,
            ),
        )
        self.conn.commit()

    def add_audit_event(
        self,
        event_type: str,
        entity_type: str,
        entity_id: str,
        reconciliation_run_id: str | None = None,
        detail: str = "",
    ) -> None:
        self.conn.execute(
            "INSERT INTO audit_event VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                stable_id("audit", event_type, entity_type, entity_id, uuid.uuid4().hex),
                reconciliation_run_id,
                event_type,
                entity_type,
                entity_id,
                detail,
                now_iso(),
            ),
        )
        self.conn.commit()

    def list_nodes(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute("SELECT * FROM node ORDER BY entity_type, display_name")]

    def list_edges(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute("SELECT * FROM edge ORDER BY relationship_type")]

    def list_validation_results(self, reconciliation_run_id: str) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT * FROM validation_result
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id, rule_code
            """,
            (reconciliation_run_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def list_findings(self, reconciliation_run_id: str) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT * FROM finding
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id
            """,
            (reconciliation_run_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def list_exception_cases(self, reconciliation_run_id: str) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT * FROM exception_case
            WHERE reconciliation_run_id = ?
            ORDER BY invoice_line_id
            """,
            (reconciliation_run_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    def list_disputes(self, reconciliation_run_id: str) -> list[dict]:
        rows = self.conn.execute(
            """
            SELECT d.*, GROUP_CONCAT(dl.invoice_line_id) AS invoice_line_ids
            FROM dispute d
            LEFT JOIN dispute_line dl ON dl.dispute_id = d.dispute_id
            WHERE d.reconciliation_run_id = ?
            GROUP BY d.dispute_id
            ORDER BY d.created_at, d.dispute_id
            """,
            (reconciliation_run_id,),
        ).fetchall()
        return [dict(row) for row in rows]

    @staticmethod
    def _effective_term_from_row(row: sqlite3.Row) -> EffectiveContractLineTerm:
        return EffectiveContractLineTerm(
            contract_line_id=row["contract_line_id"],
            contract_version_id=row["contract_version_id"],
            contract_id=row["contract_id"],
            item_id=row["item_id"],
            contract_uom=row["contract_uom"],
            unit_price=row["unit_price"],
            currency_code=row["currency_code"],
            tier_id=row["tier_id"],
            effective_from=parse_date(row["effective_from"]),
            effective_to=parse_date(row["effective_to"]),
            min_quantity=row["min_quantity"],
            max_quantity=row["max_quantity"],
            description=row["description"] or "",
            sequence_number=row["sequence_number"],
            category_code=SQLiteOntologyRepository._row_value(row, "category_code", "") or "",
            charge_term_type=SQLiteOntologyRepository._row_value(row, "charge_term_type", "UNIT") or "UNIT",
            pricing_basis=SQLiteOntologyRepository._row_value(row, "pricing_basis", "UNIT") or "UNIT",
            billing_frequency=SQLiteOntologyRepository._row_value(row, "billing_frequency", "") or "",
            charge_term_allowed=bool(
                SQLiteOntologyRepository._row_value(row, "charge_term_allowed", 1)
            ),
        )

    @staticmethod
    def _row_value(row: sqlite3.Row, name: str, default: Any = None) -> Any:
        try:
            return row[name]
        except (KeyError, IndexError):
            return default
