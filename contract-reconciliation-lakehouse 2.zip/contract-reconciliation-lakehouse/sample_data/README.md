# Sample Data

Purpose: seed data used by the local runnable reconciliation demo.

Files:

- `seed_data.py`: loads sample suppliers, contract, amendment, invoice, validation rules, graph nodes, and graph edges.

Source analysis:

- `../docs/PRICE_ASSURANCE_SEED_GAP_ANALYSIS.md`

