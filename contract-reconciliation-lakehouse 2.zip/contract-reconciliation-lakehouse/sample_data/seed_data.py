from __future__ import annotations

from datetime import date

from ontology.models import (
    Contract,
    ContractLineTerm,
    ContractVersion,
    Edge,
    EffectiveContractLineTerm,
    Invoice,
    InvoiceLine,
    Item,
    MatchingPolicy,
    MemberEligibility,
    Node,
    Party,
    RuleCatalogEntry,
    Severity,
    UomConversion,
)
from ontology.repository import OntologyRepository
from ontology.utils import stable_id


def seed_demo_data(repo: OntologyRepository) -> str:
    """Load a deterministic demo data set and return the demo invoice id."""

    parties = [
        Party("GPO-VZT", "GPO", "Vizient GPO"),
        Party(
            "SUP-MEDLINE",
            "SUPPLIER",
            "Medline Supply Co.",
            contact_email="pa-disputes@medline.example",
            contact_data_complete=True,
            gl_code="SUP-100",
        ),
        Party("MEM-UH", "MEMBER", "Unity Hospital"),
        Party("DIST-ACME", "DISTRIBUTOR", "Acme Medical Distribution"),
    ]
    for party in parties:
        repo.add_party(party)
        repo.add_node(Node(f"node-{party.party_id}", "party", party.party_id, party.party_name))

    items = [
        Item(
            "ITEM-GLOVES-NITRILE",
            "Nitrile exam gloves, powder-free",
            manufacturer_item_number="MFG-GLV-100",
            supplier_item_number="MED-GLV-100",
            gtin="00312345000100",
            category_code="MED-SUPPLIES",
        ),
        Item(
            "ITEM-SYRINGE-10ML",
            "10 mL sterile syringe",
            manufacturer_item_number="MFG-SYR-10",
            supplier_item_number="MED-SYR-10",
            gtin="00312345000200",
            category_code="MED-SUPPLIES",
        ),
        Item(
            "ITEM-MASK-SURGICAL",
            "Level 3 surgical mask",
            manufacturer_item_number="MFG-MSK-L3",
            supplier_item_number="MED-MSK-L3",
            gtin="00312345000300",
            category_code="MED-SUPPLIES",
        ),
        Item(
            "ITEM-BANDAGE-OFFCONTRACT",
            "Elastic bandage roll",
            manufacturer_item_number="MFG-BND-01",
            supplier_item_number="MED-BND-01",
            gtin="00312345000400",
            category_code="MED-SUPPLIES",
        ),
    ]
    for item in items:
        repo.add_item(item)
        repo.add_node(Node(f"node-{item.item_id}", "item", item.item_id, item.description))

    repo.add_uom_conversion(UomConversion("ITEM-GLOVES-NITRILE", "EA", "CS", 100.0))

    contract = Contract(
        contract_id="CONTRACT-GPO-2026-001",
        contract_number="GPO-2026-001",
        contract_name="Vizient Medline Medical Supplies Agreement",
        gpo_id="GPO-VZT",
        supplier_id="SUP-MEDLINE",
        effective_date=date(2026, 1, 1),
        expiration_date=date(2026, 12, 31),
    )
    repo.add_contract(contract)
    repo.add_node(
        Node(
            f"node-{contract.contract_id}",
            "contract",
            contract.contract_id,
            contract.contract_name,
            {"contract_number": contract.contract_number},
        )
    )
    repo.add_edge(
        Edge(
            stable_id("edge", contract.gpo_id, "GOVERNS", contract.contract_id),
            f"node-{contract.gpo_id}",
            f"node-{contract.contract_id}",
            "GOVERNS",
            contract.effective_date,
            contract.expiration_date,
        )
    )
    repo.add_edge(
        Edge(
            stable_id("edge", contract.supplier_id, "PARTICIPATES_IN", contract.contract_id),
            f"node-{contract.supplier_id}",
            f"node-{contract.contract_id}",
            "PARTICIPATES_IN",
            contract.effective_date,
            contract.expiration_date,
        )
    )

    base_version = ContractVersion(
        contract_version_id="CV-GPO-2026-001-BASE",
        contract_id=contract.contract_id,
        version_type="BASE",
        sequence_number=1,
        effective_date=date(2026, 1, 1),
        expiration_date=date(2026, 12, 31),
    )
    amendment_1 = ContractVersion(
        contract_version_id="CV-GPO-2026-001-AMD-001",
        contract_id=contract.contract_id,
        version_type="AMENDMENT",
        amendment_number="AMD-001",
        sequence_number=2,
        effective_date=date(2026, 6, 1),
        expiration_date=date(2026, 12, 31),
    )
    repo.add_contract_version(base_version)
    repo.add_contract_version(amendment_1)

    raw_terms = [
        ContractLineTerm(
            "CL-GLOVES-BASE",
            base_version.contract_version_id,
            contract.contract_id,
            "ITEM-GLOVES-NITRILE",
            "ADD",
            "CS",
            100.00,
            "USD",
            "TIER-1",
            date(2026, 1, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Nitrile exam gloves, case of 100",
        ),
        ContractLineTerm(
            "CL-SYRINGE-BASE",
            base_version.contract_version_id,
            contract.contract_id,
            "ITEM-SYRINGE-10ML",
            "ADD",
            "EA",
            2.00,
            "USD",
            "TIER-1",
            date(2026, 1, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="10 mL sterile syringe",
        ),
        ContractLineTerm(
            "CL-GLOVES-AMD1",
            amendment_1.contract_version_id,
            contract.contract_id,
            "ITEM-GLOVES-NITRILE",
            "UPDATE_PRICE",
            "CS",
            95.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Nitrile exam gloves amended price",
        ),
        ContractLineTerm(
            "CL-MASK-AMD1",
            amendment_1.contract_version_id,
            contract.contract_id,
            "ITEM-MASK-SURGICAL",
            "ADD",
            "BX",
            45.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Level 3 surgical mask box",
            category_code="MED-SUPPLIES",
        ),
        ContractLineTerm(
            "CL-LAUNDRY-SUB",
            amendment_1.contract_version_id,
            contract.contract_id,
            "",
            "ADD",
            "",
            1200.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Monthly linen and laundry subscription service",
            category_code="LAUNDRY",
            charge_term_type="SUBSCRIPTION",
            pricing_basis="MONTHLY",
            billing_frequency="MONTHLY",
        ),
    ]
    for term in raw_terms:
        repo.add_contract_line_term(term)
        repo.add_node(Node(f"node-{term.contract_line_id}", "contract_line_term", term.contract_line_id, term.description))
        repo.add_edge(
            Edge(
                stable_id("edge", contract.contract_id, "HAS_TERM", term.contract_line_id),
                f"node-{contract.contract_id}",
                f"node-{term.contract_line_id}",
                "HAS_TERM",
                term.effective_from,
                term.effective_to,
            )
        )
        if term.item_id:
            repo.add_edge(
                Edge(
                    stable_id("edge", term.contract_line_id, "PRICES_ITEM", term.item_id),
                    f"node-{term.contract_line_id}",
                    f"node-{term.item_id}",
                    "PRICES_ITEM",
                    term.effective_from,
                    term.effective_to,
                    {"unit_price": term.unit_price, "uom": term.contract_uom},
                )
            )

    effective_terms = [
        EffectiveContractLineTerm(
            "CL-GLOVES-BASE",
            base_version.contract_version_id,
            contract.contract_id,
            "ITEM-GLOVES-NITRILE",
            "CS",
            100.00,
            "USD",
            "TIER-1",
            date(2026, 1, 1),
            date(2026, 5, 31),
            min_quantity=1,
            description="Nitrile exam gloves before amendment",
            sequence_number=1,
        ),
        EffectiveContractLineTerm(
            "CL-GLOVES-AMD1",
            amendment_1.contract_version_id,
            contract.contract_id,
            "ITEM-GLOVES-NITRILE",
            "CS",
            95.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Nitrile exam gloves after amendment",
            sequence_number=2,
        ),
        EffectiveContractLineTerm(
            "CL-SYRINGE-BASE",
            base_version.contract_version_id,
            contract.contract_id,
            "ITEM-SYRINGE-10ML",
            "EA",
            2.00,
            "USD",
            "TIER-1",
            date(2026, 1, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="10 mL sterile syringe",
            sequence_number=1,
        ),
        EffectiveContractLineTerm(
            "CL-MASK-AMD1",
            amendment_1.contract_version_id,
            contract.contract_id,
            "ITEM-MASK-SURGICAL",
            "BX",
            45.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Level 3 surgical mask box",
            sequence_number=2,
            category_code="MED-SUPPLIES",
        ),
        EffectiveContractLineTerm(
            "CL-LAUNDRY-SUB",
            amendment_1.contract_version_id,
            contract.contract_id,
            "",
            "",
            1200.00,
            "USD",
            "TIER-1",
            date(2026, 6, 1),
            date(2026, 12, 31),
            min_quantity=1,
            description="Monthly linen and laundry subscription service",
            sequence_number=2,
            category_code="LAUNDRY",
            charge_term_type="SUBSCRIPTION",
            pricing_basis="MONTHLY",
            billing_frequency="MONTHLY",
        ),
    ]
    for term in effective_terms:
        repo.add_effective_contract_line_term(term)

    eligibility = MemberEligibility(
        eligibility_id="ELIG-UH-GPO-2026-001",
        contract_id=contract.contract_id,
        party_id="MEM-UH",
        tier_id="TIER-1",
        valid_from=date(2026, 1, 1),
        valid_to=date(2026, 12, 31),
    )
    repo.add_member_eligibility(eligibility)
    repo.add_edge(
        Edge(
            stable_id("edge", eligibility.party_id, "ELIGIBLE_FOR", eligibility.contract_id),
            f"node-{eligibility.party_id}",
            f"node-{eligibility.contract_id}",
            "ELIGIBLE_FOR",
            eligibility.valid_from,
            eligibility.valid_to,
            {"tier_id": eligibility.tier_id},
        )
    )

    rules = [
        RuleCatalogEntry("DATA_QUALITY_SUFFICIENT", "1.0", "DATA_QUALITY", Severity.HIGH, "Structured source data is reliable enough for financial validation."),
        RuleCatalogEntry("CONTRACT_FOUND", "1.0", "MATCHING", Severity.HIGH, "An active contract line exists."),
        RuleCatalogEntry("CONTRACT_CANDIDATE_SELECTED", "1.0", "MATCHING", Severity.HIGH, "Supplier/date contract candidate was selected."),
        RuleCatalogEntry("CHARGE_TERM_CANDIDATE_SELECTED", "1.0", "MATCHING", Severity.HIGH, "Charge term candidate was selected within the contract."),
        RuleCatalogEntry("MEMBER_ELIGIBLE", "1.0", "ELIGIBILITY", Severity.HIGH, "Member is eligible for contract."),
        RuleCatalogEntry("ITEM_OR_SERVICE_TERM_MATCHED", "1.0", "ITEM", Severity.HIGH, "Invoice item or service description maps to contract term."),
        RuleCatalogEntry("CATEGORY_COMPATIBLE", "1.0", "CATEGORY", Severity.MEDIUM, "Invoice and contract line categories are compatible."),
        RuleCatalogEntry("CHARGE_TERM_ALLOWED", "1.0", "CONTRACT_TERM", Severity.HIGH, "Selected charge term is contractually allowed."),
        RuleCatalogEntry("UOM_NOT_REQUIRED_OR_CONVERTIBLE", "1.0", "UOM", Severity.MEDIUM, "Invoice UOM is not required for the service term or can convert to contract UOM."),
        RuleCatalogEntry("PRICE_WITHIN_TOLERANCE", "1.0", "PRICE", Severity.HIGH, "Invoice unit price is within tolerance."),
        RuleCatalogEntry("QUANTITY_LIMIT_VALID", "1.0", "QUANTITY", Severity.MEDIUM, "Quantity is inside min/max limits."),
        RuleCatalogEntry("FREQUENCY_ALLOWED", "1.0", "FREQUENCY", Severity.MEDIUM, "Invoice billing frequency is allowed by contract term."),
        RuleCatalogEntry("SUPPLIER_CONTACT_COMPLETE", "1.0", "DISPUTE", Severity.MEDIUM, "Supplier contact data is complete before dispute initiation."),
        RuleCatalogEntry("AMENDMENT_VERSION_VALID", "1.0", "AMENDMENT", Severity.HIGH, "Latest effective amendment term was applied."),
    ]
    for rule in rules:
        repo.add_rule(rule)

    repo.set_matching_policy(MatchingPolicy())

    invoice = Invoice(
        invoice_id="INV-1001",
        invoice_number="1001",
        invoice_date=date(2026, 6, 15),
        supplier_id="SUP-MEDLINE",
        member_id="MEM-UH",
        currency_code="USD",
        total_amount=2527.00,
        contract_number_reference=contract.contract_number,
        payment_status="PENDING_APPROVAL",
        po_type="SERVICE_AND_SUPPLY",
        interception_status="PRE_PAYMENT_REVIEW",
    )
    repo.add_invoice(invoice)
    repo.add_node(Node(f"node-{invoice.invoice_id}", "invoice", invoice.invoice_id, invoice.invoice_number))

    invoice_lines = [
        InvoiceLine(
            "INV-1001-L1",
            invoice.invoice_id,
            "1",
            "ITEM-GLOVES-NITRILE",
            "Nitrile gloves case",
            10,
            "CS",
            95.00,
            950.00,
            date(2026, 6, 10),
        ),
        InvoiceLine(
            "INV-1001-L2",
            invoice.invoice_id,
            "2",
            "ITEM-MASK-SURGICAL",
            "Surgical mask level 3",
            4,
            "BX",
            48.00,
            192.00,
            date(2026, 6, 10),
        ),
        InvoiceLine(
            "INV-1001-L3",
            invoice.invoice_id,
            "3",
            "ITEM-SYRINGE-10ML",
            "10 ml syringe",
            25,
            "EA",
            2.00,
            50.00,
            date(2026, 6, 10),
        ),
        InvoiceLine(
            "INV-1001-L4",
            invoice.invoice_id,
            "4",
            "ITEM-BANDAGE-OFFCONTRACT",
            "Elastic bandage roll",
            8,
            "EA",
            5.00,
            40.00,
            date(2026, 6, 10),
        ),
        InvoiceLine(
            "INV-1001-L5",
            invoice.invoice_id,
            "5",
            "ITEM-GLOVES-NITRILE",
            "Nitrile gloves each",
            100,
            "EA",
            0.95,
            95.00,
            date(2026, 6, 10),
        ),
        InvoiceLine(
            "INV-1001-L6",
            invoice.invoice_id,
            "6",
            "",
            "Monthly linen laundry service",
            1,
            "",
            1200.00,
            1200.00,
            date(2026, 6, 10),
            category_code="LAUNDRY",
            charge_term_text="linen laundry monthly subscription",
            billing_frequency="MONTHLY",
            billing_period_start=date(2026, 6, 1),
            billing_period_end=date(2026, 6, 30),
            parse_confidence=0.98,
            source_quality_status="TRUSTED",
        ),
    ]
    for line in invoice_lines:
        repo.add_invoice_line(line)
        repo.add_node(Node(f"node-{line.invoice_line_id}", "invoice_line", line.invoice_line_id, line.description))
        repo.add_edge(
            Edge(
                stable_id("edge", invoice.invoice_id, "HAS_LINE", line.invoice_line_id),
                f"node-{invoice.invoice_id}",
                f"node-{line.invoice_line_id}",
                "HAS_LINE",
                invoice.invoice_date,
                None,
            )
        )

    repo.add_audit_event("SEED_LOADED", "invoice", invoice.invoice_id, detail="Demo data loaded")
    return invoice.invoice_id
