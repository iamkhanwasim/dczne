# Silver Layer

Purpose: create conformed, trusted domain entities from Bronze payloads.

Key responsibilities:

- Normalize parties, suppliers, facilities, categories, and GL accounts.
- Normalize contracts, amendments, clauses, and effective terms.
- Normalize invoices and invoice lines.
- Persist detailed reconciliation runs, validation results, and findings.

Representative tables:

- `platform_dev.pspa_silver.party`
- `platform_dev.pspa_silver.supplier_profile`
- `platform_dev.pspa_silver.facility_profile`
- `platform_dev.pspa_silver.contract`
- `platform_dev.pspa_silver.contract_version`
- `platform_dev.pspa_silver.effective_contract_line_term`
- `platform_dev.pspa_silver.invoice`
- `platform_dev.pspa_silver.invoice_line`
- `platform_dev.pspa_silver.validation_result`
- `platform_dev.pspa_silver.finding`

