# SQL

Purpose: Databricks SQL DDL for Unity Catalog, Medallion tables, ontology tables, Gold outputs, Ops metadata, and Price Assurance extensions.

## Recommended Script

Run one script for new environments:

```text
databricks_lakehouse_schema.sql
```

This unified script creates:

- Catalog: `platform_dev`
- `platform_dev.pspa_bronze` raw structured payload tables
- `platform_dev.pspa_silver` conformed contract, invoice, party, item, eligibility, tier, roster, and obligation tables
- `platform_dev.pspa_ontology` graph, policy, matching cache, reconciliation evidence, validation, finding, audit, and runtime compatibility tables
- `platform_dev.pspa_gold` reconciliation summary, line fact, dispute queue, and recovery opportunity tables
- `platform_dev.pspa_ops` pipeline run log table

Unity Catalog supports a three-level namespace: `catalog.schema.table`. Because it does not support nested schemas like `platform_dev.pspa.bronze.table`, PSPA is represented as a schema prefix: `pspa_bronze`, `pspa_silver`, `pspa_ontology`, `pspa_gold`, and `pspa_ops`.

The table-level comments and `quality` table properties document each Delta table's responsibility directly in Unity Catalog.

## Package Rule

The package intentionally ships one canonical Databricks DDL script:

```text
databricks_lakehouse_schema.sql
```

Older modular SQL drafts were removed from the packaged solution to avoid conflicting setup instructions. Use the canonical script for demo and production bootstrap.
