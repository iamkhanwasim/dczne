-- =================================================================================================
-- Contract Reconciliation Lakehouse - Unified Databricks SQL Schema
-- =================================================================================================
--
-- Purpose:
--   This single script creates the complete Unity Catalog / Delta Lake schema for the
--   Contract Reconciliation Lakehouse.
--
-- Execution:
--   Run this script once per environment after Unity Catalog metastore and workspace access
--   are available.
--
-- Catalog:
--   platform_dev
--
-- Schemas:
--   platform_dev.pspa_bronze    - raw structured source payload preservation and replay
--   platform_dev.pspa_silver    - conformed, trusted, reconciliation-ready business entities
--   platform_dev.pspa_ontology  - semantic graph, rules, policies, cache, evidence, and audit
--   platform_dev.pspa_gold      - business-ready facts, summaries, recovery opportunities, and queues
--   platform_dev.pspa_ops       - pipeline observability and operational run metadata
--
-- Delta Table Responsibility Summary:
--
--   Bronze tables:
--     Preserve source payloads exactly as received, with lineage fields. No matching,
--     validation, or business aggregation should happen in Bronze.
--
--   Silver tables:
--     Store normalized and quality-checked business entities. These are the trusted inputs
--     used to build the ontology graph and run reconciliation. Contract amendments are
--     resolved into effective contract terms here.
--
--   Ontology tables:
--     Store semantic nodes and relationships, rule catalog, matching policy, match cache,
--     reconciliation evidence, validation detail, findings, and audit events. The ontology
--     is built from Silver and enriched with reconciliation results.
--
--   Gold tables:
--     Store BI-ready and workflow-ready outputs produced after reconciliation. Gold should
--     not drive pre-reconciliation matching. It is the serving layer for analytics,
--     dispute workflow, and recovery tracking.
--
--   Ops tables:
--     Store workflow and pipeline run metadata for monitoring, SLA tracking, and support.
--
-- Recommended flow:
--   Bronze -> Silver -> Ontology + Reconciliation -> Gold -> API / BI / Workflow
--
-- Unity Catalog namespace note:
--   Unity Catalog supports catalog.schema.table. It does not support nested schemas such as
--   platform_dev.pspa.bronze.table. To keep the PSPA domain explicit and preserve layer-level
--   governance, this solution uses pspa_<layer> schemas under the platform_dev catalog.
--
-- =================================================================================================

-- -------------------------------------------------------------------------------------------------
-- 1. Catalog and schema setup
-- -------------------------------------------------------------------------------------------------

CREATE CATALOG IF NOT EXISTS platform_dev
COMMENT 'Supply Chain and GPO contract reconciliation lakehouse catalog.';

CREATE SCHEMA IF NOT EXISTS platform_dev.pspa_bronze
COMMENT 'Bronze layer: raw structured source payload preservation, lineage, and replay.';

CREATE SCHEMA IF NOT EXISTS platform_dev.pspa_silver
COMMENT 'Silver layer: conformed, trusted contract, invoice, item, party, eligibility, and effective-term entities.';

CREATE SCHEMA IF NOT EXISTS platform_dev.pspa_ontology
COMMENT 'Ontology layer: semantic graph, rule catalog, matching policy, cache, validation evidence, findings, and audit.';

CREATE SCHEMA IF NOT EXISTS platform_dev.pspa_gold
COMMENT 'Gold layer: business-ready reconciliation facts, summaries, recovery opportunities, and dispute queues.';

CREATE SCHEMA IF NOT EXISTS platform_dev.pspa_ops
COMMENT 'Operations schema: workflow run logs, pipeline observability, and support metadata.';

-- -------------------------------------------------------------------------------------------------
-- 2. Bronze Delta tables
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_bronze.contract_payload (
  source_system STRING NOT NULL,
  source_file_name STRING,
  source_record_id STRING NOT NULL,
  ingestion_ts TIMESTAMP NOT NULL,
  payload_json STRING NOT NULL,
  payload_hash STRING NOT NULL,
  load_id STRING NOT NULL
) USING DELTA
TBLPROPERTIES (
  'quality' = 'bronze',
  'delta.enableChangeDataFeed' = 'true'
);

COMMENT ON TABLE platform_dev.pspa_bronze.contract_payload IS
'Bronze contract landing table. Stores structured contract and amendment payloads as received from upstream systems with lineage, load id, and payload hash for replay and audit.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_bronze.invoice_payload (
  source_system STRING NOT NULL,
  source_file_name STRING,
  source_record_id STRING NOT NULL,
  ingestion_ts TIMESTAMP NOT NULL,
  payload_json STRING NOT NULL,
  payload_hash STRING NOT NULL,
  load_id STRING NOT NULL
) USING DELTA
TBLPROPERTIES (
  'quality' = 'bronze',
  'delta.enableChangeDataFeed' = 'true'
);

COMMENT ON TABLE platform_dev.pspa_bronze.invoice_payload IS
'Bronze invoice landing table. Stores structured invoice header and invoice line payloads as received from upstream systems with lineage, load id, and payload hash.';

-- -------------------------------------------------------------------------------------------------
-- 3. Silver Delta tables - conformed business entities
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.party (
  party_id STRING NOT NULL,
  party_type STRING NOT NULL,
  party_name STRING NOT NULL,
  active_flag BOOLEAN NOT NULL,
  contact_email STRING,
  contact_data_complete BOOLEAN,
  primary_facility_id STRING,
  gl_code STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.party IS
'Conformed party master for GPOs, suppliers, manufacturers, distributors, members, facilities, and other commercial actors.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.item (
  item_id STRING NOT NULL,
  description STRING NOT NULL,
  manufacturer_item_number STRING,
  supplier_item_number STRING,
  gtin STRING,
  category_code STRING,
  active_flag BOOLEAN NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.item IS
'Conformed item master used for invoice-line to contract-line matching, including manufacturer item number, supplier item number, GTIN, and category.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.uom_conversion (
  item_id STRING NOT NULL,
  from_uom STRING NOT NULL,
  to_uom STRING NOT NULL,
  conversion_factor DOUBLE NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.uom_conversion IS
'Unit-of-measure and pack-size conversion table used to normalize invoice unit price into contract UOM before price validation.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.contract (
  contract_id STRING NOT NULL,
  contract_number STRING NOT NULL,
  contract_name STRING NOT NULL,
  gpo_id STRING NOT NULL,
  supplier_id STRING NOT NULL,
  effective_date DATE NOT NULL,
  expiration_date DATE NOT NULL,
  status STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.contract IS
'Conformed contract header. Represents the governed GPO/supplier agreement and anchors versions, terms, eligibility, and ontology relationships.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.contract_version (
  contract_version_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  version_type STRING NOT NULL,
  sequence_number INT NOT NULL,
  effective_date DATE NOT NULL,
  expiration_date DATE,
  amendment_number STRING,
  retroactive_flag BOOLEAN NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.contract_version IS
'Conformed contract version and amendment table. Orders base contracts and amendments so effective terms can be materialized deterministically.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.contract_line_term (
  contract_line_id STRING NOT NULL,
  contract_version_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  item_id STRING,
  supplier_id STRING,
  gpo_id STRING,
  action_type STRING NOT NULL,
  contract_uom STRING NOT NULL,
  unit_price DOUBLE NOT NULL,
  currency_code STRING NOT NULL,
  tier_id STRING,
  effective_from DATE NOT NULL,
  effective_to DATE,
  min_quantity DOUBLE,
  max_quantity DOUBLE,
  description STRING,
  category_code STRING,
  charge_term_type STRING,
  pricing_basis STRING,
  billing_frequency STRING,
  charge_term_allowed BOOLEAN,
  source_record_id STRING,
  quality_status STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.contract_line_term IS
'Versioned contract pricing and compliance term table. Stores line terms before final amendment-effective materialization.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.effective_contract_line_term (
  contract_line_id STRING NOT NULL,
  contract_version_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  item_id STRING,
  supplier_id STRING,
  contract_uom STRING NOT NULL,
  unit_price DOUBLE NOT NULL,
  currency_code STRING NOT NULL,
  tier_id STRING,
  effective_from DATE NOT NULL,
  effective_to DATE,
  min_quantity DOUBLE,
  max_quantity DOUBLE,
  description STRING,
  sequence_number INT,
  amendment_sequence INT,
  effective_term_hash STRING,
  category_code STRING,
  charge_term_type STRING,
  pricing_basis STRING,
  billing_frequency STRING,
  charge_term_allowed BOOLEAN
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.effective_contract_line_term IS
'Amendment-aware effective contract term table. This is the primary contract input for reconciliation and service-date matching.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.member_eligibility (
  eligibility_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  party_id STRING NOT NULL,
  tier_id STRING NOT NULL,
  valid_from DATE NOT NULL,
  valid_to DATE,
  status STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.member_eligibility IS
'Member and facility eligibility table. Determines whether an invoice buyer is allowed to use a contract and tier on the service date.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.invoice (
  invoice_id STRING NOT NULL,
  invoice_number STRING NOT NULL,
  invoice_date DATE NOT NULL,
  supplier_id STRING NOT NULL,
  member_id STRING NOT NULL,
  currency_code STRING NOT NULL,
  total_amount DOUBLE NOT NULL,
  contract_number_reference STRING,
  payment_status STRING,
  po_type STRING,
  interception_status STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.invoice IS
'Conformed invoice header table used as the reconciliation run subject and Gold summary source.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.invoice_line (
  invoice_line_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  supplier_id STRING,
  member_id STRING,
  invoice_number STRING,
  line_number STRING NOT NULL,
  item_id STRING,
  description STRING,
  quantity DOUBLE NOT NULL,
  invoice_uom STRING NOT NULL,
  unit_price DOUBLE NOT NULL,
  extended_amount DOUBLE NOT NULL,
  service_date DATE NOT NULL,
  category_code STRING,
  charge_term_text STRING,
  billing_frequency STRING,
  billing_period_start DATE,
  billing_period_end DATE,
  parse_confidence DOUBLE,
  source_quality_status STRING,
  source_record_id STRING,
  quality_status STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.invoice_line IS
'Conformed invoice line table. This is the primary invoice input for line-by-line contract reconciliation.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.contract_tier (
  tier_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  tier_name STRING NOT NULL,
  tier_rank INT,
  spend_threshold_amount DOUBLE,
  volume_threshold_quantity DOUBLE,
  effective_from DATE NOT NULL,
  effective_to DATE,
  status STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.contract_tier IS
'Contract tier definition table for GPO pricing tiers, thresholds, and tier effective dates.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.member_roster (
  roster_id STRING NOT NULL,
  member_id STRING NOT NULL,
  gpo_id STRING NOT NULL,
  facility_id STRING,
  class_of_trade STRING,
  hin STRING,
  dea_number STRING,
  gln STRING,
  valid_from DATE NOT NULL,
  valid_to DATE,
  status STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.member_roster IS
'GPO member and facility roster table. Supports member identity, facility mapping, class of trade, HIN, DEA, and GLN enrichment.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_silver.contract_compliance_obligation (
  obligation_id STRING NOT NULL,
  contract_id STRING NOT NULL,
  obligation_type STRING NOT NULL,
  expected_value STRING,
  tolerance_value DOUBLE,
  severity STRING NOT NULL,
  active_flag BOOLEAN NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'silver');

COMMENT ON TABLE platform_dev.pspa_silver.contract_compliance_obligation IS
'Contract compliance obligation table. Stores contract-level obligations, tolerances, and severity for rule-driven validations.';

-- -------------------------------------------------------------------------------------------------
-- 4. Ontology Delta tables - semantic graph and reconciliation evidence
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.node (
  node_id STRING NOT NULL,
  entity_type STRING NOT NULL,
  entity_id STRING NOT NULL,
  display_name STRING NOT NULL,
  properties_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.node IS
'Ontology node registry. Each row represents a semantic business object such as contract, party, item, invoice, invoice line, finding, or rule.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.edge (
  edge_id STRING NOT NULL,
  from_node_id STRING NOT NULL,
  to_node_id STRING NOT NULL,
  relationship_type STRING NOT NULL,
  valid_from DATE,
  valid_to DATE,
  evidence_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.edge IS
'Ontology edge table. Stores semantic relationships such as GOVERNS, PARTICIPATES_IN, HAS_TERM, PRICES_ITEM, ELIGIBLE_FOR, HAS_LINE, MATCHED_TO, and SUPPORTED_BY.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.rule_catalog (
  rule_code STRING NOT NULL,
  rule_version STRING NOT NULL,
  rule_group STRING NOT NULL,
  severity STRING NOT NULL,
  description STRING NOT NULL,
  active_flag BOOLEAN NOT NULL,
  parameters_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.rule_catalog IS
'Governed reconciliation rule catalog. Stores rule version, group, severity, active flag, description, and runtime parameters.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.matching_policy (
  policy_id STRING NOT NULL,
  policy_json STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.matching_policy IS
'Matching policy table. Stores configurable weights, thresholds, ambiguity settings, and price tolerance used by the matching engine.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.match_cache (
  invoice_line_signature STRING NOT NULL,
  contract_id STRING NOT NULL,
  contract_version_id STRING,
  contract_line_id STRING NOT NULL,
  candidate_json STRING NOT NULL,
  cache_status STRING NOT NULL,
  created_at TIMESTAMP NOT NULL,
  invalidated_at TIMESTAMP,
  invalidation_reason STRING,
  hit_count BIGINT NOT NULL,
  last_hit_at TIMESTAMP
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.match_cache IS
'Fast-path match cache. Stores high-confidence invoice-line signatures linked to contract/version/line terms and supports contract-driven invalidation.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.reconciliation_run (
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  status STRING NOT NULL,
  started_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP,
  invoice_line_count BIGINT NOT NULL,
  fast_path_count BIGINT NOT NULL,
  deep_path_count BIGINT NOT NULL,
  manual_review_count BIGINT NOT NULL,
  pass_count BIGINT NOT NULL,
  fail_count BIGINT NOT NULL,
  warning_count BIGINT NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.reconciliation_run IS
'Reconciliation run control table. Stores run status, start and completion time, route counts, and rule outcome counts.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.validation_result (
  validation_result_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  rule_code STRING NOT NULL,
  status STRING NOT NULL,
  severity STRING NOT NULL,
  matched_contract_id STRING,
  matched_contract_version_id STRING,
  matched_contract_line_id STRING,
  expected_value STRING,
  actual_value STRING,
  variance_amount DOUBLE NOT NULL,
  evidence_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.validation_result IS
'Detailed validation result table. Stores one row per rule per invoice line with expected value, actual value, variance, matched contract references, and evidence.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.finding (
  finding_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  finding_type STRING NOT NULL,
  status STRING NOT NULL,
  severity STRING NOT NULL,
  summary STRING NOT NULL,
  detail STRING NOT NULL,
  variance_amount DOUBLE NOT NULL,
  matched_contract_id STRING,
  matched_contract_line_id STRING,
  evidence_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.finding IS
'Finding table. Stores line-level compliant, price variance, off-contract, warning, or manual-review outcomes with evidence and variance.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.exception_case (
  exception_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  exception_type STRING NOT NULL,
  exception_status STRING NOT NULL,
  severity STRING NOT NULL,
  detected_at TIMESTAMP NOT NULL,
  variance_amount DOUBLE NOT NULL,
  annualized_exposure DOUBLE NOT NULL,
  explanation STRING,
  remediation_suggestion STRING,
  dismissal_reason STRING,
  human_decision STRING,
  source_quality_status STRING,
  contact_data_complete BOOLEAN NOT NULL,
  dispute_ready BOOLEAN NOT NULL,
  evidence_json STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.exception_case IS
'First-class Price Assurance exception object detected on invoice lines. Stores OOUX exception taxonomy, lifecycle status, exposure, remediation, and dispute readiness.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.dispute (
  dispute_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  supplier_id STRING NOT NULL,
  status STRING NOT NULL,
  to_email STRING,
  from_email STRING,
  cc_email STRING,
  subject STRING,
  body STRING,
  email_template STRING,
  variable_data_json STRING,
  contact_data_complete BOOLEAN NOT NULL,
  created_at TIMESTAMP NOT NULL,
  sent_at TIMESTAMP,
  responded_at TIMESTAMP,
  resolution_type STRING,
  delivery_method STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.dispute IS
'Formal supplier dispute lifecycle object. Disputes are created only after exception evidence exists and contact data is complete.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.dispute_line (
  dispute_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.dispute_line IS
'Bridge table linking a dispute to one or more invoice lines.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.dispute_message (
  dispute_message_id STRING NOT NULL,
  dispute_id STRING NOT NULL,
  from_email STRING,
  to_email STRING,
  sent_timestamp TIMESTAMP NOT NULL,
  subject STRING,
  body STRING,
  direction STRING NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.dispute_message IS
'Dispute communication history for outbound and inbound supplier messages.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.audit_event (
  audit_event_id STRING NOT NULL,
  reconciliation_run_id STRING,
  event_type STRING NOT NULL,
  entity_type STRING NOT NULL,
  entity_id STRING NOT NULL,
  detail STRING,
  created_at TIMESTAMP NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'ontology');

COMMENT ON TABLE platform_dev.pspa_ontology.audit_event IS
'Audit event table. Stores operational and business trace events such as reconciliation started, line reconciled, completed, cache invalidated, and data loaded.';

-- -------------------------------------------------------------------------------------------------
-- 5. Compatibility runtime tables
-- -------------------------------------------------------------------------------------------------
--
-- The local application repository contract currently reads and writes canonical entities through
-- the configured repository schema. In production, Silver remains the governed source of truth for
-- these entities. If the API service is configured to use platform_dev.pspa_ontology as its runtime schema,
-- these compatibility tables allow the service to operate while migration to direct Silver-backed
-- repository queries is completed.
--
-- Responsibility:
--   These tables are operational mirrors for service runtime compatibility. They should be loaded
--   from Silver, not treated as a separate independent source of truth.
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.party LIKE platform_dev.pspa_silver.party;
COMMENT ON TABLE platform_dev.pspa_ontology.party IS
'Runtime compatibility mirror of platform_dev.pspa_silver.party. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.item LIKE platform_dev.pspa_silver.item;
COMMENT ON TABLE platform_dev.pspa_ontology.item IS
'Runtime compatibility mirror of platform_dev.pspa_silver.item. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.uom_conversion LIKE platform_dev.pspa_silver.uom_conversion;
COMMENT ON TABLE platform_dev.pspa_ontology.uom_conversion IS
'Runtime compatibility mirror of platform_dev.pspa_silver.uom_conversion. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.contract LIKE platform_dev.pspa_silver.contract;
COMMENT ON TABLE platform_dev.pspa_ontology.contract IS
'Runtime compatibility mirror of platform_dev.pspa_silver.contract. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.contract_version LIKE platform_dev.pspa_silver.contract_version;
COMMENT ON TABLE platform_dev.pspa_ontology.contract_version IS
'Runtime compatibility mirror of platform_dev.pspa_silver.contract_version. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.contract_line_term LIKE platform_dev.pspa_silver.contract_line_term;
COMMENT ON TABLE platform_dev.pspa_ontology.contract_line_term IS
'Runtime compatibility mirror of platform_dev.pspa_silver.contract_line_term. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.effective_contract_line_term LIKE platform_dev.pspa_silver.effective_contract_line_term;
COMMENT ON TABLE platform_dev.pspa_ontology.effective_contract_line_term IS
'Runtime compatibility mirror of platform_dev.pspa_silver.effective_contract_line_term. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.member_eligibility LIKE platform_dev.pspa_silver.member_eligibility;
COMMENT ON TABLE platform_dev.pspa_ontology.member_eligibility IS
'Runtime compatibility mirror of platform_dev.pspa_silver.member_eligibility. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.invoice LIKE platform_dev.pspa_silver.invoice;
COMMENT ON TABLE platform_dev.pspa_ontology.invoice IS
'Runtime compatibility mirror of platform_dev.pspa_silver.invoice. Silver remains the governed source of truth.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ontology.invoice_line LIKE platform_dev.pspa_silver.invoice_line;
COMMENT ON TABLE platform_dev.pspa_ontology.invoice_line IS
'Runtime compatibility mirror of platform_dev.pspa_silver.invoice_line. Silver remains the governed source of truth.';

-- -------------------------------------------------------------------------------------------------
-- 6. Gold Delta tables - serving facts, analytics, and workflow queues
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_gold.invoice_reconciliation_summary (
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_number STRING NOT NULL,
  supplier_id STRING NOT NULL,
  member_id STRING NOT NULL,
  final_status STRING NOT NULL,
  total_variance DOUBLE NOT NULL,
  line_count BIGINT NOT NULL,
  pass_count BIGINT NOT NULL,
  fail_count BIGINT NOT NULL,
  warning_count BIGINT NOT NULL,
  completed_at TIMESTAMP
) USING DELTA
TBLPROPERTIES ('quality' = 'gold');

COMMENT ON TABLE platform_dev.pspa_gold.invoice_reconciliation_summary IS
'Gold invoice-level reconciliation summary for BI, AP review, finance reporting, and operational dashboards.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_gold.invoice_reconciliation_line (
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  line_number STRING NOT NULL,
  item_id STRING,
  route STRING NOT NULL,
  final_status STRING NOT NULL,
  matched_contract_id STRING,
  matched_contract_version_id STRING,
  matched_contract_line_id STRING,
  match_score DOUBLE,
  variance_amount DOUBLE NOT NULL,
  finding_type STRING NOT NULL,
  finding_summary STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'gold');

COMMENT ON TABLE platform_dev.pspa_gold.invoice_reconciliation_line IS
'Gold line-level reconciliation fact table. Stores final status, match result, route, variance, and finding summary for each invoice line.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_gold.dispute_case_queue (
  case_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  supplier_id STRING NOT NULL,
  member_id STRING NOT NULL,
  exception_id STRING,
  exception_type STRING,
  severity STRING NOT NULL,
  case_status STRING NOT NULL,
  variance_amount DOUBLE NOT NULL,
  annualized_exposure DOUBLE,
  dispute_ready BOOLEAN,
  contact_data_complete BOOLEAN,
  owner_group STRING,
  created_at TIMESTAMP NOT NULL,
  updated_at TIMESTAMP NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'gold');

COMMENT ON TABLE platform_dev.pspa_gold.dispute_case_queue IS
'Gold analyst work queue for price variances, off-contract lines, ambiguous matches, and other dispute or recovery cases.';

CREATE TABLE IF NOT EXISTS platform_dev.pspa_gold.price_assurance_recovery_opportunity (
  opportunity_id STRING NOT NULL,
  reconciliation_run_id STRING NOT NULL,
  invoice_id STRING NOT NULL,
  invoice_line_id STRING NOT NULL,
  supplier_id STRING NOT NULL,
  member_id STRING NOT NULL,
  contract_id STRING,
  finding_type STRING NOT NULL,
  severity STRING NOT NULL,
  recoverable_amount DOUBLE NOT NULL,
  root_cause_code STRING,
  case_status STRING NOT NULL,
  created_at TIMESTAMP NOT NULL
) USING DELTA
TBLPROPERTIES ('quality' = 'gold');

COMMENT ON TABLE platform_dev.pspa_gold.price_assurance_recovery_opportunity IS
'Gold recovery opportunity table for Price Assurance. Stores recoverable amount, root cause, case status, and contract/invoice lineage.';

-- -------------------------------------------------------------------------------------------------
-- 7. Operations Delta tables
-- -------------------------------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS platform_dev.pspa_ops.pipeline_run_log (
  pipeline_run_id STRING NOT NULL,
  workflow_name STRING NOT NULL,
  task_name STRING NOT NULL,
  status STRING NOT NULL,
  started_at TIMESTAMP NOT NULL,
  completed_at TIMESTAMP,
  input_count BIGINT,
  output_count BIGINT,
  error_message STRING
) USING DELTA
TBLPROPERTIES ('quality' = 'ops');

COMMENT ON TABLE platform_dev.pspa_ops.pipeline_run_log IS
'Operational pipeline run log used for workflow monitoring, SLA tracking, row-count reconciliation, and support troubleshooting.';

-- -------------------------------------------------------------------------------------------------
-- 8. Optional optimization statements
-- -------------------------------------------------------------------------------------------------
-- Run these after tables contain meaningful data. They are intentionally commented because
-- OPTIMIZE requires Databricks Runtime / SQL Warehouse support and may be scheduled separately.
--
-- OPTIMIZE platform_dev.pspa_silver.invoice_line ZORDER BY (invoice_id, item_id, service_date);
-- OPTIMIZE platform_dev.pspa_silver.effective_contract_line_term ZORDER BY (contract_id, item_id, effective_from);
-- OPTIMIZE platform_dev.pspa_silver.member_eligibility ZORDER BY (contract_id, party_id, valid_from);
-- OPTIMIZE platform_dev.pspa_ontology.edge ZORDER BY (relationship_type, from_node_id, to_node_id);
-- OPTIMIZE platform_dev.pspa_ontology.match_cache ZORDER BY (contract_id, invoice_line_signature, cache_status);
-- OPTIMIZE platform_dev.pspa_ontology.validation_result ZORDER BY (reconciliation_run_id, invoice_line_id);
-- OPTIMIZE platform_dev.pspa_ontology.exception_case ZORDER BY (reconciliation_run_id, invoice_line_id, exception_type);
-- OPTIMIZE platform_dev.pspa_ontology.dispute ZORDER BY (reconciliation_run_id, supplier_id, status);
-- OPTIMIZE platform_dev.pspa_gold.invoice_reconciliation_line ZORDER BY (invoice_id, invoice_line_id);

-- =================================================================================================
-- End of unified schema script
-- =================================================================================================
