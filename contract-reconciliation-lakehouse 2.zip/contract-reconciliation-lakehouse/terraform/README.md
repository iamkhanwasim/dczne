# Terraform

Purpose: infrastructure-as-code placeholders for cloud resources outside Databricks.

Typical responsibilities:

- Storage accounts / buckets.
- Networking.
- Key vault / secrets.
- Service principals.
- External locations, if managed outside Databricks bundle deployment.

