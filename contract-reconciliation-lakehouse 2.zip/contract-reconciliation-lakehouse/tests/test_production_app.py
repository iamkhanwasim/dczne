from __future__ import annotations

import uuid
import unittest
from pathlib import Path

from workflows.config import AppConfig
from workflows.repository_factory import build_local_repository
from workflows.service import ReconciliationService


class ProductionAppTest(unittest.TestCase):
    def build_service(self) -> tuple[ReconciliationService, object]:
        test_root = Path("data/test_work")
        test_root.mkdir(parents=True, exist_ok=True)
        db_path = test_root / f"service_{uuid.uuid4().hex}.db"
        repo, invoice_id = build_local_repository(db_path, reset=True)
        self.addCleanup(lambda: db_path.exists() and db_path.unlink())
        self.addCleanup(repo.close)
        config = AppConfig(
            environment="test",
            app_name="contract-reconciliation-lakehouse",
            app_version="0.2.0",
            repository_backend="sqlite",
            sqlite_db_path=db_path,
            seed_on_startup=False,
            log_level="INFO",
            databricks_catalog="platform_dev",
            databricks_schema="pspa_ontology",
            cors_allow_origins=(),
        )
        return ReconciliationService(repo, config, invoice_id), repo

    def test_service_health_and_metrics(self) -> None:
        service, _ = self.build_service()

        health = service.health()
        metrics = service.metrics()

        self.assertEqual(health["status"], "ok")
        self.assertEqual(health["repository"]["backend"], "sqlite")
        self.assertGreaterEqual(metrics["table_counts"]["invoice_line"], 6)

    def test_service_reconcile_response_contract(self) -> None:
        service, _ = self.build_service()

        payload = service.reconcile(correlation_id="unit-test")

        self.assertEqual(payload["correlation_id"], "unit-test")
        self.assertEqual(payload["final_status"], "FAIL")
        self.assertEqual(payload["line_count"], 6)
        self.assertEqual(len(payload["lines"][0]["validation_results"]), 14)
        self.assertEqual(payload["lines"][0]["graph_support_score"], 1.0)
        self.assertEqual(payload["lines"][0]["graph_evidence"]["matched_relationships"], 5)
        service_line = next(line for line in payload["lines"] if line["line_number"] == "6")
        self.assertEqual(service_line["charge_term_type"], "SUBSCRIPTION")
        self.assertEqual(service_line["match_status"], "PARTIAL_MATCH")
        self.assertIsNone(service_line["exception_case"])

    def test_repeated_runs_have_unique_run_ids(self) -> None:
        service, _ = self.build_service()

        first = service.reconcile()
        second = service.reconcile()

        self.assertNotEqual(
            first["run"]["reconciliation_run_id"],
            second["run"]["reconciliation_run_id"],
        )

    def test_config_rejects_unknown_backend(self) -> None:
        config = AppConfig(
            environment="test",
            app_name="contract-reconciliation-lakehouse",
            app_version="0.2.0",
            repository_backend="unknown",
            sqlite_db_path=Path("data/test.db"),
            seed_on_startup=False,
            log_level="INFO",
            databricks_catalog="platform_dev",
            databricks_schema="pspa_ontology",
            cors_allow_origins=(),
        )

        with self.assertRaises(ValueError):
            config.validate()


if __name__ == "__main__":
    unittest.main()
