from __future__ import annotations

import uuid
import unittest
from pathlib import Path

from ontology.engine import ReconciliationEngine
from sample_data.seed_data import seed_demo_data
from ontology.sqlite_repository import SQLiteOntologyRepository


class ReconciliationDemoTest(unittest.TestCase):
    def build_repo(self) -> SQLiteOntologyRepository:
        test_root = Path("data")
        test_root.mkdir(parents=True, exist_ok=True)
        db_path = test_root / f"test_{uuid.uuid4().hex}.db"
        repo = SQLiteOntologyRepository(db_path)
        self.addCleanup(lambda: db_path.exists() and db_path.unlink())
        self.addCleanup(repo.conn.close)
        repo.initialize()
        seed_demo_data(repo)
        return repo

    def test_seed_creates_graph(self) -> None:
        repo = self.build_repo()
        self.assertGreaterEqual(len(repo.list_nodes()), 10)
        self.assertGreaterEqual(len(repo.list_edges()), 8)

    def test_reconciliation_outputs_expected_findings(self) -> None:
        repo = self.build_repo()
        summary = ReconciliationEngine(repo).reconcile_invoice("INV-1001")

        self.assertEqual(summary.final_status, "FAIL")
        self.assertEqual(len(summary.line_outcomes), 6)
        self.assertEqual(summary.run.pass_count, 4)
        self.assertEqual(summary.run.fail_count, 2)
        self.assertEqual(summary.total_variance, 52.0)

        by_line = {outcome.invoice_line.line_number: outcome for outcome in summary.line_outcomes}
        self.assertEqual(by_line["1"].final_status, "PASS")
        self.assertEqual(by_line["2"].finding.finding_type, "PRICE_VARIANCE")
        self.assertEqual(by_line["2"].finding.variance_amount, 12.0)
        self.assertEqual(by_line["4"].finding.finding_type, "OFF_CONTRACT")
        self.assertEqual(by_line["4"].finding.variance_amount, 40.0)
        self.assertEqual(by_line["5"].final_status, "PASS")
        self.assertEqual(by_line["6"].final_status, "PASS")
        self.assertIsNotNone(by_line["6"].candidate)
        assert by_line["6"].candidate is not None
        self.assertEqual(by_line["6"].candidate.charge_term_type, "SUBSCRIPTION")
        self.assertTrue(by_line["6"].candidate.uom_absent_accepted)
        self.assertEqual(by_line["6"].candidate.match_status.value, "PARTIAL_MATCH")

    def test_matching_uses_graph_relationship_support(self) -> None:
        repo = self.build_repo()
        summary = ReconciliationEngine(repo).reconcile_invoice("INV-1001")

        by_line = {outcome.invoice_line.line_number: outcome for outcome in summary.line_outcomes}
        candidate = by_line["1"].candidate

        self.assertIsNotNone(candidate)
        assert candidate is not None
        self.assertEqual(candidate.graph_support_score, 1.0)
        self.assertEqual(candidate.graph_evidence["matched_relationships"], 5)
        self.assertEqual(candidate.graph_evidence["expected_relationships"], 5)
        self.assertIn("graph=1.000", candidate.reason)
        relationship_names = {
            check["name"]
            for check in candidate.graph_evidence["checks"]
            if check["found"]
        }
        self.assertIn("invoice_has_line", relationship_names)
        self.assertIn("contract_has_term", relationship_names)
        self.assertIn("term_prices_item", relationship_names)
        self.assertIn("member_eligible_for_contract", relationship_names)
        self.assertIn("supplier_participates_in_contract", relationship_names)

    def test_second_run_uses_fast_path_cache(self) -> None:
        repo = self.build_repo()
        engine = ReconciliationEngine(repo)
        first = engine.reconcile_invoice("INV-1001")
        second = engine.reconcile_invoice("INV-1001")

        self.assertEqual(first.run.fast_path_count, 0)
        self.assertGreaterEqual(second.run.fast_path_count, 3)

    def test_exception_and_dispute_lifecycle_outputs(self) -> None:
        repo = self.build_repo()
        summary = ReconciliationEngine(repo).reconcile_invoice("INV-1001")

        exceptions = repo.list_exception_cases(summary.run.reconciliation_run_id)
        disputes = repo.list_disputes(summary.run.reconciliation_run_id)

        self.assertEqual(len(exceptions), 2)
        self.assertEqual(len(disputes), 2)
        exception_types = {row["exception_type"] for row in exceptions}
        self.assertIn("RATE_ABOVE_CONTRACT", exception_types)
        self.assertIn("UNMATCHED_LINE", exception_types)
        self.assertTrue(all(row["dispute_ready"] for row in exceptions))
        self.assertTrue(all(row["status"] == "READY_TO_SEND" for row in disputes))


if __name__ == "__main__":
    unittest.main()
