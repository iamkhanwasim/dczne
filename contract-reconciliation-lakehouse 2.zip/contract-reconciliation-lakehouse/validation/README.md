# Validation

Purpose: run deterministic financial and contract compliance rules.

Current local implementation:

- `validators.py`

Core rules:

- `CONTRACT_FOUND`
- `ITEM_MATCHED`
- `MEMBER_ELIGIBLE`
- `AMENDMENT_VERSION_VALID`
- `UOM_CONVERTIBLE`
- `PRICE_WITHIN_TOLERANCE`
- `QUANTITY_LIMIT_VALID`

Rule metadata belongs in `platform_dev.pspa_ontology.rule_catalog`.

