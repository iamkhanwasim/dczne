from __future__ import annotations

from ontology.models import (
    Invoice,
    InvoiceLine,
    MatchCandidate,
    Severity,
    ValidationResult,
    ValidationStatus,
)
from ontology.repository import OntologyRepository
from ontology.utils import stable_id


RULE_ORDER = [
    "DATA_QUALITY_SUFFICIENT",
    "CONTRACT_FOUND",
    "CONTRACT_CANDIDATE_SELECTED",
    "CHARGE_TERM_CANDIDATE_SELECTED",
    "ITEM_OR_SERVICE_TERM_MATCHED",
    "CATEGORY_COMPATIBLE",
    "MEMBER_ELIGIBLE",
    "AMENDMENT_VERSION_VALID",
    "CHARGE_TERM_ALLOWED",
    "UOM_NOT_REQUIRED_OR_CONVERTIBLE",
    "PRICE_WITHIN_TOLERANCE",
    "QUANTITY_LIMIT_VALID",
    "FREQUENCY_ALLOWED",
    "SUPPLIER_CONTACT_COMPLETE",
]


RULE_SEVERITY = {
    "DATA_QUALITY_SUFFICIENT": Severity.HIGH,
    "CONTRACT_FOUND": Severity.HIGH,
    "CONTRACT_CANDIDATE_SELECTED": Severity.HIGH,
    "CHARGE_TERM_CANDIDATE_SELECTED": Severity.HIGH,
    "ITEM_OR_SERVICE_TERM_MATCHED": Severity.HIGH,
    "CATEGORY_COMPATIBLE": Severity.MEDIUM,
    "MEMBER_ELIGIBLE": Severity.HIGH,
    "AMENDMENT_VERSION_VALID": Severity.HIGH,
    "CHARGE_TERM_ALLOWED": Severity.HIGH,
    "UOM_NOT_REQUIRED_OR_CONVERTIBLE": Severity.MEDIUM,
    "PRICE_WITHIN_TOLERANCE": Severity.HIGH,
    "QUANTITY_LIMIT_VALID": Severity.MEDIUM,
    "FREQUENCY_ALLOWED": Severity.MEDIUM,
    "SUPPLIER_CONTACT_COMPLETE": Severity.MEDIUM,
}


def _frequency_compatible(line_frequency: str, term_frequency: str) -> bool:
    if not line_frequency or not term_frequency:
        return True
    return line_frequency.upper() == term_frequency.upper()


def _enum_value(value: object) -> str:
    return getattr(value, "value", str(value))


def _base_evidence(candidate: MatchCandidate | None) -> dict:
    if not candidate:
        return {}
    return {
        "match_score": candidate.score,
        "route": candidate.route.value,
        "match_status": _enum_value(candidate.match_status),
        "reason": candidate.reason,
        "contract_line_id": candidate.contract_line_id,
        "contract_selection_score": candidate.contract_selection_score,
        "contract_selection_evidence": candidate.contract_selection_evidence,
        "contract_candidate_count": candidate.contract_candidate_count,
        "term_candidate_count": candidate.term_candidate_count,
        "charge_term_type": candidate.charge_term_type,
        "pricing_basis": candidate.pricing_basis,
        "category_compatible": candidate.category_compatible,
        "uom_required": candidate.uom_required,
        "uom_absent_accepted": candidate.uom_absent_accepted,
        "data_quality_sufficient": candidate.data_quality_sufficient,
        "graph_support_score": candidate.graph_support_score,
        "graph_relationships": {
            "matched": candidate.graph_evidence.get("matched_relationships", 0),
            "expected": candidate.graph_evidence.get("expected_relationships", 0),
        },
    }


def validate_line(
    repo: OntologyRepository,
    reconciliation_run_id: str,
    invoice: Invoice,
    line: InvoiceLine,
    candidate: MatchCandidate | None,
) -> list[ValidationResult]:
    results: list[ValidationResult] = []
    policy = repo.get_matching_policy()
    contact = repo.get_supplier_contact(invoice.supplier_id)

    for rule_code in RULE_ORDER:
        status = ValidationStatus.PASS
        expected = ""
        actual = ""
        variance = 0.0
        evidence = _base_evidence(candidate)

        if rule_code == "DATA_QUALITY_SUFFICIENT":
            expected = "Structured source quality is sufficient for financial validation"
            actual = f"{line.source_quality_status}; confidence={line.parse_confidence}"
            status = (
                ValidationStatus.PASS
                if not candidate or candidate.data_quality_sufficient
                else ValidationStatus.FAIL
            )

        elif rule_code == "CONTRACT_FOUND":
            expected = "A valid contract line exists"
            actual = candidate.contract_line_id if candidate else "NO_MATCH"
            status = ValidationStatus.PASS if candidate else ValidationStatus.FAIL

        elif rule_code == "CONTRACT_CANDIDATE_SELECTED":
            expected = "At least one supplier/date contract candidate was evaluated"
            actual = str(candidate.contract_candidate_count if candidate else 0)
            status = (
                ValidationStatus.PASS
                if candidate and candidate.contract_candidate_count > 0
                else ValidationStatus.FAIL
            )

        elif rule_code == "CHARGE_TERM_CANDIDATE_SELECTED":
            expected = "At least one charge term candidate was evaluated"
            actual = str(candidate.term_candidate_count if candidate else 0)
            status = (
                ValidationStatus.PASS
                if candidate and candidate.term_candidate_count > 0
                else ValidationStatus.FAIL
            )

        elif rule_code == "ITEM_OR_SERVICE_TERM_MATCHED":
            expected = "Invoice line maps to contract item or semantic service charge term"
            actual = (
                f"exact={candidate.exact_item_match}; semantic={candidate.semantic_similarity:.4f}; "
                f"match_status={_enum_value(candidate.match_status)}"
                if candidate
                else "False"
            )
            status = (
                ValidationStatus.PASS
                if candidate
                and (
                    candidate.exact_item_match
                    or candidate.semantic_similarity >= policy.semantic_match_threshold
                )
                else ValidationStatus.FAIL
            )

        elif rule_code == "CATEGORY_COMPATIBLE":
            expected = "Invoice line category is compatible with contract charge term category"
            actual = str(candidate.category_compatible) if candidate else "False"
            status = (
                ValidationStatus.PASS
                if candidate and candidate.category_compatible
                else ValidationStatus.SKIP if not candidate else ValidationStatus.FAIL
            )

        elif rule_code == "MEMBER_ELIGIBLE":
            expected = "Member is eligible for selected contract"
            actual = str(candidate.member_eligible) if candidate else "False"
            status = (
                ValidationStatus.PASS
                if candidate and candidate.member_eligible
                else ValidationStatus.FAIL
            )

        elif rule_code == "AMENDMENT_VERSION_VALID":
            expected = "Selected term is effective for invoice service date"
            actual = candidate.contract_version_id if candidate else "NO_MATCH"
            status = ValidationStatus.PASS if candidate and candidate.date_valid else ValidationStatus.FAIL

        elif rule_code == "CHARGE_TERM_ALLOWED":
            expected = "Selected charge term is allowed by contract"
            actual = (
                f"{candidate.charge_term_allowed}; type={candidate.charge_term_type}"
                if candidate
                else "False"
            )
            status = (
                ValidationStatus.PASS
                if candidate and candidate.charge_term_allowed
                else ValidationStatus.SKIP if not candidate else ValidationStatus.FAIL
            )

        elif rule_code == "UOM_NOT_REQUIRED_OR_CONVERTIBLE":
            expected = "Invoice UOM is not required for service term or converts to contract UOM"
            actual = (
                f"uom_required={candidate.uom_required}; convertible={candidate.uom_convertible}; "
                f"absent_accepted={candidate.uom_absent_accepted}"
                if candidate
                else "False"
            )
            if not candidate:
                status = ValidationStatus.SKIP
            elif candidate.uom_absent_accepted:
                status = ValidationStatus.SKIP
            else:
                status = ValidationStatus.PASS if candidate.uom_convertible else ValidationStatus.FAIL

        elif rule_code == "PRICE_WITHIN_TOLERANCE":
            expected = f"Invoice unit price <= contract price + {policy.price_tolerance_pct:.3%}"
            if not candidate or candidate.normalized_invoice_unit_price is None:
                status = ValidationStatus.SKIP
                actual = "NO_PRICE_COMPARISON"
            else:
                threshold = candidate.contract_unit_price * (1 + policy.price_tolerance_pct)
                actual = (
                    f"{candidate.normalized_invoice_unit_price:.4f} vs "
                    f"{candidate.contract_unit_price:.4f}"
                )
                if candidate.normalized_invoice_unit_price <= threshold:
                    status = ValidationStatus.PASS
                else:
                    status = ValidationStatus.FAIL
                    variance = round(
                        (candidate.normalized_invoice_unit_price - candidate.contract_unit_price)
                        * line.quantity,
                        2,
                    )

        elif rule_code == "QUANTITY_LIMIT_VALID":
            expected = "Quantity is inside contract min/max limits"
            actual = str(line.quantity)
            if not candidate:
                status = ValidationStatus.SKIP
            else:
                min_ok = (
                    candidate.contract_min_quantity is None
                    or line.quantity >= candidate.contract_min_quantity
                )
                max_ok = (
                    candidate.contract_max_quantity is None
                    or line.quantity <= candidate.contract_max_quantity
                )
                status = ValidationStatus.PASS if min_ok and max_ok else ValidationStatus.FAIL
                expected = (
                    f"min={candidate.contract_min_quantity}; "
                    f"max={candidate.contract_max_quantity}"
                )

        elif rule_code == "FREQUENCY_ALLOWED":
            term_frequency = (
                candidate.contract_selection_evidence.get("billing_frequency", "")
                if candidate
                else ""
            )
            expected = "Invoice billing frequency is compatible with selected charge term"
            actual = f"{line.billing_frequency or 'UNSPECIFIED'} vs {term_frequency or 'UNSPECIFIED'}"
            if not candidate:
                status = ValidationStatus.SKIP
            else:
                status = (
                    ValidationStatus.PASS
                    if _frequency_compatible(line.billing_frequency, term_frequency)
                    else ValidationStatus.FAIL
                )

        elif rule_code == "SUPPLIER_CONTACT_COMPLETE":
            expected = "Supplier contact data is complete before dispute initiation"
            actual = str(contact.get("contact_data_complete", False))
            status = (
                ValidationStatus.PASS
                if contact.get("contact_data_complete", False)
                else ValidationStatus.FAIL
            )
            evidence = {**evidence, "supplier_contact": contact}

        results.append(
            ValidationResult(
                validation_result_id=stable_id(
                    reconciliation_run_id,
                    line.invoice_line_id,
                    rule_code,
                ),
                reconciliation_run_id=reconciliation_run_id,
                invoice_id=invoice.invoice_id,
                invoice_line_id=line.invoice_line_id,
                rule_code=rule_code,
                status=status,
                severity=RULE_SEVERITY[rule_code],
                matched_contract_id=candidate.contract_id if candidate else None,
                matched_contract_version_id=candidate.contract_version_id if candidate else None,
                matched_contract_line_id=candidate.contract_line_id if candidate else None,
                expected_value=expected,
                actual_value=actual,
                variance_amount=variance,
                evidence=evidence,
            )
        )

    return results


def final_status(results: list[ValidationResult]) -> str:
    has_high_fail = any(
        result.status == ValidationStatus.FAIL and result.severity == Severity.HIGH
        for result in results
    )
    if has_high_fail:
        return "FAIL"

    has_warning = any(
        result.status == ValidationStatus.FAIL and result.severity != Severity.HIGH
        for result in results
    )
    if has_warning:
        return "WARN"

    return "PASS"
