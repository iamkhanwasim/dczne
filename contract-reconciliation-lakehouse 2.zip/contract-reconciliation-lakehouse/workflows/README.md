# Workflows

Purpose: local demo entry points and Databricks workflow definitions.

Local runnable files:

- `cli.py`
- `api.py`

Recommended Databricks workflows:

- Bronze-to-Silver normalization.
- Amendment/effective-term resolution.
- Ontology graph build.
- Invoice reconciliation.
- Gold fact publishing.
- Exception/dispute workflow refresh.

