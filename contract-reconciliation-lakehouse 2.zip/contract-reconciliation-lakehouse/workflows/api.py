from __future__ import annotations

import argparse
from typing import Any

from workflows.config import AppConfig
from workflows.logging_config import configure_logging
from workflows.repository_factory import build_repository
from workflows.service import ReconciliationService

try:
    from fastapi import FastAPI, HTTPException, Request
    from fastapi.middleware.cors import CORSMiddleware
    from pydantic import BaseModel, Field
except ImportError:  # pragma: no cover - exercised only without api extra installed
    FastAPI = None  # type: ignore[assignment]
    HTTPException = None  # type: ignore[assignment]
    Request = object  # type: ignore[assignment]
    CORSMiddleware = None  # type: ignore[assignment]
    BaseModel = object  # type: ignore[assignment]


if FastAPI is not None:

    class ReconcileRequest(BaseModel):
        invoice_id: str | None = Field(default=None, description="Invoice id to reconcile")
        correlation_id: str | None = Field(
            default=None,
            description="Optional caller-supplied id for traceability",
        )


def create_app(config: AppConfig | None = None, reset: bool = False) -> Any:
    if FastAPI is None:
        raise RuntimeError("Install API dependencies first: pip install .[api]")

    runtime_config = config or AppConfig.from_env()
    configure_logging(runtime_config.log_level)
    repo, default_invoice_id = build_repository(runtime_config, reset=reset)
    service = ReconciliationService(repo, runtime_config, default_invoice_id)

    app = FastAPI(
        title="Contract Reconciliation Lakehouse API",
        version=runtime_config.app_version,
        description=(
            "Ontology-based contract-to-invoice reconciliation API for "
            "Supply Chain, GPO, AP, and Price Assurance workflows."
        ),
    )
    app.state.service = service
    app.state.repository = repo

    if runtime_config.cors_allow_origins and CORSMiddleware is not None:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(runtime_config.cors_allow_origins),
            allow_credentials=True,
            allow_methods=["GET", "POST"],
            allow_headers=["*"],
        )

    @app.on_event("shutdown")
    def shutdown() -> None:
        if hasattr(repo, "close"):
            repo.close()

    @app.get("/health", tags=["operations"])
    def health() -> dict[str, Any]:
        return service.health()

    @app.get("/ready", tags=["operations"])
    def ready() -> dict[str, Any]:
        return service.ready()

    @app.get("/metrics", tags=["operations"])
    def metrics() -> dict[str, Any]:
        return service.metrics()

    @app.post("/v1/reconciliations", tags=["reconciliation"])
    def reconcile(payload: ReconcileRequest, request: Request) -> dict[str, Any]:
        correlation_id = payload.correlation_id or request.headers.get("x-correlation-id")
        try:
            return service.reconcile(payload.invoice_id, correlation_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    @app.get("/v1/reconciliations/{run_id}/validation-results", tags=["reconciliation"])
    def validation_results(run_id: str) -> list[dict[str, Any]]:
        return service.validation_results(run_id)

    @app.get("/v1/reconciliations/{run_id}/findings", tags=["reconciliation"])
    def findings(run_id: str) -> list[dict[str, Any]]:
        return service.findings(run_id)

    @app.get("/v1/reconciliations/{run_id}/exception-cases", tags=["reconciliation"])
    def exception_cases(run_id: str) -> list[dict[str, Any]]:
        return service.exception_cases(run_id)

    @app.get("/v1/reconciliations/{run_id}/disputes", tags=["reconciliation"])
    def disputes(run_id: str) -> list[dict[str, Any]]:
        return service.disputes(run_id)

    @app.get("/v1/ontology/graph", tags=["ontology"])
    def ontology_graph() -> dict[str, Any]:
        return service.ontology_graph()

    @app.get("/v1/ontology/nodes", tags=["ontology"])
    def ontology_nodes() -> list[dict[str, Any]]:
        return service.repo.list_nodes()

    @app.get("/v1/ontology/edges", tags=["ontology"])
    def ontology_edges() -> list[dict[str, Any]]:
        return service.repo.list_edges()

    return app


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve the production reconciliation API.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8008)
    parser.add_argument("--db", default=None, help="Override SQLITE_DB_PATH for local runs.")
    parser.add_argument("--reset", action="store_true", help="Reset local seed data before startup.")
    args = parser.parse_args()

    if args.db:
        import os

        os.environ["SQLITE_DB_PATH"] = args.db

    config = AppConfig.from_env()
    configure_logging(config.log_level)

    try:
        import uvicorn
    except ImportError as exc:  # pragma: no cover - depends on optional dependency
        raise RuntimeError("Install API dependencies first: pip install .[api]") from exc

    uvicorn.run(create_app(config, reset=args.reset), host=args.host, port=args.port)


if __name__ == "__main__":
    main()
