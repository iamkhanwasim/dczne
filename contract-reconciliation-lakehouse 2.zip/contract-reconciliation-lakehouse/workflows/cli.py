from __future__ import annotations

import argparse
import json
from pathlib import Path

from ontology.engine import ReconciliationEngine
from ontology.models import ReconciliationSummary
from ontology.sqlite_repository import SQLiteOntologyRepository
from workflows.repository_factory import build_local_repository
from workflows.schemas import summary_to_dict


def print_table(summary: ReconciliationSummary) -> None:
    print()
    print("Databricks Ontology Reconciliation Demo")
    print("=" * 44)
    print(f"Invoice:      {summary.invoice.invoice_number}")
    print(f"Run ID:       {summary.run.reconciliation_run_id}")
    print(f"Status:       {summary.final_status}")
    print(f"Variance:     ${summary.total_variance:,.2f}")
    print()

    headers = ["Line", "Description", "Route", "Status", "Matched Term", "Variance"]
    rows = []
    for outcome in summary.line_outcomes:
        rows.append(
            [
                outcome.invoice_line.line_number,
                outcome.invoice_line.description[:28],
                outcome.route.value,
                outcome.final_status,
                outcome.candidate.contract_line_id if outcome.candidate else "NO_MATCH",
                f"${outcome.finding.variance_amount:,.2f}",
            ]
        )

    widths = [
        max(len(str(row[i])) for row in rows + [headers])
        for i in range(len(headers))
    ]
    print(" | ".join(header.ljust(widths[i]) for i, header in enumerate(headers)))
    print("-+-".join("-" * width for width in widths))
    for row in rows:
        print(" | ".join(str(value).ljust(widths[i]) for i, value in enumerate(row)))

    print()
    print("Findings")
    print("-" * 44)
    for outcome in summary.line_outcomes:
        print(f"{outcome.invoice_line.line_number}. {outcome.finding.summary}")
        print(f"   {outcome.finding.detail}")


def build_repo(db_path: Path, reset: bool) -> tuple[SQLiteOntologyRepository, str]:
    return build_local_repository(db_path, reset=reset)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the ontology reconciliation demo.")
    parser.add_argument("--db", default="data/demo_reconciliation.db", help="SQLite demo database path.")
    parser.add_argument("--invoice-id", default=None, help="Invoice id to reconcile.")
    parser.add_argument("--reset", action="store_true", help="Reset and reload demo data before running.")
    parser.add_argument("--json", action="store_true", help="Print JSON instead of a text table.")
    parser.add_argument("--metrics", action="store_true", help="Print repository metrics and exit.")
    parser.add_argument(
        "--twice",
        action="store_true",
        help="Run reconciliation twice to demonstrate fast-path cache hits on the second run.",
    )
    args = parser.parse_args()

    repo, default_invoice_id = build_repo(Path(args.db), reset=args.reset)
    if args.metrics:
        print(json.dumps(repo.metrics(), indent=2, default=str))
        repo.close()
        return

    invoice_id = args.invoice_id or default_invoice_id
    engine = ReconciliationEngine(repo)

    summary = engine.reconcile_invoice(invoice_id)
    if args.twice:
        summary = engine.reconcile_invoice(invoice_id)

    if args.json:
        print(json.dumps(summary_to_dict(summary), indent=2, default=str))
    else:
        print_table(summary)
    repo.close()


if __name__ == "__main__":
    main()
