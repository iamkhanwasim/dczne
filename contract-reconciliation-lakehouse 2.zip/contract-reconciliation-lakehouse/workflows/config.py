from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


TRUE_VALUES = {"1", "true", "yes", "y", "on"}


def _get_bool(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in TRUE_VALUES


@dataclass(frozen=True)
class AppConfig:
    """Runtime configuration for local, container, and Databricks-backed execution."""

    environment: str
    app_name: str
    app_version: str
    repository_backend: str
    sqlite_db_path: Path
    seed_on_startup: bool
    log_level: str
    databricks_catalog: str
    databricks_schema: str
    cors_allow_origins: tuple[str, ...]

    @classmethod
    def from_env(cls) -> "AppConfig":
        origins = tuple(
            origin.strip()
            for origin in os.environ.get("CORS_ALLOW_ORIGINS", "").split(",")
            if origin.strip()
        )
        return cls(
            environment=os.environ.get("APP_ENV", "local"),
            app_name=os.environ.get("APP_NAME", "contract-reconciliation-lakehouse"),
            app_version=os.environ.get("APP_VERSION", "0.2.0"),
            repository_backend=os.environ.get("REPOSITORY_BACKEND", "sqlite").lower(),
            sqlite_db_path=Path(os.environ.get("SQLITE_DB_PATH", "data/reconciliation.db")),
            seed_on_startup=_get_bool("SEED_ON_STARTUP", True),
            log_level=os.environ.get("LOG_LEVEL", "INFO").upper(),
            databricks_catalog=os.environ.get("DATABRICKS_CATALOG", "platform_dev"),
            databricks_schema=os.environ.get("DATABRICKS_SCHEMA", "pspa_ontology"),
            cors_allow_origins=origins,
        )

    def validate(self) -> None:
        supported = {"sqlite", "databricks"}
        if self.repository_backend not in supported:
            raise ValueError(
                f"Unsupported REPOSITORY_BACKEND={self.repository_backend!r}; "
                f"expected one of {sorted(supported)}"
            )
        if self.repository_backend == "sqlite" and not self.sqlite_db_path.parent:
            raise ValueError("SQLITE_DB_PATH must include a valid parent directory")
