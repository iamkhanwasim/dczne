from __future__ import annotations

from pathlib import Path

from ontology.databricks_repository import (
    DatabricksOntologyRepository,
    DatabricksSqlClient,
    DatabricksSqlConfig,
)
from ontology.repository import OntologyRepository
from ontology.sqlite_repository import SQLiteOntologyRepository
from sample_data.seed_data import seed_demo_data
from workflows.config import AppConfig


def build_repository(config: AppConfig, reset: bool = False) -> tuple[OntologyRepository, str | None]:
    """Create and initialize the configured ontology repository.

    Returns the repository and a default seeded invoice id when seed data was loaded
    or already exists. Production Databricks runs generally return None because
    invoices are expected to already be present in Unity Catalog tables.
    """

    config.validate()
    if config.repository_backend == "databricks":
        client = DatabricksSqlClient(DatabricksSqlConfig.from_env())
        repo = DatabricksOntologyRepository(
            client,
            catalog=config.databricks_catalog,
            schema=config.databricks_schema,
        )
        repo.initialize()
        return repo, None

    repo = SQLiteOntologyRepository(config.sqlite_db_path)
    repo.initialize()
    default_invoice_id = ensure_seed_data(repo, reset=reset or config.seed_on_startup)
    return repo, default_invoice_id


def ensure_seed_data(repo: OntologyRepository, reset: bool = False) -> str:
    if reset:
        repo.reset()
        return seed_demo_data(repo)

    try:
        repo.get_invoice("INV-1001")
        return "INV-1001"
    except KeyError:
        return seed_demo_data(repo)


def build_local_repository(db_path: str | Path, reset: bool = False) -> tuple[SQLiteOntologyRepository, str]:
    config = AppConfig.from_env()
    local_config = AppConfig(
        environment=config.environment,
        app_name=config.app_name,
        app_version=config.app_version,
        repository_backend="sqlite",
        sqlite_db_path=Path(db_path),
        seed_on_startup=True,
        log_level=config.log_level,
        databricks_catalog=config.databricks_catalog,
        databricks_schema=config.databricks_schema,
        cors_allow_origins=config.cors_allow_origins,
    )
    repo, invoice_id = build_repository(local_config, reset=reset)
    return repo, invoice_id or "INV-1001"
