from __future__ import annotations

from dataclasses import asdict, is_dataclass
from datetime import date, datetime
from enum import Enum
from typing import Any

from ontology.models import ReconciliationSummary, ValidationStatus


def to_primitive(value: Any) -> Any:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {key: to_primitive(item) for key, item in asdict(value).items()}
    if isinstance(value, list):
        return [to_primitive(item) for item in value]
    if isinstance(value, tuple):
        return [to_primitive(item) for item in value]
    if isinstance(value, dict):
        return {str(key): to_primitive(item) for key, item in value.items()}
    return value


def enum_value(value: Any) -> Any:
    return value.value if isinstance(value, Enum) else value


def summary_to_dict(summary: ReconciliationSummary) -> dict[str, Any]:
    return {
        "run": to_primitive(summary.run),
        "invoice": to_primitive(summary.invoice),
        "final_status": summary.final_status,
        "total_variance": summary.total_variance,
        "line_count": len(summary.line_outcomes),
        "lines": [
            {
                "invoice_line_id": outcome.invoice_line.invoice_line_id,
                "line_number": outcome.invoice_line.line_number,
                "description": outcome.invoice_line.description,
                "item_id": outcome.invoice_line.item_id,
                "category_code": outcome.invoice_line.category_code,
                "charge_term_text": outcome.invoice_line.charge_term_text,
                "source_quality_status": outcome.invoice_line.source_quality_status,
                "parse_confidence": outcome.invoice_line.parse_confidence,
                "quantity": outcome.invoice_line.quantity,
                "invoice_uom": outcome.invoice_line.invoice_uom,
                "unit_price": outcome.invoice_line.unit_price,
                "status": outcome.final_status,
                "route": outcome.route.value,
                "matched_contract_id": outcome.candidate.contract_id if outcome.candidate else None,
                "matched_contract_version_id": (
                    outcome.candidate.contract_version_id if outcome.candidate else None
                ),
                "matched_contract_line_id": (
                    outcome.candidate.contract_line_id if outcome.candidate else None
                ),
                "match_score": outcome.candidate.score if outcome.candidate else None,
                "match_status": enum_value(outcome.candidate.match_status) if outcome.candidate else "NO_MATCH",
                "contract_selection_score": (
                    outcome.candidate.contract_selection_score if outcome.candidate else None
                ),
                "contract_selection_evidence": (
                    outcome.candidate.contract_selection_evidence if outcome.candidate else None
                ),
                "contract_candidate_count": (
                    outcome.candidate.contract_candidate_count if outcome.candidate else 0
                ),
                "term_candidate_count": outcome.candidate.term_candidate_count if outcome.candidate else 0,
                "charge_term_type": outcome.candidate.charge_term_type if outcome.candidate else None,
                "pricing_basis": outcome.candidate.pricing_basis if outcome.candidate else None,
                "graph_support_score": (
                    outcome.candidate.graph_support_score if outcome.candidate else None
                ),
                "graph_evidence": outcome.candidate.graph_evidence if outcome.candidate else None,
                "finding_type": outcome.finding.finding_type,
                "finding_summary": outcome.finding.summary,
                "exception_case": to_primitive(outcome.exception_case),
                "dispute": to_primitive(outcome.dispute),
                "variance": outcome.finding.variance_amount,
                "failed_rules": [
                    result.rule_code
                    for result in outcome.validation_results
                    if result.status == ValidationStatus.FAIL
                ],
                "validation_results": [to_primitive(result) for result in outcome.validation_results],
            }
            for outcome in summary.line_outcomes
        ],
    }


def graph_to_dict(nodes: list[dict[str, Any]], edges: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "node_count": len(nodes),
        "edge_count": len(edges),
        "nodes": nodes,
        "edges": edges,
    }
