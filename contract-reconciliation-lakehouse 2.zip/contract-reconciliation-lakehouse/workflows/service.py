from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from typing import Any

from ontology.engine import ReconciliationEngine
from ontology.repository import OntologyRepository
from workflows.config import AppConfig
from workflows.schemas import graph_to_dict, summary_to_dict


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ReconcileCommand:
    invoice_id: str
    correlation_id: str


class ReconciliationService:
    """Application service boundary for API, CLI, and scheduled workflows."""

    def __init__(
        self,
        repo: OntologyRepository,
        config: AppConfig,
        default_invoice_id: str | None = None,
    ) -> None:
        self.repo = repo
        self.config = config
        self.default_invoice_id = default_invoice_id
        self.engine = ReconciliationEngine(repo)

    def health(self) -> dict[str, Any]:
        diagnostics = (
            self.repo.healthcheck()
            if hasattr(self.repo, "healthcheck")
            else {"status": "unknown", "backend": self.config.repository_backend}
        )
        return {
            "status": "ok",
            "app_name": self.config.app_name,
            "app_version": self.config.app_version,
            "environment": self.config.environment,
            "repository": diagnostics,
            "default_invoice_id": self.default_invoice_id,
        }

    def ready(self) -> dict[str, Any]:
        health = self.health()
        repo_status = health.get("repository", {}).get("status")
        ready = repo_status in {"ok", "unknown"}
        return {"ready": ready, **health}

    def reconcile(self, invoice_id: str | None = None, correlation_id: str | None = None) -> dict[str, Any]:
        selected_invoice_id = invoice_id or self.default_invoice_id
        if not selected_invoice_id:
            raise ValueError("invoice_id is required when no default seeded invoice is configured")
        command = ReconcileCommand(
            invoice_id=selected_invoice_id,
            correlation_id=correlation_id or uuid.uuid4().hex,
        )
        logger.info(
            "reconciliation requested",
            extra={
                "event": "RECONCILIATION_REQUESTED",
                "invoice_id": command.invoice_id,
                "correlation_id": command.correlation_id,
            },
        )
        summary = self.engine.reconcile_invoice(command.invoice_id)
        payload = summary_to_dict(summary)
        payload["correlation_id"] = command.correlation_id
        logger.info(
            "reconciliation completed",
            extra={
                "event": "RECONCILIATION_COMPLETED",
                "invoice_id": command.invoice_id,
                "run_id": summary.run.reconciliation_run_id,
                "correlation_id": command.correlation_id,
            },
        )
        return payload

    def ontology_graph(self) -> dict[str, Any]:
        return graph_to_dict(self.repo.list_nodes(), self.repo.list_edges())

    def validation_results(self, run_id: str) -> list[dict[str, Any]]:
        return self.repo.list_validation_results(run_id)

    def findings(self, run_id: str) -> list[dict[str, Any]]:
        return self.repo.list_findings(run_id)

    def exception_cases(self, run_id: str) -> list[dict[str, Any]]:
        return self.repo.list_exception_cases(run_id)

    def disputes(self, run_id: str) -> list[dict[str, Any]]:
        return self.repo.list_disputes(run_id)

    def metrics(self) -> dict[str, Any]:
        if hasattr(self.repo, "metrics"):
            return self.repo.metrics()
        return {"backend": self.config.repository_backend, "metrics_available": False}
