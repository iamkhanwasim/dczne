# PSPA Reconciliation Engine — Architecture & Design

## Table of Contents

1. [System Overview](#system-overview)
2. [Domain Model & Ontology](#domain-model--ontology)
3. [Architecture Diagram](#architecture-diagram)
4. [Core Design Principles](#core-design-principles)
5. [Component Architecture](#component-architecture)
6. [API Interfaces](#api-interfaces)
7. [Data Flow](#data-flow)
8. [Key Decisions (ADRs)](#key-decisions-adrs)
9. [Tech Debt & Prototype Constraints](#tech-debt--prototype-constraints)

---

## System Overview

**PSPA Reconciliation Engine** is a service that evaluates vendor invoices against governing service contracts with high auditability and limited LLM use.

### Core Prototype Scope

The prototype focuses on **reconciliation logic** and is designed around these steps:

1. **Ingest contract text** → Extract charge terms via LLM → Store as RDF triples in ontology graph
2. **Receive structured invoice** → Normalize line items (already in JSON/structured format)
3. **Match invoice lines** → Two-tier routing (fast-path cache vs. deep semantic matching)
4. **Run deterministic validators** → Arithmetic, dates, preconditions, pass-through evidence
5. **Return findings** → Audit trail, confidence scores, recommended actions

### Supporting Harness Code (Not Core Prototype)

The codebase includes utilities to support **end-to-end testing and demo**, but these are **not part of the core prototype design**:

- **PDF → Text conversion** (`data_parsers/pdf_extractor.py`, sidecar .txt files): Converts contract/invoice PDFs to text. This is an input transformation handled upstream in production.
- **Text → Structured JSON** (`data_parsers/markdown_parser.py`, `invoice_parser.py`): Parses markdown/YAML contracts and invoices. In production, these would be pre-structured by upstream systems (ERP, document management).
- **Streamlit workbench UI** (`ui/`): Interactive exploration tool for development and debugging. Not intended for production analyst workflows.

These utilities enable end-to-end demos from raw PDFs, but they are **not in scope for production hardening**.

### Key Capabilities

- ✅ Ingest contract text → extract & store charge terms in ontology
- ✅ Ingest structured invoices (JSON)
- ✅ Match invoice lines to contract terms via two-tier routing
- ✅ Run deterministic validators
- ✅ Return findings with full audit trail
- ⚠️ PDF parsing (for demo only; upstream responsibility in production)
- ⚠️ Text-to-JSON parsing (for demo only; upstream responsibility in production)
- ⚠️ Interactive workbench UI (for development; production UI in Phase 5)

### Target Outcomes

- Fast-path lines: < 500ms, no LLM, 100% deterministic
- Deep-path lines: 2–10s, LLM for ambiguity resolution only
- All findings traceable to specific validators and source evidence

---

## Domain Model & Ontology

### Design of the Logical Model

The reconciliation engine operates on a **logical domain model** that normalizes messy contract and invoice evidence into a stable, queryable graph representation. This model addresses two fundamental reconciliation questions:

1. **Is each invoice line billable under an active governing term?**
2. **Is the invoice total compliant after accepted lines, credits, taxes, pass-throughs, discounts, and timing rules are applied?**

**Key Insight — Contracts Are Hierarchical:** Contracts are not flat documents. A single vendor relationship often includes:
- **Master agreements** defining general terms and product/service tables
- **Amendments and change orders** that override earlier prices, add locations, or alter scopes
- **Statements of Work (SOWs)** binding scope, deliverables, and fees to the master agreement
- **Location-specific agreements** as separate documents under the same vendor relationship
- **Cover memos and signature summaries** providing business context (lower authority unless incorporated)

Each term carries **amendment provenance**: source document, effective period, precedence rank, and explicit links to superseded terms. This enables the engine to answer: *"Which term applies on 2026-03-15 for Facility X?"* through amendment precedence rules.

### Charge Term Taxonomy

Real-world vendor contracts exhibit diverse billing patterns. Analysis of the production corpus (94 files, 33 contracts) reveals distinct charge types:

| Charge Term | Corpus Evidence | Characteristics |
| --- | --- | --- |
| **FixedFeeTerm** | Reputation.com implementation | Single amount, no volume-based adjustment |
| **SubscriptionFeeTerm** | Perficient support retainer, NRC fees | Recurring fixed amount on cadence |
| **UsageFeeTerm** | Office supplies, transaction-based | Rate × quantity, measurement source from invoice or vendor report |
| **TieredUsageFeeTerm** | Experian transaction packages | Base fee + included quantity + overage rate |
| **ClaimsBasedSubscriptionTerm** | Experian price amendment | Monthly amount with volume adjustment (e.g., actual claims vs. baseline) |
| **PerLocationFeeTerm** | Quality Lawn maintenance, Johnson Controls | Different amount per facility or site |
| **EventFeeTerm** | Spring cleanup, inspection, repair call | Amount per occurrence; measurement from vendor report or invoice detail |
| **PassThroughFeeTerm** | Experian payer cost pass-throughs | Reimbursable costs + markup; requires backup invoices or receipts |
| **TaxTerm** | Tax-exempt contracts, sales tax verification | Jurisdiction-specific rules, exemption evidence requirements |
| **ContingencyFeeTerm** | HealthROI recovery consulting | Percentage of realized recovery; proof of realization required |
| **LateFeeTerm** | Quality Lawn payment terms | Fixed fee or interest after grace period |

### Amendment Precedence & Document Resolution

When reconciling an invoice line with service period 2026-03-15 to 2026-04-14:

1. **Identify candidate terms** for this vendor, service period, and facility
2. **Follow amendment chain:** If Term B amends Term A, and both overlap the service period, Term B takes precedence (higher authority)
3. **Apply effective date filtering:** Use the term whose effective date range contains the service period
4. **Resolve conflicts:** If two amendments both claim precedence, flag for manual review and cite source documents
5. **Calculate expected amount** from the selected term and invoice line quantity/UOM
6. **Cite evidence:** Record which source document and which amendment chain led to this decision

**Example:** Experian contract with base fee plus amendment

```
BASE TERM (MSA, effective 2025-01-01):
  "MCA Fee: $5,000/month"

AMENDMENT 1 (effective 2025-06-01, supersedes BASE):
  "MCA Fee: $6,000/month; Experian Health Billing Amendment, Section 2"
  
AMENDMENT 2 (effective 2026-01-01, supersedes AMENDMENT 1):
  "MCA Fee: $5,500/month + 3% annual inflation; Price Change Amendment, Schedule A"

For invoice dated 2026-03-15:
  → Service period: 2026-03-15 to 2026-04-14
  → Applicable term: AMENDMENT 2 ($5,500/month)
  → Audit trail: "DOC-PRICE-AMENDMENT-2026-01, Schedule A, effective 2026-01-01"
```

### Corpus Insights: Design Validation

The production corpus (94 files across 9 vendor categories) validates the ontology design:

- **33 contracts** processed, extracting charge terms and scope evidence
- **60 invoices** matched against contract terms
- **Signal coverage** across corpus:
  - 30 files with location evidence (per-site billing)
  - 25 files with pricing (multiple tier/rate/fee patterns)
  - 15 files with amendments (chain of precedence)
  - 10 files with subscription patterns
  - 11 files with tax-specific rules
  - 27 files with volume/usage evidence

**Key Design Implications:**
- The corpus contains service relationships whose billability depends on **more than a product SKU**: named sites, service periods, SOW scopes, amendments, subscriptions, transaction volumes, inspections, consulting reviews, and invoice-level tax and total rules all appear as **first-class evidence signals**.
- A useful logical model must represent **both contract hierarchy and invoice evidence**: master agreements, amendments, SOWs, cover memos, location-specific agreements, invoice headers, line items, service periods, quantities, rates, and totals.
- The same vendor **may need different reconciliation strategies by charge type**. Fixed recurring fees, per-location maintenance, transaction/usage fees, contingency-based consulting fees, and project SOW deliverables should not be flattened into one generic rule.
- The model must **preserve source provenance** because many compliance decisions rely on an exact clause, schedule row, amendment, or invoice field, not a broad summary.

### Ontology Representation

See [ONTOLOGY.md](ONTOLOGY.md) for complete entity model, RDF implementation details, and mermaid diagrams. The ontology includes:

- **Parties** (customers, vendors, affiliates, facilities)
- **VendorRelationships** and their governing documents
- **ContractDocuments** and **DocumentParts** (source of truth for every assertion)
- **GoverningTerms** (normalized from one or more document parts, with amendment chains)
- **ChargeTerms** (billable constructs with type taxonomy above)
- **ServiceOfferings** and **ServiceObligations** (what the vendor must do and where)
- **BillingSchedules** (when and how often to invoice)
- **MeasurementRules** (how to calculate what's due)
- **Invoices** and **InvoiceLines** (evidence to be reconciled)
- **ReconciliationCases** and **Findings** (results with audit trail)
- **EvidenceSpans** (source locators for every assertion)

All entities are persisted as **RDF triples** in the ontology graph, enabling:
- **Composability:** Multiple amendments exist as separate triples; no merge conflicts
- **Temporality:** SPARQL queries filter by effective dates and amendment precedence
- **Auditability:** Each triple includes source document, extraction method, and confidence
- **Portability:** Schema works on mock graph (MVP), StarDog (Phase 3+), or any SPARQL endpoint

---

## Architecture Diagram

```mermaid
flowchart TD
    subgraph CONTRACT["📄 Contract Ingestion"]
        C1["Ingest Contract Documents\n(PDF / Markdown / YAML)"]
        C2["Extract Text\n(OCR / Parser)"]
        C3["LLM Extraction Agent\n(charge terms, rates, scopes)"]
        C4["Detect Conflicts &\nDeduplicate Terms"]
        C5["Finalize Contract\n(sanity checks, RDF triples)"]
        C6[("Ontology Graph\n(vendor + charge terms)")]
        C7[("Fast-Path Cache\n(rule index)")]

        C1 --> C2 --> C3 --> C4 --> C5
        C5 -->|"persist triples"| C6
        C5 -->|"build index"| C7
    end

    subgraph INVOICE["🧾 Invoice Ingestion"]
        I1["Ingest Invoice Document\n(PDF / Markdown / YAML)"]
        I2["Extract Text\n(OCR / Parser)"]
        I3["Parse Invoice\n(header + line items)"]
        I4["Normalize Lines\n(amounts, UOM, dates)"]

        I1 --> I2 --> I3 --> I4
    end

    subgraph RECON["⚖️ Reconciliation Pipeline"]
        R1["Look Up Contract\n(by contract_id)"]
        R2["Verify Contract\nFinalized"]
        R3{{"For Each\nInvoice Line"}}

        subgraph MATCH["Matching & Routing"]
            M1{"Fast-Path\nCache Hit?"}
            M2["Fast-Path Match\n(< 500 ms, no LLM)"]
            M3["Deep-Path Match\n(graph query + semantic)"]
            M4{"Ambiguous\nCandidates?"}
            M5["LLM Ambiguity\nResolver"]
            M6{"Match\nFound?"}
        end

        subgraph VALIDATE["Validation"]
            V1["Run Deterministic\nValidators\n(amount, date, scope,\npreconditions, pass-through)"]
            V2["Generate Line Finding\n(PASS / REJECT /\nNEEDS_REVIEW)"]
        end

        V3["Generate Line Finding\n(NO_MATCH)"]

        R1 --> R2 --> R3
        R3 --> M1
        M1 -->|"hit & confidence > 0.95"| M2
        M1 -->|"miss or low confidence"| M3
        M2 --> V1
        M3 --> M4
        M4 -->|"yes"| M5
        M4 -->|"no"| M6
        M5 --> M6
        M6 -->|"matched"| V1
        M6 -->|"no match"| V3
        V1 --> V2
    end

    subgraph PROMOTE["🚀 Promotion Engine"]
        P1{"High Confidence\nDeep-Path Result?"}
        P2["Promote to\nFast-Path Cache"]
    end

    subgraph OUTPUT["📊 Findings & Output"]
        O1["Aggregate Line Findings\n(totals, variances)"]
        O2["Build Audit Trail\n(charge terms, provenance)"]
        O3["Invoice Finding\n(overall PASS / VARIANCE /\nNEEDS_REVIEW)"]
        O4["Reviewer Workflow\n(human-in-the-loop)"]
    end

    %% Cross-subgraph connections
    C6 -->|"term lookup"| R1
    C7 -->|"rule lookup"| M1
    I4 --> R3
    V2 --> P1
    V3 --> O1
    P1 -->|"yes"| P2
    P2 -->|"update cache"| C7
    P1 -->|"no"| O1
    V2 --> O1
    O1 --> O2 --> O3 --> O4

    style CONTRACT fill:#dbeafe,stroke:#3b82f6
    style INVOICE fill:#dcfce7,stroke:#22c55e
    style RECON fill:#fef9c3,stroke:#eab308
    style MATCH fill:#fef3c7,stroke:#f59e0b
    style VALIDATE fill:#fff7ed,stroke:#f97316
    style PROMOTE fill:#f3e8ff,stroke:#a855f7
    style OUTPUT fill:#fce7f3,stroke:#ec4899
```

---

## Core Design Principles

### 1. **Auditability First**
Every finding must trace back to:
- Which contract terms were considered
- Which validators ran and how they scored
- What evidence supported the decision
- The exact LLM prompts and responses (for deep-path decisions)

### 2. **Determinism for Validation**
All validation logic is hand-coded, deterministic pure functions:
- Same input → always same output
- No randomness, no extern calls except logging
- Easy to unit test, debug, and certify
- LLM is isolated to extraction and ambiguity resolution only

### 3. **Two-Tier Routing for Cost & Speed**
- **Fast path**: cached/exact matches + validators only (~70% of lines, < 500ms)
- **Deep path**: semantic matching + LLM ambiguity only (~30% of lines, 2–10s)
- Routing decision is explicit and can be audited

### 4. **Ontology-Backed Storage**
- All contract data stored as RDF triples
- Portable to StarDog or any SPARQL endpoint
- Each triple is an assertion with source and validity period
- Enables composing multiple contract documents without merge conflicts

### 5. **Progressive Optimization**
- Start with mock in-memory graph (MVP fast, portable)
- Cache fast-path decisions as confidence improves
- Eventually replace mock with StarDog for scale
- Metrics drive optimization; never guess at bottlenecks

---

## Component Architecture

### Root-Level Directories

```
PSPA-Rec/
├── api/                           # FastAPI endpoints
├── core/                          # Orchestration logic
├── graph/                         # RDF schema & repository
├── llm/                           # LLM integration
├── matching/                      # Term matching & routing
├── models/                        # Pydantic domain models
├── validators/                    # Deterministic validation
├── data_parsers/                  # Contract/invoice parsing
├── storage/                       # Fast-path cache
├── utils/                         # Config, logging, errors
├── tests/                         # Test suite (see below)
├── ui/                            # Streamlit workbench (test harness)
├── docs/                          # Documentation
│   ├── reconciliation-engine/
│   │   ├── active/                # Active approach docs & ADRs
│   │   └── domain-model/          # Domain definitions
│   └── history/                   # Historical approach docs
├── tools/                         # Utilities (corpus analysis, PDF sidecar gen)
├── main.py                        # FastAPI app entry point
├── requirements.txt               # Python dependencies
├── pyproject.toml                 # Build & test config
├── PRODUCT_REQUIREMENTS.md        # PRD
├── ARCHITECTURE.md                # This file
└── TECH_DEBT.md                   # Tech debt & prototype constraints
```

### Core Components

#### **api/** — HTTP Interfaces
- `contract_endpoints.py`: `POST /contracts/ingest`, `GET /contracts/{id}/status`, `DELETE /contracts/{id}`
- `invoice_endpoints.py`: `POST /reconcile` (canonical), `POST /reconcile-from-text` (legacy)
- `request_models.py`: Pydantic schemas for incoming requests
- `response_models.py`: Pydantic schemas for responses
- `dependencies.py`: FastAPI dependency injection (processor, cache, logger)

#### **core/** — Orchestration
- `contract_processor.py`: `ingest_contract()`, `finalize_contract()`, `get_contract_status()`
- `invoice_processor.py`: `process_invoice()` — main reconciliation loop
- `routing_engine.py`: Routing decision logic (fast vs. deep)
- `promotion_engine.py`: Fast-path cache update logic
- `finding_generator.py`: Assembles findings from validation results

#### **graph/** — RDF & Storage

Abstraction over graph backend:

- `graph_repository.py`: Abstract interface (insert, query, update, delete triples)
- `mock_graph.py`: In-memory implementation (rdflib-based)
- `stardog_adapter.py`: StarDog backend (deferred to Phase 3)
- `ontology_schema.py`: RDF class/property URIs (scb:ChargeTerm, scb:rate, etc.)
- `rdf_generator.py`: Convert domain models to RDF triples
- `prefixes.py`: Namespace prefixes and URI base

#### **llm/** — LLM Integration

- `llm_client.py`: Abstraction over LLM provider (Azure OpenAI, OpenAI, Anthropic)
- `contract_extraction_agent.py`: Extract charge terms from contract text
- `ambiguity_resolver_agent.py`: Resolve ambiguous line matches
- `prompts.py`: Prompt templates (extraction, ambiguity resolution)
- `stub_llm_client.py`: Deterministic stub for testing

#### **matching/** — Term Matching

- `matching_engine.py`: Main matching orchestrator
- `term_retriever.py`: Retrieve candidate charge terms from graph
- `similarity.py`: Scoring functions (text similarity, field alignment)

#### **validators/** — Deterministic Rules

- `orchestrator.py`: Runs all registered validators for a charge term type
- `arithmetic_validators.py`: Check amount calculations
- `temporal_validators.py`: Validate dates, effective periods
- `contingency_validators.py`: Check contingency conditions
- `precondition_validators.py`: Pre-flight checks (vendor active, location in scope)
- `pass_through_validators.py`: Verify supporting docs for pass-through charges
- `tax_validators.py`: Tax-specific rules
- `validator_registry.py`: ChargeType → validators mapping

#### **models/** — Domain Models

- `contract_models.py`: ChargeTerm, VendorRelationship, Amendment, etc.
- `invoice_models.py`: Invoice, InvoiceLine, SupportingDocRef
- `finding_models.py`: Finding, ValidationResult, RoutingDecision
- `routing_models.py`: MatchCandidate, MatchResult

#### **data_parsers/** — Input Parsing

- `data_directory.py`: Discover & list files from Data/ corpus
- `markdown_parser.py`: Parse markdown (contracts, invoices)
- `yaml_parser.py`: Parse YAML (contracts, invoices)
- `pdf_extractor.py`: Extract text from PDFs (uses PDF sidecar .txt if available)
- `sidecar_text.py`: Manage .txt sidecars from corpus workbench
- `invoice_parser.py`: Parse invoice markdown/YAML to Invoice objects
- `parser_registry.py`: Auto-detect file type and dispatch

#### **storage/** — Fast-Path Cache

- `fast_path_cache.py`: In-memory TTL cache of high-confidence matches
  - Key: (contract_id, description, quantity, unit)
  - Value: (charge_term_id, confidence, routing_path)
  - TTL: configurable (default 30 days)
  - Invalidation: entry expires or contract updated

#### **test/demo Harness** — `ui/` and `tests/`

**`ui/` — Streamlit Workbench** (test harness, not production)
- Interactive exploration and debugging
- Load contracts, view parsed terms, test matching
- Inspect findings and audit trails
- **Not intended for production user-facing workflows**
- Only for analyst debugging and demo

**`tests/` — Test Suite** (validation & development)
- Unit tests for each component
- Integration tests for contract → finding flow
- Fixtures for ABC Cleaning, GreenTech, and other test scenarios
- Smoke tests and e2e scenarios
- Pytest-based; run with `pytest`

---

## API Interfaces

### Contract Lifecycle

#### POST `/contracts/ingest`
Ingest a contract document and extract charge terms.

**Request:**
```json
{
  "metadata": {
    "vendor_id": "EHI-001",
    "vendor_name": "Experian Health Inc.",
    "contract_name": "2025 MSA + Amendment"
  },
  "documents": [
    {
      "filename": "base_contract.md",
      "text": "..."
    },
    {
      "filename": "amendment_1.md",
      "text": "..."
    }
  ]
}
```

**Response:**
```json
{
  "contract_id": "con_EHI001_20250101",
  "status": "finalized",
  "term_count": 12,
  "warnings": [
    "Amendment conflicts with base: rate effective date",
    "Line 3: manual review recommended"
  ]
}
```

**Status Codes:**
- `200`: Success, contract ingested and finalized
- `400`: Parse error; `reason` explains what failed
- `409`: Conflict during term deduplication; contract not finalized

---

#### GET `/contracts/{contract_id}/status`
Check contract status and term count.

**Response:**
```json
{
  "contract_id": "con_EHI001_20250101",
  "status": "finalized",
  "term_count": 12,
  "finalized_at": "2026-06-03T19:45:22Z"
}
```

---

#### DELETE `/contracts/{contract_id}`
Remove contract and invalidate fast-path cache entries.

**Response:** `204 No Content`

---

### Reconciliation

#### POST `/reconcile` (Canonical API)
Reconcile a structured invoice against a contract.

**Request:**
```json
{
  "contract_id": "con_EHI001_20250101",
  "invoice": {
    "vendor_id": "EHI-001",
    "invoice_number": "INV-20260531-001",
    "invoice_date": "2026-05-31",
    "lines": [
      {
        "line_number": 1,
        "description": "MCA Master Contract Fee May 2026",
        "quantity": 1.0,
        "unit": "MONTH",
        "rate": 5000.00,
        "amount": 5000.00,
        "supporting_docs": [
          {
            "doc_type": "MASTER_CONTRACT",
            "reference": "con_EHI001_20250101"
          }
        ]
      }
    ]
  }
}
```

**Response:**
```json
{
  "invoice_id": "inv_EHI001_202605_001",
  "contract_id": "con_EHI001_20250101",
  "overall_status": "PASS",
  "line_findings": [
    {
      "line_number": 1,
      "status": "PASS",
      "matched_term_id": "term_EHI001_mca_monthly",
      "routing_path": "FAST_PATH",
      "validators_run": [
        {
          "validator_name": "amount_match",
          "result": "PASS",
          "expected": 5000.00,
          "actual": 5000.00
        }
      ],
      "confidence": 0.98,
      "audit_trail": {
        "term_source": "base_contract.md line 5",
        "match_strategy": "exact_description_match",
        "promoted_at": "2026-05-15T08:30:00Z"
      }
    }
  ],
  "summary": {
    "total_amount": 5000.00,
    "passed_amount": 5000.00,
    "variance_amount": 0.0,
    "needs_review_count": 0
  }
}
```

**Status Codes:**
- `200`: Reconciliation complete (may include NEEDS_REVIEW lines)
- `400`: Invalid invoice structure
- `404`: Contract not found
- `409`: Contract not finalized

---

#### POST `/reconcile-from-text` (Legacy Adapter)
Raw-text invoice ingestion (for backward compatibility).

**Request:**
```json
{
  "contract_id": "con_EHI001_20250101",
  "invoice_text": "..."
}
```

**Response:** Same as `/reconcile`

**Note:** This endpoint parses the raw text to structured Invoice before calling the canonical pipeline. Use `/reconcile` for new integrations.

---

## Data Flow

### Contract Ingestion Flow

```
1. Receive contract text(s)
2. Parse markdown/YAML → ContractDocument objects
3. Extract charge terms via LLM extraction agent
4. Normalize each term (effective dates, locations, UOM)
5. Detect conflicts & duplicates (manual review if needed)
6. Finalize: convert to RDF triples, persist to graph, build fast-path index
7. Return contract_id and warnings
```

### Invoice Reconciliation Flow

```
For each invoice line:
  1. Normalize description, quantity, rate
  2. Query graph for contract terms by category
  3. Routing decision:
     a. If fast-path cache hit + confidence > 0.95 → FAST_PATH
     b. Else → DEEP_PATH
  4. If FAST_PATH:
     - Run validators against cached charge term
  5. If DEEP_PATH:
     - Semantic match against graph (similarity scores)
     - If ambiguous (multiple candidates): call LLM ambiguity resolver
     - If still no match: NO_MATCH finding
     - If matched: check if high confidence for fast-path promotion
     - Run validators against matched charge term
  6. Validators emit ValidationResult (PASS/FAIL/WARN)
  7. Aggregate into Finding (status, audit trail, routing path)
  
After all lines:
  8. Aggregate line findings into invoice Finding
  9. Compute overall status (PASS, VARIANCE, NEEDS_REVIEW)
  10. Return invoice finding with audit trail
```

---

## Key Decisions (ADRs)

### ADR-001: RDF Triples as Canonical Storage
**Status:** Accepted

All contract data stored as RDF triples for auditability and portability to StarDog. See [ADRs in active/architecture/ADR.md](docs/reconciliation-engine/active/architecture/ADR.md) for full details.

### ADR-002: Two-Tier Routing (Fast vs. Deep)
**Status:** Accepted

Routing is explicit and auditable. Fast-path routes high-confidence matches with no LLM; deep-path uses LLM only for ambiguity resolution.

### ADR-003: Validators Are Deterministic Functions
**Status:** Accepted

All validation is hand-coded, deterministic, and non-probabilistic. LLM never participates in validation decisions.

### ADR-004: Mock Graph for MVP
**Status:** Accepted (temporary)

MVP uses in-memory RDF graph (rdflib) for speed and portability. StarDog integration deferred to Phase 3.

---

## Tech Debt & Prototype Constraints

See [TECH_DEBT.md](TECH_DEBT.md) for detailed discussion of:
- Prototype vs. production code boundaries
- Known limitations and deferred work
- Recommendations for productionization
- Performance and scalability notes

### Summary of Prototype Constraints

| Area | Constraint | Impact | Planned Fix |
|------|-----------|--------|------------|
| LLM Provider | Azure OpenAI via APIM only (MVP) | No multi-provider support | ADR-020: LLM provider abstraction (Phase 2) |
| Graph Backend | Mock (in-memory); single-threaded | Can't handle > 10K terms or concurrent writes | ADR-019: StarDog backend (Phase 3) |
| Cache Invalidation | TTL-only; no event-based invalidation | Stale cache possible if contract updated | Stream-based invalidation (Phase 3) |
| Validation Rules | Hand-coded; no DSL or rule engine | Adding new validators requires code change | DSL or visual rule engine (Phase 4) |
| Audit Trail | Minimal; LLM responses not persisted | Hard to debug LLM decisions later | Audit log storage (Phase 2) |
| Workbench UI | Streamlit (dev-only); not intended for production | Not suitable for analyst workflows | React SPA (Phase 5) |

---

## Testing Strategy

- **Unit tests** (`tests/test_*.py`): Isolated component tests; use mocks/stubs
- **Integration tests** (`tests/test_e2e*.py`): Full contract → finding flow with fixtures
- **Fixtures** (`tests/fixtures/`): ABC Cleaning, GreenTech, other scenarios
- **Live tests** (`@pytest.mark.live`): Hit real LLM; skip in CI
- **Smoke tests** (`tests/test_smoke.py`): Quick sanity checks before deploy

Run tests with:
```bash
pytest                       # All except @live
pytest -m live -xvs         # Only @live tests (requires API keys)
pytest tests/test_*.py -xvs  # Specific test file
```

---

## Deployment & Operations

See `docs/reconciliation-engine/active/releases/PHASE_8_COMPLETION.md` for deployment readiness checklist.

Short version:
1. Python 3.9+, FastAPI 0.100+
2. Set `.env` with LLM provider credentials (Azure APIM recommended)
3. `pip install -r requirements.txt`
4. `uvicorn main:app --host 0.0.0.0 --port 8000`
5. Health check: `curl http://localhost:8000/health`

---

## References

- ADRs: [docs/reconciliation-engine/active/architecture/ADR.md](docs/reconciliation-engine/active/architecture/ADR.md)
- Implementation Plan: [docs/reconciliation-engine/active/architecture/plan.md](docs/reconciliation-engine/active/architecture/plan.md)
- Domain Model: [docs/reconciliation-engine/active/domain/DATA_MODEL.md](docs/reconciliation-engine/active/domain/DATA_MODEL.md)
- Tech Debt: [TECH_DEBT.md](TECH_DEBT.md)
