# Service Contract Billing Ontology

## Ontology Overview

The PSPA Reconciliation Engine uses an **RDF-based ontology** to represent the domain model as interconnected assertions (triples). This enables:

- **Flexible composition** of multiple contract documents without merge conflicts
- **Temporal reasoning** about effective dates and amendment precedence
- **Portable storage** to any SPARQL endpoint (mock graph, StarDog, etc.)
- **Audit trail** linking every finding to source RDF triples

## Core Entity Relationships

```mermaid
erDiagram
    PARTY ||--o{ VENDOR_RELATIONSHIP : "participates-in"
    VENDOR_RELATIONSHIP ||--o{ CONTRACT_DOCUMENT : "governed-by"
    VENDOR_RELATIONSHIP ||--o{ FACILITY_LOCATION : "operates-at"
    CONTRACT_DOCUMENT ||--o{ DOCUMENT_PART : "contains"
    DOCUMENT_PART ||--o{ GOVERNING_TERM : "defines"
    GOVERNING_TERM ||--o{ CHARGE_TERM : "establishes"
    GOVERNING_TERM ||--|| GOVERNING_TERM : "amended-by"
    CHARGE_TERM ||--o{ BILLING_SCHEDULE : "has"
    CHARGE_TERM ||--o{ MEASUREMENT_RULE : "requires"
    SERVICE_OFFERING ||--o{ SERVICE_OBLIGATION : "includes"
    GOVERNING_TERM ||--o{ SERVICE_OFFERING : "scopes"
    BILLING_SCHEDULE ||--o{ SERVICE_OBLIGATION : "triggers"
    INVOICE ||--o{ INVOICE_LINE : "contains"
    INVOICE_LINE ||--o{ CHARGE_TERM : "claims-against"
    RECONCILIATION_CASE ||--o{ INVOICE : "evaluates"
    RECONCILIATION_CASE ||--o{ FINDING : "produces"
    GOVERNING_TERM ||--o{ FINDING : "supports"
    FINDING ||--o{ EVIDENCE_SPAN : "cites"
```

## Entity Definitions

### Party

A customer, vendor, affiliate, billing entity, remittance entity, or facility owner.

**Key Attributes:**
- `party_id` — Unique identifier (e.g., "VENDOR-EHI-001")
- `party_name` — Legal name
- `party_type` — CUSTOMER | VENDOR | AFFILIATE | BILLING_ENTITY | REMITTANCE_ENTITY | FACILITY_OWNER
- `active` — Boolean; true if party can engage in new contracts

### VendorRelationship

The durable commercial relationship between a customer and vendor.

**Key Attributes:**
- `relationship_id` — Unique identifier (e.g., "REL-CUST123-VENDOR-EHI-001")
- `customer_party_id` — Reference to customer Party
- `vendor_party_id` — Reference to vendor Party
- `effective_start` — Date relationship began
- `effective_end` — Date relationship ended (null if ongoing)
- `status` — ACTIVE | INACTIVE | UNDER_REVIEW

### ContractDocument

A master agreement, SOW, amendment, addendum, change order, LOA, renewal, cover memo, quote, or service agreement.

**Key Attributes:**
- `document_id` — Unique identifier (e.g., "DOC-EHI-MSA-2025")
- `document_type` — MASTER_AGREEMENT | SOW | AMENDMENT | ADDENDUM | CHANGE_ORDER | LOA | RENEWAL | COVER_MEMO | QUOTE | SERVICE_AGREEMENT
- `vendor_relationship_id` — Reference to VendorRelationship
- `executed_date` — Date document was signed
- `effective_date` — Date terms become active
- `expiration_date` — Date terms end
- `precedence_rank` — Integer; lower = higher authority (used for amendment conflicts)
- `source_path` — File path or document identifier in corpus
- `extracted_text` — Raw or OCR'd text content

### DocumentPart

A clause, exhibit, schedule row, price table, equipment list, signature block, or administrative memo section.

**Key Attributes:**
- `part_id` — Unique identifier (e.g., "PART-DOC-EHI-MSA-2025-exhibit-a-row-3")
- `document_id` — Reference to ContractDocument
- `part_type` — CLAUSE | EXHIBIT | SCHEDULE | PRICE_TABLE | EQUIPMENT_LIST | SIGNATURE_BLOCK | MEMO_SECTION | ROW
- `section_number` — (e.g., "3.2.1")
- `page_number` — Page in source document
- `text` — Extracted text of this part
- `confidence` — Extraction confidence (0.0–1.0)

### GoverningTerm

A normalized term extracted from one or more DocumentParts, representing a single obligation or right.

**Key Attributes:**
- `term_id` — Unique identifier (e.g., "TERM-EHI-MCA-MONTHLY-5K")
- `vendor_relationship_id` — Reference to VendorRelationship
- `source_parts` — References to DocumentParts that define this term
- `term_type` — CHARGE_OBLIGATION | SERVICE_OBLIGATION | PAYMENT_TERM | CONFIDENTIALITY | LIABILITY | etc.
- `effective_start` — When this term becomes active
- `effective_end` — When this term expires
- `location_scope` — List of FacilityLocations this term applies to (null = all)
- `service_scope` — List of ServiceOfferings (null = all)
- `precedence_rank` — For amendments; lower = higher authority
- `amended_by_term_id` — Reference to GoverningTerm that supersedes this (null if not amended)
- `extracted_with_confidence` — LLM extraction confidence
- `requires_manual_review` — Boolean; true if conflicts or ambiguities detected

### ChargeTerm

A billable pricing construct (FixedFee, UsageFee, SubscriptionFee, etc.).

**Key Attributes:**
- `charge_term_id` — Unique identifier (e.g., "CHARGE-EHI-MCA-MONTHLY-5K")
- `governing_term_id` — Reference to GoverningTerm
- `charge_type` — FIXED_FEE | SUBSCRIPTION_FEE | USAGE_FEE | TIERED_USAGE | CLAIMS_BASED_SUBSCRIPTION | PER_LOCATION_FEE | EVENT_FEE | TIME_MATERIALS | PASS_THROUGH_FEE | TAX_TERM | CONTINGENCY_FEE | LATE_FEE | REPORTED_USAGE
- `amount` — Fixed amount (for FIXED_FEE, SUBSCRIPTION_FEE, PER_LOCATION_FEE)
- `unit_rate` — (for USAGE_FEE, EVENT_FEE)
- `unit` — (e.g., "PER_MONTH", "PER_TRANSACTION", "PER_LOCATION", "PER_EVENT")
- `included_quantity` — (for TIERED_USAGE; maximum included in base fee)
- `overage_rate` — (for TIERED_USAGE; rate above included quantity)
- `currency` — (e.g., "USD")
- `measurement_rule_id` — Reference to MeasurementRule
- `billing_schedule_id` — Reference to BillingSchedule

### ServiceOffering

The contracted product/service family (eligibility verification, landscaping, inspection, market insights, recovery consulting).

**Key Attributes:**
- `offering_id` — Unique identifier (e.g., "SVC-EXPERIAN-EHI-TRANSACTIONS")
- `vendor_relationship_id` — Reference to VendorRelationship
- `offering_name` — (e.g., "Eligibility Verification", "Landscaping Maintenance")
- `description` — Service description
- `product_codes` — List of SKUs or product identifiers for this offering

### ServiceObligation

What the vendor must do, where, when, and with what acceptance or evidence requirements.

**Key Attributes:**
- `obligation_id` — Unique identifier (e.g., "OBL-EHI-TRANSACTIONS-MONTHLY-REPORT")
- `service_offering_id` — Reference to ServiceOffering
- `obligation_type` — DELIVERY | REPORTING | ACCEPTANCE | EVIDENCE | DOCUMENTATION | REMEDIATION
- `description` — (e.g., "Monthly eligibility transactions with daily edge updates")
- `location_id` — Reference to FacilityLocation (null = applies to all)
- `service_period` — (e.g., "CALENDARMONTH", "FISCALYEAR")
- `acceptance_criteria` — (e.g., "Report delivered by 5th business day of following month")
- `evidence_required` — Boolean; if true, supporting documentation is required for billing

### BillingSchedule

When a charge may be invoiced and for what service period.

**Key Attributes:**
- `schedule_id` — Unique identifier (e.g., "SCHED-EHI-MONTHLY")
- `charge_term_id` — Reference to ChargeTerm
- `cadence` — MONTHLY | QUARTERLY | ANNUAL | ON_DEMAND | PER_EVENT
- `anchor_date` — Reference date for alignment (e.g., contract start, calendar month start)
- `invoice_lag_days` — Days after service period close before invoicing is permitted
- `grace_period_days` — Days after invoice due date before late fees apply

### MeasurementRule

Usage, claim volume, license count, bed count, recovery amount, inspection event, or service occurrence.

**Key Attributes:**
- `rule_id` — Unique identifier (e.g., "MEAS-EHI-MONTHLY-TRANSACTIONS")
- `charge_term_id` — Reference to ChargeTerm
- `measurement_type` — TRANSACTION_COUNT | CLAIM_VOLUME | LICENSE_COUNT | BED_COUNT | RECOVERY_AMOUNT | INSPECTION_EVENT | SERVICE_OCCURRENCE | HOURS_WORKED | UNITS_DELIVERED
- `source` — (e.g., "VENDOR_REPORT", "INVOICE_DETAIL", "INVOICE_TOTAL_ROW")
- `unit_of_measure` — (e.g., "TRANSACTION", "CLAIM", "LICENSE", "BED", "DOLLAR", "EVENT", "HOUR")
- `validation_rule` — (e.g., "must be positive integer", "must match prior month ±5%")

### Invoice

Header-level invoice evidence: number, date, due date, vendor account, bill-to, remit-to, totals, taxes, credits, and terms.

**Key Attributes:**
- `invoice_id` — Unique identifier (e.g., "INV-EHI-20260531-001")
- `vendor_relationship_id` — Reference to VendorRelationship
- `invoice_number` — Original invoice number from vendor
- `invoice_date` — Date invoice was issued
- `due_date` — Date payment is due
- `vendor_account` — Vendor's account identifier for this customer
- `bill_to_party_id` — Reference to Party (billing entity)
- `remit_to_party_id` — Reference to Party (remittance entity)
- `service_period_start` — Start of service period covered
- `service_period_end` — End of service period covered
- `subtotal` — Sum of line amounts before taxes and credits
- `tax_amount` — Total tax
- `credit_amount` — Total credits
- `total_amount` — Final invoice total
- `currency` — (e.g., "USD")
- `source_path` — File path to source invoice
- `extracted_text` — Raw or OCR'd text

### InvoiceLine

Line-level evidence: description, quantity, UOM, unit rate, amount, service period, facility, product code, and source span.

**Key Attributes:**
- `line_id` — Unique identifier (e.g., "INV-EHI-20260531-001-LINE-1")
- `invoice_id` — Reference to Invoice
- `line_number` — Line sequence (1, 2, 3, ...)
- `description` — Line item description
- `quantity` — Quantity of units
- `unit` — (e.g., "MONTH", "TRANSACTION", "LOCATION")
- `unit_rate` — Price per unit
- `amount` — Calculated or stated amount
- `service_period_start` — Start of service covered by this line
- `service_period_end` — End of service covered by this line
- `facility_id` — Reference to FacilityLocation (null if not facility-specific)
- `product_code` — SKU or product identifier
- `source_span` — (e.g., "page 2, row 5") locating this line in source document

### FacilityLocation

A site, hospital, clinic, campus, service area, or market to which terms apply.

**Key Attributes:**
- `location_id` — Unique identifier (e.g., "FAC-UHS-CHENANGO-MEMORIAL")
- `vendor_relationship_id` — Reference to VendorRelationship (null if used across relationships)
- `location_name` — (e.g., "Chenango Memorial Hospital")
- `location_type` — HOSPITAL | CLINIC | CAMPUS | SERVICE_AREA | MARKET | OTHER
- `address` — (if known)
- `region` — Geographic region or operational area
- `active` — Boolean; true if location is in scope

### ReconciliationCase

The evaluation record connecting an invoice to candidate contract terms and final findings.

**Key Attributes:**
- `case_id` — Unique identifier (e.g., "RECON-INV-EHI-20260531-001")
- `invoice_id` — Reference to Invoice
- `contract_id` / `vendor_relationship_id` — Reference to contract/relationship
- `routing_decision` — FAST_PATH | DEEP_PATH | HUMAN_REVIEW
- `started_at` — Timestamp when reconciliation began
- `completed_at` — Timestamp when reconciliation completed
- `overall_status` — PASS | VARIANCE | NEEDS_REVIEW | REJECT

### Finding

A compliant, non-compliant, ambiguous, or not-enough-evidence decision with provenance and expected vs. actual math.

**Key Attributes:**
- `finding_id` — Unique identifier (e.g., "FIND-INV-EHI-20260531-001-LINE-1")
- `reconciliation_case_id` — Reference to ReconciliationCase
- `line_id` — Reference to InvoiceLine (or null for invoice-level findings)
- `status` — PASS | VARIANCE | NEEDS_REVIEW | REJECT | NO_MATCH
- `matched_charge_term_id` — Reference to ChargeTerm (null if no match)
- `matched_governing_term_id` — Reference to GoverningTerm (null if no match)
- `routing_path` — FAST_PATH | DEEP_PATH | LLM_AMBIGUITY_RESOLUTION | UNMATCHED
- `confidence` — Confidence score (0.0–1.0)
- `expected_amount` — Calculated amount per contract
- `actual_amount` — Amount on invoice line or invoice total
- `variance_amount` — actual_amount - expected_amount
- `variance_percent` — (actual_amount - expected_amount) / expected_amount
- `recommendation` — "APPROVE" | "HOLD_FOR_REVIEW" | "REJECT"
- `audit_trail` — Structured log of all validators run and their decisions
- `evidence_citations` — References to EvidenceSpans and supporting DocumentParts

### EvidenceSpan

A locator for evidence supporting a finding.

**Key Attributes:**
- `span_id` — Unique identifier
- `finding_id` — Reference to Finding
- `source_document_id` — Reference to ContractDocument or Invoice
- `source_part_id` — Reference to DocumentPart (if applicable)
- `span_type` — CLAUSE | SCHEDULE | PRICE_TABLE | AMENDMENT | INVOICE_HEADER | INVOICE_LINE
- `page_number` — Page in source
- `text_excerpt` — Quoted text from source
- `confidence` — Extraction confidence

## Amendment & Precedence Logic

GoverningTerms form a directed acyclic graph (DAG) through amendment relationships:

```
GoverningTerm(CHARGE-A, "Original fee $5K/month, eff. 2025-01-01")
  ↓ amended_by
GoverningTerm(CHARGE-B, "Amendment: fee now $6K/month, eff. 2025-06-01")
  ↓ amended_by
GoverningTerm(CHARGE-C, "Amendment: fee now $5.5K/month + 3% inflation, eff. 2026-01-01")
```

When resolving an invoice line with service period 2026-03-15 to 2026-04-14:
1. Query all GoverningTerms for the vendor relationship
2. Filter by effective date overlap with service period
3. Check amendment chain: if CHARGE-C amended CHARGE-B, use CHARGE-C (higher precedence)
4. Apply CHARGE-C rate to calculate expected amount
5. Compare expected vs. actual invoice line amount

## RDF Implementation (Graph Backend)

In the mock graph (rdflib) and StarDog backend, entities are stored as RDF triples:

**Example:** $5K/month MCA fee for Experian Health

```turtle
@prefix scb: <http://vizientinc.com/ontology/service-contract-billing/> .
@prefix ex: <http://example.org/> .

ex:CHARGE-EHI-MCA-MONTHLY-5K
  a scb:ChargeTerm ;
  scb:charge_type scb:SUBSCRIPTION_FEE ;
  scb:amount "5000.00"^^xsd:decimal ;
  scb:unit scb:MONTH ;
  scb:currency "USD" ;
  scb:governed_by ex:TERM-EHI-MCA-MONTHLY-5K ;
  scb:effective_start "2025-01-01"^^xsd:date ;
  scb:effective_end "2026-12-31"^^xsd:date .

ex:TERM-EHI-MCA-MONTHLY-5K
  a scb:GoverningTerm ;
  scb:source_document ex:DOC-EHI-MSA-2025 ;
  scb:vendor_relationship ex:REL-CUST123-VENDOR-EHI-001 ;
  scb:service_scope ex:SVC-EXPERIAN-EHI-TRANSACTIONS ;
  scb:precedence_rank "1"^^xsd:integer .
```

**Advantages:**
- **Composability:** Multiple amendments are separate triples; no merge conflicts
- **Temporality:** SPARQL queries can filter by effective dates
- **Auditability:** Each triple includes provenance (source_document, extracted_at, confidence)
- **Portability:** Same schema works on mock graph, StarDog, etc.
