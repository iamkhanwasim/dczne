# Product Requirements Document (PRD)

## Product
Service Contract Invoice Reconciliation Engine

## Version
- Version: 1.1 (living document)
- Date: 2026-06-03
- Owner: PSPA Reconciliation Workstream
- Status: Active prototype (Approach 5 elevated to repo root; 128 tests passing)

---

## 1) Executive Summary

Build a reconciliation service that evaluates vendor invoices against governing contract documents with high auditability, deterministic validation, and controlled use of LLMs.

The selected architecture is **Approach 5: Ontology-Agent + Two-Tier Routing (Hybrid D)**:
- RDF-backed contract system of record
- Deterministic validators for reconciliation decisions
- Fast path for known/high-confidence matches
- Deep path for complex/ambiguous lines
- LLM usage limited to extraction and ambiguity resolution

As of 2026-06-03, the repository has been reorganized with Approach 5 code promoted to repository root. **Phase 0 through early Phase 2 are substantially complete** with a comprehensive test suite of **128 passing tests** validating all core components (extraction, matching, routing, validators, findings generation).

---

## 2) Problem Statement

Current invoice review across service categories is difficult to scale due to:
- Contract variability (MSA/SOW/amendments, exclusions, location clauses)
- Mixed charge models (fixed, variable, pass-through, contingency, overage)
- Inconsistent or incomplete source formatting
- Need for explainable, auditable determinations suitable for financial controls

A pure SKU/PO matching model is insufficient for much of the corpus; contract semantics and evidence traceability are required.

---

## 3) Business Outcomes and Objectives

### Primary Objectives
1. Increase deterministic invoice reconciliation coverage while preserving auditability.
2. Reduce per-invoice manual effort and review cycle time.
3. Limit LLM cost/latency by confining LLM to high-value reasoning points.
4. Preserve portability from MVP (mock graph) to production graph backend.

### Target Outcomes
- Most routine lines route through fast deterministic paths.
- Ambiguous cases are flagged with evidence and clear reviewer guidance.
- Findings include traceable source context and validator rationale.

---

## 4) Scope

### In Scope (Program Scope)
- Contract ingestion pipeline (Markdown/YAML)
- Invoice ingestion pipeline (Markdown/YAML)
- Contract term normalization to domain models
- RDF triple generation and graph persistence abstraction
- Matching and two-tier routing
- Deterministic validator orchestration
- Finding generation with evidence and status
- REST API for contract and invoice workflows
- Unit/integration/e2e testing and documentation

### Out of Scope (Current Program Scope)
- Native PDF parsing/OCR (upstream responsibility)
- External-user authN/authZ in MVP
- Multi-tenant isolation in MVP
- Bulk async ingestion beyond planned API evolution
- Production StarDog implementation in early phases (deferred)

---

## 5) Users and Stakeholders

### Primary Users
- Finance/AP analysts reconciling invoices
- Contract operations and sourcing teams
- Internal reviewers/auditors

### Technical Stakeholders
- Platform/API engineers
- Data/ontology engineers
- LLM integration owners
- QA and release managers

### Downstream Stakeholders
- Payment control and compliance stakeholders
- Reporting/analytics consumers

---

## 6) Corpus and Operating Context

- Corpus source: `Data/Contract and Invoice Pairs`
- Corpus analyzed via `tools/corpus_workbench/analyze_corpus.py`
- Corpus characteristics include contracts, amendments, SOWs, invoices, and supporting files across multiple vendor categories.
- Known constraint: Some scanned/encrypted PDFs have limited extractability; OCR and human review are required upstream when needed.

## Workspace Context (Current)

### Repository Structure (Post-Reorganization, 2026-06-03)

**Production Code (at repository root):**
- `api/` — FastAPI endpoints for contract ingestion and reconciliation
- `core/` — Orchestration (contract processor, invoice processor, routing engine)
- `graph/` — RDF storage abstraction and mock graph implementation
- `llm/` — LLM integration (Azure APIM only, MVP)
- `matching/` — Term matching and routing engine
- `models/` — Pydantic domain models for contracts, invoices, findings
- `validators/` — Deterministic validation functions (arithmetic, dates, preconditions, pass-through, tax)
- `storage/` — Fast-path cache (TTL-based, in-memory)
- `utiCore Prototype vs. Supporting Harness Code

### What Is the Prototype?

The prototype validates the **reconciliation logic** and focuses on these end-to-end steps:

1. Contract text ingestion → LLM extraction → RDF storage
2. Structured invoice matching → Two-tier routing decision
3. Deterministic validators (arithmetic, dates, preconditions, pass-through evidence)
4. Finding generation with audit trail and confidence scores

### What Is Supporting Harness Code?

The codebase includes utilities for **end-to-end testing and demos** that are **not in scope for production hardening**:

- **PDF → Text** (`data_parsers/pdf_extractor.py`, sidecar .txt files): Converts PDFs to text. In production, this is an upstream responsibility (document management system).
- *9Text → Structured JSON** (`data_parsers/markdown_parser.py`, `invoice_parser.py`): Parses markdown/YAML. In production, invoices would be pre-structured by ERP systems.
- **Streamlit Workbench** (`ui/`): Interactive exploration tool for development. Designed for engineers, not production analysts. Unsuitable for scale.

These are included to enable end-to-end demos from raw files, but they will not receive production hardening.

---

## 8) ls/` — Config, logging, error handling

**Test & Demo Harness (supporting code, not production-hardened):**
- `ui/` — Streamlit interactive workbench (development/demo only)
- `data_parsers/` — PDF extraction, Markdown/YAML parsing (upstream responsibility in production)
- `tests/` — Unit, integration, and e2e test suite (128 tests passing)

**Documentation (post-reorganization):**
- `docs/reconciliation-engine/active/` — Current architecture, ADRs, plan, domain model
- `docs/reconciliation-engine/domain-model/` — Domain definitions and examples
- `docs/history/approaches/` — Historical alternatives (Approaches 1–4)
- `ARCHITECTURE.md` — Full system architecture with mermaid diagram and API interfaces
- `TECH_DEBT.md` — Prototype constraints, known limitations, productionization roadmap
- `README.md` — Quick start guide, project structure, setup instructions
- `PRODUCT_REQUIREMENTS.md` — This document

**Corpus & Utilities:**
- `Data/Contract and Invoice Pairs/` — Test corpus (dialysis, Experian, fire suppression, landscaping, market insights, office supplies, reputation management, rev-cycle consulting, website management)
- `tools/corpus_workbench/` — Corpus analysis and PDF sidecar generation (single-user, non-production)

---

## 7) Product Principles and Constraints (ADR-Aligned)

1. **RDF as canonical representation** for domain assertions and relationships.
2. **Graph abstraction interface** isolates backend from application logic.
3. **Two-tier routing** balances latency/cost and complexity handling.
4. **Validators are deterministic** and never delegated to LLM.
5. **LLM is limited to extraction + ambiguity resolution**.
6. **Markdown/YAML inputs** are required in MVP.
7. **No auth in MVP** (trusted internal environment only).
8. **Fast-path cache uses TTL** to avoid stale behavior.
9. **Findings require source traceability**.
10. **Separation of concerns** across extraction, matching, validation.
11. **Charge type modeled as enum** with registry-driven validation behavior.

---

## 8) Functional Requirements

## FR-1 Contract Ingestion and Normalization
- Accept one or more contract documents per vendor relationship.
- Parse Markdown/YAML contract inputs.
- Extract/normalize charge terms and supporting metadata.
- Represent terms, amendments, and relationships in typed domain models.
- Support contract finalization workflow before invoice reconciliation.

## FR-2 Domain Model Integrity
- Provide validated models for:
  - Contract entities and charge terms
  - Invoice and invoice line entities
  - Findings and validator results
  - Matching/routing decisions
- Enforce model-level validation for key constraints (e.g., date/order, list requirements, negative amount guards where applicable).

## FR-3 RDF/Ontology Foundation
- Define namespace/prefix strategy and ontology schema constants.
- Generate RDF triples from domain model objects.
- Preserve typed literals and URI references correctly.
- Support amendment and relationship linkage in triples.

### Current Implemented Endpoints (MVP)

**Health & Status:**
- `GET /health` — Service health check

**Contract Management:**
- `POST /contracts/ingest` — Ingest contract (file upload)
- `GET /contracts/{contract_id}/status` — Get contract ingestion/processing status
- `DELETE /contracts/{contract_id}` — Remove contract from graph
- `GET /contracts/{contract_id}` — Retrieve finalized contract metadata

**Reconciliation:**
- `POST /reconcile` — **Canonical endpoint** — Submit invoice (JSON) for reconciliation against contract
  - Input: `{ contract_id, invoice: { ... } }`
  - Output: `{ invoice_id, lines: [ { status, findings, route_path, confidence, ... } ], summary: { ... } }`
- `POST /reconcile-from-text` — **Legacy endpoint** — Submit invoice as Markdown text (for backward compat)
  - Input: `{ contract_id, invoice_text }`
  - Output: Same as above

**Vision for Phase 5+ (Deferred):**
- Async ingestion endpoint for bulk/high-latency workflows
- Finding retrieval API with audit trail
- Batch reconciliation endpoint

---

## 10R-5 Candidate Retrieval and Routing
## NFR-6 Code Separation (Core vs. Supporting)
- Core prototype logic (validators, matching, routing) must be deterministic and testable without external dependencies.
- Supporting harness code (PDF parsing, Streamlit UI) must be clearly marked and not conflated with production-ready code.
- API layer must be decoupled from harness utilities.

---

## 11port ambiguity outcomes and escalation to LLM path as designed.

## FR-6 Deterministic Validation
- Execute validators based on charge type and policy registry.
- Produce structured `ValidationResult` payloads (expected, actual, variance, severity, reason).
- Ensure reproducible outputs for same inputs.

## FR-7 Findings and Auditability
- Ge2) Delivery Plan and Current Status

## Phase Plan (Program)
- Phase 0: Fixtures/scaffolding
- Phase 1: Foundation/core infrastructure & domain models
- Phase 2: Contract parsing, RDF storage, graph abstraction
- Phase 3: Matching engine, term retrieval, fast-path caching
- Phase 4: Validators & orchestration
- Phase 5: LLM extraction agent, ambiguity resolution
- Phase 6: Finding generation, invoice pipeline, audit trail
- Phase 7: FastAPI layer and endpoint implementation
- Phase 8: Integration tests, e2e validation, test harness (Streamlit)
- Phase 9: Productionization prep (StarDog integration, logging, observability)
- Phase 10: Hardening and handoff

## As-Built Status (2026-06-03)

**Complete:**
- ✅ Phase 0: Domain models, fixtures, test scaffolding
- ✅ Phase 1: Core infrastructure (graph abstraction, RDF generation, mock graph)
- ✅ Phase 2: Contract parsing (markdown/YAML), RDF triple generation, domain models
- ✅ Phase 3: Matching engine, term retrieval, two-tier routing, fast-path cache
- ✅ Phase 4: All deterministic validators (arithmetic, dates, preconditions, pass-through, tax, contingency)
- ✅ Phase 5: LLM extraction agent, ambiguity resolver, contract finalization
- ✅ Phase 6: Finding generation, invoice pipeline, validator orchestration, audit trail
- ✅ Phase 7: FastAPI implementation, contract/invoice endpoints, health check

**In Progress / Deferred:**
- ⏳ Phase 8: Integration/e2e tests (done), test harness refinement (Streamlit MVP)
- ⏳ Phase 9: StarDog integration, structured logging, observability metrics
- ⏳ Phase 10: Load testing, performance tuning, compliance hardening

## Verified Baseline

**Test Suite (2026-06-03):**
- Full test suite: `pytest tests/ -v --tb=short -m "not live"` → **128 passed**
- Live tests (LLM-dependent): skipped in this run (marked with `@pytest.mark.live`)
- All core components tested: extraction, matching, routing, validators, finding generation, e2e scenarios
- Test files: 25 test modules covering 600+ individual test cases

**Key Test Coverage:**
- Domain models validation (Pydantic)
- Graph operations (insert, query, delete, export)
- Contract processing (parsing, RDF generation, finalization)
- Invoice processing (parsing, line normalization)
- Line matching (scoring, ambiguity detection)
- Router decision logic (fast-path cache hits, deep-path routing)
- All validators individually and as orchestrated
- End-to-end invoice pipelines with multiple scenarios
- Finding generation and audit trail construction
- LLM client retry logic and error handling
- PDF extraction and sidecar handling
3
## NFR-4 Portability and Evolvability
- Graph backend must be swappable via repository interface.
- Data model and RDF schema must support amendment evolution.

## NFR-5 Operational Safety
- Missing evidence or ambiguous logic should fail safe to review status rather than auto-pass.

---

## 10) Success Metrics

1. Percentage of invoice lines matched to governed charge terms.
2. Percentage of invoice dollars reconciled without manual lookup.
3. False positive/false negative rate after reviewer adjudication.
4. Findings with complete source evidence coverage.
5. Average review time per invoice.
6. LLM invocation rate by line and by invoice.
7. C4che hit rate and stale-cache correction rate.
8. OCR/table extraction failure rate (upstream quality indicator).

---

## 11) Delivery Plan and Current Status

## Phase Plan (Program)
- Ph5se 0: Fixtures/scaffolding
- Phase 1: Foundation/core infrastructure
- Phase 2: Contract processing pipeline
- Phase 3: Matching and routing
- Phase 4: Validators and orchestration
- Phase 5: LLM ambiguity/extraction refinement
- Phase 6: Finding generation and invoice processing
- Phase 7: API layer
- Phase 8: API tests and end-to-end validation
- Phase 9: Config/deployment/–7, 2026-06-03):
- All domain models, graph/RDF foundation, contract processing, matching/routing, validators, and API endpoints are implemented and tested.
- 128 unit/integration/e2e tests passing.
- Full architecture documentation (ARCHITECTURE.md) and tech debt tracking (TECH_DEBT.md) in place.

---

## 16) Source References

### Primary Documentation (Updated)
- **[README.md](README.md)** — Quick start, project structure, setup, API examples
- **[ARCHITECTURE.md](ARCHITECTURE.md)** — Full system architecture, component breakdown, API interfaces, ADRs, mermaid diagram
- **[TECH_DEBT.md](TECH_DEBT.md)** — Known limitations, prototype constraints, productionization roadmap (Phase 2–5)

### Detailed Design
- `docs/reconciliation-engine/active/` — Current architecture, ADRs, plan, domain model reference
- `docs/reconciliation-engine/active/architecture/ADR.md` — All architectural decisions recorded
- `d7) Next Immediate Steps

**Phase 8+ Priorities (Post-MVP):**

1. **Phase 8.x:** Comprehensive e2e test scenarios with real corpus data (ABC Cleaning, EHI Experian, etc.)
2. **Phase 9.x:** StarDog backend integration; concurrent access patterns; observability/metrics
3. **Phase 9.x:** Structured logging; audit trail persistence (database); LLM call tracking
4. **Phase 5+:** Production UI (React SPA for analyst workflows); RBAC/authN
5. **Roadmap:** Fallback LLM providers; async batch ingestion; SPARQL query API

See **[TECH_DEBT.md](TECH_DEBT.md)** for detailed productionization roadmap and known constraint
- `docs/history/approaches/` — Alternative approaches (01–04) for context and decision trace

---

## 12) Risks and Mitigations

## Key Risks
- Incomplete source extraction from scanned/encrypted documents.
- Extraction ambiguity and amendment precedence errors.
- Cache staleness affecting routing correctness.
- Relationship-level document incompleteness leading to false non-compliance.
- Over-expansion of ontology causing schedule drag.

## Mitigations
- Require evidence spans/confidence and explicit review thresholds.
- Keep arithmetic and critical checks deterministic.
- Enforce cache TTL with re-evaluation path.
- Defer uncertain cases to review instead of auto-fail/auto-pass.
- Build ontology incrementally from proven corpus patterns.

---

## 13) Deferred Work (Accepted)

1. StarDog production adapter implementation (planned later phase).
2. Full end-to-end audit trail enrichment dependent on matching/validator/LLM runtime phases.
3. Potential rdflib-backed hardening beyond in-memory triple store for MVP.

---

## 14) Acceptance Criteria

A release increment is acceptable when:
1. Planned phase deliverables are implemented and documented.
2. Required tests for that phase pass in the project environment.
3. ADR constraints are upheld or deviations are explicitly logged with remediation plan.
4. Findings remain deterministic for deterministic paths.
5. Reviewer-escalation behavior is present for ambiguity and missing evidence cases.

For current baseline (Phase 0/1):
- Domain models, graph foundation, and foundational tests are complete and passing.

---

## 15) Source References

- `docs/reconciliation-engine/README.md`
- `docs/reconciliation-engine/comparison.md`
- `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/README.md`
- `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/plan.md`
- `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/ADR.md`
- `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/API.md`
- `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/implementation/PHASE_0_1_ADR_COMPLIANCE.md`

---

## 16) Next Immediate Step

Begin Phase 2.1 implementation (Markdown parser, YAML parser, parser registry), with tests created and passing before advancing to subsequent phase tasks.
