# PSPA Reconciliation Engine

**Contract-invoice reconciliation service using ontology-backed agent with two-tier routing.**

## Quick Overview

Given a service contract and an invoice, this engine:

1. **Ingests contract text** — Extracts charge terms via LLM, stores them as RDF triples in an ontology graph
2. **Receives structured invoice** — Invoice is already in JSON/structured format (per API spec)
3. **Matches & routes** — Two-tier routing: 70% fast-path (cached, no LLM, < 500ms); 30% deep-path (semantic matching + LLM, 2–10s)
4. **Validates deterministically** — Arithmetic, dates, preconditions, pass-through evidence (no LLM)
5. **Returns findings** — Per-line and invoice-level status with full audit trail and confidence scores

### Core Prototype vs. Supporting Code

**In Scope** (core prototype design):
- Contract text ingestion & LLM extraction → RDF storage
- Structured invoice matching & routing
- Deterministic validators
- Finding generation with audit trail

**Supporting Harness** (for end-to-end testing & demo, not production-ready):
- PDF → text parsing (`data_parsers/pdf_extractor.py`) — upstream responsibility in production
- Markdown/YAML → structured JSON parsing — upstream responsibility in production
- Streamlit workbench UI (`ui/`) — for development/debugging only, not for production analyst workflows

These utilities are included to enable demos and end-to-end testing from raw files, but **are not part of the core prototype and will not be production-hardened**.

**Status:** Active prototype; Phase 1–2 complete. See [PRODUCT_REQUIREMENTS.md](PRODUCT_REQUIREMENTS.md) and [TECH_DEBT.md](TECH_DEBT.md) for current scope and known constraints.

---

## Table of Contents

- [Project Structure](#project-structure)
- [Installation & Setup](#installation--setup)
- [Quick Start](#quick-start)
- [Key Concepts & Domain Model](#key-concepts--domain-model)
- [API Documentation](#api-documentation)
- [Development & Testing](#development--testing)
- [Architecture & Design](#architecture--design)
- [Tech Debt & Constraints](#tech-debt--constraints)

---

## Project Structure

```
PSPA-Rec/
├── 📂 api/                        # FastAPI endpoints (contracts, invoice reconciliation)
│   ├── contract_endpoints.py      # POST /contracts/ingest, GET /contracts/{id}/status, DELETE
│   ├── invoice_endpoints.py       # POST /reconcile (canonical), POST /reconcile-from-text (legacy)
│   ├── request_models.py
│   ├── response_models.py
│   └── dependencies.py
│
├── 📂 core/                       # Orchestration & workflow logic
│   ├── contract_processor.py      # ingest_contract(), finalize_contract(), get_contract_status()
│   ├── invoice_processor.py       # process_invoice() — main reconciliation loop
│   ├── routing_engine.py          # Fast-path vs. deep-path routing decisions
│   ├── promotion_engine.py        # Fast-path cache update logic
│   └── finding_generator.py       # Assemble findings from validation results
│
├── 📂 graph/                      # RDF storage & ontology
│   ├── graph_repository.py        # Abstract interface (insert, query, delete triples)
│   ├── mock_graph.py              # In-memory RDF graph (rdflib) [MVP]
│   ├── stardog_adapter.py         # StarDog backend [Phase 3 deferred]
│   ├── ontology_schema.py         # RDF class & property URIs
│   ├── rdf_generator.py           # Domain objects → RDF triples
│   └── prefixes.py                # RDF namespace prefixes
│
├── 📂 llm/                        # LLM integration
│   ├── llm_client.py              # Azure OpenAI (via APIM) [MVP]
│   ├── contract_extraction_agent.py
│   ├── ambiguity_resolver_agent.py
│   ├── prompts.py
│   └── stub_llm_client.py         # Deterministic stub for testing
│
├── 📂 matching/                   # Term matching & routing
│   ├── matching_engine.py
│   ├── term_retriever.py          # Retrieve candidate terms from graph
│   └── similarity.py              # Scoring functions
│
├── 📂 models/                     # Pydantic domain models
│   ├── contract_models.py         # ChargeTerm, VendorRelationship, Amendment
│   ├── invoice_models.py          # Invoice, InvoiceLine
│   ├── finding_models.py          # Finding, ValidationResult, RoutingDecision
│   └── routing_models.py          # MatchCandidate, MatchResult
│
├── 📂 validators/                 # Deterministic validation rules
│   ├── orchestrator.py            # Run all validators for a charge term type
│   ├── arithmetic_validators.py
│   ├── temporal_validators.py
│   ├── contingency_validators.py
│   ├── precondition_validators.py
│   ├── pass_through_validators.py
│   ├── tax_validators.py
│   └── validator_registry.py      # ChargeType → validators mapping
│
├── 📂 data_parsers/               # ⚠️ Supporting harness: Input parsing (contracts, invoices)
│   ├── data_directory.py          # Discover files from Data/ corpus
│   ├── markdown_parser.py         # Parse markdown (contract/invoice text)
│   ├── yaml_parser.py             # Parse YAML (contract/invoice text)
│   ├── pdf_extractor.py           # Extract text from PDFs (sidecar .txt files)
│   ├── sidecar_text.py            # Manage .txt sidecars for PDFs
│   ├── invoice_parser.py          # Parse text → structured Invoice JSON
│   └── parser_registry.py         # Auto-detect file type and dispatch
│
├── 📂 storage/                    # Fast-path cache
│   └── fast_path_cache.py         # TTL-based cache of high-confidence matches
│
├── 📂 utils/                      # Utilities
│   ├── config.py                  # Env-var-driven configuration
│   ├── logging_config.py          # Structured logging setup
│   └── errors.py                  # Domain exception hierarchy
│
├── 📂 tests/                      # ✅ Test suite (validation & development)
│   ├── conftest.py
│   ├── factories.py
│   ├── helpers.py
│   ├── fixtures/                  # Test data (ABC Cleaning, GreenTech, etc.)
│   ├── test_*.py                  # Unit & integration tests
│   └── test_e2e_*.py              # End-to-end scenarios
│
├── 📂 ui/                         # ⚠️ TEST HARNESS: Streamlit workbench (dev-only)
│   ├── app.py                     # Main Streamlit entry point
│   ├── pages/
│   │   ├── 01_contract.py         # Contract exploration
│   │   ├── 02_reconcile.py        # Invoice reconciliation
│   │   └── workbench.py           # Debugging tools
│   ├── components/
│   │   ├── findings_table.py
│   │   ├── graph_viewer.py
│   │   └── pdf_viewer.py
│   └── README.md                  # Workbench instructions
│
├── 📂 docs/                       # Documentation
│   ├── reconciliation-engine/
│   │   ├── active/                # Current approach (Approach 5)
│   │   │   ├── api/
│   │   │   ├── architecture/      # ADRs, plan, README
│   │   │   ├── domain/
│   │   │   ├── implementation/    # Agents, checklists
│   │   │   ├── quality/           # Coverage reports
│   │   │   └── releases/          # Deployment readiness
│   │   └── domain-model/
│   │       ├── logical-model.md
│   │       ├── corpus-evidence-summary.md
│   │       └── examples/
│   └── history/                   # Historical approaches (01–04)
│       └── approaches/
│
├── 📂 tools/                      # ⚠️ Utilities & corpus workbench
│   ├── corpus_workbench/
│   │   ├── analyze_corpus.py      # Analyze Data/ directory
│   │   └── generate_pdf_sidecars.py
│   ├── reorg/
│   │   └── run_approach5_reorg.ps1 # Reorganization script [git artifact]
│   └── README.md
│
├── 📂 Data/                       # Test data (contracts & invoices)
│   └── Contract and Invoice Pairs/
│       ├── UHS - Dialysis/
│       ├── UHS - Experian/
│       ├── UHS - Fire Suppression/
│       ├── UHS - Landscaping/
│       └── ...
│
├── 📄 main.py                     # ✅ FastAPI app entry point
├── 📄 pyproject.toml              # Build, test, lint config
├── 📄 requirements.txt            # Python dependencies
├── 📄 requirements-dev.txt        # Dev dependencies (pytest, ruff, mypy)
├── 📄 .env.example                # Configuration template
├── 📄 .gitignore
├── 📄 PRODUCT_REQUIREMENTS.md     # PRD: business context & scope
├── 📄 ARCHITECTURE.md             # ✨ Full architecture guide (incl. mermaid diagram)
├── 📄 TECH_DEBT.md               # Prototype constraints & productionization plan
└── 📄 README.md                   # ← You are here
```

**Legend:**
- ✅ Production-ready code
- ⚠️ Test harness / dev tools / supporting utilities (not for production)
- ✨ New documentation (post-reorganization)

---

## Installation & Setup

### Prerequisites

- Python 3.9+
- Azure OpenAI API credentials (via Azure APIM) — or mock LLM for testing
- Optional: StarDog 8+ (deferred to Phase 3; mock graph used for MVP)

### 1. Clone Repository

```bash
git clone https://github.com/vizientinc/pspa-reconciliation.git
cd PSPA-Rec
```

### 2. Create Virtual Environment

```bash
python -m venv .venv
source .venv/bin/activate      # macOS/Linux
# or
.venv\Scripts\activate         # Windows
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

For development (including pytest, ruff, mypy):

```bash
pip install -r requirements-dev.txt
```

### 4. Configure Environment

Copy `.env.example` to `.env` and fill in your LLM provider credentials:

```bash
cp .env.example .env
```

**`.env` Example:**
```bash
# LLM Provider Configuration
LLM_PROVIDER=azure-apim

# Azure OpenAI via APIM (recommended for production)
AZURE_OPENAI_ENDPOINT=https://api.vizientinc.com/azure-openai
AZURE_OPENAI_API_KEY=<your-api-key>
AZURE_OPENAI_API_VERSION=2024-08-01-preview
AZURE_OPENAI_DEPLOYMENT=gpt-5.4

# Model Configuration
LLM_MODEL=gpt-5.4
LLM_TEMPERATURE_EXTRACTION=0.1
LLM_TEMPERATURE_AMBIGUITY=0.3
LLM_MAX_TOKENS=4096

# Graph Backend
GRAPH_BACKEND=mock                  # or: stardog [Phase 3]
# STARDOG_URL=http://localhost:5820
# STARDOG_DATABASE=pspa-rec

# Application
LOG_LEVEL=INFO
FAST_PATH_CACHE_TTL_DAYS=30
VALIDATOR_TOLERANCE=0.01
```

See [AZURE_APIM_SETUP.md](docs/reconciliation-engine/active/implementation/AZURE_APIM_SETUP.md) for detailed Azure APIM setup.

### 5. Run Tests

```bash
# All tests except live (requires API keys)
pytest

# Only live tests (requires Azure OpenAI credentials)
pytest -m live -xvs

# Specific test file
pytest tests/test_invoice_processor.py -xvs

# With coverage
pytest --cov=. --cov-report=html
```

### 6. Start API Server

```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Then visit:
- **API docs:** http://localhost:8000/docs
- **Health check:** http://localhost:8000/health

### 7. (Optional) Start Streamlit Workbench

```bash
cd ui
streamlit run app.py --server.port 8501
```

Then visit: http://localhost:8501

**Note:** Streamlit workbench is for **development & debugging only**, not production analyst workflows.

---

## Quick Start

### Example 1: Ingest a Contract

```bash
curl -X POST http://localhost:8000/contracts/ingest \
  -H "Content-Type: application/json" \
  -d '{
    "metadata": {
      "vendor_id": "EHI-001",
      "vendor_name": "Experian Health Inc."
    },
    "documents": [
      {
        "filename": "master_agreement.md",
        "text": "# Master Service Agreement\n\n## Charges\n- MCA Fee: $5,000/month\n- Per-record lookup: $0.50"
      }
    ]
  }'
```

**Response:**
```json
{
  "contract_id": "con_EHI001_20250101",
  "status": "finalized",
  "term_count": 2,
  "warnings": []
}
```

### Example 2: Reconcile an Invoice

```bash
curl -X POST http://localhost:8000/reconcile \
  -H "Content-Type: application/json" \
  -d '{
    "contract_id": "con_EHI001_20250101",
    "invoice": {
      "vendor_id": "EHI-001",
      "invoice_number": "INV-20260531-001",
      "invoice_date": "2026-05-31",
      "lines": [
        {
          "line_number": 1,
          "description": "MCA Fee May 2026",
          "quantity": 1.0,
          "unit": "MONTH",
          "rate": 5000.00,
          "amount": 5000.00
        }
      ]
    }
  }'
```

**Response:**
```json
{
  "invoice_id": "inv_EHI001_202605_001",
  "contract_id": "con_EHI001_20250101",
  "overall_status": "PASS",
  "line_findings": [
    {
      "line_number": 1,
      "status": "PASS",
      "matched_term_id": "term_EHI001_mca_monthly",
      "routing_path": "FAST_PATH",
      "confidence": 0.98,
      "validators_run": [
        {
          "validator_name": "amount_match",
          "result": "PASS",
          "expected": 5000.00,
          "actual": 5000.00
        }
      ]
    }
  ],
  "summary": {
    "total_amount": 5000.00,
    "passed_amount": 5000.00,
    "variance_amount": 0.0
  }
}
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for full API documentation and more examples.

---

## Key Concepts & Domain Model

### Logical Model Overview

The reconciliation engine operates on a **logical domain model** that normalizes messy contract and invoice evidence into stable, queryable representations. This model answers two critical reconciliation questions:

1. **Is each invoice line billable under an active governing term?**
2. **Is the invoice total compliant after accepted lines, credits, taxes, pass-throughs, discounts, and timing rules are applied?**

**Core Entities:**
- **VendorRelationship** — The durable commercial relationship between customer and vendor
- **ContractDocument** — Master agreements, SOWs, amendments, addenda, cover memos
- **DocumentPart** — Clauses, exhibits, schedules, price tables (source of truth for every assertion)
- **GoverningTerm** — Normalized terms: effective period, precedence, location/service scope, charge type
- **ChargeTerm** — Billable constructs: FixedFee, SubscriptionFee, UsageFee, TieredUsage, PerLocation, EventFee, PassThrough, Tax, Contingency, LateFee
- **Invoice** — Header (number, date, vendor, totals) + line items with provenance
- **Finding** — Reconciliation result: PASS/VARIANCE/NEEDS_REVIEW with audit trail and confidence

**Key Insight — Document Hierarchy:** Contracts are not flat. The model treats each relationship as a graph where:
- Master agreements define general terms and product/service tables
- Amendments/change orders override earlier terms, add locations, or introduce new billing cadences
- SOWs bind scope, deliverables, and fees to a master agreement
- Location-specific agreements can be separate governing documents under the same vendor relationship
- Each `GoverningTerm` carries source document, effective period, precedence rank, and amendment relationships

### Charge Term Types

The model recognizes distinct charge patterns observed across real vendor contracts (from corpus analysis of 94 files, 33 contracts):

| Charge Term | Examples from Corpus |
| --- | --- |
| **FixedFeeTerm** | Reputation.com professional services implementation fee |
| **SubscriptionFeeTerm** | NRC annual membership, Perficient semiannual support |
| **UsageFeeTerm** | Office supplies quantity rows, transaction-based fees |
| **TieredUsageFeeTerm** | Experian transaction packages with monthly max + overages |
| **ClaimsBasedSubscriptionTerm** | Experian claims-based products with volume adjustment |
| **PerLocationFeeTerm** | Quality Lawn site-specific, Johnson Controls inspections |
| **EventFeeTerm** | Spring cleanup, inspection event, repair service call |
| **PassThroughFeeTerm** | Experian pass-through costs (payer/government reimbursements) |
| **TaxTerm** | UHS tax-exempt agreements, invoice sales-tax checks |
| **ContingencyFeeTerm** | HealthROI percentage of additional reimbursements recovered |

### Matching & Validation Flow

1. **Normalize** invoice header and lines
2. **Identify** vendor relationship candidates (vendor, account, remittance, facility, PO)
3. **Expand** governing terms after amendment precedence is applied
4. **Match** each line by product/service, SKU, location, service period, quantity/UOM, amount
5. **Calculate** expected amount from candidate term
6. **Classify** as: compliant, overbilled, outside scope/date/location, duplicate, missing auth, or ambiguous
7. **Validate** deterministically (arithmetic, dates, contingency conditions, preconditions, pass-through evidence, tax rules)
8. **Produce** provenance-rich explanation citing source documents and validators

### Provenance & Evidence Model

Every assertion includes:
- Source file path and document type
- Page/sheet/row/chunk identifier when available
- Extraction method (manual, OCR, parser) and confidence
- Exact extracted value and normalized value
- Reviewer status if human-validated

This enables findings that say: *"This amendment effective 2026-03-15 establishes $20K/month for Facility X, but the invoice allocates $18K; discrepancy is $2K (10% variance)."*

### Contract Ingestion
1. **Parse** contract text (markdown, YAML)
2. **Extract** charge terms using LLM extraction agent
3. **Normalize** terms (dates, locations, UOM)
4. **Detect conflicts** and flag for manual review if needed
5. **Finalize** by converting to RDF triples and building fast-path cache index

### Two-Tier Routing
- **Fast Path:** Cached/exact matches; validators only; < 500ms
- **Deep Path:** Semantic matching + optional LLM ambiguity resolution; 2–10s

### Validators
Deterministic functions that check:
- **Arithmetic:** Quantities, rates, amounts match contract terms
- **Temporal:** Effective dates are within contract period
- **Contingencies:** Conditions (budget, volume) are met
- **Preconditions:** Vendor is active, location is in scope
- **Pass-Through:** Supporting documentation provided
- **Tax:** Tax rules correctly applied

### Findings
Per-line and invoice-level results:
- **PASS:** Line matches contract, validators pass, no issues
- **VARIANCE:** Line matches, but some validators flag discrepancies (e.g., 2% rate difference)
- **NEEDS_REVIEW:** Ambiguous match, no match, or critical validation failure
- **REJECT:** Definitive mismatch or blocked charge type

---

## API Documentation

### Contracts

#### `POST /contracts/ingest`
Ingest and extract charge terms from contract.

**Request:**
```json
{
  "metadata": { "vendor_id": "...", "vendor_name": "..." },
  "documents": [
    { "filename": "...", "text": "..." }
  ]
}
```

**Response:** `{ "contract_id": "...", "status": "finalized", "term_count": N, "warnings": [...] }`

---

#### `GET /contracts/{contract_id}/status`
Check contract finalization status.

**Response:** `{ "contract_id": "...", "status": "finalized", "term_count": N, "finalized_at": "..." }`

---

#### `DELETE /contracts/{contract_id}`
Remove contract and invalidate cache entries.

**Response:** `204 No Content`

---

### Invoice Reconciliation

#### `POST /reconcile`
Reconcile structured invoice against contract (canonical endpoint).

**Request:**
```json
{
  "contract_id": "...",
  "invoice": {
    "vendor_id": "...",
    "invoice_number": "...",
    "invoice_date": "...",
    "lines": [
      {
        "line_number": 1,
        "description": "...",
        "quantity": 1.0,
        "unit": "MONTH",
        "rate": 5000.00,
        "amount": 5000.00,
        "supporting_docs": [...]
      }
    ]
  }
}
```

**Response:**
```json
{
  "invoice_id": "...",
  "contract_id": "...",
  "overall_status": "PASS|VARIANCE|NEEDS_REVIEW",
  "line_findings": [
    {
      "line_number": 1,
      "status": "PASS",
      "matched_term_id": "...",
      "routing_path": "FAST_PATH",
      "confidence": 0.98,
      "validators_run": [...]
    }
  ],
  "summary": { "total_amount": ..., "passed_amount": ..., "variance_amount": ... }
}
```

---

#### `POST /reconcile-from-text` (Legacy)
Raw-text invoice parsing (deprecated v0.1.0; will remove in v2).

Use `/reconcile` with structured `Invoice` instead.

---

### Health
#### `GET /health`
Service health check.

**Response:** `{ "status": "ok", "version": "0.1.0" }`

---

## Development & Testing

### Running Tests

```bash
# All tests (except @live)
pytest -v

# Only integration/e2e tests
pytest tests/test_e2e*.py -v

# Only live tests (requires Azure OpenAI credentials)
pytest -m live -xvs

# Specific test with coverage
pytest tests/test_validators.py --cov=validators --cov-report=term-missing
```

### Test Structure

- **`tests/fixtures/`** — Test contracts and invoices (ABC Cleaning, GreenTech, etc.)
- **`tests/conftest.py`** — Pytest fixtures and shared utilities
- **`tests/factories.py`** — Factory functions for generating test models
- **`tests/test_*.py`** — Unit tests for each module
- **`tests/test_e2e_*.py`** — End-to-end reconciliation scenarios

### Debugging

#### View Parsed Contract

```bash
python -c "
from data_parsers.markdown_parser import parse_contract_markdown
contract = parse_contract_markdown(open('Data/.../contract.md').read())
print(contract)
"
```

#### Run Specific Validator

```bash
python -c "
from validators.arithmetic_validators import validate_amount_match
from models.finding_models import ValidationResult
result = validate_amount_match(expected=5000, actual=5000)
print(result)
"
```

#### Inspect Fast-Path Cache

Use Streamlit workbench:
```bash
cd ui
streamlit run app.py
```

Then navigate to "Cache Explorer" tab.

---

## Architecture & Design

For comprehensive architecture documentation, see:

- **[ARCHITECTURE.md](ARCHITECTURE.md)** — System design, components, API interfaces, data flow, and mermaid diagram
- **[PRODUCT_REQUIREMENTS.md](PRODUCT_REQUIREMENTS.md)** — Business context, scope, objectives, user personas
- **[docs/reconciliation-engine/active/architecture/ADR.md](docs/reconciliation-engine/active/architecture/ADR.md)** — Architecture Decision Records

Key principles:
- ✅ **Auditability:** Every finding traces back to source contracts, validators, and confidence scores
- ✅ **Determinism:** All validators are hand-coded pure functions; no randomness
- ✅ **Two-Tier Routing:** Fast-path (cached, < 500ms) for 70% of lines; deep-path (LLM, 2–10s) for complex cases
- ✅ **Ontology-Backed:** RDF triples as canonical storage; portable to StarDog

---

## Tech Debt & Constraints

This is a **prototype** optimized for MVP velocity. Production concerns (performance, concurrency, compliance) are deferred to Phase 2–3.

### Key Constraints

| Area | Constraint | Fix Timeline |
|------|-----------|--------------|
| Graph Backend | Mock (single-threaded); max ~10K triples | StarDog integration (Phase 3, Q4 2026) |
| LLM Provider | Azure APIM only | Multi-provider abstraction (Phase 2, Q3 2026) |
| Cache Invalidation | TTL-based; no real-time updates | Stream-based invalidation (Phase 3) |
| Validators | Hand-coded; no rule DSL | Visual rule editor (Phase 4, Q1 2027) |
| Workbench UI | Streamlit (dev-only) | React SPA (Phase 5, Q2 2027) |
| Observability | Minimal metrics & logging | Prometheus + structured logs (Phase 2) |

See [TECH_DEBT.md](TECH_DEBT.md) for detailed discussion and productionization roadmap.

---

## FAQ

### Q: Is this production-ready?
**A:** Core business logic (validators, matching, API design) is production-ready. Infrastructure (graph backend, observability) needs Phase 2–3 hardening. See [TECH_DEBT.md](TECH_DEBT.md#recommendations-for-productionization).

### Q: Can I use this without Azure OpenAI?
**A:** Not in MVP. Phase 2 (Q3 2026) will add multi-provider support (OpenAI, Anthropic, etc.). For now, use `stub_llm_client.py` for testing without API keys.

### Q: How do I add a new validator?
**A:** Write a deterministic function in `validators/`, add it to the registry in `validator_registry.py`, and write unit tests. See [validators/README.md](validators/README.md) for examples.

### Q: What happens if the fast-path cache becomes stale?
**A:** TTL-based invalidation (default 30 days) prevents stale entries. If contract is manually updated, call `DELETE /contracts/{id}` to invalidate its cache. Phase 3 will add stream-based real-time invalidation.

### Q: Can I run invoice reconciliation in parallel?
**A:** Not with mock graph (single-threaded). Phase 3 StarDog backend will support concurrent writes. For MVP, use a worker queue (e.g., Celery) to process invoices sequentially.

### Q: Why is Streamlit used for the workbench?
**A:** Rapid prototyping tool for debugging and demos. Not intended for production analyst workflows. Phase 5 will build a React SPA for production use.

---

## Support & Contributing

For questions or bug reports:
1. Create a GitHub issue with reproduction steps
2. Tag with appropriate label (bug, enhancement, question, documentation)
3. Include `pytest` output if relevant

For contributions:
1. Create a feature branch
2. Write tests (aim for >80% coverage)
3. Follow PEP 8 style (use `ruff` for linting)
4. Submit PR with clear description

---

## License

[Add license here]

---

## References

- [PRODUCT_REQUIREMENTS.md](PRODUCT_REQUIREMENTS.md) — Business context & scope
- [ARCHITECTURE.md](ARCHITECTURE.md) — Full system design (incl. mermaid diagram)
- [TECH_DEBT.md](TECH_DEBT.md) — Prototype constraints & productionization plan
- [docs/reconciliation-engine/active/architecture/ADR.md](docs/reconciliation-engine/active/architecture/ADR.md) — Architecture Decision Records
- [docs/reconciliation-engine/active/architecture/plan.md](docs/reconciliation-engine/active/architecture/plan.md) — Implementation roadmap

---

**Last Updated:** 2026-06-03  
**Maintained By:** PSPA Reconciliation Workstream
