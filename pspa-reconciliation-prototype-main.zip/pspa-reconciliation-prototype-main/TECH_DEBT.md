# Tech Debt & Prototype Constraints

**Last Updated:** 2026-06-03  
**Status:** Active prototype; Phase 1–2 complete

This document catalogs technical debt, deferred work, and prototype constraints introduced to ship the MVP quickly while maintaining a path to production.

---

## Overview

The PSPA Reconciliation Engine is a **prototype** designed to:
- Validate the core business logic and API design
- Demonstrate the two-tier routing and validator architecture
- Support internal development, testing, and demo workflows
- Establish a foundation for Phase 3+ productionization

**Key insight:** We've explicitly traded off some production concerns (performance, concurrency, observability) to move fast on validation logic and UX iteration. This doc tracks those tradeoffs and mitigation plans.

---

## Table of Contents

1. [Prototype vs. Production Code](#prototype-vs-production-code)
2. [Known Limitations](#known-limitations)
3. [Tech Debt by Area](#tech-debt-by-area)
4. [Deprecations & Breaking Changes](#deprecations--breaking-changes)
5. [Recommendations for Productionization](#recommendations-for-productionization)
6. [Deferred Work](#deferred-work)

---

## Prototype vs. Production Code

### What Counts as Prototype Code

- **In scope for MVP:** Business logic (matching, routing, validators), API design, domain models
- **In scope for MVP:** Test suite, data fixtures, documentation
- **Out of scope for MVP:** Performance optimization, multi-region deployment, compliance (SOC 2, HIPAA)

### What Counts as Test/Demo Harness

- **`ui/` (Streamlit workbench):** Interactive debugging tool; not intended for production analyst workflows. Suitable for demos and rapid iteration only.
- **`tests/fixtures/`:** Test data (ABC Cleaning, GreenTech); not real production customer data.
- **`tools/corpus_workbench/`:** Utility scripts for corpus analysis and PDF sidecar generation; single-user, non-production.
- **`@pytest.mark.live` tests:** Hit real LLM API; for development validation only, skipped in CI.

### Production-Ready Code

The following components are production-ready as-is:

- **`api/` endpoints:** Schemas, error handling, response models (FastAPI standard patterns)
- **`models/` domain objects:** Pydantic models with validation
- **`validators/` deterministic functions:** Pure functions with no external dependencies
- **`data_parsers/markdown_parser.py & yaml_parser.py`:** Robust parsing; handles errors gracefully
- **`storage/fast_path_cache.py`:** Thread-safe, TTL-based; ready for concurrent use

The following need hardening before production:

- **`graph/` (mock_graph.py):** In-memory, single-threaded; replace with StarDog for scale
- **`llm/` integrations:** Azure APIM hardening needed; fallback providers not production-tested
- **`core/` orchestration:** Error handling & observability; add structured logging, metrics
- **`ui/` workbench:** Redesign for production analyst workflows (React SPA, not Streamlit)

---

## Known Limitations

### 1. Graph Backend: Mock (In-Memory) Only

**Issue:** Current `graph/mock_graph.py` stores triples in Python memory (rdflib).

**Constraints:**
- Single-threaded; no concurrent writes (bottleneck for parallel invoice processing)
- Max ~10K triples before performance degrades (ABC Cleaning contract = ~500 triples; EHI = ~1K)
- No persistence across process restarts
- No query optimization or indexing

**Date Introduced:** Prototype (2026-05-23)

**Impact:** MVP works fine; production will need StarDog backend.

**Mitigation:** 
- Mock graph abstraction separates interface (`GraphRepository`) from implementation
- StarDog adapter already drafted (`graph/stardog_adapter.py`); swap it in for Phase 3
- Use mock for development and testing until scale testing reveals bottleneck

---

### 2. LLM Provider: Azure APIM Only (MVP)

**Issue:** Current LLM client hardcoded for Azure OpenAI via APIM.

**Code Path:** `llm/llm_client.py`, `utils/config.py`

**Constraints:**
- Only Azure OpenAI deployment supported
- No fallback to direct OpenAI or Anthropic APIs
- No provider abstraction or strategy pattern
- API key hardcoded in .env; no secret manager integration

**Date Introduced:** Prototype (2026-05-23)

**Impact:** MVP contracts built for Azure. Multi-provider support deferred.

**Mitigation:**
- `llm_client.py` already has minimal Azure-specific code; mostly calls standard OpenAI SDK
- `stub_llm_client.py` provides mock for testing without API keys
- ADR-020 (deferred to Phase 2) will introduce LLM provider abstraction; easy refactor

---

### 3. Cache Invalidation: TTL Only

**Issue:** Fast-path cache uses simple TTL (time-to-live); no event-based invalidation.

**Constraints:**
- If contract is updated, cache entries may remain valid for up to TTL (default 30 days)
- Manually deleting a contract clears its cache entries (via `FastPathCache.invalidate_contract()`), but concurrent requests might still hit stale cache
- No audit log of cache hits/misses or invalidations

**Date Introduced:** Prototype (2026-05-23)

**Impact:** Small risk of stale matches; acceptable for MVP where contract updates are rare.

**Mitigation:**
- Reduce TTL in early phases (default 7 days instead of 30) if invalidation causes problems
- Add cache hit/miss metrics to observe stale-cache frequency
- Stream-based invalidation (Phase 3): when contract updated, emit event to invalidate cache entries in real-time

---

### 4. Validators: Hand-Coded, No DSL

**Issue:** All validation logic is hand-coded Python functions in `validators/`.

**Constraints:**
- Adding a new validation rule requires:
  1. Write Python function
  2. Add to appropriate validator module
  3. Register in `validator_registry.py`
  4. Write unit tests
  5. Deploy code
- No visual rule editor or configuration UI
- Rule versioning not explicit (rules evolve with code)
- No A/B testing framework for validator rules

**Date Introduced:** Prototype (2026-05-23)

**Impact:** MVP reasonable for 10–20 rules; becomes unwieldy beyond ~50.

**Mitigation:**
- Document validator module structure clearly (see [validators/README.md](validators/README.md) when created)
- Use feature flags (Phase 2) to A/B test new validator versions
- DSL or visual rule engine deferred to Phase 4 if validator complexity grows

---

### 5. Workbench UI: Streamlit (Dev-Only)

**Issue:** `ui/` is a Streamlit app, not a production UI framework.

**Current State:** Streamlit workbench for debugging and exploration (not intended for analyst use)

**Constraints:**
- Streamlit is designed for quick prototypes, not production apps
- No role-based access control (RBAC)
- No audit log of user actions
- No offline capability
- Session state is in-memory; no persistence across reloads

**Date Introduced:** Prototype (2026-05-23)

**Impact:** Unsuitable for production analyst workflows; fine for internal demos and debugging.

**Mitigation:**
- Explicitly label Streamlit UI as "Development Tool"
- Phase 5: Build React SPA for production analyst workflows
- In MVP, use `/reconcile` API directly for production integrations

---

### 6. Audit Trail: Minimal Persistence

**Issue:** Audit trail data is computed on-the-fly in responses; not persisted to database.

**Constraints:**
- Finding audit trails include matched term, validators, confidence, but not:
  - Full LLM prompt and response (lost after request)
  - User who triggered reconciliation
  - Timestamp of decision vs. current time
- Hard to debug "Why did this match yesterday but not today?" scenarios
- No compliance-grade audit log

**Date Introduced:** Prototype (2026-05-23)

**Impact:** MVP acceptable for development; compliance workflows need better audit.

**Mitigation:**
- Phase 2: Add structured audit log (database storage for findings, LLM calls, user actions)
- Implement audit log retention policies and export APIs

---

## Tech Debt by Area

### `api/` — HTTP Interfaces

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| No rate limiting | Medium | Backlog | Add rate limiter (Phase 2) |
| No API key auth (MVP) | Medium | Backlog | Add FastAPI Security (Phase 2) |
| Legacy `/reconcile-from-text` endpoint | Low | Deprecate v2 | Keep for backward compat; plan removal for v2 |
| No request/response logging | Medium | Backlog | Add middleware logging (Phase 2) |
| Limited error detail in responses | Low | Backlog | Expand error schema v2 (Phase 2) |

### `core/` — Orchestration

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| No structured logging | Medium | Phase 2 | Add JSON-formatted logs with trace IDs |
| Error handling is minimal | Medium | Phase 2 | Add retry logic, circuit breakers, timeouts |
| No observability metrics | High | Phase 2 | Add Prometheus metrics (latency, throughput, errors) |
| LLM calls are synchronous | Medium | Phase 3 | Add async/await; use worker pool for scale |
| No contract caching across requests | Low | Phase 3 | Cache contract in memory for warm start |

### `graph/` — RDF Storage

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| Mock graph is single-threaded | High | Phase 3 | Replace with StarDog for concurrent access |
| No query optimization | Medium | Phase 3 | Index frequently-queried triples |
| No SPARQL support | Low | Phase 3 | StarDog backend will include SPARQL |
| Triple export is debug-only | Low | Phase 3 | Add export API for audit/backup |

### `llm/` — LLM Integration

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| Azure APIM only; no other providers | Medium | Phase 2 | ADR-020: LLM provider abstraction |
| No fallback model or provider | Medium | Phase 2 | Add circuit breaker + fallback |
| No token counting or cost estimation | Low | Phase 2 | Add OpenAI token counter |
| LLM calls not persisted in audit | Medium | Phase 2 | Store LLM calls in audit log |
| No prompt versioning | Low | Phase 3 | Version prompts with model selects for A/B testing |

### `matching/` — Term Matching

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| Similarity scoring is heuristic | Low | Phase 2 | Consider ML-based similarity if accuracy issues |
| No semantic embeddings | Low | Phase 3 | Add vector similarity (embedding-based) if needed |
| No ambiguity threshold tuning | Low | Phase 2 | Add configurable confidence thresholds |

### `validators/` — Validation

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| Hand-coded rules; no DSL | Low | Phase 4 | Visual rule editor if complexity grows |
| No rule versioning | Low | Phase 2 | Use feature flags for rule A/B testing |
| No conditional rule execution | Low | Phase 2 | Enhance registry to support rule conditions |

### `storage/` — Fast-Path Cache

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| TTL-only invalidation | Medium | Phase 3 | Stream-based invalidation for real-time updates |
| In-memory only; no persistence | Low | Phase 2 | Add Redis backing store for multi-process |
| No cache statistics or metrics | Low | Phase 2 | Add cache hit/miss rate observability |

### `data_parsers/` — Input Parsing

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| PDF extraction uses sidecar .txt files | Medium | Phase 2 | Integrate native PDF OCR (e.g., pdfminer, tesseract) |
| No validation of parsed data structure | Low | Phase 1 | Already done (Pydantic validation) |

### `tests/` — Test Suite

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| No integration tests with StarDog | N/A | Phase 3 | Add CI job to run against real StarDog |
| No load testing | Medium | Phase 3 | Add performance benchmarks (concurrent requests, large graphs) |
| Coverage not tracked | Low | Phase 2 | Add `pytest-cov` and coverage gate (>80%) |
| Live tests slow down CI | Medium | Phase 2 | Move `@live` tests to separate CI stage or skip by default |

### `ui/` — Streamlit Workbench

| Item | Severity | Status | Notes |
|------|----------|--------|-------|
| Streamlit not production-scale | High | Phase 5 | Migrate to React SPA |
| No RBAC or authN | High | Phase 2 | Add FastAPI Security to API; Streamlit authN is minimal |
| No audit log of user actions | Medium | Phase 2 | Log all actions to audit table |
| Session state not persistent | Low | Phase 2 | Use browser storage + backend session store |

---

## Deprecations & Breaking Changes

### Current Deprecations

#### 1. `POST /reconcile-from-text` (Legacy Raw-Text Endpoint)

**Deprecated in:** v0.1.0  
**Status:** Maintained for backward compat; will be removed in v2  
**Alternative:** Use `POST /reconcile` with structured `Invoice` payload  
**Timeline:** Removal planned for v2 (Q3 2026)

**Why:** Raw-text parsing is error-prone and hard to audit. Structured input (JSON) enables better error messages and validation.

---

### Planned Breaking Changes (Future Versions)

#### 1. Finding Status Values (v1.0 → v2.0)

Current: `PASS`, `REJECT`, `NEEDS_REVIEW`  
Proposed: `PASS`, `FAIL`, `REQUIRES_REVIEW`, `UNDER_REVIEW`

(To align with industry terminology)

**Target:** v2.0 (Q4 2026)

---

## Recommendations for Productionization

### Phase 2 (Q3 2026): Hardening & Observability
- [ ] Add structured logging with trace IDs
- [ ] Implement LLM provider abstraction (ADR-020)
- [ ] Add Prometheus metrics (latency, throughput, errors, cache hit rate)
- [ ] Implement API key auth (FastAPI Security)
- [ ] Add audit log database (store findings, LLM calls, user actions)
- [ ] Integrate with secret manager (AWS Secrets Manager, HashiCorp Vault)
- [ ] Move `/reconcile-from-text` to legacy endpoint; deprecate in release notes

### Phase 3 (Q4 2026): Scale & Production Backend
- [ ] Implement StarDog graph backend
- [ ] Add stream-based cache invalidation
- [ ] Implement contract state caching for warm starts
- [ ] Add load testing (concurrent invoice processing)
- [ ] Implement async LLM calls with worker pool
- [ ] Add SPARQL query API for power users
- [ ] Multi-region deployment support

### Phase 4 (Q1 2027): Operations & Governance
- [ ] Rule engine DSL or visual editor
- [ ] A/B testing framework for validator rules
- [ ] Compliance audit module (SOC 2, HIPAA-eligible)
- [ ] Multi-tenancy support
- [ ] Data retention and purge policies
- [ ] Bulk async ingestion API

### Phase 5 (Q2 2027): Production UI
- [ ] React SPA for analyst workflows
- [ ] RBAC and fine-grained permissions
- [ ] Real-time findings dashboard
- [ ] Offline support
- [ ] Integration with AP/Finance systems (ERP, AP automation)

---

## Deferred Work

### High Priority (Will Block Q4 Release)

- **Multi-region deployment:** Needed for production SLA
- **Compliance audit module:** Required for Finance sign-off
- **Performance profiling & optimization:** Must meet < 2s median latency for 95% of lines

### Medium Priority (Q4–Q1)

- **LLM provider abstraction:** Enable multi-provider support
- **Stream-based cache invalidation:** Prevent stale cache issues at scale
- **Enhanced observability:** Detailed metrics and alerting

### Low Priority (Q1+)

- **Rule engine DSL:** Nice-to-have if validator complexity grows
- **React SPA:** Replace Streamlit when analyst workflow is finalized
- **Bulk async API:** Low priority; sync API handles current throughput

---

## Appendix: Decision Log

### Why Mock Graph Instead of StarDog from Day 1?

**Decision:** Start with in-memory mock graph (rdflib); plan StarDog for Phase 3.

**Rationale:**
1. **Speed to MVP:** Mock graph lets us iterate on API and business logic without StarDog complexity
2. **Portability:** Mock graph abstraction makes StarDog swap trivial; no code rewrite needed
3. **Cost:** No need to pay for StarDog instance during development
4. **Simplicity:** Mock graph is deterministic and easy to debug

**Risk:** Single-threaded mock graph won't scale to production. Mitigation: Phase 3 plan includes StarDog integration with minimal code changes.

---

### Why Streamlit for Workbench?

**Decision:** Build internal debugging tool in Streamlit, not production UI in React.

**Rationale:**
1. **Speed:** Streamlit lets analyst build UI in hours, not weeks
2. **Iteration:** Easy to add new debugging tools as use cases emerge
3. **Clarity:** Explicit that Streamlit tool is "development only"
4. **Separation:** Forces API design first; UI is secondary concern

**Risk:** Team might expect Streamlit workbench to be production-ready. Mitigation: Clear labeling in docs and code.

---

### Why Hand-Coded Validators, Not ML?

**Decision:** All validators are deterministic pure functions; no ML-based validators.

**Rationale:**
1. **Auditability:** Every decision traceable to specific validator code
2. **Compliance:** Deterministic logic easier to certify for financial controls
3. **Debugging:** Pure functions easy to unit test and debug
4. **Reproducibility:** Same input → always same output

**Risk:** Adding new rules requires code changes, not data changes. Mitigation: Phase 4 rule DSL if complexity grows.

---

### Why Azure APIM vs. Direct OpenAI?

**Decision:** Use Azure OpenAI via APIM (not direct OpenAI API).

**Rationale:**
1. **Corporate policy:** Vizient infrastructure uses APIM for API management
2. **Cost control:** APIM enables rate limiting, quota management, cost allocation
3. **Compliance:** APIM audit logs support internal security reviews

**Risk:** Locks us into Azure for MVP. Mitigation: Phase 2 LLM provider abstraction will reduce Azure dependency.

---

## Questions & Feedback

- **Q: Which prototype constraints will cause the most pain in production?**
  - **A:** Graph backend (mock is single-threaded) and observability (no metrics). Both addressed in Phase 3.

- **Q: Should we refactor X now or wait for Phase Y?**
  - **A:** If X blocks MVP or causes bugs in testing, refactor now. Otherwise follow phase schedule. Engineers: file GitHub issues for evaluation.

- **Q: Is the code production-ready?**
  - **A:** Core business logic (validators, matching, API design) is production-ready. Infrastructure (graph backend, observability, ops) needs Phase 2–3 hardening.

---

Last Updated: 2026-06-03  
Owner: PSPA Reconciliation Workstream
