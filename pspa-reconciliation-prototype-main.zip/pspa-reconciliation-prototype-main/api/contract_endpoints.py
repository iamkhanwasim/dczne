"""Contract lifecycle API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Response, status

from api.dependencies import get_contract_processor, get_fast_path_cache
from api.request_models import ContractIngestRequest
from api.response_models import ContractIngestResponse, ContractStatusResponse
from core.contract_processor import ContractProcessor
from storage.fast_path_cache import FastPathCache


router = APIRouter(tags=["contracts"])


@router.get("/health")
def health() -> dict:
    return {"status": "ok", "version": "0.1.0"}


@router.post("/contracts/ingest", response_model=ContractIngestResponse)
def ingest_contract(
    payload: ContractIngestRequest,
    contract_processor: ContractProcessor = Depends(get_contract_processor),
) -> ContractIngestResponse:
    vendor_id = str(payload.metadata.get("vendor_id") or "unknown-vendor")
    ingest = contract_processor.ingest_contract(vendor_id=vendor_id, documents=payload.documents)
    finalize = contract_processor.finalize_contract(ingest.contract_id)

    warnings = list(ingest.conflicts)
    if ingest.manual_review_required:
        warnings.extend(ingest.review_reasons)

    return ContractIngestResponse(
        contract_id=finalize.contract_id,
        status=finalize.status,
        term_count=finalize.terms_finalized,
        warnings=warnings,
    )


@router.get("/contracts/{contract_id}/status", response_model=ContractStatusResponse)
def get_contract_status(
    contract_id: str,
    contract_processor: ContractProcessor = Depends(get_contract_processor),
) -> ContractStatusResponse:
    status_result = contract_processor.get_contract_status(contract_id)
    return ContractStatusResponse(
        contract_id=status_result.contract_id,
        status=status_result.status,
        term_count=status_result.term_count,
        finalized_at=status_result.finalized_at,
    )


@router.delete("/contracts/{contract_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_contract(
    contract_id: str,
    contract_processor: ContractProcessor = Depends(get_contract_processor),
    cache: FastPathCache = Depends(get_fast_path_cache),
) -> Response:
    contract_processor.delete_contract(contract_id)
    cache.invalidate_contract(contract_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)
