"""Shared API dependencies (singleton-like in-process services)."""

from __future__ import annotations

from core.contract_processor import ContractProcessor
from core.invoice_processor import InvoiceProcessor
from graph.mock_graph import MockGraph
from storage.fast_path_cache import FastPathCache


_graph = MockGraph()
_cache = FastPathCache()
_contract_processor = ContractProcessor(graph_repository=_graph)
_invoice_processor = InvoiceProcessor(
    contract_processor=_contract_processor,
    fast_path_cache=_cache,
)


def get_contract_processor() -> ContractProcessor:
    return _contract_processor


def get_invoice_processor() -> InvoiceProcessor:
    return _invoice_processor


def get_fast_path_cache() -> FastPathCache:
    return _cache
