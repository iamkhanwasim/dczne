"""Invoice reconciliation API endpoints."""

from __future__ import annotations

from datetime import timezone
from typing import Any, Dict, List

from fastapi import APIRouter, Depends

from api.dependencies import get_invoice_processor
from api.request_models import InvoiceReconcileRequest, InvoiceReconcileTextRequest
from api.response_models import FindingDetailResponse, InvoiceReconcileResponse
from core.invoice_processor import InvoiceProcessor


router = APIRouter(tags=["invoices"])


def _audit_trail_from_result(result) -> Dict[str, Any]:
    finding = result.invoice_finding
    created_iso = finding.created_at.astimezone(timezone.utc).isoformat()
    return {
        "invoice_id": finding.invoice_id,
        "audit_trail_id": finding.audit_trail_id,
        "created_at": created_iso,
        "lines_processed": result.lines_processed,
        "lines_fast_path": result.lines_fast_path,
        "lines_deep_path": result.lines_deep_path,
        "lines_no_match": result.lines_no_match,
        "promotion_summary": result.promotion_summary,
        "parse_warnings": result.parse_warnings,
    }


def _response_from_result(result) -> InvoiceReconcileResponse:
    finding = result.invoice_finding
    details: List[FindingDetailResponse] = [
        FindingDetailResponse(
            line_num=line.line_number,
            charge_term_id=line.matched_charge_term_id,
            status=line.status.value,
            variance=line.variance,
            validators_run=list(line.validators_run),
            source_evidence=line.source_evidence,
        )
        for line in finding.line_findings
    ]

    summary = {
        "contract_id": finding.contract_id,
        "line_count": len(finding.line_findings),
        "total_variance": finding.total_variance,
        "tax_finding": finding.tax_finding.model_dump(mode="json") if finding.tax_finding else None,
    }

    return InvoiceReconcileResponse(
        invoice_id=finding.invoice_id,
        findings=details,
        invoice_total=finding.total_invoiced,
        expected_total=finding.total_expected,
        status=finding.overall_status.value,
        summary=summary,
        audit_trail=_audit_trail_from_result(result),
    )


@router.post("/reconcile", response_model=InvoiceReconcileResponse)
def reconcile_invoice(
    payload: InvoiceReconcileRequest,
    invoice_processor: InvoiceProcessor = Depends(get_invoice_processor),
) -> InvoiceReconcileResponse:
    result = invoice_processor.process_parsed_invoice(
        contract_id=payload.contract_id,
        invoice=payload.invoice,
        source_name=payload.source_name,
    )
    return _response_from_result(result)


@router.post("/reconcile-from-text", response_model=InvoiceReconcileResponse, deprecated=True)
def reconcile_invoice_from_text(
    payload: InvoiceReconcileTextRequest,
    invoice_processor: InvoiceProcessor = Depends(get_invoice_processor),
) -> InvoiceReconcileResponse:
    result = invoice_processor.process_invoice(
        contract_id=payload.contract_id,
        invoice_text=payload.invoice_text,
        source_name=payload.source_name,
    )
    return _response_from_result(result)
