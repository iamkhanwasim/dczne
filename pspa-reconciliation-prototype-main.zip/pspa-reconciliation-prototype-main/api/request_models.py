"""Request models for API endpoints."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from models.invoice_models import Invoice


class SupportingDocRef(BaseModel):
    type: str = Field(..., description="Document type (PO, receipt, etc.)")
    reference: str = Field(..., description="Identifier or reference string")


class ContractIngestRequest(BaseModel):
    documents: List[str] = Field(..., min_length=1)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class InvoiceReconcileRequest(BaseModel):
    contract_id: str
    invoice: Invoice
    source_name: str = "invoice"
    metadata: Dict[str, Any] = Field(default_factory=dict)
    supporting_docs: Optional[List[SupportingDocRef]] = None


class InvoiceReconcileTextRequest(BaseModel):
    contract_id: str
    invoice_text: str
    source_name: str = "invoice"
    metadata: Dict[str, Any] = Field(default_factory=dict)
    supporting_docs: Optional[List[SupportingDocRef]] = None
