"""Response models for API endpoints."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class ContractIngestResponse(BaseModel):
    contract_id: str
    status: str
    term_count: int
    warnings: List[str] = Field(default_factory=list)


class ContractStatusResponse(BaseModel):
    contract_id: str
    status: str
    term_count: int
    finalized_at: Optional[str] = None


class FindingDetailResponse(BaseModel):
    line_num: int
    charge_term_id: Optional[str] = None
    status: str
    variance: float
    validators_run: List[str] = Field(default_factory=list)
    source_evidence: str = ""


class InvoiceReconcileResponse(BaseModel):
    invoice_id: str
    findings: List[FindingDetailResponse] = Field(default_factory=list)
    invoice_total: float
    expected_total: float
    status: str
    summary: Dict[str, Any] = Field(default_factory=dict)
    audit_trail: Dict[str, Any] = Field(default_factory=dict)
