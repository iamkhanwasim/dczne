"""
Contract processor orchestration for ingestion and finalization.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

from data_parsers.parser_registry import parse_document
from data_parsers.yaml_parser import ParsedYamlDocument
from graph.graph_repository import GraphRepository
from graph.mock_graph import MockGraph
from graph.rdf_generator import contract_to_triples
from graph.prefixes import uri_for
from llm.contract_extraction_agent import ContractExtractionAgent, ExtractionResult
from models.contract_models import (
    Amendment,
    ContractDocument,
    DocumentType,
    SourceCitation,
    VendorRelationship,
)
from utils.errors import ContractNotFoundError, ExtractionError, ParseError, ValidationError


@dataclass
class IngestResult:
    contract_id: str
    status: str
    terms_extracted: int
    amendments_extracted: int
    documents_processed: int
    conflicts: List[str]
    manual_review_required: bool = False
    review_reasons: List[str] = field(default_factory=list)


@dataclass
class FinalizeResult:
    contract_id: str
    status: str
    validation_issues: List[str]
    terms_finalized: int
    triples_inserted: int
    ready_for_invoices: bool


@dataclass
class ContractStatusResult:
    contract_id: str
    status: str
    term_count: int
    finalized_at: Optional[str] = None


class ContractProcessor:
    """
    In-memory contract processing service for Phase 2.3.

    Stores `VendorRelationship` objects in process memory and persists finalized
    RDF triples through the configured graph repository.
    """

    def __init__(
        self,
        graph_repository: Optional[GraphRepository] = None,
        extraction_agent: Optional[ContractExtractionAgent] = None,
    ) -> None:
        self.graph_repository = graph_repository or MockGraph()
        self.extraction_agent = extraction_agent or ContractExtractionAgent()
        self._contracts: Dict[str, VendorRelationship] = {}

    @staticmethod
    def _as_date(value: Any) -> Optional[date]:
        if value is None or value == "":
            return None
        if isinstance(value, date):
            return value
        try:
            return date.fromisoformat(str(value))
        except ValueError:
            return None

    @staticmethod
    def _safe_document_type(raw: Any) -> DocumentType:
        value = str(raw or "").strip().lower()
        if "amend" in value:
            return DocumentType.AMENDMENT
        if "sow" in value or "statement of work" in value:
            return DocumentType.SOW
        if "master service" in value or value == "msa":
            return DocumentType.MSA
        if "change order" in value:
            return DocumentType.CHANGE_ORDER
        if "letter" in value:
            return DocumentType.LOA
        if "addendum" in value:
            return DocumentType.ADDENDUM
        return DocumentType.OTHER

    @staticmethod
    def _document_payload(document: Any, index: int) -> Tuple[str, str]:
        if isinstance(document, str):
            return (f"document-{index}", document)
        if isinstance(document, dict):
            content = document.get("content")
            source_name = str(document.get("source_name") or document.get("filename") or f"document-{index}")
            if not isinstance(content, str):
                raise ParseError(source_name, "Document payload missing string content")
            return (source_name, content)
        raise ParseError(f"document-{index}", "Document must be a string or object with content")

    def ingest_contract(self, vendor_id: str, documents: Sequence[Any]) -> IngestResult:
        if not vendor_id:
            raise ParseError("vendor_id", "vendor_id is required")
        if not documents:
            raise ParseError("documents", "at least one contract document is required")

        contract: Optional[VendorRelationship] = None
        conflicts: List[str] = []
        manual_review_required = False
        review_reasons: List[str] = []

        for index, doc_payload in enumerate(documents, start=1):
            source_name, content = self._document_payload(doc_payload, index)
            parsed = parse_document(content, source_name=source_name)

            metadata = parsed.metadata if hasattr(parsed, "metadata") else parsed.data
            contract_id = str(metadata.get("contract_id") or f"{vendor_id}-contract")
            customer_id = str(metadata.get("customer_id") or "unknown-customer")
            customer_name = str(metadata.get("customer_name") or "Unknown Customer")
            vendor_name = str(metadata.get("vendor_name") or vendor_id)
            effective_date = self._as_date(metadata.get("effective_date"))
            renewal_date = self._as_date(metadata.get("renewal_date"))

            if contract is None:
                contract = VendorRelationship(
                    id=contract_id,
                    vendor_id=vendor_id,
                    vendor_name=vendor_name,
                    customer_id=customer_id,
                    customer_name=customer_name,
                    effective_date=effective_date,
                    renewal_date=renewal_date,
                    status="indexed",
                )
            elif contract.id != contract_id:
                raise ParseError(source_name, f"Document contract_id {contract_id!r} does not match {contract.id!r}")

            doc_type = self._safe_document_type(metadata.get("document_type"))
            contract.documents.append(
                ContractDocument(
                    id=f"{contract.id}-doc-{index}",
                    vendor_id=vendor_id,
                    vendor_name=vendor_name,
                    customer_id=customer_id,
                    customer_name=customer_name,
                    document_type=doc_type,
                    effective_date=effective_date,
                    renewal_date=renewal_date,
                    markdown_text=content,
                    source_path=str(Path(source_name)),
                )
            )

            if isinstance(parsed, ParsedYamlDocument) and parsed.charge_terms:
                extracted_terms = parsed.charge_terms
            else:
                extraction: ExtractionResult = self.extraction_agent.extract_charge_terms(
                    document_text=content,
                    vendor_relationship_id=contract.id,
                    source_document_id=f"{contract.id}-doc-{index}",
                    source_document_type=str(metadata.get("document_type") or "ContractDocument"),
                    metadata=metadata,
                )
                extracted_terms = extraction.charge_terms
                conflicts.extend(extraction.conflicts)
                if extraction.manual_review_required:
                    manual_review_required = True
                    review_reasons.extend(extraction.review_reasons)

            if doc_type == DocumentType.AMENDMENT:
                amendment_number = int(metadata.get("amendment_number") or len(contract.amendments) + 1)
                amendment_effective = self._as_date(metadata.get("amendment_date") or metadata.get("effective_date"))
                if amendment_effective is None:
                    raise ParseError(source_name, "Amendment must include amendment_date or effective_date")

                contract.amendments.append(
                    Amendment(
                        id=f"{contract.id}-amd-{amendment_number}",
                        base_contract_id=contract.id,
                        amendment_number=amendment_number,
                        effective_date=amendment_effective,
                        modified_terms=extracted_terms,
                        source=SourceCitation(
                            document_id=f"{contract.id}-doc-{index}",
                            document_type=str(metadata.get("document_type") or "Amendment"),
                        ),
                    )
                )
                continue

            existing_ids = {term.id for term in contract.charge_terms}
            for term in extracted_terms:
                if term.id in existing_ids:
                    conflicts.append(f"Duplicate charge term id ignored: {term.id}")
                    continue
                contract.charge_terms.append(term)
                existing_ids.add(term.id)

        if contract is None:
            raise ParseError("documents", "No valid documents were processed")

        self._contracts[contract.id] = contract

        return IngestResult(
            contract_id=contract.id,
            status=contract.status,
            terms_extracted=len(contract.charge_terms),
            amendments_extracted=len(contract.amendments),
            documents_processed=len(contract.documents),
            conflicts=conflicts,
            manual_review_required=manual_review_required,
            review_reasons=review_reasons,
        )

    def finalize_contract(self, contract_id: str) -> FinalizeResult:
        contract = self._contracts.get(contract_id)
        if contract is None:
            raise ContractNotFoundError(contract_id)

        validation_issues: List[str] = []
        all_terms = list(contract.charge_terms)
        for amendment in contract.amendments:
            all_terms.extend(amendment.modified_terms)

        if not all_terms:
            validation_issues.append("No charge terms available for finalization")

        for term in all_terms:
            if term.rate <= 0:
                validation_issues.append(f"Term {term.id} has non-positive rate")
            if not (0.0 <= term.extraction_confidence <= 1.0):
                validation_issues.append(f"Term {term.id} has invalid extraction_confidence")

        if validation_issues:
            raise ValidationError("; ".join(validation_issues))

        contract.status = "finalized"
        triples = contract_to_triples(contract)
        self.graph_repository.insert_triples(triples)

        return FinalizeResult(
            contract_id=contract.id,
            status=contract.status,
            validation_issues=[],
            terms_finalized=len(all_terms),
            triples_inserted=len(triples),
            ready_for_invoices=True,
        )

    def get_contract(self, contract_id: str) -> VendorRelationship:
        contract = self._contracts.get(contract_id)
        if contract is None:
            raise ContractNotFoundError(contract_id)
        return contract

    def get_contract_status(self, contract_id: str) -> ContractStatusResult:
        contract = self.get_contract(contract_id)
        amendment_terms = sum(len(am.modified_terms) for am in contract.amendments)
        return ContractStatusResult(
            contract_id=contract.id,
            status=contract.status,
            term_count=len(contract.charge_terms) + amendment_terms,
            finalized_at=None,
        )

    def delete_contract(self, contract_id: str) -> None:
        contract = self._contracts.pop(contract_id, None)
        if contract is None:
            raise ContractNotFoundError(contract_id)

        # Best-effort removal of the top-level contract subject from graph.
        # Charge-term triples may still remain in mock graph and can be garbage-
        # collected by rebuilding test/dev graph state between runs.
        self.graph_repository.delete_triples(uri_for(contract_id))
