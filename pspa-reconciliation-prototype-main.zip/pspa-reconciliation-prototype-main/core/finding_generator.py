"""
Finding generator — Phase 6.1.

Produces Finding (line-level) and InvoiceFinding (invoice-level) from the
outputs of the matching, routing, and validator pipeline.

These are pure functions: no I/O, no LLM calls.
"""

from __future__ import annotations

from typing import Optional

from models.contract_models import ChargeTerm
from models.finding_models import Finding, FindingStatus, InvoiceFinding, RoutingPath, ValidationResult
from models.invoice_models import Invoice, InvoiceLine
from models.routing_models import RoutingDecision

# ---------------------------------------------------------------------------
# Status mapping
# ---------------------------------------------------------------------------

_ORCHESTRATOR_STATUS_MAP: dict[str, FindingStatus] = {
    "PASS": FindingStatus.PASS,
    "FAIL": FindingStatus.REJECT,
    "CONDITIONAL": FindingStatus.NEEDS_REVIEW,
}

# ---------------------------------------------------------------------------
# Recommended actions
# ---------------------------------------------------------------------------

_RECOMMENDED_ACTIONS: dict[FindingStatus, str] = {
    FindingStatus.PASS: "Approve for payment.",
    FindingStatus.REJECT: "Dispute with vendor; do not pay until resolved.",
    FindingStatus.NEEDS_REVIEW: "Route to contract manager for manual review before payment.",
    FindingStatus.NO_MATCH: "Cannot reconcile — no matching contract term found; escalate to contract manager.",
    FindingStatus.SKIPPED: "Line was skipped; no action required.",
}


# ---------------------------------------------------------------------------
# Source evidence helper
# ---------------------------------------------------------------------------


def _build_source_evidence(charge_term: ChargeTerm) -> str:
    """Build a human-readable citation string from a charge term's source."""
    if charge_term.source is None:
        return f"Charge term '{charge_term.name}' (id: {charge_term.id})"

    src = charge_term.source
    parts: list[str] = []

    if src.document_type:
        parts.append(src.document_type)
    elif src.document_id:
        parts.append(src.document_id)

    if src.section:
        parts.append(f"§{src.section}")

    if src.page is not None:
        parts.append(f"p.{src.page}")

    if src.line_reference:
        parts.append(src.line_reference)

    base = ", ".join(parts) if parts else src.document_id
    return f"{charge_term.name} — {base}"


# ---------------------------------------------------------------------------
# Line-level finding
# ---------------------------------------------------------------------------


def generate_line_finding(
    matched_charge_term: Optional[ChargeTerm],
    invoice_line: InvoiceLine,
    validation_results: list[ValidationResult],
    *,
    invoice_id: str,
    routing_decision: Optional[RoutingDecision] = None,
    matching_confidence: float = 0.0,
    llm_resolved: bool = False,
    orchestrator_status: Optional[str] = None,
) -> Finding:
    """
    Build a Finding for one invoice line from matching + validation outputs.

    Parameters
    ----------
    matched_charge_term:
        The ChargeTerm matched to this line, or None if no match was found.
    invoice_line:
        The invoice line being evaluated.
    validation_results:
        Ordered list of ValidationResult objects produced by the orchestrator.
    invoice_id:
        Invoice identifier to embed in the finding.
    routing_decision:
        Optional RoutingDecision from the routing engine; used to populate
        routing_path and related fields.
    matching_confidence:
        Confidence score from the matching engine (0.0–1.0).
    llm_resolved:
        True if the LLM resolved a matching ambiguity for this line.
    orchestrator_status:
        Pre-computed status string from ``determine_line_status`` ("PASS",
        "FAIL", "CONDITIONAL"). If omitted, it is derived from
        ``validation_results``.

    Returns
    -------
    Finding
    """
    # --- Routing path ---------------------------------------------------------
    routing_path = RoutingPath.DEEP_PATH
    if routing_decision is not None and routing_decision.fast_path_hit:
        routing_path = RoutingPath.FAST_PATH

    # --- NO_MATCH short-circuit -----------------------------------------------
    if matched_charge_term is None:
        return Finding(
            invoice_id=invoice_id,
            line_number=invoice_line.line_number,
            description=invoice_line.description,
            status=FindingStatus.NO_MATCH,
            matching_confidence=matching_confidence,
            routing_path=routing_path,
            llm_resolved=llm_resolved,
            amount_invoiced=invoice_line.line_amount,
            amount_expected=0.0,
            variance=invoice_line.line_amount,  # full amount is unreconciled
            validators_run=[],
            validator_results={},
            source_evidence="",
            recommended_action=_RECOMMENDED_ACTIONS[FindingStatus.NO_MATCH],
        )

    # --- Determine status -----------------------------------------------------
    if orchestrator_status is not None:
        status = _ORCHESTRATOR_STATUS_MAP.get(orchestrator_status, FindingStatus.NEEDS_REVIEW)
    else:
        # Derive from results directly (mirrors determine_line_status logic)
        has_error = any(not r.passed and r.severity == "error" for r in validation_results)
        has_warning = any(not r.passed and r.severity == "warning" for r in validation_results)
        if has_error:
            status = FindingStatus.REJECT
        elif has_warning:
            status = FindingStatus.NEEDS_REVIEW
        else:
            status = FindingStatus.PASS

    # --- Amounts & variance ---------------------------------------------------
    amount_expected = round(matched_charge_term.rate * invoice_line.quantity, 2)
    variance = round(invoice_line.line_amount - amount_expected, 2)

    # --- Validator result index -----------------------------------------------
    validator_results_dict = {r.validator_name: r for r in validation_results}
    validators_run = [r.validator_name for r in validation_results]

    # --- Source evidence ------------------------------------------------------
    source_evidence = _build_source_evidence(matched_charge_term)

    return Finding(
        invoice_id=invoice_id,
        line_number=invoice_line.line_number,
        description=invoice_line.description,
        status=status,
        matched_charge_term_id=matched_charge_term.id,
        matched_charge_term_name=matched_charge_term.name,
        matching_confidence=matching_confidence,
        routing_path=routing_path,
        llm_resolved=llm_resolved,
        amount_invoiced=invoice_line.line_amount,
        amount_expected=amount_expected,
        variance=variance,
        validators_run=validators_run,
        validator_results=validator_results_dict,
        source_evidence=source_evidence,
        recommended_action=_RECOMMENDED_ACTIONS.get(status, ""),
    )


# ---------------------------------------------------------------------------
# Invoice-level finding
# ---------------------------------------------------------------------------


def generate_invoice_finding(
    invoice: Invoice,
    line_findings: list[Finding],
    *,
    contract_id: str,
) -> InvoiceFinding:
    """
    Aggregate line-level findings into an InvoiceFinding.

    Parameters
    ----------
    invoice:
        The parsed Invoice being reconciled.
    line_findings:
        One Finding per invoice line, in any order.
    contract_id:
        The VendorRelationship ID the invoice is being reconciled against.

    Returns
    -------
    InvoiceFinding
        Includes total_invoiced, total_expected, total_variance, overall_status,
        and the full list of line findings.
    """
    # Use invoice.total (which includes tax) as the invoiced amount if available.
    # Fall back to the sum of line amounts if the invoice total is not set.
    lines_invoiced = round(sum(f.amount_invoiced for f in line_findings), 2)
    total_invoiced = round(invoice.total, 2) if invoice.total else lines_invoiced

    # Expected total mirrors the invoiced total structure: line expectations + tax.
    lines_expected = round(sum(f.amount_expected for f in line_findings), 2)
    tax_amount = round(invoice.tax_amount or 0.0, 2)
    total_expected = round(lines_expected + tax_amount, 2)

    total_variance = round(total_invoiced - total_expected, 2)

    overall_status = InvoiceFinding.compute_overall_status(line_findings)

    return InvoiceFinding(
        invoice_id=invoice.invoice_id,
        contract_id=contract_id,
        overall_status=overall_status,
        total_invoiced=total_invoiced,
        total_expected=total_expected,
        total_variance=total_variance,
        line_findings=line_findings,
    )
