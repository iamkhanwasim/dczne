"""
Invoice processor — Phase 6.2.

Orchestrates the full pipeline for a single invoice:
    parse → route → match → validate → generate findings → aggregate

Usage::

    processor = InvoiceProcessor(contract_processor=cp)
    invoice_finding = processor.process_invoice(
        contract_id="abc-cleaning-uh-2025",
        invoice_text=yaml_text,
    )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Dict, List, Optional

from core.contract_processor import ContractProcessor
from core.finding_generator import generate_invoice_finding, generate_line_finding
from core.promotion_engine import PromotionEngine
from core.routing_engine import route_line
from data_parsers.invoice_parser import parse_invoice
from models.contract_models import ChargeTerm, VendorRelationship
from models.finding_models import Finding, FindingStatus, InvoiceFinding, RoutingPath
from models.invoice_models import Invoice
from models.routing_models import RoutingDecision
from storage.fast_path_cache import FastPathCache
from utils.errors import ContractNotFinalizedError, ContractNotFoundError, ParseError
from validators.orchestrator import determine_line_status, validate_line
from validators.validator_registry import ValidatorRegistry, default_validator_registry


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class ProcessInvoiceResult:
    """
    Return type of ``InvoiceProcessor.process_invoice``.

    Wraps InvoiceFinding with processing metadata useful for the API layer.
    """

    invoice_finding: InvoiceFinding
    lines_processed: int
    lines_fast_path: int
    lines_deep_path: int
    lines_no_match: int
    parse_warnings: List[str] = field(default_factory=list)
    promotion_summary: Dict[str, object] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Processor
# ---------------------------------------------------------------------------


class InvoiceProcessor:
    """
    Full invoice reconciliation pipeline.

    Parameters
    ----------
    contract_processor:
        The ContractProcessor instance that owns the contract store and
        the GraphRepository used for deep-path term retrieval.
    fast_path_cache:
        Cache for fast-path routing. If not supplied a fresh in-memory
        cache is created (useful for tests).
    validator_registry:
        Custom registry of charge-type → validator mappings.
        Defaults to ``default_validator_registry``.
    """

    def __init__(
        self,
        contract_processor: ContractProcessor,
        fast_path_cache: Optional[FastPathCache] = None,
        validator_registry: Optional[ValidatorRegistry] = None,
        promotion_engine: Optional[PromotionEngine] = None,
    ) -> None:
        self._cp = contract_processor
        self._cache = fast_path_cache or FastPathCache()
        self._registry = validator_registry or default_validator_registry
        self._promotion_engine = promotion_engine or PromotionEngine(self._cache)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def process_invoice(
        self,
        contract_id: str,
        invoice_text: str,
        *,
        source_name: str = "invoice",
    ) -> ProcessInvoiceResult:
        """
        Reconcile an invoice against a finalized contract.

        Parameters
        ----------
        contract_id:
            The VendorRelationship id the invoice should be reconciled against.
        invoice_text:
            Raw YAML (or markdown with YAML front-matter) invoice document.
        source_name:
            Label for the invoice in error messages and the audit trail.

        Returns
        -------
        ProcessInvoiceResult
            Contains InvoiceFinding plus processing metadata.

        Raises
        ------
        ContractNotFoundError
            If ``contract_id`` has not been ingested.
        ContractNotFinalizedError
            If the contract has not been finalized.
        ParseError
            If ``invoice_text`` cannot be parsed as a valid invoice.
        """
        contract = self._get_finalized_contract(contract_id)
        invoice = parse_invoice(invoice_text, source_name=source_name)
        return self._process_parsed_invoice(contract=contract, contract_id=contract_id, invoice=invoice)

    def process_parsed_invoice(
        self,
        contract_id: str,
        invoice: Invoice,
        *,
        source_name: str = "invoice",
    ) -> ProcessInvoiceResult:
        """
        Reconcile an already parsed Invoice against a finalized contract.

        This is the core entrypoint for downstream applications that perform
        custom invoice parsing (including heuristic parsing) but still want
        canonical matching/validation status generation from core logic.
        """
        contract = self._get_finalized_contract(contract_id)
        result = self._process_parsed_invoice(contract=contract, contract_id=contract_id, invoice=invoice)
        if invoice.contract_id and invoice.contract_id != contract_id:
            result.parse_warnings.append(
                f"Invoice contract_id {invoice.contract_id!r} does not match requested contract_id {contract_id!r}"
            )
        return result

    def _process_parsed_invoice(
        self,
        *,
        contract: VendorRelationship,
        contract_id: str,
        invoice: Invoice,
    ) -> ProcessInvoiceResult:
        # Build an index of all charge terms (base + amendments) by id
        term_index = self._build_term_index(contract)

        # Process each line
        line_findings: List[Finding] = []
        lines_fast = 0
        lines_deep = 0
        lines_no_match = 0
        promotions_attempted = 0
        promotions_applied = 0

        for invoice_line in invoice.lines:
            routing_decision = route_line(
                invoice_line=invoice_line,
                contract_id=contract_id,
                fast_path_cache=self._cache,
                graph_repo=self._cp.graph_repository,
                invoice_date=invoice.invoice_date,
                location=None,
                validator_registry=self._registry,
            )

            matched_term = self._resolve_charge_term(routing_decision, term_index)
            matching_confidence = self._extract_confidence(routing_decision, matched_term)
            llm_resolved = self._was_llm_resolved(routing_decision)

            if matched_term is None:
                lines_no_match += 1
                finding = generate_line_finding(
                    None,
                    invoice_line,
                    [],
                    invoice_id=invoice.invoice_id,
                    routing_decision=routing_decision,
                    matching_confidence=matching_confidence,
                )
            else:
                if routing_decision.fast_path_hit:
                    lines_fast += 1
                else:
                    lines_deep += 1

                validation_results = validate_line(
                    matched_charge_term=matched_term,
                    invoice_line=invoice_line,
                    invoice_date=invoice.invoice_date,
                    customer_name=invoice.customer_name,
                    location="",
                    tax_rate=invoice.tax_rate or 0.0,
                    validator_registry=self._registry,
                )
                status_str = determine_line_status(validation_results)

                finding = generate_line_finding(
                    matched_term,
                    invoice_line,
                    validation_results,
                    invoice_id=invoice.invoice_id,
                    routing_decision=routing_decision,
                    matching_confidence=matching_confidence,
                    llm_resolved=llm_resolved,
                    orchestrator_status=status_str,
                )

                self._promotion_engine.record_rule_firing(contract_id=contract_id, finding=finding)

                promotions_attempted += 1
                promotion = self._promotion_engine.check_for_promotion(
                    contract_id=contract_id,
                    finding=finding,
                    validators_to_run=routing_decision.validators_to_run,
                )
                if promotion.promoted:
                    promotions_applied += 1

            line_findings.append(finding)

        # Aggregate
        # Note: fast-path cache promotion for stable deep-path outcomes is
        # handled automatically by route_line (confidence >= 0.90 → cache write).
        # Explicit promotion tracking (Phase 6.3) hooks in here.

        invoice_finding = generate_invoice_finding(
            invoice,
            line_findings,
            contract_id=contract_id,
        )

        return ProcessInvoiceResult(
            invoice_finding=invoice_finding,
            lines_processed=len(line_findings),
            lines_fast_path=lines_fast,
            lines_deep_path=lines_deep,
            lines_no_match=lines_no_match,
            promotion_summary={
                "attempted": promotions_attempted,
                "promoted": promotions_applied,
                "marked_terms_for_ruleset": self._promotion_engine.get_marked_terms_for_ruleset(),
            },
        )

    def _get_finalized_contract(self, contract_id: str) -> VendorRelationship:
        contract = self._cp.get_contract(contract_id)  # raises ContractNotFoundError
        if contract.status != "finalized":
            raise ContractNotFinalizedError(contract_id)
        return contract

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_term_index(contract: VendorRelationship) -> Dict[str, ChargeTerm]:
        """Build a flat id→term lookup from base terms + all amendment terms."""
        index: Dict[str, ChargeTerm] = {}
        for term in contract.charge_terms:
            index[term.id] = term
        for amendment in contract.amendments:
            for term in amendment.modified_terms:
                index[term.id] = term
        return index

    @staticmethod
    def _resolve_charge_term(
        decision: RoutingDecision,
        term_index: Dict[str, ChargeTerm],
    ) -> Optional[ChargeTerm]:
        """
        Return the matched ChargeTerm for this routing decision, or None.

        Fast-path: look up by cached_charge_term_id.
        Deep-path: use the selected candidate from the match result.
        """
        if decision.fast_path_hit and decision.cached_charge_term_id:
            return term_index.get(decision.cached_charge_term_id)

        if decision.match_result is not None and decision.match_result.is_matched:
            return decision.match_result.selected.charge_term  # type: ignore[union-attr]

        return None

    @staticmethod
    def _extract_confidence(
        decision: RoutingDecision,
        matched_term: Optional[ChargeTerm],
    ) -> float:
        if decision.fast_path_hit:
            return 1.0  # cache hit → deterministic, treat as full confidence
        if decision.match_result is not None and decision.match_result.selected is not None:
            return decision.match_result.selected.confidence
        return 0.0

    @staticmethod
    def _was_llm_resolved(decision: RoutingDecision) -> bool:
        if decision.match_result is None:
            return False
        return decision.match_result.llm_call_id is not None
