"""
Promotion engine — Phase 6.3.

Promotes stable deep-path PASS outcomes into fast-path cache templates and
tracks lightweight metrics for rule usage quality.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from models.finding_models import Finding, FindingStatus, RoutingPath
from storage.fast_path_cache import FastPathCache


@dataclass
class PromotionRecord:
    contract_id: str
    description: str
    charge_term_id: str
    promoted: bool
    reason: str


@dataclass
class RuleMetrics:
    promotions: int = 0
    rule_fires: int = 0
    rule_passes: int = 0

    @property
    def success_rate(self) -> float:
        if self.rule_fires == 0:
            return 0.0
        return round(self.rule_passes / self.rule_fires, 4)


class PromotionEngine:
    """
    Promotion + metrics service.

    Promotion criteria:
    - finding.status == PASS
    - finding.matching_confidence > 0.90
    - finding.routing_path == DEEP_PATH
    - finding has matched charge term id
    """

    def __init__(self, fast_path_cache: FastPathCache) -> None:
        self._cache = fast_path_cache
        self._metrics_by_rule: Dict[str, RuleMetrics] = {}
        self._marked_terms_for_ruleset: Set[str] = set()

    def check_for_promotion(
        self,
        *,
        contract_id: str,
        finding: Finding,
        validators_to_run: Optional[List[str]] = None,
    ) -> PromotionRecord:
        """Promote eligible deep-path findings into fast-path cache templates."""
        if finding.status != FindingStatus.PASS:
            return PromotionRecord(
                contract_id=contract_id,
                description=finding.description,
                charge_term_id=finding.matched_charge_term_id or "",
                promoted=False,
                reason="status_not_pass",
            )

        if finding.matching_confidence <= 0.90:
            return PromotionRecord(
                contract_id=contract_id,
                description=finding.description,
                charge_term_id=finding.matched_charge_term_id or "",
                promoted=False,
                reason="confidence_too_low",
            )

        if finding.routing_path != RoutingPath.DEEP_PATH:
            return PromotionRecord(
                contract_id=contract_id,
                description=finding.description,
                charge_term_id=finding.matched_charge_term_id or "",
                promoted=False,
                reason="not_deep_path",
            )

        if not finding.matched_charge_term_id:
            return PromotionRecord(
                contract_id=contract_id,
                description=finding.description,
                charge_term_id="",
                promoted=False,
                reason="missing_charge_term",
            )

        self._cache.set(
            contract_id=contract_id,
            description=finding.description,
            charge_term_id=finding.matched_charge_term_id,
            validators_to_run=validators_to_run or finding.validators_run,
        )

        rule_id = self._rule_id(contract_id, finding.description)
        metrics = self._metrics_by_rule.setdefault(rule_id, RuleMetrics())
        metrics.promotions += 1
        self._marked_terms_for_ruleset.add(finding.matched_charge_term_id)

        return PromotionRecord(
            contract_id=contract_id,
            description=finding.description,
            charge_term_id=finding.matched_charge_term_id,
            promoted=True,
            reason="promoted",
        )

    def record_rule_firing(self, *, contract_id: str, finding: Finding) -> None:
        """Track fast-path rule usage and pass-rate quality."""
        if finding.routing_path != RoutingPath.FAST_PATH:
            return

        rule_id = self._rule_id(contract_id, finding.description)
        metrics = self._metrics_by_rule.setdefault(rule_id, RuleMetrics())
        metrics.rule_fires += 1
        if finding.status == FindingStatus.PASS:
            metrics.rule_passes += 1

    def get_rule_metrics(self) -> Dict[str, RuleMetrics]:
        return {rule_id: RuleMetrics(**vars(metrics)) for rule_id, metrics in self._metrics_by_rule.items()}

    def get_marked_terms_for_ruleset(self) -> List[str]:
        return sorted(self._marked_terms_for_ruleset)

    @staticmethod
    def _rule_id(contract_id: str, description: str) -> str:
        return f"{contract_id}::{FastPathCache.normalize_description(description)}"
