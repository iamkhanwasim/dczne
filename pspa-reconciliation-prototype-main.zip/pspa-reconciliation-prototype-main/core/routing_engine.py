from __future__ import annotations

from datetime import date
from typing import List, Optional

from graph.graph_repository import GraphRepository
from matching.matching_engine import match_line_to_term
from matching.term_retriever import retrieve_terms_for_contract
from models.contract_models import ChargeTerm
from models.finding_models import RoutingPath
from models.invoice_models import InvoiceLine
from models.routing_models import RoutingDecision
from storage.fast_path_cache import FastPathCache
from utils.errors import MatchingError
from validators.validator_registry import ValidatorRegistry, default_validator_registry


def _validators_for_term(term: ChargeTerm, registry: ValidatorRegistry) -> List[str]:
    return registry.get_validators_for_charge_type(term.charge_type)


def route_line(
    invoice_line: InvoiceLine,
    contract_id: str,
    fast_path_cache: FastPathCache,
    graph_repo: GraphRepository,
    invoice_date: Optional[date] = None,
    location: Optional[str] = None,
    validator_registry: ValidatorRegistry | None = None,
) -> RoutingDecision:
    """
    Route one invoice line using cache-first, then within-contract matching.
    """
    cache_entry = fast_path_cache.get(contract_id=contract_id, description=invoice_line.description)
    registry = validator_registry or default_validator_registry
    if cache_entry is not None:
        return RoutingDecision(
            invoice_line_id=str(invoice_line.line_number),
            route=RoutingPath.FAST_PATH,
            fast_path_hit=True,
            cached_charge_term_id=cache_entry.charge_term_id,
            cache_age_days=cache_entry.age_days(),
            validators_to_run=list(cache_entry.validators_to_run),
        )

    effective_date = invoice_date or invoice_line.service_date or date.today()
    candidates = retrieve_terms_for_contract(
        contract_id=contract_id,
        invoice_date=effective_date,
        graph_repo=graph_repo,
        location=location,
    )
    if not candidates:
        raise MatchingError(f"No active charge terms found for contract {contract_id!r}")

    match_result = match_line_to_term(invoice_line=invoice_line, candidates=candidates)
    validators: List[str] = []

    if match_result.selected is not None:
        validators = _validators_for_term(match_result.selected.charge_term, registry)
        if not match_result.ambiguous and match_result.confidence >= 0.90:
            fast_path_cache.set(
                contract_id=contract_id,
                description=invoice_line.description,
                charge_term_id=match_result.selected.charge_term.id,
                validators_to_run=validators,
            )

    return RoutingDecision(
        invoice_line_id=str(invoice_line.line_number),
        route=RoutingPath.DEEP_PATH,
        fast_path_hit=False,
        match_result=match_result,
        validators_to_run=validators,
    )
