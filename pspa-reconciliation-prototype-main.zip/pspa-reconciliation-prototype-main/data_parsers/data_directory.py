"""
Data directory scanner for demo UI.

Walks the Data/Contract and Invoice Pairs directory to find vendor contracts
and invoices, returning structured VendorPair objects for UI consumption.
"""

from dataclasses import dataclass
from pathlib import Path
from typing import Optional


def _dedupe_sorted(paths: list[Path]) -> list[Path]:
    """Return sorted unique paths while preserving Path objects."""
    return sorted(set(paths))


def _looks_like_contract_pdf(pdf_path: Path) -> bool:
    """Heuristic for root-level contract files when no Contracts folder exists."""
    name = pdf_path.name.lower()
    return any(token in name for token in ("contract", "agreement", "sow", "msa", "terms"))


@dataclass
class VendorPair:
    """Represents a vendor with their contract(s) and invoice PDFs."""

    vendor_name: str
    """Human-readable vendor name (e.g., 'UHS - Experian')"""

    contract_pdfs: list[Path]
    """List of contract PDF paths"""

    invoice_pdfs: list[Path]
    """List of invoice PDF paths (all months combined)"""

    invoice_folders: dict[str, list[Path]]
    """Invoice PDFs grouped by folder name: {'July 2025': [Path, ...], ...}"""

    def __repr__(self) -> str:
        return f"VendorPair({self.vendor_name}, {len(self.contract_pdfs)} contracts, {len(self.invoice_pdfs)} invoices)"


def scan_vendor_pairs(data_root: str | Path) -> list[VendorPair]:
    """
    Scan the Data/Contract and Invoice Pairs directory for vendor pairs.

    Structure expected:
    ```
    data_root/
      UHS - Vendor Name/
        {Vendor} Contracts/
          contract1.pdf
        {Vendor} Invoices/
          January 2025/
            invoice1.pdf
          February 2025/
            invoice2.pdf
    ```

    Args:
        data_root: Root path to search (e.g., 'Data/Contract and Invoice Pairs')

    Returns:
        List of VendorPair objects
    """
    data_root = Path(data_root)
    if not data_root.exists():
        raise FileNotFoundError(f"Data root not found: {data_root}")

    pairs = []

    # Iterate over vendor directories
    for vendor_dir in sorted(data_root.iterdir()):
        if not vendor_dir.is_dir():
            continue

        # Extract vendor name (e.g., 'UHS - Experian' from 'UHS - Experian/')
        vendor_name = vendor_dir.name
        if vendor_name.startswith("."):
            continue

        # Find contracts: standard Contracts directories first
        contract_pdfs: list[Path] = []
        contract_dirs = [item for item in vendor_dir.iterdir() if item.is_dir() and "contract" in item.name.lower()]
        for contract_dir in contract_dirs:
            contract_pdfs.extend(contract_dir.rglob("*.pdf"))

        # Fallback: some vendors place contracts directly under vendor root
        if not contract_pdfs:
            contract_pdfs.extend(
                p for p in vendor_dir.glob("*.pdf") if _looks_like_contract_pdf(p)
            )

        contract_pdfs = _dedupe_sorted(contract_pdfs)

        # Find invoice directories and group by month
        invoice_pdfs: list[Path] = []
        invoice_folders: dict[str, list[Path]] = {}
        invoice_dirs = [item for item in vendor_dir.iterdir() if item.is_dir() and "invoice" in item.name.lower()]
        for invoice_dir in invoice_dirs:
            # Some vendors store invoices directly in the invoice directory
            direct_invoice_pdfs = sorted(invoice_dir.glob("*.pdf"))
            if direct_invoice_pdfs:
                folder_key = f"{invoice_dir.name} (direct)"
                invoice_folders[folder_key] = direct_invoice_pdfs
                invoice_pdfs.extend(direct_invoice_pdfs)

            # Others store invoices in month subfolders
            for month_dir in sorted(invoice_dir.iterdir()):
                if month_dir.is_dir():
                    month_pdfs = sorted(month_dir.glob("*.pdf"))
                    if month_pdfs:
                        folder_key = month_dir.name
                        if folder_key in invoice_folders:
                            folder_key = f"{invoice_dir.name}/{month_dir.name}"
                        invoice_folders[folder_key] = month_pdfs
                        invoice_pdfs.extend(month_pdfs)

        invoice_pdfs = _dedupe_sorted(invoice_pdfs)

        # Only include vendors with at least one contract or invoice
        if contract_pdfs or invoice_pdfs:
            pairs.append(
                VendorPair(
                    vendor_name=vendor_name,
                    contract_pdfs=contract_pdfs,
                    invoice_pdfs=invoice_pdfs,
                    invoice_folders=invoice_folders,
                )
            )

    return pairs


def get_vendor_by_name(data_root: str | Path, vendor_name: str) -> Optional[VendorPair]:
    """
    Get a specific vendor pair by name.

    Args:
        data_root: Root path to search
        vendor_name: Name of the vendor to find

    Returns:
        VendorPair if found, None otherwise
    """
    pairs = scan_vendor_pairs(data_root)
    for pair in pairs:
        if pair.vendor_name.lower() == vendor_name.lower():
            return pair
    return None


def get_all_contract_pdfs(data_root: str | Path) -> dict[str, list[Path]]:
    """
    Get all contract PDFs grouped by vendor.

    Args:
        data_root: Root path to search

    Returns:
        Dict mapping vendor name to list of contract PDF paths
    """
    pairs = scan_vendor_pairs(data_root)
    return {pair.vendor_name: pair.contract_pdfs for pair in pairs if pair.contract_pdfs}


def get_all_invoice_pdfs(data_root: str | Path) -> dict[str, list[Path]]:
    """
    Get all invoice PDFs grouped by vendor.

    Args:
        data_root: Root path to search

    Returns:
        Dict mapping vendor name to list of invoice PDF paths
    """
    pairs = scan_vendor_pairs(data_root)
    return {pair.vendor_name: pair.invoice_pdfs for pair in pairs if pair.invoice_pdfs}
