"""
Invoice parser — YAML and markdown invoice documents → Invoice model.

Supported format (YAML):

    invoice_id: INV-2025-01-001
    vendor_id: abc-cleaning
    vendor_name: ABC Cleaning Services
    customer_name: UHS
    invoice_date: 2025-02-01
    contract_id: abc-cleaning-uh-2025
    lines:
      - line_number: 1
        description: Standard Cleaning
        quantity: 1.0
        unit: month
        unit_rate: 2500.00
        line_amount: 2500.00
    subtotal: 2500.00
    tax_rate: 0.085
    tax_amount: 212.50
    total: 2712.50

Markdown tables are also accepted; any YAML front-matter is extracted first
and the remainder is stored as raw_text.
"""

from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

import re

import yaml

from models.invoice_models import Invoice, InvoiceLine, SupportingDocRef
from utils.errors import ParseError

REQUIRED_INVOICE_FIELDS = [
    "invoice_id",
    "vendor_id",
    "vendor_name",
    "customer_name",
    "invoice_date",
    "contract_id",
]

REQUIRED_LINE_FIELDS = [
    "line_number",
    "description",
    "quantity",
    "unit",
    "unit_rate",
    "line_amount",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _require_str(data: Dict[str, Any], key: str, source: str) -> str:
    value = data.get(key)
    if not value and value != 0:
        raise ParseError(source, f"Missing required field: {key!r}")
    return str(value)


def _parse_date(value: Any, field_name: str, source: str) -> date:
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError) as exc:
        raise ParseError(source, f"Invalid date for {field_name!r}: {value!r}") from exc


def _opt_date(value: Any) -> Optional[date]:
    if value is None or value == "":
        return None
    try:
        return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError):
        return None


def _float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _clean_money(value: str) -> float:
    """Strip $, commas, whitespace then parse as float."""
    cleaned = re.sub(r"[$,\s]", "", value.strip())
    try:
        return float(cleaned)
    except ValueError:
        return 0.0


def _parse_markdown_table_lines(markdown_body: str, source: str) -> List[InvoiceLine]:
    """
    Parse invoice line items from a markdown pipe-table.

    Expected column order: Line | Description | Qty | Unit | Unit Rate | Amount
    Case-insensitive header matching; extra columns are ignored.
    """
    table_rows: List[List[str]] = []
    in_table = False
    header_indices: Dict[str, int] = {}

    for raw_row in markdown_body.splitlines():
        row = raw_row.strip()
        if not row.startswith("|"):
            if in_table:
                break  # table ended
            continue

        cells = [c.strip() for c in row.strip("|").split("|")]

        # Separator row (e.g. |---|---|)
        if all(re.fullmatch(r":?-+:?", c.replace(" ", "")) for c in cells if c):
            in_table = True
            continue

        if not in_table:
            # This is the header row
            for i, cell in enumerate(cells):
                key = cell.lower().strip()
                if key in {"line", "#", "no", "no.", "line no", "line #"}:
                    header_indices["line_number"] = i
                elif key in {"description", "service", "item", "desc"}:
                    header_indices["description"] = i
                elif key in {"qty", "quantity", "units", "hours"}:
                    header_indices["quantity"] = i
                elif key in {"unit", "uom"}:
                    header_indices["unit"] = i
                elif key in {"unit rate", "rate", "price", "unit price"}:
                    header_indices["unit_rate"] = i
                elif key in {"amount", "total", "line amount", "line total", "ext", "ext."}:
                    header_indices["line_amount"] = i
        else:
            table_rows.append(cells)

    if not table_rows:
        return []

    required_cols = {"line_number", "description", "quantity", "unit", "unit_rate", "line_amount"}
    missing = required_cols - set(header_indices.keys())
    if missing:
        raise ParseError(source, f"Invoice line table missing columns: {', '.join(sorted(missing))}")

    lines: List[InvoiceLine] = []
    for row_idx, cells in enumerate(table_rows):
        def _cell(col: str) -> str:
            idx = header_indices.get(col, -1)
            if idx < 0 or idx >= len(cells):
                return ""
            return cells[idx].strip()

        try:
            line_num = int(_cell("line_number"))
        except (ValueError, TypeError):
            line_num = row_idx + 1

        lines.append(
            InvoiceLine(
                line_number=line_num,
                description=_cell("description"),
                quantity=_float(_cell("quantity")),
                unit=_cell("unit"),
                unit_rate=_clean_money(_cell("unit_rate")),
                line_amount=_clean_money(_cell("line_amount")),
            )
        )

    return lines


def _parse_markdown_supporting_docs(
    markdown_body: str,
) -> Dict[int, List[SupportingDocRef]]:
    """
    Parse the ``## Supporting Documents`` section from a markdown invoice body.

    Expects bullet items like::

        - Line 2: PO#1042 attached (pre-approved after-hours cleaning, Jan 15)
        - Line 3: Supply receipt #RS-2025-01-019 attached ($200.00 actual cost)

    Returns a dict mapping line_number → [SupportingDocRef, ...].
    """
    docs_by_line: Dict[int, List[SupportingDocRef]] = {}

    in_section = False
    for raw_line in markdown_body.splitlines():
        heading = raw_line.strip()
        if re.match(r"#+\s+Supporting\s+Doc", heading, re.IGNORECASE):
            in_section = True
            continue
        if in_section and re.match(r"#+\s+", heading):
            break  # next heading ends the section

        if not in_section:
            continue

        # Bullet: "- Line N: <rest>"
        m = re.match(r"[-*]\s+Line\s+(\d+)\s*[:\-]\s*(.+)", raw_line.strip(), re.IGNORECASE)
        if not m:
            continue

        line_num = int(m.group(1))
        rest = m.group(2).strip()

        # Try to extract a dollar amount from parenthetical e.g. "$200.00 actual cost"
        amount: Optional[float] = None
        amt_match = re.search(r"\$\s*([\d,]+(?:\.\d+)?)", rest)
        if amt_match:
            amount = _float(amt_match.group(1).replace(",", ""))

        # Determine doc_type heuristically
        rest_lower = rest.lower()
        if "receipt" in rest_lower or "supply receipt" in rest_lower:
            doc_type = "receipt"
        elif "po#" in rest_lower or "purchase order" in rest_lower:
            doc_type = "PO"
        elif "work order" in rest_lower:
            doc_type = "work_order"
        elif "quote" in rest_lower:
            doc_type = "quote"
        elif "approval" in rest_lower:
            doc_type = "approval"
        else:
            doc_type = "attachment"

        docs_by_line.setdefault(line_num, []).append(
            SupportingDocRef(doc_type=doc_type, reference=rest, amount=amount)
        )

    return docs_by_line


def _parse_markdown_totals(markdown_body: str) -> Dict[str, float]:
    """
    Extract subtotal, tax_rate, tax_amount, total from bold-label lines.

    Matches patterns like:
      **Subtotal:** $3,000.00
      **Sales Tax (8.5%):** $255.00
      **Total Due:** $3,255.00
    """
    result: Dict[str, float] = {}
    for line in markdown_body.splitlines():
        stripped = re.sub(r"\*+", "", line).strip()

        m = re.match(r"Subtotal\s*:\s*(.+)", stripped, re.IGNORECASE)
        if m:
            result["subtotal"] = _clean_money(m.group(1))
            continue

        m = re.match(r"Sales\s+Tax\s*\(([0-9.]+)%\)\s*:\s*(.+)", stripped, re.IGNORECASE)
        if m:
            result["tax_rate"] = float(m.group(1)) / 100
            result["tax_amount"] = _clean_money(m.group(2))
            continue

        m = re.match(r"(?:Total\s+Due|Total\s+Amount|Total)\s*:\s*(.+)", stripped, re.IGNORECASE)
        if m:
            result["total"] = _clean_money(m.group(1))

    return result


def _parse_supporting_docs(raw: Any) -> List[SupportingDocRef]:
    if not isinstance(raw, list):
        return []
    docs: List[SupportingDocRef] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        docs.append(
            SupportingDocRef(
                doc_type=str(item.get("doc_type") or item.get("type") or "unknown"),
                reference=str(item.get("reference") or ""),
                amount=_float(item.get("amount")) if item.get("amount") is not None else None,
                date=_opt_date(item.get("date")),
                notes=str(item.get("notes") or ""),
            )
        )
    return docs


def _parse_line(raw: Dict[str, Any], index: int, source: str) -> InvoiceLine:
    for field in REQUIRED_LINE_FIELDS:
        if raw.get(field) is None:
            raise ParseError(source, f"lines[{index}] missing required field: {field!r}")

    return InvoiceLine(
        line_number=int(raw["line_number"]),
        description=str(raw["description"]),
        quantity=_float(raw["quantity"]),
        unit=str(raw["unit"]),
        unit_rate=_float(raw["unit_rate"]),
        line_amount=_float(raw["line_amount"]),
        service_date=_opt_date(raw.get("service_date")),
        service_period_start=_opt_date(raw.get("service_period_start")),
        service_period_end=_opt_date(raw.get("service_period_end")),
        supporting_docs=_parse_supporting_docs(raw.get("supporting_docs")),
        notes=str(raw.get("notes") or ""),
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def parse_invoice(text: str, source_name: str = "invoice") -> Invoice:
    """
    Parse a YAML or markdown invoice document and return an ``Invoice``.

    Markdown documents must contain a YAML front-matter block (delimited by
    ``---``) whose keys match the required invoice fields; the rest of the
    document is preserved as ``raw_text``.

    Parameters
    ----------
    text:
        Raw invoice document text.
    source_name:
        Filename or label used in error messages.

    Returns
    -------
    Invoice

    Raises
    ------
    ParseError
        If required fields are missing or values cannot be converted.
    """
    raw_text = text
    data: Dict[str, Any] = {}
    markdown_body: str = ""

    # --- YAML front-matter block (for markdown invoices) ---
    stripped = text.strip()
    if stripped.startswith("---"):
        parts = stripped[3:].split("---", 1)
        if len(parts) == 2:
            try:
                data = yaml.safe_load(parts[0]) or {}
                markdown_body = parts[1]
            except yaml.YAMLError:
                data = {}

    # --- Pure YAML invoice ---
    if not data:
        try:
            parsed = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ParseError(source_name, f"YAML parse error: {exc}") from exc

        if not isinstance(parsed, dict):
            raise ParseError(source_name, "Invoice document must be a YAML mapping")
        data = parsed

    # --- Validate required fields ---
    for f in REQUIRED_INVOICE_FIELDS:
        if not data.get(f) and data.get(f) != 0:
            raise ParseError(source_name, f"Missing required invoice field: {f!r}")

    # --- Parse lines — YAML key takes priority; fall back to markdown table ---
    raw_lines = data.get("lines")
    if isinstance(raw_lines, list) and len(raw_lines) > 0:
        lines: List[InvoiceLine] = [
            _parse_line(raw_line, i, source_name)
            for i, raw_line in enumerate(raw_lines)
        ]
    elif markdown_body:
        lines = _parse_markdown_table_lines(markdown_body, source_name)
        if not lines:
            raise ParseError(source_name, "Invoice must contain at least one line (no lines found in YAML or markdown table)")
        # Attach supporting docs parsed from the "## Supporting Documents" section
        supporting_docs_by_line = _parse_markdown_supporting_docs(markdown_body)
        if supporting_docs_by_line:
            line_map = {ln.line_number: ln for ln in lines}
            for line_num, docs in supporting_docs_by_line.items():
                if line_num in line_map:
                    line_map[line_num].supporting_docs = docs
    else:
        raise ParseError(source_name, "Invoice must contain at least one line")

    # --- Totals — YAML key takes priority; fall back to markdown text ---
    md_totals = _parse_markdown_totals(markdown_body) if markdown_body else {}

    subtotal = _float(data.get("subtotal", md_totals.get("subtotal", 0.0)))
    tax_rate_raw = data.get("tax_rate")
    if tax_rate_raw is not None:
        tax_rate: Optional[float] = _float(tax_rate_raw)
    elif "tax_rate" in md_totals:
        tax_rate = md_totals["tax_rate"]
    else:
        tax_rate = None
    tax_amount = _float(data.get("tax_amount", md_totals.get("tax_amount", 0.0)))
    total = _float(data.get("total", md_totals.get("total", 0.0)))

    return Invoice(
        invoice_id=_require_str(data, "invoice_id", source_name),
        vendor_id=_require_str(data, "vendor_id", source_name),
        vendor_name=_require_str(data, "vendor_name", source_name),
        customer_name=_require_str(data, "customer_name", source_name),
        invoice_date=_parse_date(data["invoice_date"], "invoice_date", source_name),
        service_period_start=_opt_date(data.get("service_period_start")),
        service_period_end=_opt_date(data.get("service_period_end")),
        due_date=_opt_date(data.get("due_date")),
        contract_id=_require_str(data, "contract_id", source_name),
        lines=lines,
        subtotal=subtotal,
        tax_rate=tax_rate,
        tax_amount=tax_amount,
        total=total,
        raw_text=raw_text,
        source_path=source_name,
    )
