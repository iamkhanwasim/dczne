"""
Markdown parsing utilities for contract and invoice documents.

This parser supports:
- YAML frontmatter extraction
- Section extraction with source line ranges
- Markdown table extraction with structured rows
- Lightweight structured field extraction (dates, amounts)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Dict, List, Optional

import yaml

from utils.errors import ParseError


@dataclass
class ParsedSection:
    title: str
    level: int
    start_line: int
    end_line: int
    content: str


@dataclass
class ParsedTable:
    start_line: int
    end_line: int
    headers: List[str]
    rows: List[Dict[str, str]] = field(default_factory=list)
    raw_text: str = ""


@dataclass
class ParsedMarkdownDocument:
    source_name: str
    metadata: Dict[str, Any]
    body: str
    sections: List[ParsedSection]
    tables: List[ParsedTable]
    structured_fields: Dict[str, Any]


HEADING_RE = re.compile(r"^(#{1,6})\s+(.+?)\s*$")
TABLE_SEPARATOR_RE = re.compile(r"^\s*\|?\s*[:\-]+(?:\s*\|\s*[:\-]+)+\s*\|?\s*$")
MONEY_RE = re.compile(r"\$\s?\d[\d,]*(?:\.\d{2})?")


def _split_frontmatter(text: str) -> tuple[Dict[str, Any], str, int]:
    lines = text.splitlines()
    if not lines:
        return {}, "", 1
    if lines[0].strip() != "---":
        return {}, text, 1

    for index in range(1, len(lines)):
        if lines[index].strip() == "---":
            raw_meta = "\n".join(lines[1:index])
            try:
                metadata = yaml.safe_load(raw_meta) or {}
            except yaml.YAMLError as exc:
                raise ParseError("frontmatter", f"Invalid YAML frontmatter: {exc}") from exc
            body = "\n".join(lines[index + 1 :])
            body_start_line = index + 2
            return metadata, body, body_start_line

    raise ParseError("frontmatter", "Unterminated YAML frontmatter block")


def _parse_tables(body_lines: List[str], body_start_line: int) -> List[ParsedTable]:
    tables: List[ParsedTable] = []
    i = 0
    while i < len(body_lines) - 1:
        line = body_lines[i]
        next_line = body_lines[i + 1]
        if "|" in line and TABLE_SEPARATOR_RE.match(next_line.strip()):
            start = i
            j = i + 2
            while j < len(body_lines) and "|" in body_lines[j]:
                j += 1

            raw_rows = body_lines[start:j]
            header_cols = [c.strip() for c in line.strip().strip("|").split("|")]
            rows: List[Dict[str, str]] = []
            for row_line in raw_rows[2:]:
                values = [c.strip() for c in row_line.strip().strip("|").split("|")]
                if len(values) != len(header_cols):
                    continue
                rows.append(dict(zip(header_cols, values)))

            tables.append(
                ParsedTable(
                    start_line=body_start_line + start,
                    end_line=body_start_line + j - 1,
                    headers=header_cols,
                    rows=rows,
                    raw_text="\n".join(raw_rows),
                )
            )
            i = j
            continue
        i += 1
    return tables


def _parse_sections(body_lines: List[str], body_start_line: int) -> List[ParsedSection]:
    sections: List[ParsedSection] = []
    current_title: Optional[str] = None
    current_level = 0
    current_start: Optional[int] = None
    current_content: List[str] = []

    preamble: List[str] = []
    first_heading_line: Optional[int] = None

    for idx, line in enumerate(body_lines):
        absolute_line = body_start_line + idx
        match = HEADING_RE.match(line)
        if match:
            if first_heading_line is None:
                first_heading_line = absolute_line
            if current_title is not None and current_start is not None:
                sections.append(
                    ParsedSection(
                        title=current_title,
                        level=current_level,
                        start_line=current_start,
                        end_line=absolute_line - 1,
                        content="\n".join(current_content).strip(),
                    )
                )
            current_level = len(match.group(1))
            current_title = match.group(2).strip()
            current_start = absolute_line
            current_content = []
        else:
            if current_title is None:
                preamble.append(line)
            else:
                current_content.append(line)

    if preamble and first_heading_line is not None:
        sections.insert(
            0,
            ParsedSection(
                title="Preamble",
                level=0,
                start_line=body_start_line,
                end_line=first_heading_line - 1,
                content="\n".join(preamble).strip(),
            ),
        )
    elif preamble and first_heading_line is None:
        sections.append(
            ParsedSection(
                title="Preamble",
                level=0,
                start_line=body_start_line,
                end_line=body_start_line + len(body_lines) - 1,
                content="\n".join(preamble).strip(),
            )
        )

    if current_title is not None and current_start is not None:
        sections.append(
            ParsedSection(
                title=current_title,
                level=current_level,
                start_line=current_start,
                end_line=body_start_line + len(body_lines) - 1,
                content="\n".join(current_content).strip(),
            )
        )

    return sections


def _parse_date(raw: str) -> Optional[str]:
    raw = raw.strip()
    try:
        return date.fromisoformat(raw).isoformat()
    except ValueError:
        pass
    for fmt in ("%B %d, %Y", "%b %d, %Y"):
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            continue
    return None


def _extract_structured_fields(body: str, metadata: Dict[str, Any]) -> Dict[str, Any]:
    fields: Dict[str, Any] = {}

    for key in ("contract_id", "invoice_id", "vendor_id", "vendor_name", "customer_name", "customer_id"):
        if key in metadata:
            fields[key] = metadata[key]

    for key in ("effective_date", "renewal_date", "invoice_date", "service_period_start", "service_period_end", "due_date"):
        if key in metadata and metadata[key] is not None:
            parsed = _parse_date(str(metadata[key]))
            fields[key] = parsed or str(metadata[key])

    body_lines = body.splitlines()
    inline_dates: Dict[str, str] = {}
    for line in body_lines:
        normalized = line.strip().strip("*")
        if ":" not in normalized:
            continue
        label, value = [p.strip() for p in normalized.split(":", 1)]
        parsed = _parse_date(value)
        if not parsed:
            continue
        if "effective date" in label.lower():
            inline_dates["effective_date"] = parsed
        elif "renewal date" in label.lower():
            inline_dates["renewal_date"] = parsed
        elif "invoice date" in label.lower():
            inline_dates["invoice_date"] = parsed
        elif "due date" in label.lower():
            inline_dates["due_date"] = parsed

    for key, value in inline_dates.items():
        fields.setdefault(key, value)

    amounts = MONEY_RE.findall(body)
    if amounts:
        fields["amount_mentions"] = amounts

    return fields


def parse_markdown(text: str, source_name: str = "document.md") -> ParsedMarkdownDocument:
    """Parse markdown content into metadata, sections, tables, and structured fields."""
    if not text or not text.strip():
        raise ParseError(source_name, "Document is empty")

    metadata, body, body_start_line = _split_frontmatter(text)
    body_lines = body.splitlines()

    sections = _parse_sections(body_lines, body_start_line)
    tables = _parse_tables(body_lines, body_start_line)
    structured_fields = _extract_structured_fields(body, metadata)

    return ParsedMarkdownDocument(
        source_name=source_name,
        metadata=metadata,
        body=body,
        sections=sections,
        tables=tables,
        structured_fields=structured_fields,
    )
