"""
Parser registry for format detection and parser dispatch.
"""

from __future__ import annotations

from enum import Enum
from pathlib import Path
from typing import Union

import yaml

from data_parsers.markdown_parser import ParsedMarkdownDocument, parse_markdown
from data_parsers.yaml_parser import ParsedYamlDocument, parse_yaml
from utils.errors import ParseError


ParsedDocument = Union[ParsedMarkdownDocument, ParsedYamlDocument]


class DocumentFormat(str, Enum):
    MARKDOWN = "markdown"
    YAML = "yaml"


def detect_format(content: str, source_name: str = "document") -> DocumentFormat:
    """Detect input format from source name and content heuristics."""
    suffix = Path(source_name).suffix.lower()
    if suffix in {".md", ".markdown"}:
        return DocumentFormat.MARKDOWN
    if suffix in {".yaml", ".yml"}:
        return DocumentFormat.YAML

    stripped = content.lstrip()

    # Markdown files can begin with YAML front-matter delimiters.
    # If we see a second delimiter later in the content, treat as markdown.
    if stripped.startswith("---"):
        remainder = stripped[3:]
        if "---" in remainder:
            return DocumentFormat.MARKDOWN

    if stripped.startswith("#") or "|---" in content or "| ---" in content:
        return DocumentFormat.MARKDOWN

    try:
        parsed = yaml.safe_load(content)
    except yaml.YAMLError:
        parsed = None
    if isinstance(parsed, dict):
        return DocumentFormat.YAML

    raise ParseError(source_name, "Unable to detect document format (expected markdown or YAML)")


def parse_document(content: str, source_name: str = "document") -> ParsedDocument:
    """Auto-detect document format and dispatch to parser."""
    document_format = detect_format(content, source_name=source_name)
    if document_format == DocumentFormat.MARKDOWN:
        return parse_markdown(content, source_name=source_name)
    if document_format == DocumentFormat.YAML:
        return parse_yaml(content, source_name=source_name)
    raise ParseError(source_name, f"Unsupported format: {document_format}")
