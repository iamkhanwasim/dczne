"""
PDF extraction layer for demo UI.

Wraps PyMuPDF (fitz) to extract text and render pages as images.
Supports both contracts and invoices; returns structured data for UI consumption.
"""

import io
import os
import re
import shutil
from pathlib import Path
from typing import Optional

import fitz  # PyMuPDF


def _is_low_quality_text(text: str) -> bool:
    """Heuristic: detect OCR-like garbage from native extractor and prefer OCR output."""
    candidate = (text or "").strip()
    if not candidate:
        return True

    lines = [line.strip() for line in candidate.splitlines() if line.strip()]
    if len(lines) <= 2 and len(candidate) < 80:
        return True

    words = re.findall(r"[A-Za-z]+", candidate)
    if not words:
        return True

    short_words = sum(1 for word in words if len(word) <= 2)
    short_ratio = short_words / max(len(words), 1)

    tiny_token_lines = 0
    for line in lines:
        compact = re.sub(r"[^A-Za-z]", "", line)
        if 1 <= len(compact) <= 2:
            tiny_token_lines += 1

    unique_word_ratio = len(set(word.lower() for word in words)) / max(len(words), 1)
    alpha_chars = sum(1 for ch in candidate if ch.isalpha())
    total_chars = len(candidate)
    alpha_ratio = alpha_chars / max(total_chars, 1)

    # Common garbage patterns in noisy native extraction: many tiny repeated tokens.
    if short_ratio > 0.60 and unique_word_ratio < 0.45:
        return True

    if tiny_token_lines >= 6:
        return True

    if alpha_ratio < 0.25 and len(candidate) < 250:
        return True

    return False


def _resolve_tesseract_cmd() -> Optional[str]:
    cmd = shutil.which("tesseract")
    if cmd:
        return cmd

    env_cmd = (os.getenv("TESSERACT_CMD", "") or "").strip().strip('"')
    env_path = Path(env_cmd) if env_cmd else None

    candidates = [
        env_path,
        Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
        Path(r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"),
        Path.home() / "AppData" / "Local" / "Programs" / "Tesseract-OCR" / "tesseract.exe",
    ]
    for candidate in candidates:
        if (
            candidate
            and str(candidate).strip()
            and candidate.exists()
            and candidate.is_file()
            and candidate.name.lower() == "tesseract.exe"
        ):
            return str(candidate)
    return None


def get_ocr_engine_status() -> dict:
    cmd = _resolve_tesseract_cmd()
    if cmd:
        return {"available": True, "tesseract_cmd": cmd}
    return {
        "available": False,
        "tesseract_cmd": None,
        "reason": "Tesseract executable not found (set TESSERACT_CMD or install Tesseract OCR)",
    }


def _ocr_text_from_pixmap(pix: fitz.Pixmap) -> tuple[str, str]:
    try:
        from PIL import Image, ImageEnhance, ImageFilter, ImageOps
        import pytesseract
    except Exception as exc:
        return "", f"OCR dependencies unavailable: {exc}"

    tesseract_cmd = _resolve_tesseract_cmd()
    if not tesseract_cmd:
        return "", "Tesseract executable not found (install Tesseract OCR or set TESSERACT_CMD)"
    pytesseract.pytesseract.tesseract_cmd = tesseract_cmd

    try:
        image = Image.open(io.BytesIO(pix.tobytes("png")))
        gray = ImageOps.grayscale(image)
        contrast = ImageEnhance.Contrast(gray).enhance(2.0)
        sharpen = contrast.filter(ImageFilter.SHARPEN)
        threshold = sharpen.point(lambda x: 255 if x > 160 else 0, mode="1")

        variants = {
            "gray": gray,
            "contrast": contrast,
            "threshold": threshold,
        }
        configs = [
            "--oem 3 --psm 11",
            "--oem 3 --psm 6",
            "--oem 1 --psm 4",
        ]

        best_text = ""
        best_score = -1.0

        for variant in variants.values():
            for config in configs:
                try:
                    candidate = pytesseract.image_to_string(variant, config=config).strip()
                except Exception:
                    continue

                if not candidate:
                    continue

                words = re.findall(r"[A-Za-z]{3,}", candidate)
                unique_words = len(set(word.lower() for word in words))
                letters = sum(ch.isalpha() for ch in candidate)
                score = letters + (unique_words * 6)

                if score > best_score:
                    best_score = score
                    best_text = candidate

        if best_text:
            return best_text, ""
        return "", "OCR produced no usable text"
    except Exception as exc:
        return "", f"OCR execution failed: {exc}"


def extract_text(pdf_path: str | Path) -> str:
    """
    Extract all text from a PDF, with page breaks marked.

    Args:
        pdf_path: Path to PDF file

    Returns:
        Full extracted text with "-- Page N --" separators
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(pdf_path)
    text_parts = []

    try:
        for page_num, page in enumerate(doc, start=1):
            text = page.get_text("text")
            if text.strip():
                text_parts.append(f"-- Page {page_num} --\n{text}")
            else:
                text_parts.append(f"-- Page {page_num} --\n[No extractable text (possible image-only page)]")
    finally:
        doc.close()

    return "\n\n".join(text_parts)


def render_pages(pdf_path: str | Path, dpi: int = 150) -> list[bytes]:
    """
    Render each page of a PDF as a PNG image.

    Args:
        pdf_path: Path to PDF file
        dpi: Resolution for rendering (default 150 DPI)

    Returns:
        List of PNG bytes, one per page
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(pdf_path)
    images = []
    zoom = dpi / 72  # PyMuPDF uses 72 DPI as base

    try:
        for page in doc:
            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            img_bytes = pix.tobytes("png")
            images.append(img_bytes)
    finally:
        doc.close()

    return images


def extract_text_and_pages(pdf_path: str | Path, dpi: int = 150) -> tuple[str, list[bytes]]:
    """
    Extract text and render pages from a PDF in a single call.

    Args:
        pdf_path: Path to PDF file
        dpi: Resolution for rendering (default 150 DPI)

    Returns:
        Tuple of (extracted_text, page_images)
    """
    text = extract_text(pdf_path)
    images = render_pages(pdf_path, dpi=dpi)
    return text, images


def extract_text_with_ocr_fallback(pdf_path: str | Path, dpi: int = 300) -> str:
    """
    Extract text from PDF pages with OCR fallback for image-only pages.

    Args:
        pdf_path: Path to PDF file
        dpi: Rendering resolution for OCR (higher improves OCR quality)

    Returns:
        Full extracted text with page markers. OCR text is used when native text extraction is empty.
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(pdf_path)
    text_parts = []
    zoom = dpi / 72

    try:
        for page_num, page in enumerate(doc, start=1):
            native_text = page.get_text("text").strip()
            native_low_quality = _is_low_quality_text(native_text)

            if native_text and not native_low_quality:
                text_parts.append(f"-- Page {page_num} --\n{native_text}")
                continue

            pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
            ocr_text, ocr_error = _ocr_text_from_pixmap(pix)

            if ocr_text:
                text_parts.append(f"-- Page {page_num} --\n{ocr_text}")
            elif native_text:
                # Keep native text as fallback if OCR failed, even if quality is poor.
                text_parts.append(f"-- Page {page_num} --\n{native_text}")
            else:
                suffix = f" ({ocr_error})" if ocr_error else ""
                text_parts.append(
                    f"-- Page {page_num} --\n[No extractable text after OCR fallback{suffix}]"
                )
    finally:
        doc.close()

    return "\n\n".join(text_parts)


def get_page_count(pdf_path: str | Path) -> int:
    """
    Get the number of pages in a PDF.

    Args:
        pdf_path: Path to PDF file

    Returns:
        Number of pages
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(pdf_path)
    try:
        return len(doc)
    finally:
        doc.close()


def get_pdf_metadata(pdf_path: str | Path) -> dict:
    """
    Extract basic metadata from a PDF.

    Args:
        pdf_path: Path to PDF file

    Returns:
        Dictionary with: title, author, subject, creator, page_count, file_size
    """
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = fitz.open(pdf_path)
    try:
        meta = doc.metadata or {}
        return {
            "title": meta.get("title") or "Untitled",
            "author": meta.get("author") or "Unknown",
            "subject": meta.get("subject") or "",
            "creator": meta.get("creator") or "",
            "page_count": len(doc),
            "file_size": pdf_path.stat().st_size,
        }
    finally:
        doc.close()
