"""Utilities for loading/writing sidecar text files adjacent to PDFs."""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple


def sidecar_candidates(pdf_path: str | Path) -> list[Path]:
    path = Path(pdf_path)
    return [
        path.with_suffix('.txt'),
        path.with_suffix('.md'),
        Path(f"{path}.txt"),
        Path(f"{path}.md"),
    ]


def load_sidecar_text(pdf_path: str | Path) -> Tuple[Optional[str], Optional[Path]]:
    for candidate in sidecar_candidates(pdf_path):
        if candidate.exists() and candidate.is_file():
            try:
                text = candidate.read_text(encoding='utf-8', errors='replace')
            except Exception:
                continue
            return text, candidate
    return None, None


def write_sidecar_text(pdf_path: str | Path, text: str, suffix: str = '.txt') -> Path:
    path = Path(pdf_path)
    sidecar = path.with_suffix(suffix)
    sidecar.write_text(text, encoding='utf-8')
    return sidecar
