"""
YAML parsing utilities for structured contract/invoice documents.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Any, Dict, List, Optional

import yaml

from models.contract_models import ChargeTerm, ChargeType, EffectivePeriod, SourceCitation
from utils.errors import ParseError


@dataclass
class ParsedYamlDocument:
    source_name: str
    data: Dict[str, Any]
    charge_terms: List[ChargeTerm] = field(default_factory=list)


REQUIRED_CONTRACT_FIELDS = [
    "contract_id",
    "vendor_id",
    "vendor_name",
    "customer_name",
]


def _parse_date(value: Any, field_name: str, source_name: str) -> Optional[date]:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError as exc:
        raise ParseError(source_name, f"Invalid date for {field_name}: {value!r}") from exc


def _validate_required_fields(data: Dict[str, Any], source_name: str) -> None:
    missing = [field for field in REQUIRED_CONTRACT_FIELDS if not data.get(field)]
    if missing:
        raise ParseError(source_name, f"Missing required fields: {', '.join(missing)}")


def _parse_charge_type(raw: Any, source_name: str, index: int) -> ChargeType:
    if raw is None:
        raise ParseError(source_name, f"charge_terms[{index}].charge_type is required")
    try:
        return ChargeType(str(raw))
    except ValueError as exc:
        valid = ", ".join([member.value for member in ChargeType])
        raise ParseError(
            source_name,
            f"Invalid charge_type {raw!r} in charge_terms[{index}]. Valid values: {valid}",
        ) from exc


def _extract_charge_terms(data: Dict[str, Any], source_name: str) -> List[ChargeTerm]:
    raw_terms = data.get("charge_terms") or []
    if not isinstance(raw_terms, list):
        raise ParseError(source_name, "charge_terms must be a list when provided")

    relationship_id = str(data.get("contract_id", ""))
    charge_terms: List[ChargeTerm] = []

    for index, raw_term in enumerate(raw_terms):
        if not isinstance(raw_term, dict):
            raise ParseError(source_name, f"charge_terms[{index}] must be an object")

        term_id = raw_term.get("id")
        name = raw_term.get("name")
        rate = raw_term.get("rate")
        rate_unit = raw_term.get("rate_unit")
        if not term_id or not name or rate is None or not rate_unit:
            raise ParseError(
                source_name,
                f"charge_terms[{index}] missing required fields (id, name, rate, rate_unit)",
            )

        effective_period_obj: Optional[EffectivePeriod] = None
        effective_period = raw_term.get("effective_period")
        if isinstance(effective_period, dict) and effective_period.get("start") and effective_period.get("end"):
            effective_period_obj = EffectivePeriod(
                start=_parse_date(effective_period.get("start"), "effective_period.start", source_name),
                end=_parse_date(effective_period.get("end"), "effective_period.end", source_name),
            )

        source_citation: Optional[SourceCitation] = None
        source = raw_term.get("source")
        if isinstance(source, dict) and source.get("document_id"):
            source_citation = SourceCitation(
                document_id=str(source.get("document_id")),
                document_type=str(source.get("document_type", "")),
                page=source.get("page"),
                section=source.get("section"),
                line_reference=source.get("line_reference"),
                span_text=source.get("span_text"),
            )

        charge_terms.append(
            ChargeTerm(
                id=str(term_id),
                vendor_relationship_id=str(raw_term.get("vendor_relationship_id", relationship_id)),
                name=str(name),
                service_scope=str(raw_term.get("service_scope", "")),
                charge_type=_parse_charge_type(raw_term.get("charge_type"), source_name, index),
                rate=float(rate),
                rate_unit=str(rate_unit),
                rate_currency=str(raw_term.get("rate_currency", "USD")),
                billing_interval=str(raw_term.get("billing_interval", "")),
                invoice_cadence=str(raw_term.get("invoice_cadence", "")),
                location_scope=[str(value) for value in raw_term.get("location_scope", [])],
                effective_period=effective_period_obj,
                effective_date=_parse_date(raw_term.get("effective_date"), "effective_date", source_name),
                renewal_date=_parse_date(raw_term.get("renewal_date"), "renewal_date", source_name),
                preconditions=[str(value) for value in raw_term.get("preconditions", [])],
                is_passthrough=bool(raw_term.get("is_passthrough", False)),
                requires_cost_evidence=bool(raw_term.get("requires_cost_evidence", False)),
                max_amount=raw_term.get("max_amount"),
                overage_rate=raw_term.get("overage_rate"),
                included_quantity=raw_term.get("included_quantity"),
                contingency_pct=raw_term.get("contingency_pct"),
                source=source_citation,
                extraction_confidence=float(raw_term.get("extraction_confidence", 1.0)),
                extraction_notes=str(raw_term.get("extraction_notes", "")),
            )
        )

    return charge_terms


def parse_yaml(text: str, source_name: str = "document.yaml") -> ParsedYamlDocument:
    """Parse YAML content and extract structured charge terms when present."""
    if not text or not text.strip():
        raise ParseError(source_name, "Document is empty")

    try:
        loaded = yaml.safe_load(text)
    except yaml.YAMLError as exc:
        raise ParseError(source_name, f"Invalid YAML: {exc}") from exc

    if not isinstance(loaded, dict):
        raise ParseError(source_name, "YAML root must be an object")

    _validate_required_fields(loaded, source_name)
    charge_terms = _extract_charge_terms(loaded, source_name)

    return ParsedYamlDocument(
        source_name=source_name,
        data=loaded,
        charge_terms=charge_terms,
    )
