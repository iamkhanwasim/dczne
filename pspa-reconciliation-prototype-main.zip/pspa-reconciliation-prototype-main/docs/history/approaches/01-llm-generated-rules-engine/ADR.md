# ADR: Use LLMs to Generate Deterministic Vendor Rulesets

## Status

Proposed.

## Context

The corpus contains repeatable billing patterns that can be expressed as
deterministic rules: Experian monthly fees and overages, Quality Lawn
location-specific service charges, Reputation.com semiannual payments, NRC
quarterly membership fees, and Johnson Controls annual inspection plans.

However, the contracts also include amendments, SOWs, pass-throughs, exclusions,
and conditions that are easy to miss if rules are manually authored from
unstructured documents.

## Decision

Use LLMs to propose vendor-specific rulesets from normalized contract evidence,
but require deterministic execution, schema validation, regression tests, and
human approval before a ruleset can block or approve payment.

## Consequences

Positive:

- Efficient invoice-time processing.
- Clear audit trail from finding to rule to source evidence.
- Rules can be tested against historical invoices.
- LLM variability is moved out of the payment-time path.

Negative:

- Requires onboarding workflow and reviewer capacity.
- Generated rules can encode extraction errors.
- Requires version control for rule changes and amendment precedence.
- Harder to use for one-off contracts or ambiguous deliverable acceptance.

## Guardrails

- No generated rule becomes active without source evidence and review status.
- Rules must compile from a schema, not free-form code.
- Runtime cannot call an LLM to decide arithmetic.
- Any invoice line with no high-confidence rule match goes to review or fallback
  adjudication.
