# Approach 1: LLM-Generated Rules Engine

## Summary

Use an LLM during contract onboarding to convert each vendor relationship into
versioned, executable reconciliation rules. At invoice time, the system parses
the invoice into normalized header and line items, selects the active vendor
ruleset, and runs deterministic checks.

This approach is strongest for repeat vendors with stable, high-volume invoices
where the cost of human-reviewed rule synthesis is paid back over many invoice
runs.

## How It Enables Reconciliation

1. Ingest all governing documents for a vendor relationship.
2. Extract clauses, tables, schedules, service locations, term dates, pricing,
   billing cadence, exclusions, pass-throughs, and amendment precedence.
3. Ask an LLM to synthesize a structured ruleset from the extracted evidence.
4. Validate the generated rules through schema checks, generated test cases,
   human review, and sample invoices.
5. Compile the ruleset to a deterministic runtime.
6. Parse each received invoice into the shared invoice model.
7. Execute rules line-by-line and invoice-total checks.
8. Return findings with rule ids and source evidence.

## Rule Inputs

The runtime receives normalized objects, not raw PDFs:

- `vendor_relationship`
- active `contract_documents`
- normalized `charge_terms`
- normalized `invoice`
- normalized `invoice_lines`
- optional delivery evidence, usage files, PO data, and payment/recovery data

The ontology model remains useful even in this approach because it provides the
normal form from which rules are generated.

## Ruleset Structure

Each vendor ruleset should include:

- Metadata: vendor, customer entity, version, effective period, source docs.
- Precedence graph: master agreement, amendments, SOWs, change orders, renewals.
- Service catalog: service names, aliases, invoice descriptions, locations,
  account codes, SKUs, and service periods.
- Charge terms: amount calculation, cadence, included quantities, overages,
  floors, caps, taxes, pass-throughs, contingency percentages.
- Preconditions: PO required, written change order required, accepted
  deliverable required, recovery received, service event occurred.
- Line matchers: deterministic criteria for mapping invoice lines to charge
  terms.
- Invoice checks: subtotal, tax, credit, total, duplicate invoice, due date.
- Evidence links: source document, page, table row, or span for every rule.

## Example Rules

See `example-ruleset.json` for a compact ruleset containing examples from the
corpus:

- Experian claims-based subscription and transaction overage logic.
- Quality Lawn location/service pricing and tax exemption.
- HealthROI contingency fee dependency on realized recovery.

## Strengths

- Low invoice-time cost and latency.
- Deterministic arithmetic and repeatable outcomes.
- Good auditability when every rule points to source evidence.
- Easy to regression-test with known invoices.
- Works well for high-volume relationships like Experian or recurring
  location-based services.

## Weaknesses

- Rule synthesis can be wrong if document extraction misses a table, amendment,
  or exception.
- Rules can become brittle when invoice descriptions change.
- Multi-document precedence and partial amendments still require a robust
  contract model.
- Low-volume or unusual services may not justify custom ruleset review.
- Ambiguous contract language still needs human or LLM adjudication.

## Best Fit

Use for vendors where:

- invoices recur monthly, quarterly, or semiannually;
- pricing is mostly formulaic;
- the same charge terms are reused;
- a human can review the generated rules before payment impact;
- deterministic auditability matters more than rapid onboarding.

## Not Enough By Itself

This approach should not be the only layer. It needs:

- a contract evidence model;
- OCR/table extraction;
- rule review workflow;
- drift detection when invoice patterns change;
- a fallback path for unmatched or ambiguous invoice lines.
