# Implementation Plan

## Phase 1: Ruleset Schema

- Define a vendor ruleset JSON schema aligned to the ontology.
- Define charge calculators for fixed, recurring, usage, tiered usage,
  per-location, pass-through, tax, and contingency fees.
- Define source evidence and reviewer metadata requirements.

## Phase 2: Contract Onboarding

- Extract contract text, tables, schedules, and amendments.
- Populate normalized contract terms.
- Ask an LLM to draft a ruleset from the normalized terms.
- Generate contract-derived test cases for each charge term.

## Phase 3: Review and Activation

- Provide reviewer UI or review packet showing rule, source evidence, and test
  cases.
- Require approval before ruleset activation.
- Version rulesets by vendor relationship and effective date.

## Phase 4: Invoice Runtime

- Parse invoices into normalized header and line items.
- Select active ruleset by vendor, customer entity, date, account, PO, and
  facility.
- Run line matchers and calculators.
- Recompute totals and taxes.
- Emit findings with rule ids and source evidence.

## Phase 5: Monitoring

- Track unmatched lines, ambiguous matches, recurring variance, and invoice
  description drift.
- Trigger ruleset review when amendments are added or invoice patterns change.
- Maintain regression suites from historical invoices.

## Pilot Vendors

- Experian for high-volume usage/subscription logic.
- Quality Lawn for location-specific service terms.
- Reputation.com or NRC for scheduled recurring payments.
