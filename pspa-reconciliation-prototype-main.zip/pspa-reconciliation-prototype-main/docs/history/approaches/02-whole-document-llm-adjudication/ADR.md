# ADR: Use Whole-Document LLM Adjudication Only as Assisted Review or Fallback

## Status

Proposed.

## Context

The user asked whether the system could simply ingest the entire contract and
invoice together. Modern LLMs can reason across narrative contract terms and
invoice line descriptions, which is attractive for rapid prototyping. The corpus
also includes scanned invoices, encrypted documents, amendments, tables, and
formula-heavy pricing that increase the risk of missed evidence and arithmetic
errors.

## Decision

Whole-document LLM adjudication may be used for triage, reviewer assistance, and
fallback handling, but should not be the primary autonomous reconciliation
engine for payment-impacting decisions.

## Consequences

Positive:

- Rapid prototype path.
- Good coverage of unusual invoice narratives.
- Useful for generating explanations and identifying missing evidence.

Negative:

- Requires strong retrieval and source citation verification.
- Requires deterministic arithmetic checks outside the LLM.
- Can be inconsistent across runs.
- Harder to audit than explicit rules or graph-backed findings.

## Guardrails

- LLM output must be schema-constrained.
- Every finding must cite specific source evidence.
- An external calculator recomputes all amounts and totals.
- Findings above dollar or risk thresholds require human review.
- No uncited finding can be treated as final.
