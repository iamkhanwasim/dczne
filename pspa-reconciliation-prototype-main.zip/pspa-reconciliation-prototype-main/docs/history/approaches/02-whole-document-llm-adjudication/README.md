# Approach 2: Whole-Document LLM Adjudication

## Summary

At invoice time, provide the LLM with the full governing contract set, extracted
invoice, supporting usage/delivery evidence, and a structured adjudication
prompt. The model returns line-level and invoice-level compliance findings with
citations and required follow-up.

This approach is the fastest to prototype and can handle unusual documents, but
it is the weakest as a primary payment-control mechanism unless surrounded by
retrieval, arithmetic tools, citation checks, and human review.

## How It Enables Reconciliation

1. Ingest contract documents and invoice documents.
2. Extract text, tables, and document metadata.
3. Retrieve the most relevant contract pages, schedules, amendments, and prior
   findings for the invoice.
4. Provide the invoice and retrieved contract evidence to an LLM adjudicator.
5. Require the LLM to output a strict JSON finding schema.
6. Independently verify arithmetic, totals, date comparisons, and cited source
   references.
7. Route high-confidence, low-risk findings to a reviewer or downstream workflow.
8. Send low-confidence, uncited, or high-dollar-impact findings to human review.

## Required Prompt Inputs

- Vendor relationship metadata.
- Ordered contract document list with document roles and precedence hints.
- Extracted invoice header, line items, totals, taxes, and remittance data.
- Retrieved source passages and table rows.
- External supporting evidence, if needed:
  - PO/work order;
  - usage file;
  - delivery or inspection log;
  - recovery/payment evidence;
  - tax exemption certificate.
- The output schema.

## Output Requirements

The LLM must return:

- one decision per invoice line;
- invoice-total decision;
- supporting source citations;
- expected amount and actual amount;
- variance amount;
- confidence;
- reason code;
- missing evidence;
- recommended next action.

See `example-adjudication-output.json`.

## Strengths

- Fastest way to explore the reconciliation problem space.
- Handles one-off SOWs and unusual invoice descriptions better than a rigid
  ruleset.
- Can reason across narrative terms and schedules when retrieval is good.
- Useful as a human-review copilot.

## Weaknesses

- Higher cost and latency at invoice time.
- Non-deterministic unless tightly constrained.
- Long contracts plus multiple amendments can exceed context limits.
- Arithmetic, date logic, and total reconciliation need independent tools.
- Citation fidelity must be verified.
- Hard to certify for automatic payment approval or denial.

## Best Fit

Use for:

- low-volume vendors;
- first-pass triage;
- unmatched invoice lines from deterministic rules;
- explanation drafting for reviewers;
- exploratory pilots before investing in a ruleset or ontology extraction.

## Not Recommended As Sole Engine

The corpus contains enough formulaic and high-dollar billing patterns that raw
LLM adjudication should not be the only decision layer. Experian-style
transaction packages, HealthROI contingency fees, and tax/total checks all
benefit from deterministic validation.
