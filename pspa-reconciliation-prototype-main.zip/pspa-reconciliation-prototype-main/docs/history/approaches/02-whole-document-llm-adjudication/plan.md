# Implementation Plan

## Phase 1: Evidence Packet Builder

- Extract source text and tables.
- Classify document roles and precedence.
- Normalize invoice lines.
- Retrieve candidate source evidence for each invoice line.
- Build a compact adjudication packet with source ids.

## Phase 2: Adjudication Prompt and Schema

- Define a strict JSON output schema.
- Require one finding per invoice line and one invoice-total finding.
- Require citations to source ids.
- Require missing-evidence statements for low-confidence decisions.

## Phase 3: Verification Layer

- Verify cited source ids exist in the packet.
- Recompute all expected amounts, actual amounts, variances, taxes, and totals.
- Check date ranges, service periods, and invoice cadence.
- Flag any discrepancy between LLM math and calculator math.

## Phase 4: Review Workflow

- Build review queues by risk:
  - auto-suggested compliant;
  - non-compliant;
  - missing evidence;
  - ambiguous;
  - extraction failure.
- Capture reviewer disposition to improve future retrieval and prompts.

## Phase 5: Fallback Integration

- Use this approach when generated rules cannot match a line.
- Use it to bootstrap candidate terms for ontology population.
- Use reviewer-approved findings as regression tests.
