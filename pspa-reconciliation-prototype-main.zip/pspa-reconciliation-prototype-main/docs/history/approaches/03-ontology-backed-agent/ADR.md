# ADR: Adopt an Ontology-Backed Contract Billing Model as the Strategic Core

## Status

Proposed.

## Context

The corpus is too varied for simple SKU/PO matching and too high-risk for raw
LLM adjudication alone. It includes different document structures, governing
document hierarchies, amendments, recurring schedules, site-specific scope,
usage thresholds, SOW deliverables, professional service recovery fees, taxes,
and scanned invoices.

## Decision

Adopt a service contract and billing ontology as the strategic core model.
Populate it with LLM-assisted extraction and use graph-backed deterministic
validators for reconciliation. Use generated rules and whole-document LLM
adjudication as complementary techniques rather than as replacements for the
model.

## Consequences

Positive:

- Provides a reusable representation across vendors and invoice types.
- Captures contract document precedence and provenance.
- Makes line-level and invoice-level checks explainable.
- Enables ruleset generation for high-volume relationships.
- Supports human validation workflows for low-confidence extracted terms.

Negative:

- More upfront work than a prompt-only solution.
- Requires ontology versioning and governance.
- Requires extraction pipelines for OCR, tables, and source evidence.
- Requires careful MVP scoping to avoid over-modeling.

## Guardrails

- Start with the charge terms found in the corpus, not an abstract universal
  procurement ontology.
- Keep every assertion tied to evidence and confidence.
- Do not use OWL reasoning alone for arithmetic; use deterministic validators.
- Treat low-confidence extraction as incomplete evidence, not as a final term.
- Add ontology classes only when a new contract pattern requires them.
