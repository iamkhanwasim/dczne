# Approach 3: Ontology-Backed Reconciliation Agent

## Summary

Use an LLM to populate a service contract and billing ontology from governing
documents, then reconcile invoices through a graph-backed agent that combines
deterministic validators, retrieval, and targeted LLM reasoning.

This is the most complete approach for the corpus because it models contract
hierarchy, amendments, location scope, charge types, invoice evidence, and
source provenance as first-class objects.

## How It Enables Reconciliation

1. Ingest all contract and invoice source documents.
2. Extract text, tables, images/OCR, and metadata.
3. Populate ontology instances:
   - parties;
   - vendor relationships;
   - contract documents and document parts;
   - service offerings;
   - charge terms;
   - billing schedules;
   - measurements;
   - invoice lines;
   - evidence spans.
4. Apply contract precedence and effective-date reasoning.
5. For each invoice line, ask the agent to retrieve candidate charge terms from
   the graph.
6. Run deterministic validators for amount, cadence, date, location, quantity,
   tax, pass-through, and total checks.
7. Use LLM reasoning only for ambiguous mapping, narrative explanation, or
   missing-evidence triage.
8. Store reconciliation findings back into the graph with citations.

## Architecture

```mermaid
flowchart LR
  A["Source documents"] --> B["Extraction and OCR"]
  B --> C["Evidence spans and tables"]
  C --> D["Ontology population"]
  D --> E["Contract billing graph"]
  F["Invoice parser"] --> G["Invoice graph objects"]
  E --> H["Reconciliation agent"]
  G --> H
  H --> I["Deterministic validators"]
  H --> J["Targeted LLM reasoning"]
  I --> K["Findings"]
  J --> K
  K --> L["Reviewer workflow and audit trail"]
```

## Graph Objects

The ontology in `../../domain-model/service-contract-billing-ontology.owl.ttl`
defines the graph vocabulary. The MVP graph should include:

- contract document graph;
- normalized governing terms;
- service and location scopes;
- invoice header and lines;
- measurements and supporting evidence;
- reconciliation cases and findings.

## Validators

The graph-backed agent should call deterministic validators such as:

- `active_term(invoice_date, service_period, charge_term)`
- `line_amount_equals(rate * quantity)`
- `fixed_schedule_amount_due(invoice_date, billing_schedule)`
- `usage_within_included_quantity(measurement, baseline)`
- `overage_amount(quantity, included_quantity, overage_rate)`
- `tax_allowed(customer, location, charge_term)`
- `pass_through_requires_cost_evidence(line)`
- `contingency_fee_requires_realized_recovery(line)`
- `invoice_total_recomputes(invoice)`
- `amendment_precedence_resolves(term_set)`

## Example Walkthrough

### 1. Simple Contract (Input)

**Narrative excerpt:**
```
ABC Cleaning Services agrees to provide weekly facility cleaning at the
Customer's single location (Building A, Suite 100). The service begins
January 1, 2025 and renews annually. Base monthly fee is $2,500. 
Invoicing occurs on the 15th of each month for the following month's service.
Additional ad-hoc cleaning is available at $150/hour, billed separately
and requires pre-approval by Customer.
```

**Pricing table:**
```
| Service Type            | Unit   | Rate   | Frequency | Notes                   |
|-------------------------|--------|--------|-----------|-------------------------|
| Standard Cleaning       | Month  | $2,500 | Monthly   | Includes 4 cleanings    |
| After-hours Cleaning    | Hour   | $150   | As-needed | Requires PO             |
| Restroom Supplies       | Month  | $200   | Monthly   | Pass-through cost       |
```

### 2. Extracted Ontology Objects

The LLM extraction and ontology population would produce these RDF-like objects
(simplified notation):

```
VendorRelationship(
  id: "abc-cleaning-uh-2025",
  vendor: "ABC Cleaning Services",
  customer: "UHS",
  effective_date: "2025-01-01",
  renewal_date: "2026-01-01"
)

ChargeTerm(
  id: "abc-std-cleaning-2025",
  vendor_relationship: "abc-cleaning-uh-2025",
  name: "Standard Cleaning",
  service_scope: "weekly facility cleaning",
  location_scope: ["Building A, Suite 100"],
  billing_interval: "monthly",
  rate: 2500.00,
  rate_unit: "month",
  rate_currency: "USD",
  invoice_cadence: "15th of month, for following month",
  effective_period: ["2025-01-01", "2026-01-01"],
  source_document: "Master Service Agreement, page 2, para 3.1",
  source_table: "Pricing table, row 1"
)

ChargeTerm(
  id: "abc-adhoc-cleaning-2025",
  vendor_relationship: "abc-cleaning-uh-2025",
  name: "After-hours Cleaning",
  service_scope: "ad-hoc cleaning outside standard schedule",
  location_scope: ["Building A, Suite 100"],
  billing_interval: "per occurrence",
  rate: 150.00,
  rate_unit: "hour",
  rate_currency: "USD",
  preconditions: ["PO required"],
  source_document: "MSA, page 2, para 3.2"
)

ChargeTerm(
  id: "abc-restroom-supplies-2025",
  vendor_relationship: "abc-cleaning-uh-2025",
  name: "Restroom Supplies",
  service_scope: "pass-through for consumables",
  billing_interval: "monthly",
  rate: 200.00,
  rate_unit: "month",
  rate_currency: "USD",
  is_passthrough: true,
  source_document: "MSA, page 2, Pricing table, row 3"
)
```

### 3. Sample Invoice (Input)

```
Invoice ABC-2025-02-001
Issued: 2025-02-01
Bill For: February 2025 Service
Due Date: 2025-02-28

Line Items:
  Line 1: Standard Cleaning - 1 month @ $2,500.00 = $2,500.00
  Line 2: After-hours Cleaning (Jan 30) - 3 hours @ $175/hr = $525.00
  Line 3: Restroom Supplies - 1 month = $200.00

Subtotal: $3,225.00
Tax (Sales Tax 8.5%): $274.13
Total Due: $3,499.13
```

### 4. Reconciliation Agent Workflow

**Step A: Invoice Parsing**
The agent normalizes the invoice into a graph:
```
Invoice(
  id: "abc-2025-02-001",
  vendor_id: "ABC Cleaning Services",
  customer_id: "UHS",
  invoice_date: "2025-02-01",
  service_month: "2025-02",
  lines: [...]
)

InvoiceLine(
  id: "abc-2025-02-001-l1",
  description: "Standard Cleaning",
  quantity: 1,
  unit: "month",
  unit_rate: 2500.00,
  line_amount: 2500.00
)

InvoiceLine(
  id: "abc-2025-02-001-l2",
  description: "After-hours Cleaning (Jan 30)",
  quantity: 3,
  unit: "hour",
  unit_rate: 175.00,
  line_amount: 525.00,
  service_date: "2025-01-30"
)

InvoiceLine(
  id: "abc-2025-02-001-l3",
  description: "Restroom Supplies",
  quantity: 1,
  unit: "month",
  unit_rate: 200.00,
  line_amount: 200.00
)
```

**Step B: Candidate Retrieval**
For each invoice line, the agent queries the graph for matching ChargeTerm nodes
using deterministic and semantic filters. **Importantly: This retrieval step is NOT
LLM-dependent.** It runs fast deterministic queries plus simple text similarity;
the LLM only enters if multiple candidates are ambiguous or confidence is low.

**Matching process:**

1. **Deterministic filters** (exact, cheap):
   - Vendor relationship ID (from invoice header).
   - Active service period (charge term's effective_period must include invoice date).
   - Location scope (if charge term specifies locations, invoice location must be in scope).

2. **Semantic/flexible matching** (string similarity, NOT LLM):
   - Text similarity of invoice line description to charge term name/aliases (e.g., token overlap, fuzzy string match).
   - Match on units if provided (e.g., "hour" to ChargeTerm with rate_unit="hour").
   - Rate proximity heuristic: if line shows "$175/hr" and ChargeTerm has rate=$150 and rate_unit="hour", they match on unit but the rate will be flagged as a variance in validation.

3. **Ranking & tiebreaking** (if multiple candidates match):
   - Exact name match > fuzzy text match.
   - Matching unit > mismatched unit.
   - More recent term version (closer to invoice date) > older versions.
   - Higher extraction confidence score > lower.

**Example queries:**

```
Line 1: "Standard Cleaning - 1 month @ $2,500.00"

Query:
  ChargeTerm WHERE
    vendor_relationship= "abc-cleaning-uh-2025" AND
    effective_period.start <= "2025-02-01" <= effective_period.end AND
    location_scope includes "Building A, Suite 100" (or location_scope is empty/global)

Candidates found:
  - abc-std-cleaning-2025: name="Standard Cleaning", rate=2500, rate_unit="month"
    → Exact match on name and rate → Confidence: 0.98
  
No ambiguity. Selected: abc-std-cleaning-2025


Line 2: "After-hours Cleaning (Jan 30) - 3 hours @ $175/hr"

Query:
  ChargeTerm WHERE
    vendor_relationship= "abc-cleaning-uh-2025" AND
    effective_period.start <= "2025-02-01" <= effective_period.end AND
    rate_unit matches "hour" (parsed from "$175/hr")

Candidates found:
  - abc-adhoc-cleaning-2025: name="After-hours Cleaning", rate=150, rate_unit="hour"
    → Exact match on name and unit ✓
    → Rate mismatch: contract says $150/hr, invoice says $175/hr ✗
    → Confidence: 0.95 (high name + unit match, but rate variance noted)

No ambiguity on which charge term, BUT the rate will be flagged as a variance.
Selected: abc-adhoc-cleaning-2025


Line 3: "Restroom Supplies - 1 month = $200.00"

Query:
  ChargeTerm WHERE
    vendor_relationship= "abc-cleaning-uh-2025" AND
    effective_period.start <= "2025-02-01" <= effective_period.end AND
    description contains "Restroom" OR name contains "Supplies"

Candidates found:
  - abc-restroom-supplies-2025: name="Restroom Supplies", rate=200, rate_unit="month"
    → Exact match on name → Confidence: 0.99

No ambiguity. Selected: abc-restroom-supplies-2025
```

**What happens if matching fails or is ambiguous:**

- Zero candidates: The line is flagged as `needs_review` with reason "No matching charge term found."
- Multiple candidates with similar scores: The agent lists alternatives and either picks the highest-confidence candidate or escalates to targeted LLM reasoning (e.g., "Line description is ambiguous; could match Service A or Service B; need human input").
- Low confidence (< 0.7) but only one candidate: The system marks it `low_confidence_match` and sends to review, but does not auto-approve.

**Step C: Deterministic Validation**

Before showing the results, it's important to clarify what "the agent" means here and how validators execute.

**Validator Execution Model:**

Validators are **hand-coded, deterministic functions**, not LLM tools. They are invoked by a **deterministic reconciliation engine** (not the LLM). The engine is a state machine or rule orchestrator that:

1. Receives the matched ChargeTerm and InvoiceLine objects from Step B.
2. Automatically dispatches to the appropriate validator functions based on the charge term type and what needs to be checked.
3. Collects results and produces findings.

**Example validator pseudocode:**

```python
def line_amount_equals(contract_rate: float, quantity: float, 
                        invoice_line_amount: float, tolerance_pct: float = 0.0) -> ValidationResult:
  """
  Validate that invoice line amount matches contract rate * quantity.
  Returns a structured result with pass/fail, expected vs. actual, variance, etc.
  """
  expected_amount = contract_rate * quantity
  variance = invoice_line_amount - expected_amount
  variance_pct = (variance / expected_amount * 100) if expected_amount > 0 else 0
  
  passed = abs(variance) <= (expected_amount * tolerance_pct / 100)
  
  return ValidationResult(
    validator_name="line_amount_equals",
    passed=passed,
    expected_amount=expected_amount,
    actual_amount=invoice_line_amount,
    variance=variance,
    variance_pct=variance_pct,
    reason="Arithmetic check: rate × quantity vs. invoice charged amount"
  )

def active_term(invoice_date: date, charge_term: ChargeTerm) -> ValidationResult:
  """
  Validate that the charge term was active on the invoice date.
  """
  passed = (charge_term.effective_period.start <= invoice_date <= 
            charge_term.effective_period.end)
  
  return ValidationResult(
    validator_name="active_term",
    passed=passed,
    reason=f"Term active {charge_term.effective_period.start} to {charge_term.effective_period.end}"
  )

def precondition_check(required_conditions: List[str], 
                        supporting_docs: Dict[str, bool]) -> ValidationResult:
  """
  Validate that all preconditions (e.g., PO required) have supporting evidence.
  """
  unmet = [cond for cond in required_conditions if not supporting_docs.get(cond, False)]
  passed = len(unmet) == 0
  
  return ValidationResult(
    validator_name="precondition_check",
    passed=passed,
    unmet_conditions=unmet,
    reason=f"Preconditions: {required_conditions}"
  )
```

**Orchestration Example:**

```python
def validate_invoice_line(matched_charge_term: ChargeTerm, 
                          invoice_line: InvoiceLine) -> List[ValidationResult]:
  """
  Run all applicable validators for this line.
  Returns a list of validation results and an overall status.
  """
  results = []
  
  # Always check: is the term active?
  results.append(active_term(invoice_line.service_date, matched_charge_term))
  
  # Always check: amount arithmetic
  results.append(line_amount_equals(
    contract_rate=matched_charge_term.rate,
    quantity=invoice_line.quantity,
    invoice_line_amount=invoice_line.line_amount
  ))
  
  # If term requires preconditions, check them
  if matched_charge_term.preconditions:
    results.append(precondition_check(
      required_conditions=matched_charge_term.preconditions,
      supporting_docs=invoice_line.supporting_docs  # populated from invoice metadata
    ))
  
  # If term is a pass-through, require evidence
  if matched_charge_term.is_passthrough:
    results.append(pass_through_requires_cost_evidence(
      charge_term=matched_charge_term,
      supporting_docs=invoice_line.supporting_docs
    ))
  
  # If this is a contingency fee, check for realized recovery
  if matched_charge_term.is_contingency_fee:
    results.append(contingency_fee_requires_realized_recovery(
      charge_term=matched_charge_term,
      recovery_evidence=invoice_header.recovery_data
    ))
  
  overall_status = "PASS" if all(r.passed for r in results) else "FAIL"
  return results, overall_status
```

**Key points about the execution model:**

- Validators are **pure functions**: deterministic, side-effect free, repeatable.
- They return **structured ValidationResult objects** with details (expected, actual, variance, reason, etc.).
- They are **not called by the LLM** and do not use LLM tool-calling.
- The **orchestrator (reconciliation engine) is deterministic code**, not LLM-driven. It decides which validators to run based on charge term attributes and invoice context.
- The orchestrator **is not a general agent**; it's a domain-specific state machine with hard-coded dispatch logic.
- The LLM enters only for extraction (Step 1–2) and for targeted reasoning on ambiguous cases (e.g., if matching confidence is low or a finding needs explanation).

Now, here are the validation results for our invoice:

The agent runs validators on each line and the invoice total:

```
Line 1: Standard Cleaning
  - active_term(invoice_date=2025-02-01, service_period=2025-02,
    charge_term=abc-std-cleaning-2025)
    → TRUE (term active Jan 1 - Dec 31, 2025)
  - line_amount_equals(rate=2500, quantity=1, charged=2500)
    → TRUE
  - Result: PASS ✓

Line 2: After-hours Cleaning
  - line_amount_equals(rate=150, quantity=3, charged=525)
    → FALSE (contract rate is $150/hr; 3 hours * $150 = $450, not $525)
  - rate_variance(contract_rate=150, invoice_rate=175, variance=+25)
    → VARIANCE: invoice charged $25 extra per hour, total overage = $75
  - precondition_check(PO_required, has_po=NO)
    → FALSE (no PO evidence provided)
  - Result: REJECT — amount exceeds contract rate + missing precondition documentation

Line 3: Restroom Supplies
  - line_amount_equals(rate=200, quantity=1, charged=200)
    → TRUE
  - is_passthrough=true (requires external cost evidence)
    → MISSING_EVIDENCE (no receipt or vendor invoice provided)
  - Result: AMBIGUOUS

Invoice Total:
  - invoice_total_recomputes(subtotal=3225, tax_rate=0.085, tax=274.13,
    total=3499.13)
    → TRUE (arithmetic is correct)
  - tax_allowed(customer=UHS, location="Building A Suite 100",
    charge_term=abc-std-cleaning-2025, rate=0.085)
    → TRUE (standard sales tax for this location)
  - However: Line 2 variance propagates to total. Expected total should be
    ($2,500 + $450 + $200) * 1.085 = $3,417.75, not $3,499.13
  - Result: CONDITIONAL — total arithmetic passes, but total is $81.38 higher
    due to Line 2 rate variance
```

**Step D: Structured Findings**
The agent stores these findings back into the graph:

```
Finding(
  id: "finding-abc-2025-02-001-l2",
  invoice_line: "abc-2025-02-001-l2",
  charge_term: "abc-adhoc-cleaning-2025",
  status: "reject_with_variance",
  reason: "Rate variance + missing precondition documentation",
  amount_check: "FAIL",
  contract_rate: 150.00,
  invoice_rate: 175.00,
  variance_per_hour: 25.00,
  total_variance: 75.00,
  source_evidence: "MSA page 2 para 3.2, Pricing table row 2 (contract rate $150/hr)",
  recommended_action: "Contact vendor: invoice shows $175/hr but contract specifies $150/hr. Request corrected invoice for $450 (3 hrs @ $150). Also request PO or authorization for ad-hoc service."
)

Finding(
  id: "finding-abc-2025-02-001-l3",
  invoice_line: "abc-2025-02-001-l3",
  charge_term: "abc-restroom-supplies-2025",
  status: "needs_review",
  reason: "Pass-through cost: supporting cost evidence not provided",
  amount_check: "PASS",
  source_evidence: "MSA page 2 Pricing table row 3",
  recommended_action: "Request vendor receipt or cost breakdown for supplies"
)

Finding(
  id: "finding-abc-2025-02-001-invoice",
  invoice_id: "abc-2025-02-001",
  status: "reject_invoice_variance",
  total_check: "CONDITIONAL",
  lines_auto_approved: 1,
  lines_rejected: 1,
  lines_needing_review: 1,
  total_variance: 81.38,
  expected_total: 3417.75,
  invoice_total: 3499.13,
  recommended_action: "REJECT Line 2: rate variance of $75 + missing precondition. QUERY Line 3: pass-through documentation needed. AUTO-APPROVE Line 1. Return to vendor with corrected Line 2 amount and documentation requests."
)
```

**Step E: Reviewer Workflow Output**
The reviewer sees:

1. **Line 1** "Standard Cleaning" ($2,500) — **Auto-approved** ✓
   - Amount verified against contract.

2. **Line 2** "After-hours Cleaning" ($525 invoiced, $450 expected) — **REJECTED** ✗
   - **Rate variance**: Contract specifies $150/hr; invoice shows $175/hr (+$25/hr).
   - **Total overage**: $75 for this line.
   - **Missing precondition**: No PO or authorization document provided.
   - **System recommendation**: Contact vendor; request corrected invoice for $450
     and provide PO/authorization for the service.
   - Link to contract clause (MSA page 2, para 3.2) showing rate and precondition.

3. **Line 3** "Restroom Supplies" ($200) — **NEEDS DOCS** ⚠
   - Pass-through cost requires supporting receipts or vendor invoice.
   - Amount ($200) matches contract; just waiting for cost evidence.

**Key insight on matching vs. validation**:
- **Matching (Step B)** correctly identified "After-hours Cleaning" as the right charge term because the name and unit ("hour") matched exactly, despite the rate difference.
- **Validation (Step C)** caught the rate variance when it ran `line_amount_equals(rate=150, quantity=3, charged=525)`, which failed: 150 × 3 = 450 ≠ 525.
- This shows the separation of concerns: matching is deterministic text/unit logic (NO LLM needed), while validation is deterministic arithmetic logic that catches discrepancies.
- If matching had failed (zero candidates or high ambiguity), THEN the LLM would have been consulted for targeted reasoning.

The output preserves the chain of reasoning, source citations, and evidence gaps,
making review faster and more auditable.

## Strengths

- Best handling of multi-document vendor relationships.
- Reuses extracted terms across invoices and approaches.
- Preserves source provenance at assertion level.
- Supports deterministic checks without losing semantic flexibility.
- Can model service-specific differences instead of forcing all invoices into
  SKU matching.
- Good foundation for analytics, drift detection, and reviewer feedback.

## Weaknesses

- Highest upfront modeling and extraction effort.
- Requires ontology governance.
- Requires confidence management and human validation of extracted terms.
- Graph and validator design must avoid becoming over-general and slow.

## Best Fit

Use as the strategic architecture for the reconciliation engine. Generated
rulesets can be compiled from the graph for high-volume vendors, and
whole-document LLM adjudication can serve as a fallback for low-confidence graph
matches.

## Corpus Fit

The ontology approach directly covers the corpus patterns:

- master agreements plus amendments;
- SOW/change-order scope control;
- location-specific services;
- recurring subscription schedules;
- transaction packages and overages;
- pass-throughs and taxes;
- contingency recovery billing;
- scanned/extraction-limited evidence requiring review status.
