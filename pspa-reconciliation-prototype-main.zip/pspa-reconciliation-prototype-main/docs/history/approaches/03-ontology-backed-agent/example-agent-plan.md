# Example Agent Plan

Invoice: Experian `INV1126713` for December 2025.

Goal: determine line-level and invoice-level compliance.

## Step 1: Identify Relationship

Query graph for active vendor relationships matching:

- vendor account `EXH-129307`;
- bill-to United Health Services;
- invoice date `2025-12-31`;
- vendor name Experian Health.

Expected result: `ex:experian-relationship`.

## Step 2: Resolve Governing Documents

Query active documents:

- master customer agreement effective August 2025;
- price change amendment effective after execution;
- BAA for data handling, not invoice pricing;
- cover memos as administrative evidence only.

Apply amendment precedence so price amendment terms override conflicting master
agreement pricing for claims-based products.

## Step 3: Match Lines

For each invoice line:

- retrieve candidate charge terms by description alias, product/service,
  facility/account code, quantity, cadence, and invoice period;
- calculate expected amount using deterministic validators;
- compare to actual line amount;
- classify compliant, non-compliant, or needs review.

## Step 4: Claims-Based Fee Special Handling

The amendment defines a relationship-level monthly claims-based subscription fee
based on annual claims. The invoice allocates amounts by facility. The agent
should:

- confirm total claims-based fee across facilities if all relevant lines are
  available;
- verify facilities are existing facilities or added by amendment;
- require allocation methodology evidence if line-level facility amounts are
  evaluated independently.

## Step 5: Invoice Total

Recompute:

```text
accepted line subtotal + allowed tax - credits = expected invoice total
```

Flag any sales tax when the governing terms or customer evidence indicate tax
exemption.

## Step 6: Output Finding

Persist a `ReconciliationCase` with:

- invoice id;
- candidate documents;
- line findings;
- invoice-total finding;
- source evidence;
- missing evidence;
- reviewer status.
