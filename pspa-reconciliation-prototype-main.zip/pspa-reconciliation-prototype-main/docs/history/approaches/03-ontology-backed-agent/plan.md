# Implementation Plan

## Phase 1: Ontology MVP

- Finalize classes and properties from `service-contract-billing-ontology.owl.ttl`.
- Choose graph storage:
  - RDF triple store if OWL/SPARQL interoperability is primary;
  - property graph if application traversal and developer ergonomics dominate.
- Define assertion provenance and confidence fields.
- Define reviewer status lifecycle for extracted terms.

## Phase 2: Corpus Population Prototype

- Run the corpus workbench across all source documents.
- Add OCR and table extraction for scanned/encrypted documents.
- Populate graph instances for three pilot relationships:
  - Experian;
  - Quality Lawn;
  - HealthROI or NRC.
- Validate extracted terms against human-reviewed evidence notes.

## Phase 3: Validator Library

- Implement deterministic validators for:
  - active effective period;
  - amendment precedence;
  - line/service/term matching;
  - fixed and recurring fees;
  - usage, included quantity, and overage fees;
  - per-location services;
  - contingency fees;
  - pass-through fees;
  - tax exemption;
  - invoice totals and duplicate invoice checks.

## Phase 4: Agent Orchestration

- Build the reconciliation agent around tool calls:
  - graph query;
  - calculator;
  - source evidence retriever;
  - validator runner;
  - reviewer handoff.
- Use LLM reasoning only for candidate mapping, explanation, and unresolved
  ambiguity.
- Store every finding in the graph.

## Phase 5: Production Workflow

- Add vendor onboarding workflow.
- Add amendment intake and graph versioning.
- Add invoice queue and review UI.
- Add metrics for false positives, false negatives, unmatched lines, review
  outcomes, and extraction confidence.

## Phase 6: Hybrid Optimization

- Generate deterministic vendor rulesets from graph terms for high-volume
  relationships.
- Use whole-document LLM adjudication for fallback cases and reviewer drafts.
- Feed reviewed outcomes back into term aliases and matching confidence.
