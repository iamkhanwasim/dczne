# Additional Reconciliation Approaches Beyond the Current Three

## Purpose

This document proposes additional approaches that were not included in the
initial three designs. The objective is to improve both:

- flexibility across very different contract and invoice patterns;
- operational efficiency (runtime, cost, and review effort).

## Evaluation Lens

Approaches are evaluated against five practical criteria:

1. Coverage flexibility for diverse contract structures.
2. Invoice-time cost and latency.
3. Determinism and auditability.
4. Onboarding effort and time-to-value.
5. Scalability across vendors and document quality variance.

## Alternative A: Contract Query Planner + Retrieval-First Execution

### How it works

Instead of generating full vendor rulesets upfront, the system compiles a
normalized set of **query plans** from contract evidence:

1. Extract clauses/tables to normalized term objects.
2. Build a searchable term index with amendment precedence metadata.
3. For each invoice line, run a planner that selects the best retrieval strategy
   (exact alias match, semantic match, location+date constrained match, etc.).
4. Execute deterministic calculators on the retrieved candidate term(s).
5. Escalate only unresolved ambiguity to targeted LLM reasoning.

### Advantages

- Less brittle than static rules when invoice text drifts.
- Faster onboarding than full rule authoring.
- Preserves deterministic arithmetic and traceability.
- Works well when contracts change frequently but core charge semantics remain.

### Disadvantages

- Retrieval quality becomes mission-critical.
- Candidate ranking errors can cause wrong term selection.
- Requires careful precedence modeling to avoid stale term matches.

## Alternative B: Constraint-Solver Reconciliation (Optimization Model)

### How it works

Model reconciliation as a constrained optimization problem:

1. Convert contract terms into constraints (date windows, location scope,
   allowable rates, included quantity, overage formulas, tax rules, etc.).
2. Map each invoice line to one or more candidate contract terms.
3. Solve for the assignment and expected amounts that minimize total violation
   penalty.
4. Return not only pass/fail but also the minimal set of violated constraints.

Typical implementation uses OR-Tools, Z3, or CP-SAT style solvers.

### Advantages

- Very strong on complex dependencies across lines and totals.
- Deterministic and mathematically auditable.
- Produces explainable violation sets, not just model confidence.

### Disadvantages

- High modeling complexity and maintenance overhead.
- Solver formulations can become slow for very large ambiguous candidate sets.
- Not ideal when source extraction confidence is low and constraints are fuzzy.

## Alternative C: Case-Based Reasoning + Similarity Retrieval

### How it works

Create a precedent library of past adjudicated invoice lines/findings:

1. Store each resolved case with normalized context, outcome, and evidence.
2. For each new line, retrieve top-k similar historical cases.
3. Reuse prior decision templates when similarity and evidence thresholds pass.
4. Fall back to deterministic checks and/or LLM when no safe precedent exists.

### Advantages

- Excellent for reducing review effort over time.
- Handles vendor-specific language variation without full re-modeling.
- Naturally improves as adjudicated history grows.

### Disadvantages

- Weak cold-start performance.
- Risk of propagating older reviewer mistakes.
- Needs robust drift controls and confidence gating.

## Alternative D: Two-Tier Fast Path / Deep Path Architecture

### How it works

Introduce strict runtime routing:

1. Tier 1 (fast path): deterministic template checks for common recurring lines
   and known vendors.
2. Tier 2 (deep path): ontology/LLM/graph adjudication only for exceptions.
3. Continuously promote stable deep-path outcomes into fast-path templates.

This is an operating model rather than a single reasoning technique.

### Advantages

- Best runtime and cost profile at scale.
- Keeps sophisticated reasoning where it is needed most.
- Improves over time as exception classes shrink.

### Disadvantages

- Requires disciplined routing and promotion governance.
- Risk of overfitting fast-path templates to short-term invoice patterns.
- Needs strong observability to detect when lines should return to deep path.

## Alternative E: Program-Synthesis Validator Generator

### How it works

Use LLMs to generate executable validator code and tests from contract evidence,
not only JSON rules:

1. Extract normalized terms and evidence citations.
2. Generate typed validators (for example Python/SQL predicates).
3. Auto-generate unit tests from contract examples and edge cases.
4. Run test gates; only passing validators are deployed.

### Advantages

- Strong determinism once code is approved.
- Better developer control than opaque prompt-only decisions.
- Test-driven onboarding can catch extraction misunderstandings early.

### Disadvantages

- Higher engineering overhead than schema-based rules.
- Validator lifecycle/versioning can become heavy across many vendors.
- Still depends on extraction quality and review discipline.

## Combined Ranking (Current + New)

Ranking below is for the stated goal: broad flexibility **and** reasonable
processing cost/time in production.

1. **Approach 3 + Alternative D hybrid** (Ontology-backed deep path with
   two-tier routing): strongest long-term balance of flexibility, auditability,
   and cost control.
2. **Approach 3 alone** (Ontology-backed agent): best strategic core, but more
   expensive than routed hybrid.
3. **Approach 1 + Alternative A hybrid** (Rules engine with retrieval-first
   planner): strong for repeat vendors while handling moderate drift.
4. **Alternative D alone** (Two-tier fast/deep architecture): excellent
   operations model, but still needs a strong deep-path brain.
5. **Alternative B** (Constraint-solver): strongest formal correctness, but high
   implementation and maintenance complexity.
6. **Approach 1 alone** (LLM-generated rules engine): efficient and deterministic
   for stable vendors, weaker on novelty and amendment-heavy ambiguity.
7. **Alternative C** (Case-based reasoning): valuable accelerator, but should be
   a secondary layer due to cold-start and drift risk.
8. **Alternative E** (Program-synthesis validators): promising for engineering
   rigor, but heavy to scale without mature tooling.
9. **Approach 2 alone** (Whole-document LLM adjudication): still best as triage,
   fallback, and explanation support rather than primary control.

## Practical Recommendation

For this corpus and likely production needs, the best next evolution is:

- keep Approach 3 as system-of-record semantics;
- add Alternative D routing for cost/latency control;
- incorporate Alternative A retrieval planning to reduce brittle term mapping;
- retain Approach 2 only as bounded fallback and reviewer copilot.