# Approach Comparison and Recommendation

## Current Status (2026-05-23)

The recommended hybrid has been formalized and is now under active
implementation as:

- `approaches/05-ontology-agent-d-hybrid/`

Progress to date:

- Phase 0 complete (fixtures + scaffolding)
- Phase 1 complete (foundation, models, graph/RDF layer, Phase 1 tests)
- Test status: `pytest -q` → **13 passed**

This comparison remains valid as design guidance for architecture tradeoffs,
while execution is tracked in the Approach 5 plan and implementation docs.

## Executive Recommendation

Use the ontology-backed model as the strategic core, then layer the other two
approaches around it:

- Use generated deterministic rulesets for high-volume repeat vendors after the
  ontology has captured the contract terms.
- Use whole-document LLM adjudication as a triage, fallback, and reviewer
  assistance workflow.

This hybrid keeps the engine auditable and efficient without losing flexibility
for unusual service contracts.

Implementation decision taken:

- Approach 5 (Ontology-Agent + Two-Tier Routing) is the selected build path.
- Approaches 1 and 2 are retained as supporting patterns:
  - Approach 1 for generated deterministic rules on mature, repeat patterns
  - Approach 2 for fallback triage and reviewer assistance on ambiguous cases

## Comparison

| Criterion | LLM-generated rules | Whole-document LLM | Ontology-backed agent |
| --- | --- | --- | --- |
| Invoice-time cost | Low | High | Medium |
| Determinism | High after rule approval | Low to medium | High for validators, medium for ambiguous mapping |
| Onboarding speed | Medium | Fast | Slowest initially |
| Auditability | High if rules cite evidence | Medium if citations are verified | High at assertion and finding level |
| Amendment handling | Good if modeled in rules | Risky in long context | Strong |
| Service variety | Medium | High | High |
| Arithmetic reliability | High | Requires external calculator | High |
| Human review need | Upfront rule review | Per-invoice review for risk | Extraction and exception review |
| Best use | Repeat vendor automation | Triage and fallback | Strategic system of record |

## Why Pure PO/SKU Matching Is Insufficient

The corpus includes product-like office supply usage, but most categories are
not reducible to SKU and PO checks:

- Experian combines subscriptions, transaction packages, overages, pass-through
  fees, facility allocations, and amendments.
- Quality Lawn bills location-specific seasonal services with tax exemption and
  prior-month invoicing.
- Johnson Controls inspection pricing depends on site, equipment/system scope,
  contract term, exclusions, and PO/CPQ references.
- Reputation.com and Perficient use scheduled recurring payments and SOW/change
  order structure.
- NRC Health prices membership years and invoices quarterly at the start.
- HealthROI billing depends on realized recoveries and backup evidence.

## Recommended Target Architecture

```mermaid
flowchart TD
  A["Document ingestion"] --> B["OCR, table extraction, metadata"]
  B --> C["Evidence store"]
  C --> D["Ontology population"]
  D --> E["Contract billing graph"]
  E --> F["Deterministic validators"]
  E --> G["Ruleset generator for repeat vendors"]
  H["Invoice ingestion"] --> I["Invoice normalizer"]
  I --> F
  I --> G
  F --> J["Findings"]
  G --> J
  J --> K["Reviewer workflow"]
  I --> L["LLM fallback adjudication"]
  L --> K
```

## Recommended Build Sequence

1. Build the corpus workbench and ontology MVP.
2. Populate graph examples for Experian, Quality Lawn, and HealthROI.
3. Implement deterministic validators for the most common charge terms.
4. Add reviewer workflow and evidence citations.
5. Generate rulesets from reviewed graph terms for high-volume vendors.
6. Add whole-document LLM fallback for unmatched lines and low-volume vendors.

## Success Metrics

- Percentage of invoice lines matched to a governed charge term.
- Percentage of invoice dollars reconciled without manual lookup.
- False positive and false negative rates after reviewer validation.
- Number of findings with complete source evidence.
- Average review time per invoice.
- Number of terms requiring re-extraction after amendments.
- OCR/table extraction failure rate.

## Main Risks

- Scanned PDFs and encrypted documents can hide invoice line evidence.
- LLM extraction can miss tables or misread precedence.
- Facility allocation rules may be implied by invoice practice rather than
  explicit contract language.
- Pass-through and contingency fees may require external backup data.
- Some invoices reflect broader relationship renewals than the narrow contract
  addendum placed beside them, so relationship-level document completeness must
  be checked before declaring a line non-compliant.
- A too-broad ontology can slow delivery.

## Risk Mitigations

- Require evidence spans and confidence on every extracted term.
- Add OCR and visual table extraction early.
- Treat missing backup evidence as `needs_review`.
- Keep arithmetic outside LLM prompts.
- Start with the charge terms proven in the corpus and add new classes only
  when necessary.
