# PR: Add reconciliation engine architecture design docs

## Summary

- Adds a corpus workbench for inventorying, extracting, chunking, and signal
  scanning contract/invoice examples.
- Adds a domain model subproject with corpus evidence summary, logical model,
  OWL/Turtle ontology, and modeled examples.
- Adds three architecture approach folders:
  - LLM-generated deterministic rules engine;
  - whole-document LLM adjudication;
  - ontology-backed reconciliation agent.
- Adds ADRs, implementation plans, and example models for each approach.
- Adds a comparison and recommendation for a hybrid target architecture.

## Notes

- The source `Data/` folder is intentionally ignored and not included in the PR.
- Full extracted chunks and signal snippets are generated locally but ignored to
  avoid committing source document text.
- Several scanned or encrypted PDFs require OCR/encrypted PDF support before
  they can be fully machine-read in production.

## Validation

- Ran `tools/corpus_workbench/analyze_corpus.py` against all 94 corpus files.
- Generated `corpus-evidence-summary.md` and manifest artifacts.
