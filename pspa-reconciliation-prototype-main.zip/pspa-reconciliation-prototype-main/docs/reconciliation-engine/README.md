# Service Contract Invoice Reconciliation Engine

This subproject captures design and implementation work for a reconciliation
engine that evaluates vendor invoices against one or more governing contract
documents. It includes the domain model, ontology, approach designs, ADRs,
implementation plans, and active implementation artifacts.

As of 2026-05-23, this is no longer design-only: active implementation is in
progress under `approaches/05-ontology-agent-d-hybrid/implementation/`.

## Contents

- `domain-model/`
  - Corpus workbench outputs, evidence notes, logical model, and an OWL/Turtle
    ontology for service contracts and invoices.
- `approaches/01-llm-generated-rules-engine/`
  - Design for using LLMs to synthesize deterministic per-vendor rules.
- `approaches/02-whole-document-llm-adjudication/`
  - Design for evaluating a contract set and invoice together in an LLM workflow.
- `approaches/03-ontology-backed-agent/`
  - Design for populating a contract billing ontology and reconciling invoices
    through graph-backed reasoning plus agents.
- `approaches/05-ontology-agent-d-hybrid/`
  - Selected implementation approach combining ontology-backed modeling with
    two-tier routing (fast path + deep path).
  - Current status: Phase 0 and Phase 1 complete, including graph foundation
    and unit tests.
- `comparison.md`
  - Cross-approach tradeoffs and recommendation.

## Current Implementation Status (Approach 5)

- Implementation root: `approaches/05-ontology-agent-d-hybrid/implementation/`
- Completed phases:
  - Phase 0: test fixtures, factories, helpers
  - Phase 1.1: project setup and baseline infrastructure
  - Phase 1.2: contract, invoice, finding, routing data models
  - Phase 1.3: graph/RDF foundation (`prefixes`, ontology schema, repository,
    mock graph, RDF generator, StarDog stub)
  - Phase 1.4: model and graph repository unit tests
- Test status (latest): `pytest -q` → **13 passed**
- ADR/tech-debt tracking: see
  `approaches/05-ontology-agent-d-hybrid/implementation/PHASE_0_1_ADR_COMPLIANCE.md`

## Corpus Used

The designs were pressure-tested against all files under
`Data/Contract and Invoice Pairs` using `tools/corpus_workbench/analyze_corpus.py`.
The corpus contains 94 source files across healthcare vendor categories,
including contracts, amendments, SOWs, cover memos, invoices, and one usage
spreadsheet. Several scanned or encrypted PDFs produced limited text extraction;
that limitation is carried into the design as an explicit OCR and human-review
requirement.

## Working Assumption

The target system should not decide compliance from raw text alone. The safest
architecture is to preserve source evidence, normalize contracts and invoices
into a shared model, run deterministic checks where possible, and reserve LLM
judgment for extraction, classification, ambiguity handling, and explanation.
