# REST API Specification

## Base URL

```
http://localhost:8000/api/v1/
```

(Production TBD; add authentication layer at runtime)

---

## Health Check

### GET /health

Check service health and readiness.

**Response (200 OK)**:
```json
{
  "status": "healthy",
  "version": "0.1.0",
  "graph_backend": "mock",
  "llm_client": "ready",
  "uptime_seconds": 3600
}
```

---

## Contracts API

### POST /contracts/ingest

Ingest one or more contract documents for a vendor relationship.

**Request**:
```json
{
  "vendor_id": "abc-cleaning",
  "vendor_name": "ABC Cleaning Services",
  "customer_name": "UHS",
  "effective_date": "2025-01-01",
  "renewal_date": "2026-01-01",
  "documents": [
    {
      "doc_type": "MSA",
      "content_format": "markdown",
      "content": "<markdown text of contract, already OCR'd>"
    },
    {
      "doc_type": "Amendment",
      "content_format": "markdown",
      "content": "<markdown text of amendment>"
    }
  ],
  "metadata": {
    "tags": ["cleaning", "healthcare"],
    "reference_id": "ABC-2025-MSA-001"
  }
}
```

**Response (202 Accepted)** - processing is async:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "ingesting",
  "documents_received": 2,
  "extraction_job_id": "job-extract-abc-cleaning-001",
  "estimated_completion_seconds": 30,
  "polling_url": "/api/v1/contracts/abc-cleaning-uh-2025-01/status"
}
```

**Response (400 Bad Request)**:
```json
{
  "error": "Invalid request",
  "details": {
    "vendor_id": "required",
    "documents": "at least 1 document required"
  }
}
```

---

### GET /contracts/{contract_id}/status

Poll the status of contract ingestion.

**Response (200 OK)** - while processing:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "extracting",
  "progress": {
    "documents_processed": 1,
    "documents_total": 2,
    "current_step": "Extracting terms from MSA",
    "percent_complete": 50
  },
  "extraction_job_id": "job-extract-abc-cleaning-001"
}
```

**Response (200 OK)** - when complete:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "indexed",
  "terms_extracted": 3,
  "extraction_confidence_avg": 0.96,
  "ready_for_finalization": true
}
```

---

### GET /contracts/{contract_id}

Retrieve full contract data including extracted terms.

**Response (200 OK)**:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "vendor_id": "abc-cleaning",
  "vendor_name": "ABC Cleaning Services",
  "customer_name": "UHS",
  "effective_date": "2025-01-01",
  "renewal_date": "2026-01-01",
  "status": "indexed",
  "charge_terms": [
    {
      "id": "abc-std-cleaning-2025",
      "name": "Standard Cleaning",
      "charge_type": "FIXED_RATE",
      "rate": 2500.00,
      "rate_unit": "month",
      "rate_currency": "USD",
      "billing_interval": "monthly",
      "location_scope": ["Building A, Suite 100"],
      "effective_period": {
        "start": "2025-01-01",
        "end": "2026-01-01"
      },
      "source": {
        "document_type": "MSA",
        "page": 2,
        "section": "Pricing",
        "line_reference": "table row 1"
      },
      "extraction_confidence": 0.98
    },
    {
      "id": "abc-adhoc-cleaning-2025",
      "name": "After-hours Cleaning",
      "charge_type": "VARIABLE_RATE",
      "rate": 150.00,
      "rate_unit": "hour",
      "preconditions": ["PO required"],
      "extraction_confidence": 0.95
    },
    {
      "id": "abc-restroom-supplies-2025",
      "name": "Restroom Supplies",
      "charge_type": "PASS_THROUGH",
      "rate": 200.00,
      "rate_unit": "month",
      "is_passthrough": true,
      "requires_cost_evidence": true,
      "extraction_confidence": 0.97
    }
  ],
  "created_at": "2025-02-01T10:00:00Z",
  "updated_at": "2025-02-01T10:02:00Z"
}
```

---

### POST /contracts/{contract_id}/finalize

Lock contract and prepare for invoice reconciliation. Validates extracted terms and compiles fast-path rules.

**Request**:
```json
{
  "confirm_terms": true,
  "notes": "Terms reviewed and approved by finance team"
}
```

**Response (200 OK)**:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "finalized",
  "terms_finalized": 3,
  "validation_issues": [],
  "fast_path_rules_compiled": 3,
  "ready_for_invoices": true,
  "finalized_at": "2025-02-01T10:05:00Z"
}
```

**Response (400 Bad Request)** - if validation issues:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "validation_failed",
  "validation_issues": [
    {
      "term_id": "abc-adhoc-cleaning-2025",
      "issue": "Extraction confidence 0.65 < threshold 0.70",
      "severity": "warning",
      "recommendation": "Manually review term and confirm rate"
    }
  ],
  "can_force_finalize": true
}
```

---

### POST /contracts/{contract_id}/validate

Run validation checks on extracted terms without finalizing.

**Response (200 OK)**:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "validation_results": [
    {
      "term_id": "abc-std-cleaning-2025",
      "term_name": "Standard Cleaning",
      "checks": [
        {
          "check": "rate_positive",
          "passed": true
        },
        {
          "check": "date_range_valid",
          "passed": true
        },
        {
          "check": "extraction_confidence",
          "passed": true,
          "confidence": 0.98
        }
      ],
      "overall": "PASS"
    },
    {
      "term_id": "abc-adhoc-cleaning-2025",
      "term_name": "After-hours Cleaning",
      "checks": [
        {
          "check": "rate_positive",
          "passed": true
        },
        {
          "check": "extraction_confidence",
          "passed": false,
          "confidence": 0.65,
          "required": 0.70
        }
      ],
      "overall": "FAIL",
      "recommendation": "Manually review term"
    }
  ]
}
```

---

## Invoices API

### POST /invoices/reconcile

Submit a structured invoice for reconciliation against a contract.

Canonical production boundary: OCR/parsing happens outside the reconciliation engine.

**Request**:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "invoice": {
    "invoice_id": "inv-abc-2025-02-001",
    "vendor_id": "abc-cleaning",
    "vendor_name": "ABC Cleaning Services",
    "customer_name": "UHS",
    "invoice_date": "2025-02-01",
    "contract_id": "abc-cleaning-uh-2025-01",
    "lines": [
      {
        "line_number": 1,
        "description": "Standard Cleaning",
        "quantity": 1,
        "unit": "month",
        "unit_rate": 2500.0,
        "line_amount": 2500.0
      }
    ],
    "subtotal": 2500.0,
    "tax_rate": 0.0,
    "tax_amount": 0.0,
    "total": 2500.0
  },
  "source_name": "invoice",
  "metadata": {
    "received_date": "2025-02-01",
    "reference_id": "INV-ABC-2025-02-001"
  }
}
```

**Response (200 OK)** - processing is synchronous:
```json
{
  "invoice_id": "inv-abc-2025-02-001",
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "completed",
  "processing_time_ms": 2500,
  "findings": [
    {
      "line_number": 1,
      "line_description": "Standard Cleaning",
      "charge_term_id": "abc-std-cleaning-2025",
      "charge_term_name": "Standard Cleaning",
      "status": "PASS",
      "validators_run": [
        {
          "validator": "active_term",
          "passed": true,
          "reasoning": "Term active Jan 1 - Dec 31, 2025"
        },
        {
          "validator": "line_amount_equals",
          "passed": true,
          "expected_amount": 2500.00,
          "actual_amount": 2500.00,
          "variance": 0.00
        }
      ],
      "source_evidence": "MSA page 2, para 3.1",
      "recommendation": "AUTO-APPROVE"
    },
    {
      "line_number": 2,
      "line_description": "After-hours Cleaning (Jan 30) - 3 hours @ $175/hr",
      "charge_term_id": "abc-adhoc-cleaning-2025",
      "charge_term_name": "After-hours Cleaning",
      "status": "REJECT",
      "routing": "deep_path",
      "matching_confidence": 0.95,
      "validators_run": [
        {
          "validator": "line_amount_equals",
          "passed": false,
          "expected_amount": 450.00,
          "actual_amount": 525.00,
          "variance": 75.00,
          "tolerance": 0.0
        },
        {
          "validator": "precondition_check",
          "passed": false,
          "required_conditions": ["PO required"],
          "unmet_conditions": ["PO required"],
          "supporting_docs": {}
        }
      ],
      "source_evidence": "MSA page 2 para 3.2 (contract rate $150/hr)",
      "recommendation": "REJECT: Rate variance of $75 + missing PO. Request corrected invoice and PO/authorization."
    },
    {
      "line_number": 3,
      "line_description": "Restroom Supplies",
      "charge_term_id": "abc-restroom-supplies-2025",
      "charge_term_name": "Restroom Supplies",
      "status": "NEEDS_REVIEW",
      "charge_type": "PASS_THROUGH",
      "validators_run": [
        {
          "validator": "line_amount_equals",
          "passed": true,
          "expected_amount": 200.00,
          "actual_amount": 200.00,
          "variance": 0.00
        },
        {
          "validator": "pass_through_requires_cost_evidence",
          "passed": false,
          "required_evidence": ["vendor_invoice", "receipt"],
          "supporting_docs_provided": []
        }
      ],
      "source_evidence": "MSA page 2, Pricing table row 3",
      "recommendation": "NEEDS_DOCS: Request vendor invoice or receipt for supplies."
    }
  ],
  "invoice_summary": {
    "invoice_date": "2025-02-01",
    "service_period": "2025-02",
    "invoiced_total": 3499.13,
    "expected_total": 3417.75,
    "total_variance": 81.38,
    "lines_auto_approved": 1,
    "lines_rejected": 1,
    "lines_needs_review": 1,
    "overall_status": "REJECT_WITH_VARIANCES"
  },
  "audit_trail": [
    {
      "step": "parsing",
      "timestamp": "2025-02-01T14:00:00Z",
      "status": "success",
      "details": "Parsed 3 invoice lines"
    },
    {
      "step": "routing",
      "timestamp": "2025-02-01T14:00:05Z",
      "status": "success",
      "details": "Line 1: fast_path. Line 2: deep_path (ambiguous rate). Line 3: deep_path (pass-through)"
    },
    {
      "step": "matching",
      "timestamp": "2025-02-01T14:00:10Z",
      "status": "success",
      "details": "All 3 lines matched to contract terms"
    },
    {
      "step": "validation",
      "timestamp": "2025-02-01T14:00:20Z",
      "status": "success",
      "details": "1 passed, 1 rejected, 1 needs_review"
    }
  ]
}
```

**Response (400 Bad Request)**:
```json
{
  "error": "Invalid request",
  "details": {
    "contract_id": "Contract not finalized; cannot reconcile invoices"
  }
}
```

---

### POST /invoices/reconcile-from-text (Deprecated)

Legacy compatibility endpoint for callers that still send raw YAML/markdown invoice text.
This endpoint exists for backward compatibility and should not be used for new integrations.

**Request**:
```json
{
  "contract_id": "abc-cleaning-uh-2025-01",
  "invoice_text": "<legacy YAML/markdown invoice text>",
  "source_name": "invoice",
  "metadata": {}
}
```

Returns the same response schema as `POST /invoices/reconcile`.

---

### GET /invoices/{invoice_id}

Retrieve reconciliation result for an invoice.

**Response (200 OK)**:
```json
{
  "invoice_id": "inv-abc-2025-02-001",
  "contract_id": "abc-cleaning-uh-2025-01",
  "status": "completed",
  "processing_time_ms": 2500,
  "created_at": "2025-02-01T14:00:00Z",
  "findings": [...]  // Same as reconcile response
}
```

---

### GET /invoices/{invoice_id}/findings/{line_number}

Retrieve detailed finding for a specific invoice line.

**Response (200 OK)**:
```json
{
  "invoice_id": "inv-abc-2025-02-001",
  "line_number": 2,
  "finding": {
    "line_description": "After-hours Cleaning (Jan 30) - 3 hours @ $175/hr",
    "charge_term_id": "abc-adhoc-cleaning-2025",
    "charge_term_name": "After-hours Cleaning",
    "status": "REJECT",
    "routing": "deep_path",
    "matching_confidence": 0.95,
    "matching_reasoning": "Name and unit match exactly; rate differs but does not affect matching",
    "validators_run": [
      {
        "validator_name": "line_amount_equals",
        "validator_logic": "rate × quantity = expected_amount",
        "inputs": {
          "contract_rate": 150.00,
          "invoice_quantity": 3,
          "invoice_charged": 525.00
        },
        "expected_result": 450.00,
        "actual_result": 525.00,
        "passed": false,
        "variance": 75.00,
        "variance_pct": 16.67
      },
      {
        "validator_name": "precondition_check",
        "validator_logic": "All required preconditions must have supporting evidence",
        "inputs": {
          "required_conditions": ["PO required"],
          "supporting_docs_provided": {}
        },
        "unmet_conditions": ["PO required"],
        "passed": false
      }
    ],
    "source_evidence": {
      "document": "MSA",
      "page": 2,
      "section": "Pricing & Billing",
      "excerpt": "After-hours Cleaning: $150/hour, billed separately, requires PO",
      "table_reference": "Pricing table, row 2"
    },
    "recommendation": {
      "action": "REJECT",
      "reason": "Rate variance and missing precondition",
      "steps": [
        "Contact vendor ABC Cleaning",
        "Confirm service date and hours (Jan 30, 3 hours)",
        "Request corrected invoice showing $150/hour rate (total $450)",
        "Request PO or written authorization for ad-hoc service",
        "Re-submit invoice after corrections"
      ]
    }
  },
  "audit_entry_id": "audit-inv-abc-2025-02-001-l2"
}
```

---

### GET /invoices/{invoice_id}/audit

Retrieve full audit trail for reconciliation of an invoice.

**Response (200 OK)**:
```json
{
  "invoice_id": "inv-abc-2025-02-001",
  "audit_entries": [
    {
      "entry_id": "audit-inv-abc-2025-02-001-parse",
      "timestamp": "2025-02-01T14:00:00Z",
      "step": "parsing",
      "status": "success",
      "input": "<invoice markdown content>",
      "output": {
        "invoice_date": "2025-02-01",
        "lines_parsed": 3
      }
    },
    {
      "entry_id": "audit-inv-abc-2025-02-001-route-l1",
      "timestamp": "2025-02-01T14:00:05Z",
      "step": "routing",
      "line_number": 1,
      "status": "success",
      "cached_fast_path_hit": true,
      "routing_decision": "fast_path"
    },
    {
      "entry_id": "audit-inv-abc-2025-02-001-match-l2",
      "timestamp": "2025-02-01T14:00:08Z",
      "step": "matching",
      "line_number": 2,
      "status": "success",
      "candidates_retrieved": 2,
      "best_candidate_confidence": 0.95,
      "llm_ambiguity_call": true,
      "llm_call_id": "llm-call-123456",
      "llm_response": {
        "selected_charge_term_id": "abc-adhoc-cleaning-2025",
        "confidence": 0.92,
        "reasoning": "Service description is After-hours Cleaning..."
      }
    },
    {
      "entry_id": "audit-inv-abc-2025-02-001-validate-l2",
      "timestamp": "2025-02-01T14:00:15Z",
      "step": "validation",
      "line_number": 2,
      "status": "success",
      "validators_dispatched": ["line_amount_equals", "precondition_check"],
      "findings": {
        "line_amount_equals": {
          "passed": false,
          "variance": 75.00
        },
        "precondition_check": {
          "passed": false,
          "unmet": ["PO required"]
        }
      }
    }
  ]
}
```

---

## Error Handling

All errors follow this format:

```json
{
  "error": "<error code>",
  "message": "<human-readable message>",
  "details": {
    "<field>": "<reason>"
  },
  "request_id": "<unique ID for debugging>"
}
```

**Common Error Codes**:
- `400 Bad Request`: Malformed input
- `404 Not Found`: Resource not found
- `422 Unprocessable Entity`: Validation error in request body
- `500 Internal Server Error`: Server error
- `503 Service Unavailable`: LLM service unreachable

---

## Rate Limiting

(Future): Add rate limiting headers

```
X-RateLimit-Limit: 1000
X-RateLimit-Remaining: 999
X-RateLimit-Reset: 1640995200
```

---

## Pagination (Future)

(Future): Add pagination for large result sets

```json
{
  "items": [...],
  "pagination": {
    "page": 1,
    "page_size": 50,
    "total_items": 150,
    "total_pages": 3
  }
}
```

---

## Example Workflows

### Workflow 1: Happy Path (All Lines Pass)

```
1. POST /contracts/ingest
   └─> contract_id: contract-123

2. GET /contracts/contract-123/status (poll until "indexed")
   └─> status: "indexed"

3. POST /contracts/contract-123/finalize
   └─> status: "finalized"

4. POST /invoices/reconcile
   └─> status: "PASS_ALL_LINES" (all auto-approved)

5. GET /invoices/inv-456/findings
   └─> All findings status: "PASS"
```

### Workflow 2: Some Lines Rejected (Needs Human Review)

```
1-3. (same as Workflow 1)

4. POST /invoices/reconcile
   └─> status: "REJECT_WITH_VARIANCES"
   └─> findings: [PASS, REJECT, NEEDS_REVIEW]

5. GET /invoices/inv-456/findings/2 (detailed review of line 2)
   └─> Show rate variance, missing docs, recommendations

6. (Human corrects invoice and re-submits)
```

### Workflow 3: Contract Amendment

```
1. Contract ingested and finalized

2. Vendor sends amendment (rate increase)

3. POST /contracts/contract-123/ingest (submit amendment document)
   └─> contract_id: contract-123 (same ID)
   └─> status: "amending"

4. GET /contracts/contract-123/status (poll)
   └─> status: "indexed" (amendment parsed and merged)

5. POST /contracts/contract-123/finalize (re-finalize with new terms)
   └─> status: "finalized"

6. Future invoices use new rates; old fast-path cache entries expire
```
