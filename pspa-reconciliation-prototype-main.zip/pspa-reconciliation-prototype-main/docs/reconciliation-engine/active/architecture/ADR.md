# Architecture Decision Records (ADR)

## ADR-001: Use RDF Triples as Canonical Data Representation

**Status**: Accepted

**Context**
We need to store contract terms and enable future integration with StarDog, a semantic graph database. We also need to represent complex relationships (amendments, effective dates, location scopes, source citations) in a way that's both queryable and auditable.

**Decision**
Use RDF (Resource Description Framework) triples as the canonical representation of all domain data (ChargeTerm, VendorRelationship, Amendment, Invoice, etc.). In the MVP, store and query triples in an in-memory mock graph using `rdflib`. Later, replace the mock with StarDog by implementing the same `GraphRepository` interface.

**Rationale**
- **Standard format**: RDF is industry-standard and enables portability to any RDF store (StarDog, SPARQL endpoints, etc.).
- **Auditability**: Each assertion has explicit subject, predicate, object; easy to trace who said what when.
- **Composability**: Multiple documents can contribute triples to the same subject without merge conflicts.
- **Query flexibility**: SPARQL (or SPARQL-like) queries enable complex navigation (find all charge terms active on date X for location Y).
- **Extensibility**: Adding new attributes to ChargeTerm is as simple as adding new triples; no schema migration.

**Consequences**
- Slight learning curve for team unfamiliar with RDF/SPARQL.
- RDF syntax is verbose for simple data; queries are more complex than SQL for flat datasets.
- Performance depends on graph backend; mock will be slow for large datasets (acceptable for MVP).
- Must maintain mapping between domain models and RDF triple generation.

**Alternatives Considered**
- Relational database (PostgreSQL): Simpler for flat data, but harder to model complex relationships and future graph queries.
- NoSQL document store (MongoDB): Flexible, but no built-in query optimization for relationships.
- Custom object graph (in-memory): Fast MVP, but no path to StarDog integration without rewrite.

---

## ADR-002: Two-Tier Routing (Fast Path vs. Deep Path)

**Status**: Accepted

**Context**
We want to make most invoice lines fast (< 500ms) while handling ambiguous cases with LLM. However, every line must have the same deterministic validation logic, so we can't just "use LLM for everything."

**Decision**
Implement two-tier routing:
1. **Fast path**: Try exact match or cached rule lookup. If confident match found, run deterministic validators only (no LLM, no complex graph queries).
2. **Deep path**: If fast-path misses, run semantic matching against the ontology graph, and call LLM for ambiguity resolution if needed.

Route decision is based on:
- Candidate confidence score (>0.95 → fast path)
- Cache hit status (exact match in fast-path cache → fast path)
- Term maturity (new or frequently-changing terms stay in deep path longer)

**Rationale**
- **Cost control**: Fast-path routes ~70% of lines with no LLM, saving ~ทรก LLM calls.
- **Latency**: Fast-path completes in <500ms; deep-path takes 2-10s but only for hard cases.
- **Clarity**: Two distinct paths with clear decision logic; easier to debug and optimize than a single blended approach.
- **Progressive optimization**: As the system sees more invoices, it learns which lines are safe to fast-path; cost and latency naturally improve over time.

**Consequences**
- Routing logic adds complexity; must test decision logic carefully (false positives/negatives in routing are worse than LLM errors).
- Cache invalidation is critical; stale cache can cause wrong fast-path decisions.
- Metrics and observability are essential to detect when routing goes wrong.

**Alternatives Considered**
- All-LLM approach: Simple but expensive and slow; no auditability.
- All-deterministic approach: Fast and cheap, but fails on any novelty.
- Single path with branching: No clear separation; harder to reason about.

---

## ADR-003: Validators Are Deterministic Functions, Not LLM

**Status**: Accepted

**Context**
Validation (checking arithmetic, preconditions, tax rules, etc.) is the most critical part of reconciliation for audit and payment control. It must be reproducible, auditable, and cannot have randomness or hallucinations.

**Decision**
All validators are hand-coded, deterministic functions that:
- Take structured inputs (rates, quantities, dates, flags)
- Return structured `ValidationResult` objects with expected, actual, variance, pass/fail
- Are never called by LLM; they are called by a deterministic orchestrator
- Are registry-driven (charge term type determines which validators to run)
- Do not call external services

**Rationale**
- **Reproducibility**: Same invoice, run twice, same result every time (essential for audit).
- **Auditability**: Every finding links to specific validator and source evidence; easy to trace reasoning.
- **Performance**: Validators are pure functions; can be parallelized, cached, tested exhaustively.
- **Explainability**: Validator output is deterministic and explainable; no "black box."
- **Certification**: For payment approval workflows, deterministic logic is easier to certify (e.g., SOC 2).

**Consequences**
- All validation logic must be hardcoded; no machine learning or pattern-based discovery.
- If a validation rule is wrong, humans must code the fix (not learn from feedback).
- Handling novel edge cases requires new validator code, not just data changes.

**Alternatives Considered**
- LLM-based validators: Flexible but non-deterministic, expensive, hard to debug and audit.
- ML-trained validators: Possible but requires training data; overkill for rule-based validation.
- Configuration-based validators: Possible but adds complexity; stick with code for clarity.

---

## ADR-004: LLM Used Only for Extraction and Ambiguity Resolution

**Status**: Accepted

**Context**
LLMs are useful for understanding contract language (extraction) and resolving ambiguous line matches. But they're expensive and slow for every line. We need to limit LLM use to high-value cases.

**Decision**
LLM is called in exactly two scenarios:
1. **Contract extraction**: Extract charge terms from contract documents (once per contract, not per invoice).
2. **Ambiguity resolution**: When invoice line matching produces multiple equally-likely candidates or confidence is low (<0.7), ask LLM to disambiguate.

All other decisions (validation, basic matching, routing) are deterministic and do not call LLM.

**Rationale**
- **Cost reduction**: LLM is called for ~5-15% of invoice lines (ambiguous cases), not all lines.
- **Latency**: Most lines are processed in <500ms (fast path), not waiting for LLM.
- **Auditability**: When LLM is called, it's explicitly flagged and the reasoning is logged.
- **Fallback**: If LLM fails or returns nonsense, the finding is marked "needs_review" (human fallback).

**Consequences**
- Requires good extraction quality upfront (bad extraction → more ambiguous lines → more LLM calls).
- Ambiguity resolution agents must be well-designed (if LLM picks wrong candidate, finding is wrong).
- Cannot use "few-shot" learning or in-context tuning to fix validation logic; must code it.

**Alternatives Considered**
- LLM for all decisions: Simple but expensive (~$2-5 per invoice × 1000s of invoices = $$$$).
- No LLM: All matching/extraction done with rules; brittle, cannot handle novelty.

---

## ADR-005: Graph Database Abstraction Layer

**Status**: Accepted

**Context**
We want to start with a mock in-memory graph for MVP speed, but end with StarDog in production. We need a way to swap implementations without rewriting the application logic.

**Decision**
Define a `GraphRepository` interface with methods like `insert_triples()`, `query_charge_terms()`, `delete_triples()`, etc. All application code calls this interface. Implement two versions:
1. `MockGraph`: In-memory store using dictionaries/lists. Fast to implement, no external dependency.
2. `StardogAdapter`: Calls StarDog HTTP API or Java client. Implemented later when needed.

Both implement the same interface; application code is agnostic to which backend is in use.

**Rationale**
- **Rapid MVP**: Mock graph is quick to build and requires no infrastructure.
- **Future-proof**: StarDog integration is straightforward; just implement the same interface.
- **Testing**: Unit tests use mock; no external dependencies needed.
- **Portability**: Could replace StarDog with any other RDF store (Ontotext GraphDB, etc.) by implementing the interface.

**Consequences**
- Mock graph supports only basic SPARQL-like queries; production StarDog queries might be more complex.
- Must keep interface generic enough to work with multiple backends (sometimes hard for advanced features).
- Mock doesn't enforce RDF constraints (e.g., datatypes); real RDF stores might catch errors mock misses.

**Alternatives Considered**
- Direct StarDog from the start: Requires external infrastructure, slows MVP, costs $$.
- SQL database with ORM: Possible but forced into relational model; loses RDF/graph benefits.
- Custom in-memory store: Possible but must rewrite later for StarDog migration.

---

## ADR-006: Markdown + YAML as Input Format (Not PDF)

**Status**: Accepted

**Context**
Contracts and invoices are often PDF. But PDF parsing is complex, lossy, and error-prone. We need structured input.

**Decision**
Require contract and invoice documents as Markdown or YAML (human-friendly text formats), not PDF. This assumes OCR/extraction has already been done elsewhere. Application provides parsers for both formats and auto-detects format.

**Rationale**
- **Simplicity**: Markdown/YAML parsing is robust and lossless; no ambiguity.
- **Auditability**: Text input preserves exact wording; easy to diff versions.
- **Separation of concerns**: OCR/extraction is someone else's problem (doc intake team, external service, etc.).
- **Editability**: Humans can easily hand-correct extracted text before ingestion.

**Consequences**
- Input preparation (PDF → markdown) is upstream responsibility, not ours.
- Loses visual layout information (tables can be expressed in markdown but less intuitively).
- Non-technical users might struggle to prepare inputs (mitigated by templates and examples).

**Alternatives Considered**
- Native PDF parsing: Complex, error-prone; not better than requiring pre-extraction.
- Database form input: More structure but less flexible; doesn't match how contracts are written.
- JSON API: Possible but verbose; markdown is more human-friendly.

---

## ADR-007: No Authentication/Authorization in MVP

**Status**: Accepted

**Context**
The system needs to be usable by internal teams. Security is important but not a blocker for MVP.

**Decision**
MVP has no authentication or authorization. All endpoints are public and rate-limited only by API gateway (if any). In production (future), add OAuth2, role-based access control, and audit logging.

**Rationale**
- **Speed**: Focuses MVP on reconciliation logic, not security infrastructure.
- **Clarity**: No security logic mixed with business logic; easier to understand and test.
- **Future-proof**: Security layer can be added later without changing reconciliation code.

**Consequences**
- MVP must be deployed in a trusted environment (internal systems only).
- No per-user or per-contract access control; anyone with API access can see all contracts and invoices.
- Must add security before production deployment to external users.

**Alternatives Considered**
- API Key auth: Simple but not sufficient for real access control.
- OAuth2 from start: Correct but adds complexity; not needed for MVP.

---

## ADR-008: Fast-Path Cache Uses TTL (Time-To-Live)

**Status**: Accepted

**Context**
We want to cache matching results to enable fast-path routing, but contracts can change (amendments, rate updates). Stale cache is dangerous.

**Decision**
Fast-path cache entries have a TTL (time-to-live). Cache entry is valid for N days (configurable, default 30 days). After TTL expires, entry is re-evaluated against the deep-path. If still valid, it's re-cached; if contract changed, new finding is generated.

**Rationale**
- **Staleness control**: Bounds the maximum age of cached data.
- **Automatic refresh**: Cache naturally refreshes as new invoices arrive.
- **Amendment handling**: When contract amendment is ingested, old cache entries gradually expire and re-evaluate.

**Consequences**
- Requires tracking cache entry timestamps.
- Some cache entries might be evicted and re-computed unnecessarily (acceptable for accuracy).
- Must monitor cache hit/miss rates to tune TTL.

**Alternatives Considered**
- No cache: Safe but slow; defeats fast-path purpose.
- Invalidate cache on contract update: Requires knowing which entries are affected; complex logic.
- Infinite cache with manual invalidation: Risky; cached entries might never expire.

---

## ADR-009: All Findings Include Source Citations

**Status**: Accepted

**Context**
For audit and explainability, every finding must be traceable back to the source contracts and validators that produced it.

**Decision**
Every `Finding` object includes:
- `source_evidence`: direct link to contract document, page, span (e.g., "MSA page 2, para 3.1")
- `validators_run`: list of validators executed and their results
- `validator_citations`: each validator result includes its inputs and logic
- `timestamp`: when finding was generated
- `llm_calls`: if LLM was called, log the prompt and response (for ambiguity cases)

**Rationale**
- **Auditability**: Reviewers can click through to source evidence in milliseconds.
- **Debugging**: If a finding is wrong, reviewers can trace through validator logic.
- **Learning**: Over time, we can analyze findings to improve extraction or validation.
- **Compliance**: Audit trails are often required for payment controls.

**Consequences**
- Must preserve source document references throughout extraction, matching, and validation.
- Findings objects are more verbose (good for auditability, bad for performance).
- Must carefully design citation format (URIs, page/span notation, etc.).

**Alternatives Considered**
- Minimal findings (just pass/fail): Faster but impossible to debug or explain.
- Findings only link to charge terms (not source): Loses traceability.

---

## ADR-010: Separation of Concerns: Extraction ≠ Matching ≠ Validation

**Status**: Accepted

**Context**
The reconciliation pipeline has three distinct concerns: understanding contracts (extraction), finding invoice lines in contracts (matching), and checking correctness (validation). Mixing them leads to confusion and errors.

**Decision**
Enforce strict separation:
1. **Extraction** (contract ingestion): LLM + deterministic rules to extract ChargeTerm objects from documents. Output is normalized structured data.
2. **Matching** (invoice processing): Deterministic + semantic rules to map InvoiceLine to a ChargeTerm. Output is a MatchCandidate.
3. **Validation** (invoice processing): Deterministic validators to check correctness of the matched pair. Output is ValidationResult.

Each stage has clear input/output contracts. Errors in one stage don't cascade to others.

**Rationale**
- **Clarity**: Easier to reason about, test, and debug.
- **Reusability**: Validators can be tested independently of matching; extraction can be audited separately.
- **Improvements**: Can improve matching without changing validation or vice versa.

**Consequences**
- Must design clear interfaces between stages.
- Bugs in one stage might not surface until later; good error handling needed.

**Alternatives Considered**
- Monolithic "reconcile this invoice against this contract" function: Simple but opaque and unmaintainable.

---

## ADR-011: Charge Term Types as Enum, Not Polymorphism

**Status**: Accepted

**Context**
Charge terms vary (fixed-rate, variable, pass-through, contingency, etc.). Each type has different validation logic. How do we model this?

**Decision**
Charge terms have a `charge_type` enum field (FIXED_RATE, VARIABLE_RATE, PASS_THROUGH, CONTINGENCY, SUBSCRIPTION, OVERAGE, etc.). Validators are registered per type in the `ValidatorRegistry` (not via OOP polymorphism). The orchestrator looks up `charge_type` and dispatches to registered validators.

**Rationale**
- **Simplicity**: All charge terms are the same class; just different enum values.
- **Table-driven**: Easy to see which validators apply to which types in one place (the registry).
- **Extensibility**: Adding a new charge type is one enum value + one registry entry.

**Consequences**
- Must maintain the registry; new types must be explicitly registered.
- Cannot use OOP dispatch (no virtual methods); must use registry lookup instead.

**Alternatives Considered**
- OOP polymorphism (ChargeTerm base class, FixedRateChargeTerm subclass, etc.): Explicit but verbose and hard to modify later.
- Dynamic dispatch via LLM: Overkill; validators are deterministic rules, not learned patterns.

---

## ADR-012: Order of Execution: Matching → Routing → Validation

**Status**: Accepted

**Context**
The pipeline has three main steps. What order should they run in?

**Decision**
1. **Matching**: Identify which contract term an invoice line refers to.
2. **Routing**: Decide whether to use fast-path or deep-path validators.
3. **Validation**: Run validators appropriate to the charge term type.

This order makes sense because:
- Can't validate before matching; don't know what term to check against.
- Can't route before matching; routing decision depends on candidate confidence.

**Rationale**
- **Logical flow**: Dependencies naturally flow in this direction.
- **Efficiency**: Matching is cheap (deterministic); routing reuses matching results.

**Consequences**
- None; this is the only sensible order.

---

## Summary of Key Decisions

| ADR | Decision | Why |
| --- | --- | --- |
| 001 | RDF triples canonical | Standard format, auditable, future StarDog compatibility |
| 002 | Two-tier routing | Cost/latency control; fast path for 70% of lines, deep path for ambiguous |
| 003 | Deterministic validators | Reproducibility, auditability, certification-ready |
| 004 | LLM for extraction + ambiguity only | Cost control; ~5-15% of lines use LLM |
| 005 | GraphRepository abstraction | MVP with mock, production with StarDog, both same interface |
| 006 | Markdown/YAML input (not PDF) | Simplicity, auditability; assumes pre-extraction |
| 007 | No MVP auth | Speed; security added in production |
| 008 | Fast-path cache with TTL | Staleness control; automatic refresh on contract updates |
| 009 | All findings include citations | Auditability, debuggability, compliance |
| 010 | Extraction ≠ Matching ≠ Validation | Clear separation; easier to test, debug, improve |
| 011 | Enum charge types + registry | Simplicity, extensibility, table-driven dispatch |
| 012 | Order: Matching → Routing → Validation | Natural dependency flow |
