# Approach 5: Ontology-Agent + Two-Tier Routing (Hybrid D)

## Summary

This is the strategic implementation approach combining:
- **Approach 3 (Ontology-Backed Agent)**: Core system-of-record semantics with deterministic validators and targeted LLM reasoning for ambiguous cases.
- **Alternative D (Two-Tier Routing)**: Fast-path/deep-path dispatch for operational efficiency and progressive cost optimization.

The result is a production-ready reconciliation service that:
- Processes contracts to build a governed ontology stored as RDF triples.
- Routes invoice lines through a fast path (deterministic, cached) when confidence is high.
- Routes to a deep path (ontology + LLM) only when ambiguity requires reasoning.
- Gradually promotes stable deep-path outcomes into fast-path templates.
- Pluggable graph backend (mock for MVP, StarDog for production).

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   HTTP API Layer                            │
│  POST /contracts/ingest  POST /contracts/{id}/finalize     │
│  POST /invoices/reconcile  GET /findings/{id}              │
└──────────────────────────┬──────────────────────────────────┘
                           │
       ┌───────────────────┴────────────────────┐
       │                                        │
┌──────▼──────────────────┐    ┌──────────────▼─────────────┐
│   Contract Pipeline      │    │  Invoice Pipeline         │
│  ────────────────────    │    │  ──────────────────       │
│  1. Parse MD/YML        │    │  1. Parse MD/YML         │
│  2. Extract terms (LLM) │    │  2. Normalize lines      │
│  3. Generate triples    │    │  3. Route (tier logic)   │
│  4. Populate graph      │    │  4. Execute validators   │
│  5. Build rules cache   │    │  5. Generate findings    │
└──────────────────────────┘    └─────────────┬──────────────┘
       │                                      │
       │         ┌────────────────────────────┘
       │         │
       ▼         ▼
┌─────────────────────────────────────────────────────────────┐
│            Two-Tier Routing & Orchestration                │
│  ┌──────────────────┐        ┌──────────────────────────┐  │
│  │  Route Decision  │        │  Validator Orchestrator  │  │
│  │  Logic           │        │  ─────────────────────   │  │
│  │  ─────────────   │        │  - Dispatch validators   │  │
│  │  - Candidate     │        │  - Collect results       │  │
│  │    confidence    │        │  - Aggregate status      │  │
│  │  - Term maturity │        │  - Promote if stable     │  │
│  │  - Fast-path hit │        │                          │  │
│  └──────────────────┘        └──────────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                           │
           ┌───────────────┴───────────────┐
           │                               │
    ┌──────▼──────────┐           ┌────────▼──────────────┐
    │  Fast Path      │           │  Deep Path           │
    │  ────────────   │           │  ──────────────      │
    │  1. Template    │           │  1. Graph query      │
    │     lookup      │           │  2. Semantic match   │
    │  2. Exact cached│           │  3. LLM adjudication │
    │     validators  │           │  4. Complex logic    │
    │  3. No LLM      │           │  5. Context-aware    │
    │  ⏱ <500ms       │           │  ⏱ 2-10s range      │
    │  💰 Low cost    │           │  💰 Higher cost     │
    └────────┬────────┘           └────────┬─────────────┘
             │                             │
             └─────────────┬───────────────┘
                           │
               ┌───────────▼────────────┐
               │  Finding Aggregator    │
               │  ────────────────────  │
               │  - Combine results     │
               │  - Check for promotion │
               │  - Generate audit log  │
               │  - Prepare response    │
               └───────────┬────────────┘
                           │
                    ┌──────▼──────────┐
                    │  Graph Database │
                    │  ──────────────│
                    │  RDF Triples   │
                    │  (Mock/StarDog)│
                    └────────────────┘
```

## Key Design Decisions

1. **API-First**: All interactions through REST endpoints; no direct graph access from clients.
2. **RDF Triple Representation**: Contract and invoice data stored as RDF to enable future StarDog integration.
3. **Graph Database Abstraction**: GraphRepository interface allows swapping implementations (mock → StarDog).
4. **Deterministic Validators**: Pure functions, no LLM involved; all validation results are reproducible and auditable.
5. **LLM for Extraction Only**: LLM used only during contract onboarding and for targeted reasoning on ambiguous lines.
6. **Two-Tier Dispatch**: Routing decision happens before validation; fast-path is always tried first.
7. **Progressive Cost Optimization**: Stable findings are promoted to fast-path templates over time; drift detection triggers re-evaluation.

## Directory Structure

```
05-ontology-agent-d-hybrid/
├── README.md                      # This file
├── plan.md                         # Step-by-step implementation plan
├── ADR.md                          # Architecture decision records
├── AGENTS.md                       # LLM agent specifications
├── API.md                          # REST API specification
├── DATA_MODEL.md                   # RDF schema and data model
├── IMPL_CHECKLIST.md               # Detailed component checklist
└── implementation/
    ├── api/
    │   ├── contract_endpoints.py
    │   ├── invoice_endpoints.py
    │   ├── health_endpoints.py
    │   └── request_models.py
    ├── core/
    │   ├── contract_processor.py
    │   ├── invoice_processor.py
    │   ├── ontology_builder.py
    │   └── routing_engine.py
    ├── validators/
    │   ├── arithmetic_validators.py
    │   ├── temporal_validators.py
    │   ├── precondition_validators.py
    │   ├── tax_validators.py
    │   ├── orchestrator.py
    │   └── validator_registry.py
    ├── graph/
    │   ├── graph_repository.py      # Abstract interface
    │   ├── mock_graph.py             # In-memory mock implementation
    │   ├── stardog_adapter.py        # StarDog driver (future)
    │   ├── rdf_generator.py          # Triple generation
    │   ├── ontology_schema.py        # RDF class/property definitions
    │   └── prefixes.py               # RDF namespace prefixes
    ├── llm/
    │   ├── contract_extraction_agent.py
    │   ├── ambiguity_resolver_agent.py
    │   ├── prompts.py
    │   └── llm_client.py
    ├── matching/
    │   ├── candidate_retriever.py
    │   ├── similarity.py
    │   ├── ranking.py
    │   └── matching_engine.py
    ├── models/
    │   ├── contract_models.py        # ChargeTerm, VendorRelationship, etc.
    │   ├── invoice_models.py         # Invoice, InvoiceLine, etc.
    │   └── finding_models.py         # Finding, ValidationResult, etc.
    ├── data_parsers/
    │   ├── markdown_parser.py        # Parse MD contract/invoice format
    │   ├── yaml_parser.py            # Parse YAML contract/invoice format
    │   └── parser_registry.py        # Format auto-discovery
    ├── storage/
    │   ├── file_persistence.py       # Metadata & audit log storage
    │   └── json_serializers.py
    ├── utils/
    │   ├── logging.py
    │   ├── config.py
    │   ├── errors.py
    │   └── tracing.py
    ├── tests/
    │   ├── test_contract_pipeline.py
    │   ├── test_invoice_pipeline.py
    │   ├── test_validators.py
    │   ├── test_routing.py
    │   ├── test_graph_operations.py
    │   └── fixtures/
    │       ├── sample_contracts.md
    │       ├── sample_invoices.md
    │       └── expected_findings.json
    ├── requirements.txt
    ├── main.py                      # FastAPI app entry point
    └── README.md                    # Implementation-specific notes
```

## Execution Flow (Core Example)

### Contract Ingestion

```
1. Client POST /contracts/ingest
   Body: { "vendor_id": "abc-cleaning", "documents": [...markdown...] }
   
2. ContractProcessor.parse_documents()
   - Parse markdown/YAML
   - Extract text spans
   
3. ContractExtractionAgent (LLM)
   - Call LLM with extracted text
   - Output: structured ChargeTerm records with source citations
   
4. RDFGenerator.generate_triples()
   - Convert ChargeTerm → RDF Subject/Predicate/Object triples
   - Example: abc-cleaning-term-1 rdf:type scb:ChargeTerm
   - Example: abc-cleaning-term-1 scb:rate "150.00"^^xsd:decimal
   
5. GraphRepository.persist_triples()
   - Mock: store in in-memory graph
   - StarDog: SPARQL INSERT
   
6. OntologyBuilder.build_contract_index()
   - Create lookup cache for fast matching
   - Store effective dates, locations, aliases
   
7. Return: { "contract_id": "...", "terms_count": 3, "status": "ingested" }

8. Client POST /contracts/{contract_id}/finalize
   - Lock contract (no more updates)
   - Run full validation of extracted terms
   - Compile fast-path rules from high-confidence terms
   - Move to "indexed" state
```

### Invoice Reconciliation

```
1. Client POST /invoices/reconcile
   Body: { "contract_id": "...", "invoice": [...markdown...] }
   
2. InvoiceProcessor.parse_invoice()
   - Parse markdown/YAML
   - Normalize line items
   
3. RoutingEngine.route(lines, contract)
   For each line:
     a. Check fast-path first (cached templates, exact matches)
        - If hit & confidence > 0.95: use fast-path validator set
        - Result: <500ms, no LLM
     
     b. If fast-path miss or low confidence:
        - Run deep-path (graph query + semantic matching)
        - Retrieve candidate charge terms from graph
        - If ambiguous: call LLM ambiguity resolver
        - Result: 2-10s, LLM may be called
     
     c. If still ambiguous or no match:
        - Flag as "needs_review"
   
4. ValidatorOrchestrator.validate(matched_term, invoice_line)
   - Dispatch deterministic validators based on charge term type
   - Collect results
   - Aggregate to line-level findings
   
5. PromotionEngine.check_for_promotion(findings)
   - If deep-path result is high confidence & stable:
     - Generate fast-path rule and cache
     - Mark term for evaluation in future invoices
   
6. FindingAggregator.aggregate(line_findings)
   - Combine into invoice-level findings
   - Calculate totals
   - Generate audit trail
   
7. Return: { "invoice_id": "...", "findings": [...], "total_variance": ..., "status": "... }
```

## What Gets Built vs. What's Out of Scope

### In Scope (This Implementation)
- REST API layer with contract and invoice endpoints
- Contract parsing (markdown/YAML)
- Invoice parsing (markdown/YAML)
- LLM integration for contract extraction and ambiguity resolution
- RDF triple generation
- Mock graph database (in-memory)
- Deterministic validators (arithmetic, temporal, preconditions, tax, total)
- Matching engine (deterministic + semantic)
- Two-tier routing logic
- Validator orchestration
- Finding generation
- Audit logging
- Unit and integration tests

### Out of Scope (Future Extensions)
- Advanced OCR/document layout analysis (assumes already OCR'd)
- Table extraction from images (assumes markdown/YAML input)
- PDF parsing (only markdown/YAML for MVP)
- User authentication/authorization (no security in MVP)
- Multi-tenancy support
- Bulk invoice ingestion (API handles one-at-a-time)
- Performance optimization (caching, indexing) beyond basic fast-path
- Advanced monitoring/observability (basic logging in MVP)
- StarDog integration (extensible, but not built yet)
- Payment status integration
- Soft amendment reconciliation (amendments must be explicit in docs)

## Success Criteria

1. **Contract Ontology Accuracy**: ChargeTerm objects extracted from contract text match manual review > 90%
2. **Matching Reliability**: Invoice line matches to correct charge term > 95% when term is unambiguous
3. **Fast-Path Performance**: Routes > 70% of lines in <500ms
4. **Deterministic Reproducibility**: Running same invoice twice yields identical findings
5. **Auditability**: Every finding links back to source contract text and validator name
6. **LLM Efficiency**: LLM called only for ~5-15% of invoice lines (ambiguous cases)
7. **Test Coverage**: Unit tests > 80%, integration tests cover happy path + all error cases

## Next Steps

1. Read `plan.md` for detailed implementation sequence and dependencies.
2. Review `ADR.md` for key architecture decisions and rationale.
3. Review `AGENTS.md` for LLM prompt design and integration points.
4. Read `API.md` for complete endpoint specification and examples.
5. Study `DATA_MODEL.md` for RDF schema and triple examples.
6. Use `IMPL_CHECKLIST.md` to track progress on components as they are implemented.
