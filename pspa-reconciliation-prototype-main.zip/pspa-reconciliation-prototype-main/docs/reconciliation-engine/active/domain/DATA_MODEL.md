# Data Model & RDF Schema

## Overview

The service stores all contract and invoice data as RDF (Resource Description Framework) triples. This ensures:
- **Auditability**: Every assertion has subject, predicate, object.
- **StarDog compatibility**: Triples can be loaded into any SPARQL endpoint.
- **Extensibility**: New attributes add new triples; no schema migration.

---

## Namespaces (Prefixes)

```
rdf:     http://www.w3.org/1999/02/22-rdf-syntax-ns#
rdfs:    http://www.w3.org/2000/01/rdf-schema#
xsd:     http://www.w3.org/2001/XMLSchema#
dct:     http://purl.org/dc/terms/                      (Dublin Core for metadata)
scb:     http://vizientinc.com/schema/reconciliation#  (Our domain ontology)
```

### SCB Namespace Vocabulary

All domain-specific concepts are in the `scb:` namespace:

**Classes** (use with `rdf:type`):
- `scb:VendorRelationship` - relationship between vendor and customer
- `scb:ContractDocument` - a contract document (MSA, amendment, etc.)
- `scb:ChargeTerm` - a billable service or fee
- `scb:Invoice` - an invoice document
- `scb:InvoiceLine` - a line item in an invoice
- `scb:Finding` - reconciliation finding for an invoice line
- `scb:ValidationResult` - result of running a validator
- `scb:Location` - service location (e.g., "Building A, Suite 100")
- `scb:Measurement` - measurement or usage (supporting evidence)

**Properties** (use with predicates):
- `scb:vendorId` - vendor identifier (string)
- `scb:vendorName` - vendor name (string)
- `scb:customerId` - customer identifier (string)
- `scb:customerName` - customer name (string)
- `scb:effectiveDate` - effective date (xsd:dateTime)
- `scb:renewalDate` - renewal date (xsd:dateTime)
- `scb:rate` - rate amount (xsd:decimal)
- `scb:rateUnit` - unit for rate (string: "month", "hour", etc.)
- `scb:rateCurrency` - currency (string: "USD", "EUR", etc.)
- `scb:billingInterval` - billing frequency (string)
- `scb:invoiceCadence` - when invoices are issued (string)
- `scb:chargeType` - type of charge (string enum)
- `scb:locationScope` - applicable location(s) (IRI or literal)
- `scb:hasChargeTerm` - relationship from VendorRelationship to ChargeTerm
- `scb:matchedTo` - invoice line matched to charge term
- `scb:sourceDocument` - source evidence document
- `scb:sourcePage` - page number (xsd:integer)
- `scb:sourceSection` - section/paragraph reference (string)
- `scb:extractionConfidence` - confidence score (xsd:decimal, 0.0-1.0)
- `scb:precondition` - a precondition (e.g., "PO required")
- `scb:passthrough` - is pass-through cost (xsd:boolean)
- `scb:invoiceDate` - invoice date (xsd:dateTime)
- `scb:invoiceAmount` - invoice line amount (xsd:decimal)
- `scb:expectedAmount` - expected amount per contract (xsd:decimal)
- `scb:variance` - amount variance (xsd:decimal)
- `scb:validationStatus` - status (PASS, FAIL, CONDITIONAL)
- `scb:validatorName` - name of validator function (string)

---

## Triple Examples

### 1. VendorRelationship

```
Subject: abc-cleaning-uh-2025
Predicates & Objects:

rdf:type                           scb:VendorRelationship
scb:vendorId                       "abc-cleaning"
scb:vendorName                     "ABC Cleaning Services"
scb:customerId                     "uh"
scb:customerName                   "UHS"
scb:effectiveDate                  "2025-01-01"^^xsd:dateTime
scb:renewalDate                    "2026-01-01"^^xsd:dateTime
dct:created                        "2025-02-01T10:00:00Z"^^xsd:dateTime
```

### 2. ChargeTerm (Fixed-Rate)

```
Subject: abc-std-cleaning-2025
Predicates & Objects:

rdf:type                           scb:ChargeTerm
rdfs:label                         "Standard Cleaning"
scb:vendorRelationship             abc-cleaning-uh-2025
scb:name                           "Standard Cleaning"
scb:chargeType                     "FIXED_RATE"
scb:rate                           "2500.00"^^xsd:decimal
scb:rateUnit                       "month"
scb:rateCurrency                   "USD"
scb:billingInterval                "monthly"
scb:invoiceCadence                 "15th of month for following month"
scb:locationScope                  "Building A, Suite 100"
scb:effectiveDate                  "2025-01-01"^^xsd:dateTime
scb:renewalDate                    "2026-01-01"^^xsd:dateTime
scb:serviceScope                   "weekly facility cleaning"
scb:extractionConfidence           "0.98"^^xsd:decimal
scb:sourceDocument                 "MSA"
scb:sourcePage                     "2"^^xsd:integer
scb:sourceSection                  "Pricing, table row 1"
dct:created                        "2025-02-01T10:00:30Z"^^xsd:dateTime
```

### 3. ChargeTerm (Variable-Rate with Precondition)

```
Subject: abc-adhoc-cleaning-2025
Predicates & Objects:

rdf:type                           scb:ChargeTerm
rdfs:label                         "After-hours Cleaning"
scb:vendorRelationship             abc-cleaning-uh-2025
scb:name                           "After-hours Cleaning"
scb:chargeType                     "VARIABLE_RATE"
scb:rate                           "150.00"^^xsd:decimal
scb:rateUnit                       "hour"
scb:billingInterval                "per occurrence"
scb:invoiceCadence                 "billed with next invoice"
scb:locationScope                  "Building A, Suite 100"
scb:effectiveDate                  "2025-01-01"^^xsd:dateTime
scb:renewalDate                    "2026-01-01"^^xsd:dateTime
scb:serviceScope                   "ad-hoc cleaning outside standard hours"
scb:precondition                   "PO required"                    (can have multiple)
scb:extractionConfidence           "0.95"^^xsd:decimal
scb:sourceDocument                 "MSA"
scb:sourcePage                     "2"^^xsd:integer
scb:sourceSection                  "Pricing, table row 2"
dct:created                        "2025-02-01T10:00:30Z"^^xsd:dateTime
```

### 4. ChargeTerm (Pass-Through)

```
Subject: abc-restroom-supplies-2025
Predicates & Objects:

rdf:type                           scb:ChargeTerm
rdfs:label                         "Restroom Supplies"
scb:vendorRelationship             abc-cleaning-uh-2025
scb:name                           "Restroom Supplies"
scb:chargeType                     "PASS_THROUGH"
scb:rate                           "200.00"^^xsd:decimal
scb:rateUnit                       "month"
scb:billingInterval                "monthly"
scb:locationScope                  "Building A, Suite 100"
scb:effectiveDate                  "2025-01-01"^^xsd:dateTime
scb:renewalDate                    "2026-01-01"^^xsd:dateTime
scb:serviceScope                   "consumable supplies pass-through"
scb:passthrough                    "true"^^xsd:boolean
scb:requiresCostEvidence           "true"^^xsd:boolean
scb:extractionConfidence           "0.97"^^xsd:decimal
scb:sourceDocument                 "MSA"
scb:sourcePage                     "2"^^xsd:integer
scb:sourceSection                  "Pricing, table row 3"
dct:created                        "2025-02-01T10:00:30Z"^^xsd:dateTime
```

### 5. Invoice

```
Subject: inv-abc-2025-02-001
Predicates & Objects:

rdf:type                           scb:Invoice
scb:vendorRelationship             abc-cleaning-uh-2025
scb:invoiceDate                    "2025-02-01"^^xsd:dateTime
scb:servicePeriod                  "2025-02"
scb:invoiceAmount                  "3499.13"^^xsd:decimal
scb:taxAmount                      "274.13"^^xsd:decimal
scb:lineCount                      "3"^^xsd:integer
dct:created                        "2025-02-01T14:00:00Z"^^xsd:dateTime
```

### 6. InvoiceLine

```
Subject: inv-abc-2025-02-001-l1
Predicates & Objects:

rdf:type                           scb:InvoiceLine
scb:invoice                        inv-abc-2025-02-001
scb:lineNumber                     "1"^^xsd:integer
scb:description                    "Standard Cleaning"
scb:quantity                       "1.0"^^xsd:decimal
scb:unit                           "month"
scb:unitRate                       "2500.00"^^xsd:decimal
scb:lineAmount                     "2500.00"^^xsd:decimal
```

```
Subject: inv-abc-2025-02-001-l2
Predicates & Objects:

rdf:type                           scb:InvoiceLine
scb:invoice                        inv-abc-2025-02-001
scb:lineNumber                     "2"^^xsd:integer
scb:description                    "After-hours Cleaning (Jan 30) - 3 hours @ $175/hr"
scb:quantity                       "3.0"^^xsd:decimal
scb:unit                           "hour"
scb:unitRate                       "175.00"^^xsd:decimal
scb:lineAmount                     "525.00"^^xsd:decimal
scb:serviceDate                    "2025-01-30"^^xsd:dateTime
```

### 7. Matching Result

```
Subject: inv-abc-2025-02-001-l2-match
Predicates & Objects:

rdf:type                           scb:MatchResult
scb:invoiceLine                    inv-abc-2025-02-001-l2
scb:chargeTerm                     abc-adhoc-cleaning-2025
scb:matchingConfidence             "0.95"^^xsd:decimal
scb:matchingReason                 "Name and unit match exactly; rate differs"
scb:routingPath                    "deep_path"
scb:llmResolved                    "true"^^xsd:boolean
scb:llmCallId                      "llm-call-123456"
dct:created                        "2025-02-01T14:00:08Z"^^xsd:dateTime
```

### 8. Finding (Pass)

```
Subject: finding-inv-abc-2025-02-001-l1
Predicates & Objects:

rdf:type                           scb:Finding
scb:invoiceLine                    inv-abc-2025-02-001-l1
scb:chargeTerm                     abc-std-cleaning-2025
scb:status                         "PASS"
scb:matchingConfidence             "0.98"^^xsd:decimal
scb:sourceEvidence                 "MSA page 2, para 3.1"
scb:recommendation                 "AUTO-APPROVE"
scb:auditTrailId                   "audit-inv-abc-2025-02-001-l1"
dct:created                        "2025-02-01T14:00:20Z"^^xsd:dateTime
```

### 9. Finding (Reject with Variance)

```
Subject: finding-inv-abc-2025-02-001-l2
Predicates & Objects:

rdf:type                           scb:Finding
scb:invoiceLine                    inv-abc-2025-02-001-l2
scb:chargeTerm                     abc-adhoc-cleaning-2025
scb:status                         "REJECT"
scb:matchingConfidence             "0.95"^^xsd:decimal
scb:sourceEvidence                 "MSA page 2 para 3.2"
scb:validatorsFailed               ["line_amount_equals", "precondition_check"]
scb:expectedAmount                 "450.00"^^xsd:decimal
scb:invoicedAmount                 "525.00"^^xsd:decimal
scb:variance                        "75.00"^^xsd:decimal
scb:variancePct                    "16.67"^^xsd:decimal
scb:varianceReason                 "Rate $175/hr exceeds contract $150/hr"
scb:preconditionUnmet              "PO required"
scb:recommendation                 "REJECT: Rate variance + missing PO. Request corrected invoice and authorization."
scb:auditTrailId                   "audit-inv-abc-2025-02-001-l2"
dct:created                        "2025-02-01T14:00:20Z"^^xsd:dateTime
```

### 10. ValidationResult

```
Subject: val-res-inv-abc-2025-02-001-l2-amount
Predicates & Objects:

rdf:type                           scb:ValidationResult
scb:invoiceLine                    inv-abc-2025-02-001-l2
scb:validatorName                  "line_amount_equals"
scb:validatorLogic                 "rate × quantity = expected_amount"
scb:passed                         "false"^^xsd:boolean
scb:contractRate                   "150.00"^^xsd:decimal
scb:invoiceQuantity                "3.0"^^xsd:decimal
scb:expectedAmount                 "450.00"^^xsd:decimal
scb:actualAmount                   "525.00"^^xsd:decimal
scb:variance                       "75.00"^^xsd:decimal
scb:variancePct                    "16.67"^^xsd:decimal
dct:created                        "2025-02-01T14:00:20Z"^^xsd:dateTime
```

---

## Querying Examples

### SPARQL-Like Queries (for mock implementation)

**Find all charge terms for a vendor effective on a date**:

```sparql
SELECT ?term ?name ?rate
WHERE {
  ?vendor rdf:type scb:VendorRelationship ;
          scb:vendorId "abc-cleaning" .
  ?term scb:vendorRelationship ?vendor ;
        scb:name ?name ;
        scb:rate ?rate ;
        scb:effectiveDate ?start ;
        scb:renewalDate ?end .
  FILTER (?start <= "2025-02-01"^^xsd:dateTime && ?end >= "2025-02-01"^^xsd:dateTime)
}
```

**Find all findings for an invoice**:

```sparql
SELECT ?finding ?line ?status ?recommendation
WHERE {
  ?invoice rdf:type scb:Invoice ;
           scb:invoiceId "inv-abc-2025-02-001" .
  ?line scb:invoice ?invoice .
  ?finding scb:invoiceLine ?line ;
           scb:status ?status ;
           scb:recommendation ?recommendation .
}
ORDER BY ?line
```

**Find all findings with rate variance > $50**:

```sparql
SELECT ?finding ?invoiceLine ?variance ?recommendation
WHERE {
  ?finding rdf:type scb:Finding ;
           scb:invoiceLine ?invoiceLine ;
           scb:variance ?variance ;
           scb:recommendation ?recommendation .
  FILTER (?variance > "50.00"^^xsd:decimal)
}
ORDER BY DESC(?variance)
```

**Find all charges that require PO**:

```sparql
SELECT ?term ?name ?rate
WHERE {
  ?term rdf:type scb:ChargeTerm ;
        scb:name ?name ;
        scb:rate ?rate ;
        scb:precondition "PO required" .
}
```

---

## Mock Graph Implementation

For MVP, the mock graph stores triples as Python data structures:

```python
class Triple:
    def __init__(self, subject: str, predicate: str, object_value: Any):
        self.subject = subject      # URI or ID string
        self.predicate = predicate  # Full predicate URI (e.g., "scb:rate")
        self.object = object_value  # Can be string, number, boolean, date, or URI

class MockGraph:
    def __init__(self):
        self.triples: List[Triple] = []
    
    def insert_triple(self, triple: Triple):
        # Append if not duplicate
        if triple not in self.triples:
            self.triples.append(triple)
    
    def query_by_subject(self, subject: str) -> List[Triple]:
        return [t for t in self.triples if t.subject == subject]
    
    def query_by_predicate(self, predicate: str) -> List[Triple]:
        return [t for t in self.triples if t.predicate == predicate]
    
    def query_charge_terms(self, vendor_id: str, date: datetime, location: str):
        # More complex SPARQL-like query
        matching = []
        for t in self.triples:
            if (t.predicate == "scb:vendorId" and t.object == vendor_id and
                # ... additional filters for date, location
            ):
                matching.append(t.subject)  # Return subject URIs
        return matching
```

---

## Future: StarDog Migration

When moving to StarDog:

1. Triples remain identical (same RDF structure).
2. Replace `MockGraph` with `StardogAdapter`.
3. Adapter translates queries to SPARQL and makes HTTP calls to StarDog.
4. No application code changes needed (same interface).

Example StarDog adapter method:

```python
class StardogAdapter(GraphRepository):
    def query_charge_terms(self, vendor_id: str, date: datetime, location: str):
        sparql_query = f"""
        SELECT ?term
        WHERE {{
          ?vendor rdf:type scb:VendorRelationship ;
                  scb:vendorId "{vendor_id}" .
          ?term scb:vendorRelationship ?vendor ;
                scb:effectiveDate ?start ;
                scb:renewalDate ?end .
          FILTER (?start <= "{date}"^^xsd:dateTime && ?end >= "{date}"^^xsd:dateTime)
          FILTER (scb:locationScope "{location}" || !BOUND(?scope))
        }}
        """
        response = requests.post(
            f"{self.stardog_url}/query",
            data={"query": sparql_query},
            auth=(self.username, self.password)
        )
        return self._parse_sparql_response(response)
```

---

## Data Model Diagram

```
VendorRelationship
  ├─ vendorId
  ├─ vendorName
  ├─ customerId
  ├─ customerName
  ├─ effectiveDate
  └─ renewalDate
       │
       ├─→ ChargeTerm (1..*) via hasChargeTerm
       │     ├─ name
       │     ├─ chargeType (enum: FIXED_RATE, VARIABLE_RATE, PASS_THROUGH, etc.)
       │     ├─ rate
       │     ├─ rateUnit
       │     ├─ locationScope
       │     ├─ effectiveDate
       │     ├─ extractionConfidence
       │     ├─ precondition (0..*)
       │     └─ sourceDocument

Invoice (linked to VendorRelationship)
  ├─ invoiceDate
  ├─ invoiceAmount
  ├─ taxAmount
  └─ InvoiceLine (1..*) via hasLine
       ├─ lineNumber
       ├─ description
       ├─ quantity
       ├─ unitRate
       ├─ lineAmount
       ├─ MatchResult (1) via matchedTo
       │   └─ chargeTerm (-> ChargeTerm)
       │   └─ matchingConfidence
       └─ Finding (1) via hasFinding
           ├─ status
           ├─ expectedAmount
           ├─ variance
           └─ ValidationResult (*) via hasValidation
               ├─ validatorName
               ├─ passed
               └─ variance
```
