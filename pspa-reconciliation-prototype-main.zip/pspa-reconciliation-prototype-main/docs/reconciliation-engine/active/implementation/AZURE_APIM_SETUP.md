# Azure APIM Setup Guide

This document explains how to configure and use the PSPA Reconciliation Engine with Azure API Management (APIM) endpoints for all model access.

## Overview

The reconciliation engine now supports Azure APIM as a centralized endpoint for all LLM model access. This allows you to:
- Route all model requests through a managed Azure APIM gateway
- Apply consistent authentication, throttling, and rate limiting policies
- Leverage Azure's monitoring, analytics, and security features
- Support multiple backend models through a single APIM interface

## Configuration

### Environment Variables

Set the following environment variables to use Azure APIM:

```env
# LLM Provider
LLM_PROVIDER=azure-apim

# Azure OpenAI via APIM Configuration
AZURE_OPENAI_ENDPOINT=https://api.vizientinc.com/azure-openai
AZURE_OPENAI_API_KEY=<your API key>
AZURE_OPENAI_API_VERSION=2024-08-01-preview
AZURE_OPENAI_DEPLOYMENT=gpt-5.4

# Model Configuration
LLM_MODEL=gpt-5.4
```

### Configuration Details

| Variable | Description | Example |
|----------|-------------|---------|
| `LLM_PROVIDER` | Must be set to `azure-apim` | `azure-apim` |
| `AZURE_OPENAI_ENDPOINT` | Base URL of your Azure OpenAI APIM endpoint | `https://api.vizientinc.com/azure-openai` |
| `AZURE_OPENAI_API_KEY` | API key for APIM/Azure OpenAI authentication | (get from Azure Portal) |
| `AZURE_OPENAI_API_VERSION` | Azure OpenAI API version | `2024-08-01-preview` |
| `AZURE_OPENAI_DEPLOYMENT` | Azure OpenAI deployment name | `gpt-5.4` |
| `LLM_MODEL` | Model/deployment name used by the app | `gpt-5.4`, `gpt-4o`, etc. |

## Setup Steps

### 1. Create an Azure APIM Instance

If you don't have one already:
```bash
# Create an APIM instance using Azure CLI
az apim create \
  --name my-org-apim \
  --resource-group my-resource-group \
  --publisher-name "My Organization" \
  --publisher-email admin@example.com
```

### 2. Configure Your Model Backend API

Add your model provider (OpenAI, Azure OpenAI, etc.) as a backend:

```bash
az apim backend create \
  --resource-group my-resource-group \
  --service-name my-org-apim \
  --backend-id openai-backend \
  --url https://api.openai.com/v1
```

### 3. Create API and Operations

Define the model API and its operations in APIM:

```bash
# Create API (example for chat completions)
az apim api create \
  --resource-group my-resource-group \
  --service-name my-org-apim \
  --api-id models-api \
  --path models \
  --display-name "Model API"
```

### 4. Add Authentication Policy

Configure APIM to validate incoming requests. In the APIM portal:
1. Go to your API's Inbound processing
2. Add a subscription key validation policy:

```xml
<validate-jwt header-name="Ocp-Apim-Subscription-Key" failed-validation-httpcode="401">
    <openid-config url="..." />
</validate-jwt>
```

### 5. Get Your Subscription Key

From the Azure Portal:
1. Navigate to your APIM instance
2. Go to **Subscriptions**
3. Create a new subscription or use an existing one
4. Copy the primary or secondary key

## Usage Examples

### Python Direct Usage

```python
from llm.llm_client import LLMClient
from utils.config import config

# Azure APIM will be used automatically if configured
client = LLMClient(
    provider="azure-apim",
    model="gpt-4-turbo",
    api_key="your-apim-subscription-key"
)

response = client.complete_text(
    user_prompt="What are the key terms in this contract?",
    system_prompt="You are a legal contract analyzer."
)
print(response.text)
```

### Via Environment Variables

```bash
export LLM_PROVIDER=azure-apim
export AZURE_OPENAI_ENDPOINT="https://api.vizientinc.com/azure-openai"
export AZURE_OPENAI_API_KEY="<your API key>"
export AZURE_OPENAI_API_VERSION="2024-08-01-preview"
export AZURE_OPENAI_DEPLOYMENT="gpt-5.4"
export LLM_MODEL="gpt-5.4"

python -m uvicorn main:app --reload
```

### Using the Streamlit UI

When running the UI (`streamlit run ui/app.py`):

1. Select **☁️ Azure APIM** from the LLM Mode radio buttons
2. Enter your Azure OpenAI endpoint URL
3. Enter your Azure OpenAI API key
4. Enter API version (e.g., `2024-08-01-preview`)
5. Enter deployment name (e.g., `gpt-5.4`)
6. Click to confirm configuration

## Request/Response Format

The LLM client expects your APIM endpoint to implement an OpenAI-compatible API interface:

### Request
```json
{
  "messages": [
    {"role": "system", "content": "system prompt"},
    {"role": "user", "content": "user prompt"}
  ],
  "temperature": 0.1,
  "max_tokens": 4096,
  "model": "gpt-4-turbo"
}
```

### Response
```json
{
  "choices": [
    {
      "message": {
        "content": "response text"
      }
    }
  ],
  "usage": {
    "prompt_tokens": 50,
    "completion_tokens": 150,
    "total_tokens": 200
  }
}
```

If your APIM backend uses different response formats, you may need to add a transformation policy in APIM.

## Fallback Configuration

The system maintains backward compatibility with direct provider access:

```env
# If you want to fall back to direct OpenAI/Anthropic access:
LLM_PROVIDER=openai          # Instead of azure-apim
OPENAI_API_KEY=sk-...        # Direct API key
```

## Troubleshooting

### "AZURE_OPENAI_ENDPOINT is not configured"
- Ensure `AZURE_OPENAI_ENDPOINT` environment variable is set
- Check that the URL is valid and accessible
- Verify firewall/network rules allow outbound HTTPS requests

### "AZURE_OPENAI_API_KEY is not configured"
- Verify the API key is set in `AZURE_OPENAI_API_KEY`
- Ensure you're using a valid key from your APIM instance
- Check that the subscription is active

### "Azure APIM request failed"
- Verify the APIM endpoint is returning a valid chat completion response
- Check APIM policies and backend configuration
- Review APIM analytics/logs for errors
- Ensure the deployment and API version are correct

### "401 Unauthorized" from APIM
- Verify the subscription key is correct
- Check that the subscription is active in APIM
- Ensure the request includes the `Ocp-Apim-Subscription-Key` header

## Advanced Configuration

### Multiple Models via APIM

If your APIM instance exposes multiple models, you can switch between them:

```python
from llm.llm_client import LLMClient

# Route to different models through APIM
for model in ["gpt-4-turbo", "gpt-4o", "claude-3-opus"]:
    client = LLMClient(
        provider="azure-apim",
        model=model,
        api_key=subscription_key
    )
    # Use client...
```

### Custom Request Transformation

If your backend API uses a different request format, add a transformation policy in APIM:

```xml
<policies>
  <inbound>
    <base />
    <set-variable name="original-payload" value="@(context.Request.Body)" />
    <set-body>
    @{
      var original = context.GetVariable<string>("original-payload");
      // Transform to your backend's expected format
      return "transformed_json";
    }
    </set-body>
  </inbound>
  <backend>
    <base />
  </backend>
  <outbound>
    <base />
    <!-- Response transformation if needed -->
  </outbound>
</policies>
```

## Performance Considerations

- APIM adds minimal latency (typically <50ms) to requests
- Enable APIM caching for repeated queries if your use case allows
- Monitor APIM throttling policies to avoid rate limits
- Consider APIM's pricing when estimating costs

## Security Best Practices

1. **Never commit credentials** - Keep APIM keys in environment variables or secrets management systems
2. **Use managed identities** when running in Azure - enables keyless authentication
3. **Enable APIM IP restrictions** to allow only specific source IPs
4. **Rotate subscription keys regularly** - regenerate in APIM portal periodically
5. **Use Role-Based Access Control (RBAC)** - restrict who can manage APIM configurations
6. **Enable APIM diagnostics** - log and monitor all API calls for security audit trails

## Related Documentation

- [Azure API Management Documentation](https://docs.microsoft.com/en-us/azure/api-management/)
- [OpenAI API Documentation](https://platform.openai.com/docs)
- [Reconciliation Engine README](./README.md)
