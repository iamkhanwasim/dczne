# Domain Model Subproject

This folder is the shared modeling layer for the reconciliation engine designs.
It is organized around the actual contract and invoice corpus rather than around
one preferred implementation.

## Outputs

- `corpus-evidence-summary.md` inventories the corpus and extraction coverage.
- `logical-model.md` defines the conceptual entities and reconciliation flow.
- `service-contract-billing-ontology.owl.ttl` provides a concrete OWL/Turtle
  model for the domain.
- `examples/` contains modeled examples from the corpus.
- `evidence-notes/` contains subagent category reviews.

## Model Goal

The model must represent a healthcare vendor relationship where:

- Multiple documents can govern one relationship.
- Documents can amend, renew, supersede, or narrow earlier terms.
- Services can be location-specific, subscription-based, usage-based,
  deliverable-based, event-based, time-and-materials, pass-through, tax, or
  contingency/recovery-based.
- Invoice line items must be reconciled to billable contract terms and invoice
  totals must be recomputed from accepted lines, taxes, credits, and adjustments.
- Every assertion should preserve provenance back to source document, page,
  table, clause, invoice field, or extracted span.

## Pressure-Test Summary

The corpus forced the model to handle at least these patterns:

- Experian: master agreement plus BAA plus price amendment, with product
  schedules, monthly base fees, transaction packages, overages, claims-based
  subscription fees, pass-through fees, facility references, and amendment
  precedence.
- Johnson Controls: planned inspection agreements with service location,
  effective term, equipment/system scope, inspection frequency, exclusions,
  PO/CPQ references, and separately billable repairs.
- Quality Lawn: separate location-specific agreements with seasonal services,
  per-service prices, monthly invoicing for prior-month services, no tax due
  because UHS entities are tax-exempt, and service exclusions.
- NRC Health: letter of agreement amending a membership subscription, annual
  fees by membership year, quarterly invoicing, licensed beds, net patient
  revenue, oversample response allowances, and optional add-on services.
- Reputation.com: change order and SOW structure with fixed implementation fee,
  per-license monthly pricing, term dates, semiannual invoice schedule, annual
  renewal escalation, written change order requirement, and invoices that may
  include broader platform renewal charges beyond a single addendum.
- HealthROI: consulting agreements where invoiceability depends on realized
  recoveries, percentage fees, reviewed claims/cases, backup evidence, payer
  appeal timing, and reimbursement events.
- Office supplies: product/usage rows with SKUs, UOM, quantities, times sold,
  total sales, negative/credit rows, and a grand-total row that must be
  classified before aggregation. This is useful as a control case for SKU-based
  invoices.
- Dialysis and many invoices: scanned/image-heavy sources where text extraction
  is insufficient without OCR or visual document understanding.
