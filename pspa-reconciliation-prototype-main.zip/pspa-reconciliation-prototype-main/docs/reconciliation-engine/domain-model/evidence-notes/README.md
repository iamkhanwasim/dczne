# Evidence Notes

This folder contains category-specific reviews of the corpus. Each note focuses
on the contract mechanisms, invoice patterns, reconciliation checks, model
requirements, and extraction limitations observed in that category group.

The notes are analysis artifacts, not source-of-truth contract summaries. The
source documents and extracted evidence remain the authoritative inputs.
