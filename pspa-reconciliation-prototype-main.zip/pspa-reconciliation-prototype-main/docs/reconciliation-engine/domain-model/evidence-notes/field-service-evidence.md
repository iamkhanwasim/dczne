# Field Service Evidence Notes

Sources reviewed: `docs/reconciliation-engine/domain-model/generated/corpus_manifest.json`, `docs/reconciliation-engine/domain-model/generated/corpus_chunks.jsonl`, and `docs/reconciliation-engine/domain-model/generated/corpus_signals.json`. Deep PDF rendering/OCR was stopped per instruction; findings below rely on generated extraction evidence already gathered.

## UHS - Landscaping

- Contract mechanisms observed: Quality Lawn agreements are location-specific and entity-specific, with separate UHSH/UMA agreements for sites or site segments such as `1302 E Main St`, `142 Clinton St.`, `346 Grand Ave.`, `601 Riverside et al`, `Sidewalk Thomas St to Grand Ave`, `2352 Route 26`, `5 mile point plaza Kirkwood`, and `91 Chenango` under `Data/Contract and Invoice Pairs/UHS - Landscaping/`. Extracted terms show a contract term of April 1, 2016 through March 31, 2018, 30-day termination rights, and no price changes during the term without prior customer written consent.
- Contracted services are location-scoped and priced by service/activity, with some services marked `N/A` by location. Extracted examples include plantings in spring/fall, weeding, lawn mowing, pruning/trimming under 15 feet, turf management with weed control/fertilizing four times per year, and fall cleanup. Examples from signals include `1302 E Main St` with fall cleanup `$125.00`, weeding `$750.00`, pruning/trimming `$735.00`, mowing/turf `N/A`; `601 Riverside et al` with turf `$700.00`, weeding `$300.00`, lawn mowing `$5,790.00`; `2352 Route 26` with turf `$4,800.00`, lawn mowing `$2,500.00`; `91 Chenango` with turf `$472.00`, lawn mowing `$2,880.00`; and `5 mile point plaza Kirkwood` with turf `$150.00`, weeding `$600.00`, pruning/trimming `$100.00`, lawn mowing `N/A`.
- Invoice patterns observed: invoice PDFs are organized by billing month under `Data/Contract and Invoice Pairs/UHS - Landscaping/Quality Lawn Invoices/` for December 2024, January 2025, July 2025, August 2025, September 2025, and November 2025, but manifest extraction shows very low extracted text for all listed invoices. No reliable line descriptions, locations, dates, or amounts were available from generated signals.
- Reconciliation checks implied: invoice line service must match a contracted service for the exact location/entity; services marked `N/A` require an exception/change authorization; billed amount must match the service/location fixed price unless written consent changed pricing; seasonal/frequency rules should prevent duplicate or off-cycle charges; invoice service dates must be valid against contract term or an extension/amendment; customer entity must match UHSH vs UMA.

## UHS - Fire Suppression

- Contract mechanisms observed: Johnson Controls has a planned service/renewal agreement at `Data/Contract and Invoice Pairs/UHS - Fire Suppression/Johnson Controls  CPQ-1109512 Chenango Memorial SG insp 2026 (1).pdf`. Extracted fields include customer `Chenango Memorial Hospital`, customer number `259234`, proposal `CPQ-1109512`, external contract `80928457 R04- OCT-2025`, term `1-Jan-26 to 31-Dec-26`, billing customer and service location at `179 N Broad St, Norwich, NY 13815`, and a renewal note that an amendment form adjusts start/end dates to align with the fire alarm inspection contract.
- The service scope is a location/equipment inspection plan: item `SYSTEM-SG-FM200`, `FM200 SYSTEM`, `SUPPRESSION GAS SYSTEMS TEST & INSPECT`, `SG- Essential test and inspect`, semi-annual, estimated first inspection in May, including control panel and pull station. Investment summary total is `$1,800.00`.
- Exclusions and extras are reconciliation-critical: inspection labor is Monday-Friday 8am-5pm except holidays; labor, repairs, and materials outside the specified inspection frequency are excluded; hydrostatic testing is excluded; lift use may add charges; excluded services are billed at Johnson Controls' then-current rates. Taxes are not included in the quote if a valid exemption/resale certificate is received, otherwise actual sales tax and similar charges may be billed.
- Invoice patterns observed: invoice PDFs are organized in monthly folders from June 2025 through November 2025 under `Data/Contract and Invoice Pairs/UHS - Fire Suppression/Johnson Controls Invoices/`, with multiple PDFs per month and page counts ranging roughly from 3 to 17 pages. Generated signals did not extract line-level invoice content from these PDFs, so invoice numbers, work order references, service dates, line descriptions, taxes, and totals were not available from the corpus.
- Reconciliation checks implied: match invoice vendor/customer/site to the JCI agreement and authorized service location; match line/service event to FM200 suppression inspection scope and semi-annual frequency; verify invoice period/date against contract term and amendment-aligned dates; validate `$1,800.00` fixed inspection total unless invoice is for an allowed excluded service; require evidence/authorization for repairs, hydrostatic testing, lifts, after-hours labor, or then-current-rate T&M charges; validate tax only if exemption evidence is absent or tax is otherwise contractually permitted.
- Additional source limitation: `Johnson Controls UHSH- SOW DataRoom-FINAL-fully executed (1).pdf` and `Johnson Controls-Terms Service Agreement- fully executed (2).pdf` are present, but generated extraction for those files is very low text and produced no usable signals.

## UHS - Dialysis

- Contract mechanisms observed: none extractable from generated corpus. The two PDFs at `Data/Contract and Invoice Pairs/UHS - Dialysis/844180127780081.pdf` and `Data/Contract and Invoice Pairs/UHS - Dialysis/844380106590121.pdf` are classified as `unknown`, with 8 and 12 pages respectively, very low extracted text, and no extracted signals.
- Invoice patterns observed: not reliably observable. The file names look like invoice/document numbers, but the corpus has only page markers and no line items, dates, amounts, service descriptions, locations, or contract references.
- Reconciliation checks implied: this category cannot be pressure-tested from current extraction. The ontology still needs to support dialysis-style service events if later OCR reveals treatments, patient/day/location counts, per-treatment rates, emergency/acute service charges, supply add-ons, minimums, or credential/location requirements.

## Ontology / Logical Model Fields Required

- `ContractDocument`: source path, doc type, execution/effective dates, term start/end, amendment/renewal relationship, extraction confidence.
- `Party` and `CustomerEntity`: vendor, billing customer, legal UHS entity, tax/exemption status.
- `ServiceLocation`: facility/site name, address, site segment, covered equipment/system, entity ownership, location effective dates.
- `ContractedService`: service category, service activity, included scope, excluded scope, allowed substitutions, required approvals, location applicability, `N/A` applicability marker.
- `ServiceSchedule`: frequency, season, allowed service window, first/next expected event, term alignment/amendment notes.
- `PriceTerm`: amount, currency, unit basis, fixed vs recurring vs event-based vs then-current-rate, service/location binding, price-lock or change-consent rule, tax treatment.
- `ServiceEvent`: actual service date, completion evidence, work order/reference, location, equipment/system, activity performed, exception reason.
- `Invoice` and `InvoiceLine`: invoice number, invoice date, billing period, vendor/customer, location, line description, service event link, quantity, unit price, total, tax, fees, attachment/source evidence.
- `ReconciliationRule`: scope match, date/term match, location/entity match, frequency/duplicate check, price match, excluded-service authorization, tax authorization, extraction confidence/manual-review requirement.

## Extraction Limitations

- Most invoice PDFs in these categories produced only page markers or very low text in `corpus_chunks.jsonl`; invoice conclusions are therefore structural rather than line-item factual.
- Landscaping contract text is extractable but often lacks whitespace, making service/price parsing brittle and requiring careful normalization.
- Fire suppression has one usable CPQ agreement extraction, but related SOW/terms PDFs and invoice PDFs are not usable from generated text.
- Dialysis evidence is insufficient without OCR or manual review; no compliant automated reconciliation can be designed from the generated extraction alone for that category.
