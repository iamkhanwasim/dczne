# Platform, Subscription, and Usage Evidence

Scope: UHS - Experian, UHS - Reputation Management, UHS - Market Insights, and UHS - Office Supplies, based on `docs/reconciliation-engine/domain-model/generated/corpus_manifest.json`, `corpus_chunks.jsonl`, `corpus_signals.json`, and limited direct source inspection where extraction was blank.

## Contract Mechanisms Observed

- Experian uses a master customer agreement plus a later price-change amendment. The MCA defines product/service eligibility by facility, annual subscription fees billed monthly, transaction packages with monthly base rates, included monthly volumes, excess usage fees, pass-through fees, tax treatment, user/location limits, and amendment-only additions of products, facilities, or locations. The amendment changes selected products to a claims-based monthly subscription of `$114,700.00` based on `6,200,000` annual claims, with annual measurement, a `3%` increase threshold, pro rata increases, and baseline resets. Sources: `Data/Contract and Invoice Pairs/UHS - Experian/Experian Contracts/EHI -UHSH- MCA without BAA- Signed by Vendor - 08.04.25-FINAL.pdf`; `Data/Contract and Invoice Pairs/UHS - Experian/Experian Contracts/15251 EHI - UHSH-Price Change Amendment -FINAL-11-10-25.pdf`.
- Reputation.com combines an existing platform agreement with a change order and professional services SOW. The change order adds Competitive Intelligence for `6` locations, term `Nov 21, 2022` to `Oct 03, 2024`, `22` months, `$42.82` per license per month, total `$5,652.36`, plus a non-renewing implementation fee of `$1,250.00`. Billing is semiannual with four planned invoices of `$1,725.59`; payment terms are `Net 45`; renewals have a `7%` annual increase. Source: `Data/Contract and Invoice Pairs/UHS - Reputation Management/Reputation.com Contracts/Reputation.com.UHSH.Change Order Agreement.Final 1 13 23.pdf`; `Data/Contract and Invoice Pairs/UHS - Reputation Management/Reputation.com Contracts/Reputation.com.UHSH.SOW.Final.1 13 23.pdf`.
- NRC Market Insights is an LOA amending a membership subscription agreement for `09/01/2025-08/31/2028`. It defines annual membership fees by contract year (`$136,841.20`, `$139,578.20`, `$143,765.36`), quarterly invoicing at start, `Net 45`, fixed-fee pricing based on stated volumes, no convenience termination, tax exclusion, facility inclusion, Community Insights scope of up to `8` studies and `1,000` annual panel responses, and an oversample range of `64-72` annual responses. Source: `Data/Contract and Invoice Pairs/UHS - Market Insights/NRC-UHSH- LOA Market Insights- Final 11-09-25 (1).pdf`.
- Office Supplies has an encrypted/scanned Office Depot amendment whose text was not extracted, plus an XLSX usage report. The usage artifact is not a normal invoice: it is account-level spend by product code, supplier, department, pack quantity, UOM, quantity sold, times sold, and total sales for `Jan 1, 2025 - Dec 19, 2025`. Sources: `Data/Contract and Invoice Pairs/UHS - Office Supplies/Office Depot-BP0011 Amendment and Extension-11-1-16.pdf`; `Data/Contract and Invoice Pairs/UHS - Office Supplies/25454222-UNITED HEALTH SERVICES.xlsx`.

## Invoice Patterns Observed

- Experian invoices group charges by account/facility identifiers such as `EXH-129307`, `EXH-129308`, etc., with line descriptions for monthly package fees, overages, postage/pass-through-like charges, subscription fees, quantities, amounts, subtotals, sales tax, and total. Direct source inspection confirmed scanned invoices where text extraction was blank; extracted digital examples include `Experian-Nov.pdf` total `$64,174.18` and `Experian-Dec.pdf` total `$146,946.95`.
- Reputation invoices are scanned. Direct inspection showed invoice dates and service periods spanning semiannual windows, with lines for Base Reputation Management Platform, Listings, Reviews Module, Reviews, and Competitive Intelligence. Amounts observed include `$59,397.84`, `$8,025.00`, and `$73,866.24`, which indicates the invoice population includes both the Competitive Intelligence add-on and broader platform renewal charges not fully explained by the addendum alone. Sources: `Data/Contract and Invoice Pairs/UHS - Reputation Management/Reputation.com Invoices/846680112660021.pdf`; `846980111620021.pdf`; `848680115410021.pdf`.
- NRC invoices are scanned and extracted as blank in the corpus. Direct inspection showed quarterly service periods and a stable total of `$34,210.30`, with earlier invoices splitting Market Insights Complete with On Demand (`$31,845.30`) and Oversample (`$2,365.00`), and a later invoice describing NRC Health Solutions / Market Insights Complete with Community Insights and Oversample. Sources: `Data/Contract and Invoice Pairs/UHS - Market Insights/846480101170021.pdf`; `847480130840021.pdf`; `849180101790021.pdf`.
- Office Supplies XLSX shows usage rather than formal invoice totals. Rows include SKU/product-level spend; the apparent grand total row is `$512,068.23`, while a naive sum including the grand-total row doubles the amount, so extraction logic must detect report total rows. Source: `Data/Contract and Invoice Pairs/UHS - Office Supplies/25454222-UNITED HEALTH SERVICES.xlsx`.

## Reconciliation Checks Implied

- Contract document hierarchy: apply later amendments/change orders over master agreements, keep effective dates and cotermination rules, and distinguish admin cover memos from operative terms.
- Subscription billing: validate billing cadence, service period boundaries, invoice timing, payment terms, proration/term coverage, annual vs monthly/quarterly conversion, and non-taxable/taxable treatment.
- Usage/package billing: validate base package amount, included volume, overage quantity and rate, minimum monthly charge, pass-through fee eligibility, and facility/account attribution.
- Claims-based billing: compare invoiced monthly claims-based fees to baseline annual claims, annual measurement date, permitted adjustment threshold, pro rata increase calculation, and facility additions/divestitures.
- SaaS/location licensing: check licensed quantity, covered locations, competitor/customer location scope, renewal uplift, implementation fees, and one-time vs recurring/non-renewing services.
- Product spend reports: reconcile SKU-level spend using product code, supplier, UOM, pack quantity, quantity sold, times sold, department, negative/credit rows, and explicit total rows.

## Ontology / Logical Model Fields Required

- `AgreementDocument`: document type, effective date, term start/end, amendment target, precedence, signatures, source path, extraction status.
- `Offering`: product/service name, SKU, category, platform/module, included capabilities, covered facilities/accounts, covered users or locations.
- `PricingTerm`: pricing basis (`fixed_fee`, `subscription`, `transaction_package`, `claims_based`, `pass_through`, `usage_report`), unit rate, billing cadence, included quantity, minimum/base charge, overage rate, annual fee, monthly/quarterly derived amount, taxability, renewal escalator.
- `VolumeMeasure`: measure name (`claim`, `transaction`, `patient record`, `panel response`, `licensed location`, `SKU quantity`), baseline, measurement period, adjustment threshold, reset rule.
- `InvoiceHeader`: vendor, invoice number, invoice date, due date, payment terms, bill-to, account/customer id, service period, total, tax, source path.
- `InvoiceLine`: description, normalized offering/SKU, facility/account id, service period, quantity, unit price, amount, tax amount, pass-through indicator, source page/row.
- `ReconciliationRule`: applicable document, term, formula, tolerance, evidence citation, required external data, result status, exception reason.

## Extraction Limitations

- Several invoice PDFs are image-only/scanned and appeared as blank chunks in `corpus_chunks.jsonl`; limited direct image inspection was used only before this note was requested. No further OCR/rendering was performed.
- The Office Depot amendment failed text extraction because AES decryption support was missing in the available PDF reader, so no contract terms from that amendment are relied on here.
- Handwritten approvals and internal routing notes appear on scanned invoices and may interfere with OCR if later automated.
- Office Supplies XLSX has report metadata, confidential text, detail rows, and a grand-total row in one sheet; row classification is required before aggregation.
