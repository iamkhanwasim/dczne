# SOW / Consulting Evidence Notes

Scope: professional/SOW/digital service categories `UHS - Rev Cycle Consulting` and `UHS - Website Management`, based on `docs/reconciliation-engine/domain-model/generated/corpus_manifest.json`, `docs/reconciliation-engine/domain-model/generated/corpus_chunks.jsonl`, and `docs/reconciliation-engine/domain-model/generated/corpus_signals.json`. No further OCR/rendering was performed.

## Contract Mechanisms Observed

- HealthROI uses multiple project-specific consulting agreements/SOWs rather than a single SKU schedule. The PACT agreement covers Medicare post-acute care transfer reimbursement consulting, continuing reviews for discharges beginning January 1, 2018, and requires UHSH to provide PS&R detail data, Medicare rate information, and Medicare Common Working File credentials. Source: `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI.UHSH. Consulting Agreement. Medicare Post-Accute Transfer.Final.April 6 2018.pdf`; duplicate copy also appears as `(1).pdf`.
- HealthROI scope is outcome/workflow driven: identify eligible cases, review beneficiary records, contact post-acute providers when needed, obtain documentation, get Medical Center concurrence, and rebill cases. This implies contractual eligibility criteria, not simple item-price matching. Source: `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI.UHSH. Consulting Agreement. Medicare Post-Accute Transfer.Final.April 6 2018.pdf`.
- HealthROI compensation can be contingency based. The PACT agreement states professional fees are 25% of additional reimbursement recovered from CMS, including actual cash payment or reduction in liability, with a defined Medicare paid amount baseline. Source: `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI.UHSH. Consulting Agreement. Medicare Post-Accute Transfer.Final.April 6 2018.pdf`.
- Additional HealthROI documents indicate other revenue-cycle services and SOW controls: DRG review, PAAR, DSH/SSI realignment, termination on thirty days' notice, payment for undisputed services performed before termination, regulatory/licensure termination triggers, books-and-records retention, independent contractor status, indemnity, and ineligible-person representations. Sources: `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI.UHSH.Consulting Agreement DRG Review.Final.April 6 2018.pdf`, `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI.UHSH.Consulting Areement.PAAR.Final.4-6-18.pdf`, `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/HealthROI_UHSH_Consulting.SOW_FINAL.pdf`.
- Perficient website management is a fixed renewal/support arrangement for the UHS public website CMS/Drupal environment. The cover memo says Perficient maintains the CMS for `nyuhs.org`, covers the entire system, runs for 36 months, and costs $365,040 for 2026-2028. Source: `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Contracts/Perficient.UHSH.Contract_Cover_Memo_Renewal_12-5-25.pdf`.
- Perficient billing is schedule based: semiannual invoices of $60,840 in January and June of 2026, 2027, and 2028. Source: `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Contracts/Perficient.UHSH.Contract_Cover_Memo_Renewal_12-5-25.pdf`.

## Invoice Patterns Observed

- HealthROI invoice PDFs are present, but corpus extraction returned only page markers and very low text counts. The manifest lists seven HealthROI invoice PDFs with 3-5 pages and 46-78 extracted characters. Sources: `Data/Contract and Invoice Pairs/UHS - Rev Cycle Consulting/Health ROI Invoices/848480104320051.pdf`, `848580109570031.pdf`, `848680107100031.pdf`, `848780108120031.pdf`, `848880103560031.pdf`, `848880109900031.pdf`, `848980107320031.pdf`.
- Perficient invoice PDFs are also present, but extraction returned only page markers and 30 extracted characters per invoice. Sources: `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Invoices/845880109520021.pdf`, `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Invoices/847480130350021.pdf`.
- Because invoice text was not available from the generated corpus, invoice pattern findings are limited to document presence, page counts, and the contract-implied expected billing patterns: HealthROI likely needs recovery/supporting-case evidence for contingency fees, while Perficient should match the semiannual $60,840 schedule.

## Reconciliation Checks Implied

- Match invoice to the correct governing document/SOW by vendor, UHS entity, service domain, effective period, and project type rather than by item SKU alone.
- For HealthROI contingency invoices, require evidence of additional reimbursement recovered or liability reduction, validate the baseline Medicare paid amount, apply the contracted percentage, and tie charges to approved/rebilled cases within the covered review period and service scope.
- For HealthROI SOW services, check that invoiced work occurred before termination, is not for barred/ineligible activity, and aligns to the specific SOW scope such as PACT, DRG review, PAAR, or DSH/SSI realignment.
- For Perficient, check invoice date/service period against the January/June semiannual schedule, amount equals $60,840, cumulative billed amount does not exceed $365,040, billing falls within the 36-month 2026-2028 term, and services map to website/CMS/Drupal support for the UHS public website/system.
- At invoice-total level, enforce contract caps/schedules and duplicate-invoice detection across repeated invoices. At line level, validate service description, period, project/SOW identifier, recoveries or support-hour basis where applicable, allowed expense/pass-through treatment if present, and entity/site coverage.

## Ontology / Logical Model Fields Required

- `Agreement`: vendor, UHS entity, document path, document type, effective date, term start/end, renewal/amendment relationship, governing order/precedence, signatures/status.
- `StatementOfWork`: project/service domain, scope narrative, deliverables, workflow steps, covered population/cases, eligibility criteria, required customer data, dependencies, excluded services, termination rights, regulatory constraints.
- `PricingTerm`: pricing model (`contingency`, `fixed_schedule`, `time_and_materials`, `support_hours`), percentage, baseline amount definition, fixed installment amount, total contract value/cap, billing frequency, allowed pass-throughs/expenses, tax treatment.
- `BillingSchedule`: due month/date, installment amount, service period covered, cumulative cap, billing trigger.
- `RecoveryEvent` / `CaseEvidence`: payer/program, case/discharge period, original paid amount, recovered amount or liability reduction, concurrence/approval status, rebill status, supporting data source.
- `Invoice`: invoice number, invoice date, vendor, billed entity, service period, total, line items, referenced SOW/agreement, supporting attachments, cumulative billed-to-date.
- `InvoiceLine`: service description, project/SOW mapping, quantity/hours/cases/recoveries, unit or percentage rate, calculated amount, taxes/fees, pass-through flag, exception reason.
- `ReconciliationResult`: matched contract clause/term, check type, pass/fail/warn, expected amount, actual amount, variance, evidence citation, confidence, extraction limitation.

## Extraction Limitations

- The generated corpus is sufficient for most HealthROI contract/SOW text and the Perficient cover memo, but not for the Perficient SOW PDF itself: `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Contracts/Perficient-UHSH-SOW-Final-12-11-25 (1).pdf` has `text_chars: 0` and an AES/cryptography extraction warning in the manifest.
- HealthROI and Perficient invoice PDFs are image-heavy or otherwise not text-extractable in the generated corpus; no line-item amounts, invoice numbers, or service periods could be confirmed without OCR/rendering.
- `Data/Contract and Invoice Pairs/UHS - Website Management/Perficient Inc Contracts/Summary (30).pdf` is a DocuSign completion/certificate artifact, useful for signature/status evidence but not substantive commercial terms.
