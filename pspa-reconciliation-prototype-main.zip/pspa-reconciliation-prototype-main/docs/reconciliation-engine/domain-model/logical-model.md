# Logical Model for Service Contract Billing

## Purpose

The logical model converts messy contract and invoice evidence into a stable
representation that can answer two reconciliation questions:

1. Is each invoice line billable under an active governing term?
2. Is the invoice total compliant after accepted lines, credits, taxes,
   pass-throughs, discounts, and timing rules are applied?

The model is not tied to one implementation. It can feed a generated rules
engine, a whole-document LLM adjudication workflow, or an ontology-backed agent.

## Core Concepts

| Concept | Role in reconciliation |
| --- | --- |
| VendorRelationship | The durable commercial relationship between customer entities and a vendor. |
| Party | Customer, vendor, affiliate, billing entity, remittance entity, or facility owner. |
| FacilityLocation | A site, hospital, clinic, campus, service area, or market to which terms apply. |
| ContractDocument | A master agreement, SOW, amendment, addendum, change order, LOA, renewal, cover memo, quote, or service agreement. |
| DocumentPart | A clause, exhibit, schedule row, price table, equipment list, signature block, or administrative memo section. |
| GoverningTerm | A normalized term extracted from one or more document parts. |
| ServiceOffering | The contracted product/service family, such as eligibility verification, landscaping, inspection, market insights, or recovery consulting. |
| ServiceObligation | What the vendor must do, where, when, and with what acceptance or evidence requirements. |
| ChargeTerm | A billable pricing construct, such as fixed fee, usage fee, subscription fee, pass-through, tax, late fee, or contingency fee. |
| BillingSchedule | When a charge may be invoiced and for what service period. |
| Measurement | Usage, claim volume, license count, bed count, recovery amount, inspection event, or service occurrence used to calculate charges. |
| Invoice | Header-level invoice evidence: number, date, due date, vendor account, bill-to, remit-to, totals, taxes, credits, and terms. |
| InvoiceLine | Line-level evidence: description, quantity, UOM, unit rate, amount, service period, facility, product code, and source span. |
| ReconciliationCase | The evaluation record connecting an invoice to candidate contract terms and final findings. |
| Finding | A compliant, non-compliant, ambiguous, or not-enough-evidence decision with provenance and expected vs. actual math. |

## Document Hierarchy and Precedence

Contracts are not flat. The model must treat each relationship as a document
graph:

- Master agreements define general terms and product/service tables.
- BAAs and privacy agreements govern data handling but usually do not create
  invoiceable charge terms.
- Amendments and change orders can override earlier prices, add locations,
  change scope, or introduce new billing cadences.
- SOWs bind scope, deliverables, assumptions, acceptance, and fixed/professional
  services fees to a master agreement.
- Cover memos and signature summaries may contain useful business terms but
  should be lower-authority evidence unless incorporated into the executed
  contract set.
- Location-specific agreements can be separate governing documents under the
  same vendor relationship.

Each `GoverningTerm` therefore carries:

- source document and source part;
- effective period;
- precedence rank;
- amendment/supersession relationship;
- party and location scope;
- service scope;
- charge calculation method.

## Charge Term Types

| Charge term | Required fields | Example corpus pressure-test |
| --- | --- | --- |
| FixedFeeTerm | amount, currency, service scope, billing trigger | Reputation.com professional services fixed implementation fee. |
| SubscriptionFeeTerm | recurring amount, cadence, start date, end date, included services | NRC annual membership fee, Perficient semiannual support payments. |
| UsageFeeTerm | unit, rate, measurement source, service period | Office supplies quantity and total sales rows. |
| TieredUsageFeeTerm | base fee, included quantity, overage unit/rate | Experian transaction packages with monthly maximum transactions and overage fees. |
| ClaimsBasedSubscriptionTerm | monthly amount, annual baseline claims, measurement window, adjustment threshold, facilities | Experian price amendment for claims-based products. |
| PerLocationFeeTerm | location, service bundle, amount, cadence or event | Quality Lawn site-specific seasonal services and Johnson Controls inspections. |
| EventFeeTerm | event type, occurrence evidence, amount | Spring cleanup, inspection event, repair service call. |
| TimeAndMaterialsTerm | labor category, labor rate, parts/materials policy, approval requirement | Break-fix or excluded Johnson Controls repair work. |
| PassThroughFeeTerm | allowed source, cost basis, markup policy, approval policy | Experian pass-through fees for payer/government/tariff costs. |
| TaxTerm | taxability, exemption evidence, jurisdiction | UHS tax-exempt landscaping agreements and invoice sales-tax checks. |
| ContingencyFeeTerm | percentage, recovery basis, realization event, backup evidence | HealthROI percentage of additional reimbursement recovered. |
| LateFeeTerm | grace period, fixed fee, interest rate, legal cap | Quality Lawn payment timing and late fee language. |
| ReportedUsageTerm | row classification, SKU/service code, UOM, quantity, total-row handling | Office supplies usage workbook where a grand-total row must not be double-counted. |

## Invoice Matching Flow

1. Normalize invoice header and lines.
2. Identify vendor relationship candidates by vendor, account, remittance,
   customer entity, facility, PO/CPQ/order number, and invoice date.
3. Select active governing documents for the invoice date and service period.
4. Expand governing terms after amendment precedence is applied.
5. For each line, generate candidate charge terms by product/service names,
   SKU/account codes, location, service period, quantity/UOM, and amount.
6. Calculate expected amount from each candidate term.
7. Classify the line:
   - compliant match;
   - compliant but needs backup evidence;
   - overbilled amount/rate/quantity;
   - outside term/date/location/scope;
   - duplicate or premature billing;
   - missing authorization, PO, change order, or acceptance;
   - ambiguous and needs human review.
8. Recompute subtotal, taxes, credits, and invoice total from line decisions.
9. Produce a provenance-rich explanation that cites source document parts and
   invoice fields.

## Required Evidence Model

Every normalized assertion should include:

- source file path;
- document type;
- page, sheet, row, or chunk identifier when available;
- extraction method;
- confidence;
- exact extracted value and normalized value;
- reviewer status if a human validated it.

This is what lets a reconciliation result say not merely "line is wrong" but
"line is wrong because this amendment made $114,700/month effective after the
signature date, and the invoice line allocates a different monthly claim-based
fee to the same facilities."

## Handling Scanned and Encrypted Documents

The workbench processed all 94 files but many invoice PDFs exposed little text.
The production ingestion path must include:

- OCR or document-vision extraction for image PDFs;
- encrypted PDF handling where legally and operationally permitted;
- table extraction with row/column provenance;
- human validation queues for low-confidence source terms;
- no auto-payment-blocking decision when source evidence is incomplete.

## Minimum Viable Logical Schema

The MVP database or graph should include these tables or node labels:

- `party`
- `vendor_relationship`
- `facility_location`
- `contract_document`
- `document_part`
- `governing_term`
- `service_offering`
- `service_obligation`
- `charge_term`
- `rate`
- `billing_schedule`
- `measurement_rule`
- `authorization_requirement`
- `recovery_event`
- `usage_report_row`
- `invoice_cumulative_billing_state`
- `invoice`
- `invoice_line`
- `invoice_allocation`
- `reconciliation_case`
- `finding`
- `evidence_span`

The OWL file in this folder provides a concrete ontology version of the same
model.
