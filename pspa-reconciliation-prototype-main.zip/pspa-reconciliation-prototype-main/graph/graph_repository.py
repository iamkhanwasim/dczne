"""
Abstract interface for the graph (triple store) backend.

All graph operations go through this interface. This allows the mock
in-memory implementation to be swapped for StarDog (or any SPARQL endpoint)
without changing a single line of application code.

Implementations:
  - graph.mock_graph.MockGraph       — in-memory, for development and testing
  - graph.stardog_adapter.StardogAdapter — StarDog HTTP API (Phase 9)

Usage:
    from graph.graph_repository import GraphRepository, Triple

    repo: GraphRepository = MockGraph()
    repo.insert_triples(triples)
    results = repo.query_by_subject("abc-cleaning-uh-2025")
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Any, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------

# A triple is (subject_uri: str, predicate_uri: str, object_value: Any)
# object_value can be:
#   - str:              a URI reference (another subject)
#   - (str, str):       a typed literal tuple (value, datatype_uri)
#   - str (plain):      a plain string literal (no datatype)
Triple = Tuple[str, str, Any]


# ---------------------------------------------------------------------------
# Abstract interface
# ---------------------------------------------------------------------------


class GraphRepository(ABC):
    """
    Abstract base class for all graph store backends.

    All methods that modify state return None. All query methods return
    lists of triples or structured dicts as documented.
    """

    # --- Write operations ---

    @abstractmethod
    def insert_triples(self, triples: List[Triple]) -> None:
        """
        Insert a batch of triples into the store.

        Duplicate triples are silently ignored (idempotent insert).
        """

    @abstractmethod
    def update_triple(self, old: Triple, new: Triple) -> None:
        """
        Replace old triple with new triple.

        Raises KeyError if old triple does not exist.
        """

    @abstractmethod
    def delete_triples(self, subject_uri: str) -> int:
        """
        Delete all triples where subject == subject_uri.

        Returns the number of triples deleted.
        """

    # --- Read operations ---

    @abstractmethod
    def query_by_subject(self, subject_uri: str) -> List[Triple]:
        """
        Return all triples with the given subject URI.

        Returns empty list if subject not found.
        """

    @abstractmethod
    def query_by_predicate_object(self, predicate_uri: str, object_value: Any) -> List[Triple]:
        """
        Return all triples matching the given predicate and object.

        Useful for reverse lookups, e.g. find all charge terms belonging to a vendor.
        """

    @abstractmethod
    def query_charge_terms(
        self,
        vendor_relationship_id: str,
        on_date: Optional[date] = None,
        location: Optional[str] = None,
    ) -> List[str]:
        """
        Return subject URIs for all ChargeTerm nodes belonging to the given
        vendor_relationship_id that are active on on_date (if provided) and
        applicable to location (if provided).

        Returns a list of subject URIs. Callers use query_by_subject() to
        fetch the full triple set for each returned URI.
        """

    def query_charge_terms_for_contract(
        self,
        contract_id: str,
        on_date: Optional[date] = None,
    ) -> List[str]:
        """
        Return subject URIs for ChargeTerms belonging to a known contract.

        Default behavior delegates to query_charge_terms(), since the
        contract_id and vendor_relationship_id are the same identifier in
        the current model.
        """
        return self.query_charge_terms(vendor_relationship_id=contract_id, on_date=on_date)

    @abstractmethod
    def subject_exists(self, subject_uri: str) -> bool:
        """Return True if any triple with this subject URI exists in the store."""

    @abstractmethod
    def export_all_triples(self) -> List[Triple]:
        """
        Return all triples in the store.

        Intended for debugging and testing only. May be slow on large datasets.
        """

    # --- Utility ---

    def get_object(self, subject_uri: str, predicate_uri: str) -> Optional[Any]:
        """
        Convenience: return the object of the first triple matching
        (subject_uri, predicate_uri, ?). Returns None if not found.
        """
        for s, p, o in self.query_by_subject(subject_uri):
            if p == predicate_uri:
                return o
        return None

    def get_objects(self, subject_uri: str, predicate_uri: str) -> List[Any]:
        """
        Convenience: return all objects for triples matching
        (subject_uri, predicate_uri, ?).
        """
        return [o for s, p, o in self.query_by_subject(subject_uri) if p == predicate_uri]

    def get_literal(self, subject_uri: str, predicate_uri: str) -> Optional[str]:
        """
        Convenience: return the string value of a typed literal
        (value, datatype) tuple, or a plain string, for the first matching triple.
        """
        obj = self.get_object(subject_uri, predicate_uri)
        if obj is None:
            return None
        if isinstance(obj, tuple):
            return obj[0]
        return str(obj)
