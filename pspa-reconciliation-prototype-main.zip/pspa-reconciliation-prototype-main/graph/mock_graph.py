"""
In-memory mock graph repository.

Implements GraphRepository using plain Python data structures.
Suitable for development, testing, and MVP usage.

All data is stored in a list of triples. Queries are performed by
linear scan with filters — sufficient for hundreds of charge terms
and invoices. For production workloads, replace with StardogAdapter.

Usage:
    from graph.mock_graph import MockGraph

    repo = MockGraph()
    repo.insert_triples(triples)
    results = repo.query_by_subject("abc-cleaning-uh-2025")
"""

from __future__ import annotations

import re
from datetime import date
from typing import Any, Dict, List, Optional, Tuple

from graph.graph_repository import GraphRepository, Triple
from graph.ontology_schema import Classes, Props, RDF_TYPE
from graph.prefixes import uri_for, is_uri, SCB_NS


class MockGraph(GraphRepository):
    """
    In-memory triple store backed by a Python list.

    Thread-safety: not thread-safe. Use one instance per request
    in single-threaded test/dev scenarios, or add locking for concurrent use.
    """

    def __init__(self) -> None:
        self._triples: List[Triple] = []

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def insert_triples(self, triples: List[Triple]) -> None:
        """Insert triples, ignoring duplicates."""
        existing = set(self._make_hashable(t) for t in self._triples)
        for triple in triples:
            key = self._make_hashable(triple)
            if key not in existing:
                self._triples.append(triple)
                existing.add(key)

    def update_triple(self, old: Triple, new: Triple) -> None:
        """Replace an existing triple. Raises KeyError if not found."""
        old_key = self._make_hashable(old)
        for i, t in enumerate(self._triples):
            if self._make_hashable(t) == old_key:
                self._triples[i] = new
                return
        raise KeyError(f"Triple not found: {old}")

    def delete_triples(self, subject_uri: str) -> int:
        """Delete all triples with the given subject. Returns count deleted."""
        before = len(self._triples)
        self._triples = [t for t in self._triples if t[0] != subject_uri]
        return before - len(self._triples)

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def query_by_subject(self, subject_uri: str) -> List[Triple]:
        """Return all triples for the given subject URI."""
        return [t for t in self._triples if t[0] == subject_uri]

    def query_by_predicate_object(self, predicate_uri: str, object_value: Any) -> List[Triple]:
        """Return all triples matching predicate and object."""
        return [
            t for t in self._triples
            if t[1] == predicate_uri and self._objects_equal(t[2], object_value)
        ]

    def query_charge_terms(
        self,
        vendor_relationship_id: str,
        on_date: Optional[date] = None,
        location: Optional[str] = None,
    ) -> List[str]:
        """
        Return subject URIs for ChargeTerms belonging to the vendor relationship,
        optionally filtered by date and location.
        """
        vendor_uri = uri_for(vendor_relationship_id)

        # Find all charge term URIs linked from the vendor relationship
        linked_uris = {
            o for s, p, o in self._triples
            if s == vendor_uri and p == Props.hasChargeTerm and isinstance(o, str)
        }

        # Also find charge terms that point back to the vendor relationship
        back_linked = {
            s for s, p, o in self._triples
            if p == Props.vendorRelationship and o == vendor_uri
        }

        candidate_uris = linked_uris | back_linked

        results = []
        for term_uri in candidate_uris:
            # Verify it is typed as a ChargeTerm
            is_charge_term = any(
                t[1] == RDF_TYPE and t[2] == Classes.ChargeTerm
                for t in self._triples if t[0] == term_uri
            )
            if not is_charge_term:
                continue

            # Date filter
            if on_date is not None:
                if not self._term_active_on(term_uri, on_date):
                    continue

            # Location filter
            if location is not None:
                if not self._term_covers_location(term_uri, location):
                    continue

            results.append(term_uri)

        return results

    def query_charge_terms_for_contract(
        self,
        contract_id: str,
        on_date: Optional[date] = None,
    ) -> List[str]:
        """Return charge term URIs for a known contract ID."""
        return self.query_charge_terms(vendor_relationship_id=contract_id, on_date=on_date)

    def subject_exists(self, subject_uri: str) -> bool:
        """Return True if any triple has this subject."""
        return any(t[0] == subject_uri for t in self._triples)

    def export_all_triples(self) -> List[Triple]:
        """Return a copy of all triples."""
        return list(self._triples)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _make_hashable(triple: Triple) -> tuple:
        """Convert a triple to a hashable key for deduplication."""
        s, p, o = triple
        if isinstance(o, tuple):
            return (s, p, o[0], o[1])
        return (s, p, str(o))

    @staticmethod
    def _objects_equal(a: Any, b: Any) -> bool:
        """Compare two triple objects for equality."""
        if type(a) != type(b):
            # Allow comparing plain string to (value, datatype) tuple
            a_val = a[0] if isinstance(a, tuple) else str(a)
            b_val = b[0] if isinstance(b, tuple) else str(b)
            return a_val == b_val
        return a == b

    def _get_literal_value(self, subject_uri: str, predicate_uri: str) -> Optional[str]:
        """Return the string value of the first matching literal triple."""
        for s, p, o in self._triples:
            if s == subject_uri and p == predicate_uri:
                if isinstance(o, tuple):
                    return o[0]
                return str(o)
        return None

    def _term_active_on(self, term_uri: str, check_date: date) -> bool:
        """Return True if the charge term's effective period covers check_date."""
        effective_str = self._get_literal_value(term_uri, Props.effectiveDate)
        renewal_str = self._get_literal_value(term_uri, Props.renewalDate)

        if effective_str is None and renewal_str is None:
            # No date constraints → always active
            return True

        try:
            if effective_str:
                effective = date.fromisoformat(effective_str[:10])
                if check_date < effective:
                    return False
            if renewal_str:
                renewal = date.fromisoformat(renewal_str[:10])
                if check_date > renewal:
                    return False
        except ValueError:
            # Unparseable date → don't filter out
            return True

        return True

    def _term_covers_location(self, term_uri: str, location: str) -> bool:
        """Return True if the charge term covers the given location (or has no location scope)."""
        location_values = [
            o[0] if isinstance(o, tuple) else str(o)
            for s, p, o in self._triples
            if s == term_uri and p == Props.locationScope
        ]
        if not location_values:
            # No location scope → applies everywhere
            return True
        location_lower = location.lower()
        return any(location_lower in lv.lower() or lv.lower() in location_lower
                   for lv in location_values)

    def triple_count(self) -> int:
        """Return the number of triples in the store. Useful in tests."""
        return len(self._triples)

    def clear(self) -> None:
        """Remove all triples. Useful between tests."""
        self._triples = []
