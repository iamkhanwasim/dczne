"""
Ontology schema constants for the service-contract-billing (scb:) vocabulary.

Provides named constants for every class and property in the scb: namespace
so that the rest of the codebase never uses raw URI strings.

Usage:
    from graph.ontology_schema import Classes, Props

    # Use as triple predicate
    triples.append((subject_uri, Props.vendorId, ("abc-cleaning", XSD.string)))

    # Use as rdf:type object
    triples.append((subject_uri, RDF_TYPE, Classes.VendorRelationship))
"""

from __future__ import annotations

from graph.prefixes import SCB, RDF, RDFS, DCT


# ---------------------------------------------------------------------------
# RDF/RDFS/DCT constants (used everywhere)
# ---------------------------------------------------------------------------

RDF_TYPE = RDF.type
RDFS_LABEL = RDFS.label
DCT_CREATED = DCT.created


# ---------------------------------------------------------------------------
# scb: Classes
# ---------------------------------------------------------------------------


class Classes:
    """
    RDF class URIs. Use with rdf:type predicates.

    Example:
        (subject_uri, RDF_TYPE, Classes.ChargeTerm)
    """

    VendorRelationship = SCB.VendorRelationship
    """Top-level contract relationship between a vendor and a customer."""

    ContractDocument = SCB.ContractDocument
    """A contract document (MSA, SOW, amendment, etc.)."""

    ChargeTerm = SCB.ChargeTerm
    """A single billable service or fee defined in a contract."""

    Invoice = SCB.Invoice
    """An invoice document submitted by a vendor."""

    InvoiceLine = SCB.InvoiceLine
    """A single line item within an invoice."""

    Finding = SCB.Finding
    """Reconciliation finding for an invoice line."""

    ValidationResult = SCB.ValidationResult
    """Result of running one validator function."""

    MatchResult = SCB.MatchResult
    """Record of matching an invoice line to a charge term."""

    Location = SCB.Location
    """A named service location."""

    Measurement = SCB.Measurement
    """A measurement or usage quantity (supporting evidence)."""

    SupportingDoc = SCB.SupportingDoc
    """A supporting document (PO, receipt, work order) attached to an invoice line."""


# ---------------------------------------------------------------------------
# scb: Properties
# ---------------------------------------------------------------------------


class Props:
    """
    RDF property URIs. Use as predicates in triples.

    Convention:
      - Simple literals use (value, XSD.datatype) tuples as the triple object.
      - References to other subjects use the full URI string as the triple object.
    """

    # --- VendorRelationship / shared identity ---
    vendorId = SCB.vendorId
    vendorName = SCB.vendorName
    customerId = SCB.customerId
    customerName = SCB.customerName
    status = SCB.status

    # --- Dates ---
    effectiveDate = SCB.effectiveDate
    renewalDate = SCB.renewalDate
    amendmentDate = SCB.amendmentDate
    invoiceDate = SCB.invoiceDate
    serviceDate = SCB.serviceDate
    servicePeriodStart = SCB.servicePeriodStart
    servicePeriodEnd = SCB.servicePeriodEnd
    createdAt = DCT_CREATED

    # --- ChargeTerm core ---
    name = SCB.name
    serviceScope = SCB.serviceScope
    chargeType = SCB.chargeType
    rate = SCB.rate
    rateUnit = SCB.rateUnit
    rateCurrency = SCB.rateCurrency
    billingInterval = SCB.billingInterval
    invoiceCadence = SCB.invoiceCadence
    locationScope = SCB.locationScope
    precondition = SCB.precondition
    passthrough = SCB.passthrough
    requiresCostEvidence = SCB.requiresCostEvidence
    maxAmount = SCB.maxAmount
    overageRate = SCB.overageRate
    includedQuantity = SCB.includedQuantity
    contingencyPct = SCB.contingencyPct
    includedService = SCB.includedService
    excludedService = SCB.excludedService

    # --- Extraction provenance ---
    extractionConfidence = SCB.extractionConfidence
    extractionNotes = SCB.extractionNotes
    sourceDocument = SCB.sourceDocument
    sourcePage = SCB.sourcePage
    sourceSection = SCB.sourceSection
    spanText = SCB.spanText

    # --- Relationships (object properties) ---
    vendorRelationship = SCB.vendorRelationship
    """ChargeTerm → VendorRelationship"""

    hasChargeTerm = SCB.hasChargeTerm
    """VendorRelationship → ChargeTerm"""

    invoice = SCB.invoice
    """InvoiceLine → Invoice"""

    hasInvoiceLine = SCB.hasInvoiceLine
    """Invoice → InvoiceLine"""

    invoiceLine = SCB.invoiceLine
    """Finding / MatchResult / ValidationResult → InvoiceLine"""

    chargeTerm = SCB.chargeTerm
    """Finding / MatchResult → ChargeTerm"""

    hasValidationResult = SCB.hasValidationResult
    """Finding → ValidationResult"""

    # --- InvoiceLine ---
    lineNumber = SCB.lineNumber
    description = SCB.description
    quantity = SCB.quantity
    unit = SCB.unit
    unitRate = SCB.unitRate
    lineAmount = SCB.lineAmount
    supportingDoc = SCB.supportingDoc

    # --- SupportingDoc ---
    docType = SCB.docType
    reference = SCB.reference
    docAmount = SCB.docAmount
    docDate = SCB.docDate

    # --- Invoice totals ---
    subtotal = SCB.subtotal
    taxRate = SCB.taxRate
    taxAmount = SCB.taxAmount
    invoiceTotal = SCB.invoiceTotal
    lineCount = SCB.lineCount
    contractId = SCB.contractId

    # --- Matching ---
    matchingConfidence = SCB.matchingConfidence
    matchingReason = SCB.matchingReason
    routingPath = SCB.routingPath
    llmResolved = SCB.llmResolved
    llmCallId = SCB.llmCallId
    nameSimilarity = SCB.nameSimilarity
    unitMatch = SCB.unitMatch
    rateProximity = SCB.rateProximity
    dateInRange = SCB.dateInRange

    # --- Findings ---
    findingStatus = SCB.findingStatus
    amountInvoiced = SCB.amountInvoiced
    amountExpected = SCB.amountExpected
    variance = SCB.variance
    variancePct = SCB.variancePct
    varianceReason = SCB.varianceReason
    sourceEvidence = SCB.sourceEvidence
    recommendation = SCB.recommendation
    auditTrailId = SCB.auditTrailId

    # --- ValidationResult ---
    validatorName = SCB.validatorName
    passed = SCB.passed
    expectedValue = SCB.expectedValue
    actualValue = SCB.actualValue
    validationReason = SCB.validationReason
    severity = SCB.severity
