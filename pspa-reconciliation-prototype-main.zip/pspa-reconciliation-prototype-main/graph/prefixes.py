"""
RDF namespace prefixes and URI construction helpers.

All RDF subjects and predicates are built from these namespaces.
The canonical base URI is the scb: (service-contract-billing) namespace.

Usage:
    from graph.prefixes import SCB, RDF_TYPE, uri_for

    subject = uri_for("abc-cleaning-uh-2025")
    predicate = SCB.vendorId
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Namespace base URIs
# ---------------------------------------------------------------------------

RDF_NS = "http://www.w3.org/1999/02/22-rdf-syntax-ns#"
RDFS_NS = "http://www.w3.org/2000/01/rdf-schema#"
XSD_NS = "http://www.w3.org/2001/XMLSchema#"
DCT_NS = "http://purl.org/dc/terms/"
SCB_NS = "http://vizientinc.com/schema/reconciliation#"

# Base URI for named individuals (subjects) in this system
INSTANCE_BASE = "http://vizientinc.com/data/reconciliation/"


# ---------------------------------------------------------------------------
# Namespace helper class
# ---------------------------------------------------------------------------


class Namespace:
    """Lightweight namespace — attribute access returns a full URI string."""

    def __init__(self, base: str) -> None:
        self._base = base

    def __getattr__(self, name: str) -> str:
        if name.startswith("_"):
            raise AttributeError(name)
        return self._base + name

    def __call__(self, local: str) -> str:
        return self._base + local

    def __repr__(self) -> str:
        return f"Namespace({self._base!r})"


# ---------------------------------------------------------------------------
# Pre-built namespaces — import these in other modules
# ---------------------------------------------------------------------------

RDF = Namespace(RDF_NS)
RDFS = Namespace(RDFS_NS)
XSD = Namespace(XSD_NS)
DCT = Namespace(DCT_NS)
SCB = Namespace(SCB_NS)

# Convenience aliases for very common predicates
RDF_TYPE = RDF.type           # rdf:type
RDFS_LABEL = RDFS.label       # rdfs:label
DCT_CREATED = DCT.created     # dct:created


# ---------------------------------------------------------------------------
# Literal factories
# ---------------------------------------------------------------------------


def xsd_string(value: str) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:string literal."""
    return (str(value), XSD.string)


def xsd_decimal(value: float) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:decimal literal."""
    return (f"{value:.10g}", XSD.decimal)


def xsd_integer(value: int) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:integer literal."""
    return (str(int(value)), XSD.integer)


def xsd_boolean(value: bool) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:boolean literal."""
    return ("true" if value else "false", XSD.boolean)


def xsd_date(value: str) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:date literal. value must be 'YYYY-MM-DD'."""
    return (str(value), XSD.date)


def xsd_datetime(value: str) -> tuple[str, str]:
    """Return a (value, datatype) pair for an xsd:dateTime literal."""
    return (str(value), XSD.dateTime)


# ---------------------------------------------------------------------------
# URI construction
# ---------------------------------------------------------------------------


def uri_for(local_id: str) -> str:
    """
    Build a full URI for a named individual (subject) given its local ID.

    Example:
        uri_for("abc-cleaning-uh-2025")
        → "http://vizientinc.com/data/reconciliation/abc-cleaning-uh-2025"
    """
    return INSTANCE_BASE + local_id


def is_uri(value: str) -> bool:
    """Return True if value looks like a full URI (starts with http:// or https://)."""
    return value.startswith("http://") or value.startswith("https://")
