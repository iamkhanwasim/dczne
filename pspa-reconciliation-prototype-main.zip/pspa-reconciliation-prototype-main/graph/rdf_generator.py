﻿"""
RDF triple generator.

Converts domain model objects into lists of RDF triples suitable for
insertion into any GraphRepository backend.

Triple format:
    (subject_uri: str, predicate_uri: str, object_value: Any)

Object value types:
    - str starting with "http://":  URI reference (linked to another subject)
    - (str, str):                   typed literal -- (value_string, datatype_uri)
    - str (plain):                  plain string literal (no datatype)

Usage:
    from graph.rdf_generator import contract_to_triples, invoice_to_triples
    from graph.graph_repository import Triple

    triples: List[Triple] = contract_to_triples(vendor_relationship)
    repo.insert_triples(triples)
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import List

from graph.graph_repository import Triple
from graph.ontology_schema import Classes, Props, RDF_TYPE, RDFS_LABEL, DCT_CREATED
from graph.prefixes import (
    SCB,
    uri_for,
    xsd_boolean,
    xsd_date,
    xsd_datetime,
    xsd_decimal,
    xsd_integer,
    xsd_string,
)
from models.contract_models import Amendment, ChargeTerm, VendorRelationship
from models.finding_models import Finding, ValidationResult
from models.invoice_models import Invoice, InvoiceLine, SupportingDocRef


def _now_literal() -> tuple:
    return xsd_datetime(datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))


# ---------------------------------------------------------------------------
# Contract triples
# ---------------------------------------------------------------------------


def vendor_relationship_to_triples(vr: VendorRelationship) -> List[Triple]:
    """Generate triples for a VendorRelationship node."""
    s = uri_for(vr.id)
    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.VendorRelationship),
        (s, Props.vendorId, xsd_string(vr.vendor_id)),
        (s, Props.vendorName, xsd_string(vr.vendor_name)),
        (s, Props.customerId, xsd_string(vr.customer_id)),
        (s, Props.customerName, xsd_string(vr.customer_name)),
        (s, Props.status, xsd_string(vr.status)),
        (s, DCT_CREATED, _now_literal()),
    ]
    if vr.effective_date:
        triples.append((s, Props.effectiveDate, xsd_date(str(vr.effective_date))))
    if vr.renewal_date:
        triples.append((s, Props.renewalDate, xsd_date(str(vr.renewal_date))))
    for term in vr.charge_terms:
        triples.append((s, Props.hasChargeTerm, uri_for(term.id)))
    return triples


def charge_term_to_triples(term: ChargeTerm) -> List[Triple]:
    """Generate triples for a ChargeTerm node."""
    s = uri_for(term.id)
    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.ChargeTerm),
        (s, RDFS_LABEL, term.name),
        (s, Props.name, xsd_string(term.name)),
        (s, Props.vendorRelationship, uri_for(term.vendor_relationship_id)),
        (s, Props.chargeType, xsd_string(term.charge_type.value)),
        (s, Props.rate, xsd_decimal(term.rate)),
        (s, Props.rateUnit, xsd_string(term.rate_unit)),
        (s, Props.rateCurrency, xsd_string(term.rate_currency)),
        (s, Props.extractionConfidence, xsd_decimal(term.extraction_confidence)),
        (s, DCT_CREATED, _now_literal()),
    ]
    if term.service_scope:
        triples.append((s, Props.serviceScope, xsd_string(term.service_scope)))
    if term.billing_interval:
        triples.append((s, Props.billingInterval, xsd_string(term.billing_interval)))
    if term.invoice_cadence:
        triples.append((s, Props.invoiceCadence, xsd_string(term.invoice_cadence)))
    for loc in term.location_scope:
        triples.append((s, Props.locationScope, xsd_string(loc)))
    for pre in term.preconditions:
        triples.append((s, Props.precondition, xsd_string(pre)))
    if term.is_passthrough:
        triples.append((s, Props.passthrough, xsd_boolean(True)))
    if term.requires_cost_evidence:
        triples.append((s, Props.requiresCostEvidence, xsd_boolean(True)))
    if term.max_amount is not None:
        triples.append((s, Props.maxAmount, xsd_decimal(term.max_amount)))
    if term.overage_rate is not None:
        triples.append((s, Props.overageRate, xsd_decimal(term.overage_rate)))
    if term.included_quantity is not None:
        triples.append((s, Props.includedQuantity, xsd_decimal(term.included_quantity)))
    if term.contingency_pct is not None:
        triples.append((s, Props.contingencyPct, xsd_decimal(term.contingency_pct)))
    start = term.get_effective_start()
    end = term.get_effective_end()
    if start:
        triples.append((s, Props.effectiveDate, xsd_date(str(start))))
    if end:
        triples.append((s, Props.renewalDate, xsd_date(str(end))))
    if term.inclusion_exclusions:
        for inc in term.inclusion_exclusions.included:
            triples.append((s, Props.includedService, xsd_string(inc)))
        for exc in term.inclusion_exclusions.excluded:
            triples.append((s, Props.excludedService, xsd_string(exc)))
    if term.source:
        src = term.source
        if src.document_id:
            triples.append((s, Props.sourceDocument, xsd_string(src.document_id)))
        if src.page is not None:
            triples.append((s, Props.sourcePage, xsd_integer(src.page)))
        if src.section:
            triples.append((s, Props.sourceSection, xsd_string(src.section)))
        if src.span_text:
            triples.append((s, Props.spanText, xsd_string(src.span_text)))
    if term.extraction_notes:
        triples.append((s, Props.extractionNotes, xsd_string(term.extraction_notes)))
    return triples


def contract_to_triples(vr: VendorRelationship) -> List[Triple]:
    """Generate all triples for a VendorRelationship and all its charge terms."""
    triples: List[Triple] = vendor_relationship_to_triples(vr)
    for term in vr.charge_terms:
        triples.extend(charge_term_to_triples(term))
    for amendment in vr.amendments:
        triples.extend(amendment_to_triples(amendment))
    return triples


def amendment_to_triples(amendment: Amendment) -> List[Triple]:
    """Generate triples for an Amendment node and its modified charge terms."""
    s = uri_for(amendment.id)
    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.ContractDocument),
        (s, Props.chargeType, xsd_string("AMENDMENT")),
        (s, Props.contractId, xsd_string(amendment.base_contract_id)),
        (s, SCB.amendmentNumber, xsd_integer(amendment.amendment_number)),
        (s, Props.effectiveDate, xsd_date(str(amendment.effective_date))),
        (s, DCT_CREATED, _now_literal()),
    ]
    for term in amendment.modified_terms:
        triples.extend(charge_term_to_triples(term))
    return triples


# ---------------------------------------------------------------------------
# Invoice triples
# ---------------------------------------------------------------------------


def supporting_doc_to_triples(doc: SupportingDocRef, doc_uri: str) -> List[Triple]:
    """Generate triples for a SupportingDocRef node."""
    triples: List[Triple] = [
        (doc_uri, RDF_TYPE, Classes.SupportingDoc),
        (doc_uri, Props.docType, xsd_string(doc.doc_type)),
        (doc_uri, Props.reference, xsd_string(doc.reference)),
    ]
    if doc.amount is not None:
        triples.append((doc_uri, Props.docAmount, xsd_decimal(doc.amount)))
    if doc.date:
        triples.append((doc_uri, Props.docDate, xsd_date(str(doc.date))))
    if doc.notes:
        triples.append((doc_uri, Props.validationReason, xsd_string(doc.notes)))
    return triples


def invoice_line_to_triples(line: InvoiceLine, invoice_id: str) -> List[Triple]:
    """Generate triples for an InvoiceLine node."""
    line_id = f"{invoice_id}-l{line.line_number}"
    s = uri_for(line_id)
    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.InvoiceLine),
        (s, Props.invoice, uri_for(invoice_id)),
        (s, Props.lineNumber, xsd_integer(line.line_number)),
        (s, Props.description, xsd_string(line.description)),
        (s, Props.quantity, xsd_decimal(line.quantity)),
        (s, Props.unit, xsd_string(line.unit)),
        (s, Props.unitRate, xsd_decimal(line.unit_rate)),
        (s, Props.lineAmount, xsd_decimal(line.line_amount)),
    ]
    if line.service_date:
        triples.append((s, Props.serviceDate, xsd_date(str(line.service_date))))
    if line.service_period_start:
        triples.append((s, Props.servicePeriodStart, xsd_date(str(line.service_period_start))))
    if line.service_period_end:
        triples.append((s, Props.servicePeriodEnd, xsd_date(str(line.service_period_end))))
    if line.notes:
        triples.append((s, Props.validationReason, xsd_string(line.notes)))
    for i, doc in enumerate(line.supporting_docs):
        doc_uri = uri_for(f"{line_id}-doc{i + 1}")
        triples.append((s, Props.supportingDoc, doc_uri))
        triples.extend(supporting_doc_to_triples(doc, doc_uri))
    return triples


def invoice_to_triples(invoice: Invoice) -> List[Triple]:
    """Generate all triples for an Invoice and all its lines."""
    s = uri_for(invoice.invoice_id)
    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.Invoice),
        (s, Props.vendorId, xsd_string(invoice.vendor_id)),
        (s, Props.vendorName, xsd_string(invoice.vendor_name)),
        (s, Props.customerName, xsd_string(invoice.customer_name)),
        (s, Props.invoiceDate, xsd_date(str(invoice.invoice_date))),
        (s, Props.contractId, xsd_string(invoice.contract_id)),
        (s, Props.subtotal, xsd_decimal(invoice.subtotal)),
        (s, Props.taxAmount, xsd_decimal(invoice.tax_amount)),
        (s, Props.invoiceTotal, xsd_decimal(invoice.total)),
        (s, Props.lineCount, xsd_integer(len(invoice.lines))),
        (s, DCT_CREATED, _now_literal()),
    ]
    if invoice.service_period_start:
        triples.append((s, Props.servicePeriodStart, xsd_date(str(invoice.service_period_start))))
    if invoice.service_period_end:
        triples.append((s, Props.servicePeriodEnd, xsd_date(str(invoice.service_period_end))))
    if invoice.due_date:
        triples.append((s, Props.renewalDate, xsd_date(str(invoice.due_date))))
    if invoice.tax_rate is not None:
        triples.append((s, Props.taxRate, xsd_decimal(invoice.tax_rate)))
    for line in invoice.lines:
        triples.append(
            (s, Props.hasInvoiceLine, uri_for(f"{invoice.invoice_id}-l{line.line_number}"))
        )
        triples.extend(invoice_line_to_triples(line, invoice.invoice_id))
    return triples


# ---------------------------------------------------------------------------
# Finding triples
# ---------------------------------------------------------------------------


def validation_result_to_triples(result: ValidationResult, result_uri: str) -> List[Triple]:
    """Generate triples for a ValidationResult node."""
    triples: List[Triple] = [
        (result_uri, RDF_TYPE, Classes.ValidationResult),
        (result_uri, Props.validatorName, xsd_string(result.validator_name)),
        (result_uri, Props.passed, xsd_boolean(result.passed)),
        (result_uri, Props.severity, xsd_string(result.severity)),
    ]
    if result.reason:
        triples.append((result_uri, Props.validationReason, xsd_string(result.reason)))
    if result.expected is not None:
        triples.append((result_uri, Props.expectedValue, xsd_string(str(result.expected))))
    if result.actual is not None:
        triples.append((result_uri, Props.actualValue, xsd_string(str(result.actual))))
    if result.variance is not None:
        triples.append((result_uri, Props.variance, xsd_decimal(result.variance)))
    if result.variance_pct is not None:
        triples.append((result_uri, Props.variancePct, xsd_decimal(result.variance_pct)))
    return triples


def finding_to_triples(finding: Finding) -> List[Triple]:
    """Generate triples for a Finding node and all its ValidationResult nodes."""
    finding_id = f"finding-{finding.invoice_id}-l{finding.line_number}"
    s = uri_for(finding_id)
    line_uri = uri_for(f"{finding.invoice_id}-l{finding.line_number}")

    triples: List[Triple] = [
        (s, RDF_TYPE, Classes.Finding),
        (s, Props.invoiceLine, line_uri),
        (s, Props.findingStatus, xsd_string(finding.status.value)),
        (s, Props.amountInvoiced, xsd_decimal(finding.amount_invoiced)),
        (s, Props.amountExpected, xsd_decimal(finding.amount_expected)),
        (s, Props.variance, xsd_decimal(finding.variance)),
        (s, Props.matchingConfidence, xsd_decimal(finding.matching_confidence)),
        (s, Props.routingPath, xsd_string(finding.routing_path.value)),
        (s, Props.llmResolved, xsd_boolean(finding.llm_resolved)),
        (s, DCT_CREATED, _now_literal()),
    ]
    if finding.matched_charge_term_id:
        triples.append((s, Props.chargeTerm, uri_for(finding.matched_charge_term_id)))
    if finding.source_evidence:
        triples.append((s, Props.sourceEvidence, xsd_string(finding.source_evidence)))
    if finding.recommended_action:
        triples.append((s, Props.recommendation, xsd_string(finding.recommended_action)))
    if finding.audit_trail_id:
        triples.append((s, Props.auditTrailId, xsd_string(finding.audit_trail_id)))
    for vname, vresult in finding.validator_results.items():
        result_uri = uri_for(f"{finding_id}-val-{vname}")
        triples.append((s, Props.hasValidationResult, result_uri))
        triples.extend(validation_result_to_triples(vresult, result_uri))
    return triples