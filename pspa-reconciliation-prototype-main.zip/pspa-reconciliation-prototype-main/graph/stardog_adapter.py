"""
StarDog graph repository adapter (stub — not yet implemented).

This module will replace MockGraph in production once StarDog is available.
It implements the same GraphRepository interface so no application code changes.

Implementation plan (Phase 9):
  - Use the StarDog HTTP API (REST + SPARQL endpoint)
  - Authentication via HTTP Basic Auth (username/password from config)
  - INSERT DATA via SPARQL Update
  - SELECT queries via SPARQL SELECT
  - Named graph per vendor_relationship to scope queries efficiently

See:
  - https://docs.stardog.com/
  - graph/graph_repository.py for the interface contract
  - docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/DATA_MODEL.md
    for the RDF schema and sample SPARQL queries
"""

from __future__ import annotations

from datetime import date
from typing import Any, List, Optional

from graph.graph_repository import GraphRepository, Triple


class StardogAdapter(GraphRepository):
    """
    StarDog SPARQL endpoint adapter.

    All methods raise NotImplementedError until Phase 9 implementation.
    To use: set GRAPH_BACKEND=stardog in .env and configure STARDOG_* vars.
    """

    def __init__(
        self,
        url: str,
        database: str,
        username: str,
        password: str,
    ) -> None:
        """
        Initialize connection parameters.

        Does NOT open a connection at construction time — connections are
        made per-request via the StarDog HTTP API.
        """
        self._url = url.rstrip("/")
        self._database = database
        self._username = username
        self._password = password
        # TODO Phase 9: initialize httpx.Client with auth and base URL

    # --- Write operations ---

    def insert_triples(self, triples: List[Triple]) -> None:
        # TODO Phase 9: build SPARQL UPDATE INSERT DATA statement and POST to
        # {url}/{database}/update
        raise NotImplementedError("StardogAdapter.insert_triples not yet implemented (Phase 9)")

    def update_triple(self, old: Triple, new: Triple) -> None:
        # TODO Phase 9: DELETE { old } INSERT { new } WHERE {}
        raise NotImplementedError("StardogAdapter.update_triple not yet implemented (Phase 9)")

    def delete_triples(self, subject_uri: str) -> int:
        # TODO Phase 9: DELETE WHERE { <subject_uri> ?p ?o }
        raise NotImplementedError("StardogAdapter.delete_triples not yet implemented (Phase 9)")

    # --- Read operations ---

    def query_by_subject(self, subject_uri: str) -> List[Triple]:
        # TODO Phase 9: SELECT ?p ?o WHERE { <subject_uri> ?p ?o }
        raise NotImplementedError("StardogAdapter.query_by_subject not yet implemented (Phase 9)")

    def query_by_predicate_object(self, predicate_uri: str, object_value: Any) -> List[Triple]:
        # TODO Phase 9: SELECT ?s WHERE { ?s <predicate_uri> object_value }
        raise NotImplementedError(
            "StardogAdapter.query_by_predicate_object not yet implemented (Phase 9)"
        )

    def query_charge_terms(
        self,
        vendor_relationship_id: str,
        on_date: Optional[date] = None,
        location: Optional[str] = None,
    ) -> List[str]:
        # TODO Phase 9: SPARQL query joining VendorRelationship → ChargeTerm
        # with FILTER on effective/renewal dates and location scope
        raise NotImplementedError(
            "StardogAdapter.query_charge_terms not yet implemented (Phase 9)"
        )

    def subject_exists(self, subject_uri: str) -> bool:
        # TODO Phase 9: ASK { <subject_uri> ?p ?o }
        raise NotImplementedError("StardogAdapter.subject_exists not yet implemented (Phase 9)")

    def export_all_triples(self) -> List[Triple]:
        # TODO Phase 9: SELECT ?s ?p ?o WHERE { ?s ?p ?o }
        raise NotImplementedError("StardogAdapter.export_all_triples not yet implemented (Phase 9)")
