"""
Ambiguity resolver agent.

Uses an LLM to choose the best charge term when deterministic matching
returns ambiguous candidates.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from llm.llm_client import LLMClient
from llm.prompts import build_ambiguity_resolution_prompt
from models.contract_models import ChargeTerm
from utils.config import config
from utils.errors import ExtractionError


@dataclass
class AmbiguityAlternative:
    charge_term_id: str
    rank: int
    reason: str


@dataclass
class AmbiguityResolutionProvenance:
    provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    resolved_at: str


@dataclass
class AmbiguityResolutionResult:
    selected_charge_term_id: str
    confidence: float
    reasoning: str
    alternatives: List[AmbiguityAlternative]
    provenance: AmbiguityResolutionProvenance
    raw_response: Dict[str, Any]


class AmbiguityResolverAgent:
    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        min_confidence: float = 0.5,
    ) -> None:
        self.llm_client = llm_client or LLMClient(
            provider=config.llm_provider,
            model=config.llm_model,
        )
        self.min_confidence = min_confidence

    @staticmethod
    def _normalize_candidates(candidates: List[ChargeTerm | Dict[str, Any]]) -> List[Dict[str, Any]]:
        normalized: List[Dict[str, Any]] = []
        for candidate in candidates:
            if isinstance(candidate, ChargeTerm):
                normalized.append(
                    {
                        "id": candidate.id,
                        "name": candidate.name,
                        "charge_type": candidate.charge_type.value,
                        "rate": candidate.rate,
                        "rate_unit": candidate.rate_unit,
                        "service_scope": candidate.service_scope,
                        "location_scope": candidate.location_scope,
                        "preconditions": candidate.preconditions,
                    }
                )
            elif isinstance(candidate, dict):
                if "id" not in candidate:
                    raise ExtractionError("Ambiguity candidate dict missing required key 'id'")
                normalized.append(dict(candidate))
            else:
                raise ExtractionError("Candidates must be ChargeTerm objects or dicts")
        return normalized

    @staticmethod
    def _parse_alternatives(raw_alternatives: Any) -> List[AmbiguityAlternative]:
        if raw_alternatives is None:
            return []
        if not isinstance(raw_alternatives, list):
            raise ExtractionError("alternatives must be a list")

        parsed: List[AmbiguityAlternative] = []
        for idx, item in enumerate(raw_alternatives, start=1):
            if not isinstance(item, dict):
                raise ExtractionError("Each alternatives item must be an object")
            charge_term_id = str(item.get("charge_term_id", "")).strip()
            if not charge_term_id:
                raise ExtractionError("alternatives item missing charge_term_id")
            rank_raw = item.get("rank", idx)
            try:
                rank = int(rank_raw)
            except (TypeError, ValueError):
                rank = idx
            reason = str(item.get("reason", "")).strip()
            parsed.append(
                AmbiguityAlternative(
                    charge_term_id=charge_term_id,
                    rank=rank,
                    reason=reason,
                )
            )

        return sorted(parsed, key=lambda alt: alt.rank)

    def resolve_match(
        self,
        invoice_line: Dict[str, Any],
        candidates: List[ChargeTerm | Dict[str, Any]],
        relevant_excerpts: Optional[List[str]] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> AmbiguityResolutionResult:
        if not candidates:
            raise ExtractionError("At least one candidate is required for ambiguity resolution")

        normalized_candidates = self._normalize_candidates(candidates)
        candidate_ids = {str(candidate["id"]) for candidate in normalized_candidates}

        prompt = build_ambiguity_resolution_prompt(
            invoice_line=invoice_line,
            candidates=normalized_candidates,
            relevant_excerpts=relevant_excerpts,
            context=context,
        )

        payload, response = self.llm_client.complete_json_response(
            user_prompt=prompt["user_prompt"],
            system_prompt=prompt["system_prompt"],
            temperature=config.llm_temperature_ambiguity,
            max_tokens=config.llm_max_tokens,
        )

        selected_charge_term_id = str(payload.get("selected_charge_term_id", "")).strip()
        if not selected_charge_term_id:
            raise ExtractionError("Ambiguity response missing selected_charge_term_id")
        if selected_charge_term_id not in candidate_ids:
            raise ExtractionError(
                "Ambiguity response selected_charge_term_id is not in provided candidates"
            )

        confidence = float(payload.get("confidence", 0.0))
        if not (0.0 <= confidence <= 1.0):
            raise ExtractionError(f"Invalid confidence value: {confidence}")
        if confidence < self.min_confidence:
            raise ExtractionError(
                f"Ambiguity confidence below threshold {self.min_confidence:.2f}: {confidence:.2f}"
            )

        reasoning = str(payload.get("reasoning", "")).strip()
        if not reasoning:
            raise ExtractionError("Ambiguity response missing reasoning")

        alternatives = self._parse_alternatives(payload.get("alternatives"))

        provenance = AmbiguityResolutionProvenance(
            provider=response.provider,
            model=response.model,
            prompt_tokens=response.usage.prompt_tokens,
            completion_tokens=response.usage.completion_tokens,
            total_tokens=response.usage.total_tokens,
            resolved_at=datetime.now(timezone.utc).isoformat(),
        )

        return AmbiguityResolutionResult(
            selected_charge_term_id=selected_charge_term_id,
            confidence=confidence,
            reasoning=reasoning,
            alternatives=alternatives,
            provenance=provenance,
            raw_response=payload,
        )
