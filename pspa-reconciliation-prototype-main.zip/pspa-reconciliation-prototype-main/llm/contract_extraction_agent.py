"""
Contract extraction agent.

Transforms parsed contract document text into structured ChargeTerm models
using an LLM call constrained to JSON output.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from llm.llm_client import LLMClient
from llm.prompts import build_contract_extraction_prompt
from models.contract_models import ChargeTerm, ChargeType, SourceCitation
from utils.config import config
from utils.errors import ExtractionError


@dataclass
class ExtractionProvenance:
    provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    extracted_at: str


@dataclass
class ExtractionResult:
    charge_terms: List[ChargeTerm]
    provenance: ExtractionProvenance
    raw_response: Dict[str, Any]
    conflicts: List[str] = field(default_factory=list)
    manual_review_required: bool = False
    review_reasons: List[str] = field(default_factory=list)


class ContractExtractionAgent:
    def __init__(
        self,
        llm_client: Optional[LLMClient] = None,
        min_confidence: float = 0.70,
        review_confidence_threshold: float = 0.80,
    ) -> None:
        self.llm_client = llm_client or LLMClient(
            provider=config.llm_provider,
            model=config.llm_model,
        )
        self.min_confidence = min_confidence
        self.review_confidence_threshold = review_confidence_threshold

    @staticmethod
    def _slug(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")

    @staticmethod
    def _parse_date(value: Any) -> Optional[date]:
        if value is None or value == "":
            return None
        if isinstance(value, date):
            return value
        try:
            return date.fromisoformat(str(value))
        except ValueError:
            return None

    def _map_charge_term(
        self,
        raw_term: Dict[str, Any],
        vendor_relationship_id: str,
        source_document_id: str,
        source_document_type: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ChargeTerm:
        name = str(raw_term.get("name", "")).strip()
        if not name:
            raise ExtractionError("Extracted charge term missing name")

        charge_type_raw = str(raw_term.get("charge_type", "")).strip()
        try:
            charge_type = ChargeType(charge_type_raw)
        except ValueError as exc:
            raise ExtractionError(f"Invalid extracted charge_type: {charge_type_raw!r}") from exc

        if raw_term.get("rate") is None:
            raise ExtractionError(f"Extracted charge term {name!r} missing rate")

        term_id = str(raw_term.get("id") or f"{vendor_relationship_id}-{self._slug(name)}")
        confidence = float(raw_term.get("extraction_confidence", 0.0))
        if not (0.0 <= confidence <= 1.0):
            raise ExtractionError(f"Invalid extraction_confidence for term {name!r}: {confidence}")

        source = raw_term.get("source") or {}
        source_citation = SourceCitation(
            document_id=str(source.get("document_id") or source_document_id),
            document_type=str(source.get("document_type") or source_document_type),
            page=source.get("page"),
            section=source.get("section"),
            line_reference=source.get("line_reference"),
            span_text=source.get("span_text"),
        )

        extraction_notes = str(raw_term.get("extraction_notes", ""))

        doc_type_value = str((metadata or {}).get("document_type") or source_document_type).lower()
        is_amendment = "amend" in doc_type_value
        amendment_number = (metadata or {}).get("amendment_number")
        if is_amendment:
            amendment_note = "amendment_term_precedence=override_by_term_id"
            if amendment_number is not None:
                amendment_note = f"amendment_number={amendment_number}; {amendment_note}"
            extraction_notes = f"{extraction_notes}; {amendment_note}".strip("; ")

        return ChargeTerm(
            id=term_id,
            vendor_relationship_id=vendor_relationship_id,
            name=name,
            service_scope=str(raw_term.get("service_scope", "")),
            charge_type=charge_type,
            rate=float(raw_term.get("rate")),
            rate_unit=str(raw_term.get("rate_unit", "unit")),
            rate_currency=str(raw_term.get("rate_currency", "USD")),
            billing_interval=str(raw_term.get("billing_interval", "")),
            invoice_cadence=str(raw_term.get("invoice_cadence", "")),
            location_scope=[str(v) for v in raw_term.get("location_scope", [])],
            effective_date=self._parse_date(raw_term.get("effective_date")),
            renewal_date=self._parse_date(raw_term.get("renewal_date")),
            preconditions=[str(v) for v in raw_term.get("preconditions", [])],
            is_passthrough=bool(raw_term.get("is_passthrough", False)),
            requires_cost_evidence=bool(raw_term.get("requires_cost_evidence", False)),
            max_amount=raw_term.get("max_amount"),
            overage_rate=raw_term.get("overage_rate"),
            included_quantity=raw_term.get("included_quantity"),
            contingency_pct=raw_term.get("contingency_pct"),
            source=source_citation,
            extraction_confidence=confidence,
            extraction_notes=extraction_notes,
        )

    @staticmethod
    def _materially_conflicting(existing: ChargeTerm, candidate: ChargeTerm) -> bool:
        return (
            existing.charge_type != candidate.charge_type
            or round(existing.rate, 6) != round(candidate.rate, 6)
            or existing.rate_unit.strip().lower() != candidate.rate_unit.strip().lower()
        )

    def _detect_conflicts(self, terms: List[ChargeTerm]) -> List[str]:
        by_id: Dict[str, ChargeTerm] = {}
        conflicts: List[str] = []

        for term in terms:
            prior = by_id.get(term.id)
            if prior is None:
                by_id[term.id] = term
                continue
            if self._materially_conflicting(prior, term):
                conflicts.append(
                    (
                        f"Conflicting extraction for term_id={term.id}: "
                        f"{prior.charge_type.value}/{prior.rate} {prior.rate_unit} vs "
                        f"{term.charge_type.value}/{term.rate} {term.rate_unit}"
                    )
                )

        return conflicts

    def extract_charge_terms(
        self,
        document_text: str,
        vendor_relationship_id: str,
        source_document_id: str,
        source_document_type: str = "ContractDocument",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExtractionResult:
        if not document_text.strip():
            raise ExtractionError("Contract document text is empty")

        prompt = build_contract_extraction_prompt(document_text=document_text, metadata=metadata)

        llm_payload, llm_response = self.llm_client.complete_json_response(
            user_prompt=prompt["user_prompt"],
            system_prompt=prompt["system_prompt"],
            temperature=config.llm_temperature_extraction,
            max_tokens=config.llm_max_tokens,
        )

        raw_terms = llm_payload.get("charge_terms")
        if not isinstance(raw_terms, list):
            raise ExtractionError("LLM response missing charge_terms list")

        terms: List[ChargeTerm] = []
        term_errors: List[str] = []
        for raw_term in raw_terms:
            if not isinstance(raw_term, dict):
                term_errors.append("Each charge_terms entry must be an object")
                continue
            try:
                term = self._map_charge_term(
                    raw_term=raw_term,
                    vendor_relationship_id=vendor_relationship_id,
                    source_document_id=source_document_id,
                    source_document_type=source_document_type,
                    metadata=metadata,
                )
                terms.append(term)
            except ExtractionError as exc:
                term_name = str(raw_term.get("name") or "(unnamed)")
                term_errors.append(f"{term_name}: {exc}")

        if not terms:
            if term_errors:
                raise ExtractionError(
                    "No valid extracted charge terms. "
                    + "; ".join(term_errors[:5])
                )
            raise ExtractionError("No valid extracted charge terms")

        low_confidence = [t for t in terms if t.extraction_confidence < self.min_confidence]
        if low_confidence:
            names = ", ".join([f"{t.name} ({t.extraction_confidence:.2f})" for t in low_confidence])
            raise ExtractionError(
                f"Extraction confidence below threshold {self.min_confidence:.2f} for terms: {names}"
            )

        review_reasons: List[str] = []
        review_confidence_terms = [
            t for t in terms if t.extraction_confidence < self.review_confidence_threshold
        ]
        if review_confidence_terms:
            names = ", ".join([f"{t.name} ({t.extraction_confidence:.2f})" for t in review_confidence_terms])
            review_reasons.append(
                (
                    "Extraction confidence below manual-review threshold "
                    f"{self.review_confidence_threshold:.2f} for terms: {names}"
                )
            )

        conflicts = self._detect_conflicts(terms)
        if conflicts:
            review_reasons.append("Detected conflicting extracted terms; manual review required")
        if term_errors:
            review_reasons.append(
                "Some extracted terms were skipped due to validation errors: "
                + "; ".join(term_errors[:5])
            )

        provenance = ExtractionProvenance(
            provider=llm_response.provider,
            model=llm_response.model,
            prompt_tokens=llm_response.usage.prompt_tokens,
            completion_tokens=llm_response.usage.completion_tokens,
            total_tokens=llm_response.usage.total_tokens,
            extracted_at=datetime.now(timezone.utc).isoformat(),
        )

        return ExtractionResult(
            charge_terms=terms,
            provenance=provenance,
            raw_response=llm_payload,
            conflicts=conflicts,
            manual_review_required=bool(review_reasons),
            review_reasons=review_reasons,
        )
