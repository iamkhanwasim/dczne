"""
LLM client wrapper with provider abstraction, retry logic, and rate limiting.
"""

from __future__ import annotations

import json
import random
import re
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Literal, Optional, Tuple

from utils.config import config
from utils.errors import ExtractionError


@dataclass
class LLMUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class LLMResponse:
    text: str
    provider: str
    model: str
    usage: LLMUsage
    raw: Any


TransportFn = Callable[..., Dict[str, Any]]
RetryObserverFn = Callable[[float, int, int, Exception], None]


class LLMClient:
    def __init__(
        self,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        api_key: Optional[str] = None,
        max_tokens: Optional[int] = None,
        timeout_seconds: int = 60,
        max_retries: int = 3,
        requests_per_minute: int = 60,
        transport: Optional[TransportFn] = None,
        sleep_fn: Callable[[float], None] = time.sleep,
        retry_observer: Optional[RetryObserverFn] = None,
    ) -> None:
        self.provider = (provider or config.llm_provider).lower().strip()
        self.model = model or config.llm_model
        self.max_tokens = max_tokens or config.llm_max_tokens
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self.requests_per_minute = requests_per_minute
        self.transport = transport
        self.sleep_fn = sleep_fn
        self.retry_observer = retry_observer
        self._request_timestamps: List[float] = []

        if api_key:
            self.api_key = api_key
        elif self.provider == "azure-apim":
            self.api_key = config.azure_openai_api_key
        elif self.provider == "openai":
            self.api_key = config.openai_api_key
        elif self.provider == "anthropic":
            self.api_key = config.anthropic_api_key
        else:
            self.api_key = ""

    def _enforce_rate_limit(self) -> None:
        now = time.time()
        window_start = now - 60.0
        self._request_timestamps = [t for t in self._request_timestamps if t >= window_start]
        if len(self._request_timestamps) >= self.requests_per_minute:
            earliest = min(self._request_timestamps)
            wait_time = max(0.0, 60.0 - (now - earliest))
            if wait_time > 0:
                self.sleep_fn(wait_time)
        self._request_timestamps.append(time.time())

    @staticmethod
    def estimate_tokens(text: str) -> int:
        if not text:
            return 0
        return max(1, int(len(text) / 4))

    @staticmethod
    def _build_azure_openai_url(surface: Literal["chat-completions", "embeddings"]) -> str:
        if not config.azure_openai_endpoint:
            raise ExtractionError("AZURE_OPENAI_ENDPOINT is not configured")
        if not config.azure_openai_deployment:
            raise ExtractionError("AZURE_OPENAI_DEPLOYMENT is not configured")

        endpoint_base = config.azure_openai_endpoint.rstrip("/")
        api_version = config.azure_openai_api_version
        if surface == "chat-completions":
            return (
                f"{endpoint_base}/openai/deployments/{config.azure_openai_deployment}/chat/completions"
                f"?api-version={api_version}"
            )
        if surface == "embeddings":
            return (
                f"{endpoint_base}/openai/deployments/{config.azure_openai_deployment}/embeddings"
                f"?api-version={api_version}"
            )
        raise ExtractionError(f"Unsupported Azure OpenAI surface: {surface}")

    def _invoke_azure_apim(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ExtractionError("AZURE_OPENAI_API_KEY is not configured")

        try:
            import requests
        except Exception as exc:
            raise ExtractionError(f"Requests library unavailable: {exc}") from exc

        endpoint_url = self._build_azure_openai_url("chat-completions")

        headers = {
            "api-key": self.api_key,
            "Content-Type": "application/json",
        }

        payload = {
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        try:
            response = requests.post(
                endpoint_url,
                json=payload,
                headers=headers,
                timeout=self.timeout_seconds,
            )
            if response.status_code == 429:
                retry_after_header = response.headers.get("Retry-After")
                retry_after_hint = ""
                if retry_after_header is not None:
                    try:
                        retry_after_seconds = float(retry_after_header.strip())
                        if retry_after_seconds > 0:
                            retry_after_hint = f" [retry_after={retry_after_seconds}]"
                    except ValueError:
                        pass
                raise ExtractionError(
                    "Azure APIM request failed: 429 Client Error: Too Many Requests "
                    f"for url: {endpoint_url}{retry_after_hint}"
                )

            if response.status_code == 400:
                try:
                    error_payload = response.json()
                except ValueError:
                    error_payload = {}

                error_message = str(error_payload.get("error", {}).get("message", ""))
                if "max_tokens" in error_message and "max_completion_tokens" in error_message:
                    payload_retry = {
                        "messages": messages,
                        "temperature": temperature,
                        "max_completion_tokens": max_tokens,
                    }
                    response = requests.post(
                        endpoint_url,
                        json=payload_retry,
                        headers=headers,
                        timeout=self.timeout_seconds,
                    )
            response.raise_for_status()

            response_data = response.json()
            
            # Handle standard OpenAI-compatible response format
            text = ""
            if "choices" in response_data and response_data["choices"]:
                choice = response_data["choices"][0]
                if "message" in choice:
                    text = choice["message"].get("content", "")
                elif "text" in choice:
                    text = choice["text"]

            # Extract usage information
            usage = response_data.get("usage", {})
            usage_dict = {
                "prompt_tokens": int(usage.get("prompt_tokens", self.estimate_tokens("".join([m.get("content", "") for m in messages])))),
                "completion_tokens": int(usage.get("completion_tokens", self.estimate_tokens(text))),
                "total_tokens": int(usage.get("total_tokens", 0)),
            }

            return {"text": text, "usage": usage_dict, "raw": response_data}

        except requests.exceptions.RequestException as exc:
            raise ExtractionError(f"Azure APIM request failed: {exc}") from exc

    @staticmethod
    def _extract_retry_after_seconds(exc: Exception) -> Optional[float]:
        message = str(exc)
        match = re.search(r"retry_after=([0-9]+(?:\.[0-9]+)?)", message)
        if not match:
            return None
        try:
            parsed = float(match.group(1))
            return parsed if parsed > 0 else None
        except ValueError:
            return None

    def _compute_retry_backoff_seconds(self, retries: int, exc: Exception) -> float:
        exponential = float(2 ** (retries - 1))
        jitter = random.uniform(0.0, 0.5)
        backoff = min(60.0, exponential + jitter)

        retry_after = self._extract_retry_after_seconds(exc)
        if retry_after is not None:
            backoff = max(backoff, min(retry_after, 60.0))

        return backoff

    def _invoke_provider(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> Dict[str, Any]:
        if self.transport is not None:
            return self.transport(
                provider=self.provider,
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout_seconds=self.timeout_seconds,
            )

        if self.provider == "azure-apim":
            return self._invoke_azure_apim(messages, temperature, max_tokens)
        if self.provider == "openai":
            return self._invoke_openai(messages, temperature, max_tokens)
        if self.provider == "anthropic":
            return self._invoke_anthropic(messages, temperature, max_tokens)
        raise ExtractionError(f"Unsupported LLM provider: {self.provider}")

    def _invoke_openai(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ExtractionError("OPENAI_API_KEY is not configured")

        try:
            from openai import OpenAI
        except Exception as exc:
            raise ExtractionError(f"OpenAI SDK unavailable: {exc}") from exc

        client = OpenAI(api_key=self.api_key)
        response = client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            timeout=self.timeout_seconds,
        )

        text = response.choices[0].message.content or ""
        usage = response.usage
        usage_dict = {
            "prompt_tokens": int(getattr(usage, "prompt_tokens", 0)),
            "completion_tokens": int(getattr(usage, "completion_tokens", 0)),
            "total_tokens": int(getattr(usage, "total_tokens", 0)),
        }

        return {"text": text, "usage": usage_dict, "raw": response}

    def _invoke_anthropic(
        self,
        messages: List[Dict[str, str]],
        temperature: float,
        max_tokens: int,
    ) -> Dict[str, Any]:
        if not self.api_key:
            raise ExtractionError("ANTHROPIC_API_KEY is not configured")

        try:
            import anthropic
        except Exception as exc:
            raise ExtractionError(f"Anthropic SDK unavailable: {exc}") from exc

        system_text = ""
        user_text_parts: List[str] = []
        for message in messages:
            if message.get("role") == "system":
                system_text = message.get("content", "")
            elif message.get("role") == "user":
                user_text_parts.append(message.get("content", ""))

        client = anthropic.Anthropic(api_key=self.api_key)
        response = client.messages.create(
            model=self.model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system_text,
            messages=[{"role": "user", "content": "\n\n".join(user_text_parts)}],
        )

        text = ""
        if getattr(response, "content", None):
            text = "".join([getattr(part, "text", "") for part in response.content])

        usage = getattr(response, "usage", None)
        prompt_tokens = int(getattr(usage, "input_tokens", 0)) if usage else 0
        completion_tokens = int(getattr(usage, "output_tokens", 0)) if usage else 0
        usage_dict = {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens": prompt_tokens + completion_tokens,
        }

        return {"text": text, "usage": usage_dict, "raw": response}

    def complete_text(
        self,
        user_prompt: str,
        system_prompt: str = "",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> LLMResponse:
        if not user_prompt.strip():
            raise ExtractionError("Prompt cannot be empty")

        messages: List[Dict[str, str]] = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": user_prompt})

        retries = 0
        last_error: Optional[Exception] = None
        max_tokens_final = max_tokens or self.max_tokens

        while retries < self.max_retries:
            try:
                self._enforce_rate_limit()
                payload = self._invoke_provider(
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens_final,
                )
                text = str(payload.get("text", "")).strip()
                if not text:
                    raise ExtractionError("LLM returned empty response")

                usage_raw = payload.get("usage") or {}
                usage = LLMUsage(
                    prompt_tokens=int(usage_raw.get("prompt_tokens", self.estimate_tokens(system_prompt + user_prompt))),
                    completion_tokens=int(usage_raw.get("completion_tokens", self.estimate_tokens(text))),
                    total_tokens=int(usage_raw.get("total_tokens", self.estimate_tokens(system_prompt + user_prompt + text))),
                )
                return LLMResponse(
                    text=text,
                    provider=self.provider,
                    model=self.model,
                    usage=usage,
                    raw=payload.get("raw"),
                )
            except Exception as exc:
                last_error = exc
                retries += 1
                if retries >= self.max_retries:
                    break
                backoff = self._compute_retry_backoff_seconds(retries, exc)
                if self.retry_observer is not None:
                    try:
                        self.retry_observer(backoff, retries, self.max_retries, exc)
                    except Exception:
                        pass
                self.sleep_fn(backoff)

        raise ExtractionError(f"LLM request failed after retries: {last_error}")

    @staticmethod
    def _parse_json_object(raw_text: str) -> Dict[str, Any]:
        raw = raw_text.strip()
        try:
            parsed = json.loads(raw)
            if not isinstance(parsed, dict):
                raise ExtractionError("Expected JSON object response")
            return parsed
        except json.JSONDecodeError:
            pass

        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if not match:
            raise ExtractionError("Could not parse JSON object from LLM response")

        try:
            parsed = json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise ExtractionError(f"Invalid JSON response: {exc}") from exc

        if not isinstance(parsed, dict):
            raise ExtractionError("Expected JSON object response")
        return parsed

    def complete_json_response(
        self,
        user_prompt: str,
        system_prompt: str = "",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> Tuple[Dict[str, Any], LLMResponse]:
        response = self.complete_text(
            user_prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return self._parse_json_object(response.text), response

    def complete_json(
        self,
        user_prompt: str,
        system_prompt: str = "",
        temperature: float = 0.1,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        parsed, _ = self.complete_json_response(
            user_prompt=user_prompt,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return parsed
