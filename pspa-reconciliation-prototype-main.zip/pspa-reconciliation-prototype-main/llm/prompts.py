"""
Prompt builders and response schema definitions for LLM workflows.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


CONTRACT_EXTRACTION_RESPONSE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "required": ["charge_terms"],
    "properties": {
        "charge_terms": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["name", "charge_type", "rate", "rate_unit", "extraction_confidence"],
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string", "minLength": 3},
                    "service_scope": {"type": "string"},
                    "charge_type": {
                        "type": "string",
                        "enum": ["FIXED_RATE", "VARIABLE_RATE", "PASS_THROUGH", "CONTINGENCY", "SUBSCRIPTION", "OVERAGE", "EVENT", "TIME_AND_MATERIALS"],
                        "description": "Type of charge term; must be one of the valid enum values"
                    },
                    "rate": {"type": "number", "minimum": 0.01, "description": "Dollar amount per rate_unit"},
                    "rate_unit": {"type": "string", "minLength": 2, "description": "Singular unit: month, hour, year, visit, occurrence, etc."},
                    "rate_currency": {"type": "string"},
                    "billing_interval": {"type": "string"},
                    "invoice_cadence": {"type": "string"},
                    "location_scope": {"type": "array", "items": {"type": "string"}},
                    "effective_date": {"type": "string"},
                    "renewal_date": {"type": "string"},
                    "preconditions": {"type": "array", "items": {"type": "string"}},
                    "is_passthrough": {"type": "boolean"},
                    "requires_cost_evidence": {"type": "boolean"},
                    "max_amount": {"type": "number"},
                    "overage_rate": {"type": "number"},
                    "included_quantity": {"type": "number"},
                    "contingency_pct": {"type": "number"},
                    "extraction_confidence": {"type": "number"},
                    "extraction_notes": {"type": "string"},
                    "source": {
                        "type": "object",
                        "properties": {
                            "document_id": {"type": "string"},
                            "document_type": {"type": "string"},
                            "page": {"type": "integer"},
                            "section": {"type": "string"},
                            "line_reference": {"type": "string"},
                            "span_text": {"type": "string"},
                        },
                    },
                },
            },
        }
    },
}


AMBIGUITY_RESOLUTION_RESPONSE_SCHEMA: Dict[str, Any] = {
    "type": "object",
    "required": ["selected_charge_term_id", "confidence", "reasoning"],
    "properties": {
        "selected_charge_term_id": {"type": "string"},
        "confidence": {"type": "number"},
        "reasoning": {"type": "string"},
        "alternatives": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["charge_term_id", "rank", "reason"],
                "properties": {
                    "charge_term_id": {"type": "string"},
                    "rank": {"type": "integer"},
                    "reason": {"type": "string"},
                },
            },
        },
    },
}


def _metadata_block(metadata: Optional[Dict[str, Any]]) -> str:
    if not metadata:
        return "(none)"
    lines = [f"- {key}: {value}" for key, value in metadata.items()]
    return "\n".join(lines)


def build_contract_extraction_prompt(
    document_text: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    system_prompt = (
        "You extract contract charge terms for invoice reconciliation. "
        "Return valid JSON only. Preserve uncertainty in extraction_notes and confidence. "
        "Do not invent terms that are not supported by text. "
        "Each charge_terms item must include a non-empty, descriptive `name`."
    )

    user_prompt = f"""
Extract contract charge terms from the document below.

Metadata:
{_metadata_block(metadata)}

Output requirements:
- Return a JSON object with key `charge_terms`.
- Include one object per billable term.
- Required fields for each charge term (use exact field names):
  * `name`: REQUIRED, non-empty, descriptive string
    Examples: "Competitive Insights Dashboard Subscription (Semiannual)",
    "Fire Suppression Inspection - Monthly Service", "Landscaping Maintenance - Per Visit"
    If contract has no explicit title, construct from service + cadence/rate context from the document text.
    Do NOT use placeholders like "Charge", "Fee", or "Service".
  * `rate`: REQUIRED, numeric dollar amount for one unit of billing
    Examples: 1725.59 (for semiannual), 50.00 (for hourly), 500.00 (for monthly)
  * `rate_unit`: REQUIRED, singular unit describing billing frequency/quantity basis
    Valid: "month", "hour", "day", "week", "year", "occurrence", "visit", "invoice", "unit", "lot"
    NOT plural forms or vague terms like "per billing"
  * `charge_type`: REQUIRED, EXACTLY one of: FIXED_RATE | VARIABLE_RATE | PASS_THROUGH | CONTINGENCY | SUBSCRIPTION | OVERAGE | EVENT | TIME_AND_MATERIALS
    How to determine from contract language:
    - FIXED_RATE: "monthly fee of $5,000", "annual service charge", "flat fee per delivery"
    - VARIABLE_RATE: "$150 per hour", "$25 per unit", "per-occurrence at $500"
    - PASS_THROUGH: "pass through costs", "actual invoice from vendor", "cost reimbursement"
    - CONTINGENCY: "20% of recovered reimbursement", "percentage of savings realized"
    - SUBSCRIPTION: "subscription service with included features", "annual subscription"
    - OVERAGE: "overage at $10 per incident", "charges beyond 100 units"
    - EVENT: "spring cleanup fee", "annual inspection charge", "per-visit service"
    - TIME_AND_MATERIALS: "labor at $75/hr plus materials", "technician time + supplies"
  * `extraction_confidence`: REQUIRED, decimal 0.0-1.0 representing how explicitly contract states the terms (not a guess)
  * `extraction_notes`: optional string describing extraction rationale or ambiguities

Contract text:
{document_text}
---
""".strip()

    return {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
    }


def build_ambiguity_resolution_prompt(
    invoice_line: Dict[str, Any],
    candidates: List[Dict[str, Any]],
    relevant_excerpts: Optional[List[str]] = None,
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, str]:
    system_prompt = (
        "You resolve ambiguous invoice-line-to-contract-term matches. "
        "Return valid JSON only with the selected term and concise reasoning."
    )

    excerpts_block = "\n".join([f"- {excerpt}" for excerpt in (relevant_excerpts or [])])

    user_prompt = f"""
Resolve this ambiguous match.

Invoice line:
{invoice_line}

Candidates:
{candidates}

Relevant contract excerpts:
{excerpts_block or "(none)"}

Additional context:
{context or {}}

Return a JSON object with:
- selected_charge_term_id
- confidence (0.0 to 1.0)
- reasoning
- alternatives (optional list)
""".strip()

    return {
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
    }
