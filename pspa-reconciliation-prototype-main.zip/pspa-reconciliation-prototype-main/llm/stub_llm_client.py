"""
Stub LLM client for offline demo mode.

Provides pre-baked extraction results for known vendor PDFs,
allowing full end-to-end demos without API keys or network access.
"""

from datetime import date, datetime, timezone
from typing import Any, Dict, Optional

from llm.contract_extraction_agent import ExtractionProvenance, ExtractionResult
from models.contract_models import ChargeTerm, ChargeType, SourceCitation


class StubLLMClient:
    """
    Mock LLM client that returns pre-canned extraction results.

    Useful for demos, development, and CI/CD without external API dependencies.
    """

    def __init__(self) -> None:
        self.calls_made = 0

    def extract_charge_terms_stub(
        self,
        document_text: str,
        vendor_relationship_id: str,
        source_document_id: str,
        source_document_type: str = "ContractDocument",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExtractionResult:
        """
        Return stub extraction results based on vendor name or document fingerprint.

        Args:
            document_text: The contract text (used for fingerprinting)
            vendor_relationship_id: Vendor ID
            source_document_id: Document ID
            source_document_type: Type of document
            metadata: Additional metadata

        Returns:
            Pre-canned ExtractionResult
        """
        self.calls_made += 1

        # Simple heuristic: detect vendor from document text or vendor_id
        vendor_name = self._detect_vendor(vendor_relationship_id, document_text)

        # Return stub terms based on vendor
        terms = self._stub_terms_for_vendor(vendor_name, vendor_relationship_id, source_document_id)

        provenance = ExtractionProvenance(
            provider="stub",
            model="stub-v1",
            prompt_tokens=0,
            completion_tokens=0,
            total_tokens=0,
            extracted_at=datetime.now(timezone.utc).isoformat(),
        )

        return ExtractionResult(
            charge_terms=terms,
            provenance=provenance,
            raw_response={"source": "stub", "vendor": vendor_name},
            conflicts=[],
            manual_review_required=False,
            review_reasons=[],
        )

    @staticmethod
    def _detect_vendor(vendor_id: str, text: str) -> str:
        """Detect vendor name from ID or text content."""
        vendor_id_lower = vendor_id.lower()

        if "experian" in vendor_id_lower or "experian" in text.lower():
            return "experian"
        if "johnson" in vendor_id_lower or "johnson controls" in text.lower():
            return "johnson_controls"
        if "landscap" in vendor_id_lower or "quality lawn" in text.lower():
            return "quality_lawn"
        if "reputation" in vendor_id_lower or "reputation.com" in text.lower():
            return "reputation"
        if "perficient" in vendor_id_lower or "perficient" in text.lower():
            return "perficient"
        if "health roi" in vendor_id_lower or "health roi" in text.lower():
            return "health_roi"

        return "generic"

    @staticmethod
    def _stub_terms_for_vendor(
        vendor_name: str, vendor_relationship_id: str, source_document_id: str
    ) -> list[ChargeTerm]:
        """Return realistic stub charge terms for a given vendor."""

        if vendor_name == "experian":
            return [
                ChargeTerm(
                    id=f"{vendor_relationship_id}-monitoring",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Credit Monitoring Service",
                    service_scope="Unlimited credit file monitoring for all UHS entities",
                    charge_type=ChargeType.SUBSCRIPTION,
                    rate=450.0,
                    rate_unit="month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.96,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=1,
                        section="Service Terms",
                    ),
                ),
                ChargeTerm(
                    id=f"{vendor_relationship_id}-alerts",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Identity Theft Alerts",
                    service_scope="Real-time alerts for suspicious activity",
                    charge_type=ChargeType.FIXED_RATE,
                    rate=75.0,
                    rate_unit="month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.92,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=2,
                        section="Add-on Services",
                    ),
                ),
            ]

        elif vendor_name == "johnson_controls":
            return [
                ChargeTerm(
                    id=f"{vendor_relationship_id}-fire-monitoring",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Fire System Monitoring",
                    service_scope="24/7 monitoring of fire suppression systems",
                    charge_type=ChargeType.SUBSCRIPTION,
                    rate=350.0,
                    rate_unit="location/month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.94,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=1,
                        section="Service Specification",
                    ),
                ),
                ChargeTerm(
                    id=f"{vendor_relationship_id}-repairs",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Emergency Repair Service",
                    service_scope="Urgent repairs to fire suppression equipment",
                    charge_type=ChargeType.TIME_AND_MATERIALS,
                    rate=150.0,
                    rate_unit="hour",
                    rate_currency="USD",
                    billing_interval="per-service",
                    invoice_cadence="as-needed",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=["Work order approval required"],
                    is_passthrough=False,
                    requires_cost_evidence=True,
                    extraction_confidence=0.88,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=3,
                        section="Emergency Services",
                    ),
                ),
            ]

        elif vendor_name == "quality_lawn":
            return [
                ChargeTerm(
                    id=f"{vendor_relationship_id}-landscape",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Monthly Landscape Maintenance",
                    service_scope="Lawn mowing, trimming, and basic maintenance",
                    charge_type=ChargeType.SUBSCRIPTION,
                    rate=1200.0,
                    rate_unit="month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["Main Campus"],
                    effective_date=date(2024, 3, 1),
                    renewal_date=date(2025, 2, 28),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.97,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=1,
                        section="Core Services",
                    ),
                ),
                ChargeTerm(
                    id=f"{vendor_relationship_id}-seasonal",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Seasonal Spring Cleanup",
                    service_scope="Deep mulching, planting, spring preparation",
                    charge_type=ChargeType.VARIABLE_RATE,
                    rate=85.0,
                    rate_unit="hour",
                    rate_currency="USD",
                    billing_interval="per-service",
                    invoice_cadence="seasonal",
                    location_scope=["Main Campus"],
                    effective_date=date(2024, 3, 1),
                    renewal_date=date(2025, 2, 28),
                    preconditions=["PO required for any spring cleanup over $500"],
                    is_passthrough=False,
                    requires_cost_evidence=True,
                    extraction_confidence=0.85,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=2,
                        section="Optional Services",
                    ),
                ),
            ]

        elif vendor_name == "reputation":
            return [
                ChargeTerm(
                    id=f"{vendor_relationship_id}-reputation-mgmt",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Reputation Management Platform",
                    service_scope="Online review monitoring and response",
                    charge_type=ChargeType.SUBSCRIPTION,
                    rate=500.0,
                    rate_unit="month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.95,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=1,
                        section="Service Terms",
                    ),
                ),
            ]

        elif vendor_name == "perficient":
            return [
                ChargeTerm(
                    id=f"{vendor_relationship_id}-website-ops",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Website Maintenance & Support",
                    service_scope="24x7 support, monthly updates, security patches",
                    charge_type=ChargeType.SUBSCRIPTION,
                    rate=2000.0,
                    rate_unit="month",
                    rate_currency="USD",
                    billing_interval="monthly",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=[],
                    is_passthrough=False,
                    requires_cost_evidence=False,
                    extraction_confidence=0.96,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=1,
                        section="Managed Services",
                    ),
                ),
                ChargeTerm(
                    id=f"{vendor_relationship_id}-dev-hours",
                    vendor_relationship_id=vendor_relationship_id,
                    name="Development Hours",
                    service_scope="Custom development and enhancements",
                    charge_type=ChargeType.VARIABLE_RATE,
                    rate=200.0,
                    rate_unit="hour",
                    rate_currency="USD",
                    billing_interval="per-service",
                    invoice_cadence="monthly",
                    location_scope=["All"],
                    effective_date=date(2024, 1, 1),
                    renewal_date=date(2025, 12, 31),
                    preconditions=["Purchase order required", "Time tracking required"],
                    is_passthrough=False,
                    requires_cost_evidence=True,
                    extraction_confidence=0.90,
                    source=SourceCitation(
                        document_id=source_document_id,
                        document_type="ContractDocument",
                        page=2,
                        section="Additional Services",
                    ),
                ),
            ]

        # Generic/default stub
        return [
            ChargeTerm(
                id=f"{vendor_relationship_id}-service",
                vendor_relationship_id=vendor_relationship_id,
                name="Generic Service",
                service_scope="Standard service provision",
                charge_type=ChargeType.FIXED_RATE,
                rate=500.0,
                rate_unit="month",
                rate_currency="USD",
                billing_interval="monthly",
                invoice_cadence="monthly",
                location_scope=["All"],
                effective_date=date(2024, 1, 1),
                renewal_date=date(2025, 12, 31),
                preconditions=[],
                is_passthrough=False,
                requires_cost_evidence=False,
                extraction_confidence=0.80,
                source=SourceCitation(
                    document_id=source_document_id,
                    document_type="ContractDocument",
                    page=1,
                    section="Services",
                ),
            ),
        ]
