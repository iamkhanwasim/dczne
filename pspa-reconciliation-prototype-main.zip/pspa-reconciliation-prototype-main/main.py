"""
Entry point for the PSPA Reconciliation Engine API.

Run with:
    uvicorn main:app --reload
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from api.contract_endpoints import router as contract_router
from api.invoice_endpoints import router as invoice_router
from utils.errors import (
    ContractNotFinalizedError,
    ContractNotFoundError,
    ParseError,
    ReconciliationError,
    ValidationError,
)

from utils.logging_config import configure_logging

configure_logging()

app = FastAPI(
    title="PSPA Reconciliation Engine",
    description="Contract-invoice reconciliation using ontology-backed agent with two-tier routing.",
    version="0.1.0",
)


@app.exception_handler(ContractNotFoundError)
def handle_contract_not_found(_: object, exc: ContractNotFoundError) -> JSONResponse:
    return JSONResponse(status_code=404, content={"detail": str(exc), "contract_id": exc.contract_id})


@app.exception_handler(ContractNotFinalizedError)
def handle_contract_not_finalized(_: object, exc: ContractNotFinalizedError) -> JSONResponse:
    return JSONResponse(status_code=409, content={"detail": str(exc), "contract_id": exc.contract_id})


@app.exception_handler(ParseError)
def handle_parse_error(_: object, exc: ParseError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"detail": str(exc), "filename": exc.filename, "reason": exc.reason},
    )


@app.exception_handler(ValidationError)
def handle_validation_error(_: object, exc: ValidationError) -> JSONResponse:
    return JSONResponse(status_code=400, content={"detail": str(exc)})


@app.exception_handler(ReconciliationError)
def handle_reconciliation_error(_: object, exc: ReconciliationError) -> JSONResponse:
    return JSONResponse(status_code=500, content={"detail": str(exc)})


app.include_router(contract_router)
app.include_router(invoice_router)
