from __future__ import annotations

from typing import List

from matching.similarity import score_line_to_term
from models.contract_models import ChargeTerm
from models.invoice_models import InvoiceLine
from models.routing_models import MatchCandidate, MatchResult


LOW_CONFIDENCE_THRESHOLD = 0.65
AMBIGUITY_DELTA = 0.10


def _candidate_reason(
    name_similarity: float,
    unit_match: bool,
    rate_proximity: float,
    confidence: float,
) -> str:
    unit_text = "unit match" if unit_match else "unit mismatch"
    return (
        f"confidence={confidence:.2f}; "
        f"name_similarity={name_similarity:.2f}; "
        f"{unit_text}; "
        f"rate_proximity={rate_proximity:.2f}"
    )


def _build_candidate(invoice_line: InvoiceLine, term: ChargeTerm) -> MatchCandidate:
    confidence, name_similarity, is_unit_match, rate_score = score_line_to_term(invoice_line, term)
    return MatchCandidate(
        charge_term=term,
        confidence=confidence,
        name_similarity=name_similarity,
        unit_match=is_unit_match,
        rate_proximity=rate_score,
        date_in_range=True,
        reason=_candidate_reason(name_similarity, is_unit_match, rate_score, confidence),
    )


def match_line_to_term(invoice_line: InvoiceLine, candidates: List[ChargeTerm]) -> MatchResult:
    """
    Match one invoice line to the best charge term within a known contract.
    """
    invoice_line_id = str(invoice_line.line_number)
    if not candidates:
        return MatchResult(
            invoice_line_id=invoice_line_id,
            selected=None,
            alternatives=[],
            ambiguous=True,
            llm_needed=True,
        )

    scored = sorted(
        (_build_candidate(invoice_line, term) for term in candidates),
        key=lambda candidate: candidate.confidence,
        reverse=True,
    )

    top = scored[0]
    second = scored[1] if len(scored) > 1 else None
    near_tie = second is not None and abs(top.confidence - second.confidence) <= AMBIGUITY_DELTA

    if top.confidence < LOW_CONFIDENCE_THRESHOLD:
        return MatchResult(
            invoice_line_id=invoice_line_id,
            selected=None,
            alternatives=scored,
            ambiguous=True,
            llm_needed=True,
        )

    return MatchResult(
        invoice_line_id=invoice_line_id,
        selected=top,
        alternatives=scored[1:],
        ambiguous=near_tie,
        llm_needed=near_tie,
    )
