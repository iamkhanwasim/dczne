from __future__ import annotations

import math
import re
from typing import List

from models.contract_models import ChargeTerm
from models.invoice_models import InvoiceLine


def _normalize_text(value: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", value.lower())).strip()


def _tokens(value: str) -> List[str]:
    normalized = _normalize_text(value)
    if not normalized:
        return []
    return normalized.split(" ")


def token_overlap_similarity(a: str, b: str) -> float:
    ta = set(_tokens(a))
    tb = set(_tokens(b))
    if not ta or not tb:
        return 0.0
    intersection = len(ta & tb)
    union = len(ta | tb)
    return intersection / union if union else 0.0


def _jaro_similarity(a: str, b: str) -> float:
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0

    len_a = len(a)
    len_b = len(b)
    match_distance = max(len_a, len_b) // 2 - 1

    a_matches = [False] * len_a
    b_matches = [False] * len_b

    matches = 0
    transpositions = 0

    for i in range(len_a):
        start = max(0, i - match_distance)
        end = min(i + match_distance + 1, len_b)
        for j in range(start, end):
            if b_matches[j] or a[i] != b[j]:
                continue
            a_matches[i] = True
            b_matches[j] = True
            matches += 1
            break

    if matches == 0:
        return 0.0

    k = 0
    for i in range(len_a):
        if not a_matches[i]:
            continue
        while not b_matches[k]:
            k += 1
        if a[i] != b[k]:
            transpositions += 1
        k += 1

    return (
        (matches / len_a)
        + (matches / len_b)
        + ((matches - transpositions / 2) / matches)
    ) / 3.0


def jaro_winkler_similarity(a: str, b: str, prefix_scale: float = 0.1) -> float:
    norm_a = _normalize_text(a)
    norm_b = _normalize_text(b)
    base = _jaro_similarity(norm_a, norm_b)

    prefix_length = 0
    for ch_a, ch_b in zip(norm_a, norm_b):
        if ch_a == ch_b:
            prefix_length += 1
        else:
            break
        if prefix_length == 4:
            break

    return min(1.0, base + prefix_length * prefix_scale * (1.0 - base))


def _normalize_unit(unit: str) -> str:
    norm = _normalize_text(unit)
    aliases = {
        "hr": "hour",
        "hrs": "hour",
        "hours": "hour",
        "mo": "month",
        "months": "month",
        "yr": "year",
        "yrs": "year",
        "years": "year",
        "ea": "each",
    }
    return aliases.get(norm, norm)


def unit_match(invoice_unit: str, contract_unit: str) -> bool:
    return _normalize_unit(invoice_unit) == _normalize_unit(contract_unit)


def rate_proximity(invoice_rate: float, contract_rate: float) -> float:
    if invoice_rate <= 0 or contract_rate <= 0:
        return 0.0
    relative_diff = abs(invoice_rate - contract_rate) / max(abs(invoice_rate), abs(contract_rate))
    return max(0.0, 1.0 - relative_diff)


def score_line_to_term(invoice_line: InvoiceLine, term: ChargeTerm) -> tuple[float, float, bool, float]:
    name_jw = jaro_winkler_similarity(invoice_line.description, term.name)
    name_overlap = token_overlap_similarity(invoice_line.description, term.name)
    name_score = max(name_jw, name_overlap)

    description_norm = _normalize_text(invoice_line.description)
    term_norm = _normalize_text(term.name)
    if term_norm and term_norm in description_norm:
        name_score = max(name_score, 0.95)

    is_unit_match = unit_match(invoice_line.unit, term.rate_unit)
    unit_score = 1.0 if is_unit_match else 0.0

    rate_score = rate_proximity(invoice_line.unit_rate, term.rate)

    weighted = (name_score * 0.55) + (unit_score * 0.25) + (rate_score * 0.20)

    if term.charge_type.value == "FIXED_RATE" and math.isclose(invoice_line.quantity, 1.0):
        weighted = min(1.0, weighted + 0.03)

    return round(weighted, 4), round(name_score, 4), is_unit_match, round(rate_score, 4)
