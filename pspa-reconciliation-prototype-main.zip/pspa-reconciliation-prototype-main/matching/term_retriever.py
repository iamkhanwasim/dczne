from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

from graph.graph_repository import GraphRepository, Triple
from graph.ontology_schema import Props
from graph.prefixes import INSTANCE_BASE, uri_for
from models.contract_models import ChargeTerm, ChargeType, SourceCitation
from utils.errors import ContractNotFoundError


def _literal_value(obj: Any) -> Optional[str]:
    if obj is None:
        return None
    if isinstance(obj, tuple):
        return str(obj[0])
    return str(obj)


def _literal_values(triples: List[Triple], predicate: str) -> List[str]:
    values: List[str] = []
    for _, p, o in triples:
        if p == predicate:
            value = _literal_value(o)
            if value is not None:
                values.append(value)
    return values


def _literal_first(triples: List[Triple], predicate: str) -> Optional[str]:
    values = _literal_values(triples, predicate)
    return values[0] if values else None


def _parse_date(value: Optional[str]) -> Optional[date]:
    if not value:
        return None
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None


def _parse_float(value: Optional[str], default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _parse_bool(value: Optional[str], default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes"}


def _local_id(subject_uri: str) -> str:
    if subject_uri.startswith(INSTANCE_BASE):
        return subject_uri[len(INSTANCE_BASE):]
    if "/" in subject_uri:
        return subject_uri.rsplit("/", 1)[-1]
    return subject_uri


def _charge_type(value: Optional[str]) -> ChargeType:
    if not value:
        return ChargeType.FIXED_RATE
    try:
        return ChargeType(value)
    except ValueError:
        return ChargeType.FIXED_RATE


def _matches_location(scope_values: List[str], location: str) -> bool:
    if not scope_values:
        return True
    requested = location.lower()
    return any(requested in value.lower() or value.lower() in requested for value in scope_values)


def _charge_term_from_triples(
    term_uri: str,
    triples: List[Triple],
    fallback_contract_id: str,
) -> ChargeTerm:
    name = _literal_first(triples, Props.name) or _local_id(term_uri)
    charge_type = _charge_type(_literal_first(triples, Props.chargeType))
    source_document = _literal_first(triples, Props.sourceDocument)
    source_page = _literal_first(triples, Props.sourcePage)

    source: Optional[SourceCitation] = None
    if source_document:
        source = SourceCitation(
            document_id=source_document,
            page=int(source_page) if source_page and source_page.isdigit() else None,
            section=_literal_first(triples, Props.sourceSection),
            span_text=_literal_first(triples, Props.spanText),
        )

    return ChargeTerm(
        id=_local_id(term_uri),
        vendor_relationship_id=(
            _local_id(_literal_first(triples, Props.vendorRelationship) or "")
            or fallback_contract_id
        ),
        name=name,
        service_scope=_literal_first(triples, Props.serviceScope) or "",
        charge_type=charge_type,
        rate=_parse_float(_literal_first(triples, Props.rate), default=0.0),
        rate_unit=_literal_first(triples, Props.rateUnit) or "unit",
        rate_currency=_literal_first(triples, Props.rateCurrency) or "USD",
        billing_interval=_literal_first(triples, Props.billingInterval) or "",
        invoice_cadence=_literal_first(triples, Props.invoiceCadence) or "",
        location_scope=_literal_values(triples, Props.locationScope),
        effective_date=_parse_date(_literal_first(triples, Props.effectiveDate)),
        renewal_date=_parse_date(_literal_first(triples, Props.renewalDate)),
        preconditions=_literal_values(triples, Props.precondition),
        is_passthrough=_parse_bool(_literal_first(triples, Props.passthrough)),
        requires_cost_evidence=_parse_bool(_literal_first(triples, Props.requiresCostEvidence)),
        extraction_confidence=_parse_float(
            _literal_first(triples, Props.extractionConfidence),
            default=1.0,
        ),
        extraction_notes=_literal_first(triples, Props.extractionNotes) or "",
        source=source,
    )


def retrieve_terms_for_contract(
    contract_id: str,
    invoice_date: date,
    graph_repo: GraphRepository,
    location: Optional[str] = None,
) -> List[ChargeTerm]:
    """
    Retrieve active charge terms for a known contract ID and invoice date.
    """
    contract_uri = uri_for(contract_id)
    if not graph_repo.subject_exists(contract_uri):
        raise ContractNotFoundError(contract_id)

    term_uris = graph_repo.query_charge_terms_for_contract(contract_id=contract_id, on_date=invoice_date)
    terms: List[ChargeTerm] = []
    for term_uri in term_uris:
        triples = graph_repo.query_by_subject(term_uri)
        if not triples:
            continue
        term = _charge_term_from_triples(term_uri, triples, fallback_contract_id=contract_id)
        if location and not _matches_location(term.location_scope, location):
            continue
        terms.append(term)

    terms.sort(key=lambda term: term.id)
    return terms
