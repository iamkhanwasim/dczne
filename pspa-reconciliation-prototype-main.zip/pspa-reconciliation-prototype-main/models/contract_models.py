"""
Domain models for service contracts.

These are the canonical Python representations of contract data.
They are produced by the contract extraction pipeline and persisted
as RDF triples in the graph store.

All models use Pydantic v2 for validation and serialization.
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ChargeType(str, Enum):
    """Type of billable charge term. Drives which validators are applied."""

    FIXED_RATE = "FIXED_RATE"
    """Fixed recurring amount regardless of usage (e.g., $2,500/month flat fee)."""

    VARIABLE_RATE = "VARIABLE_RATE"
    """Rate × quantity billing; quantity varies per invoice (e.g., $150/hour)."""

    PASS_THROUGH = "PASS_THROUGH"
    """Vendor passes actual cost to customer; requires cost evidence (receipt/invoice)."""

    CONTINGENCY = "CONTINGENCY"
    """Percentage of realized recovery or outcome (e.g., 20% of recovered reimbursement)."""

    SUBSCRIPTION = "SUBSCRIPTION"
    """Recurring subscription with defined included services and optional overages."""

    OVERAGE = "OVERAGE"
    """Charge triggered when usage exceeds a base included quantity."""

    EVENT = "EVENT"
    """Per-occurrence charge triggered by a specific event (e.g., spring cleanup)."""

    TIME_AND_MATERIALS = "TIME_AND_MATERIALS"
    """Labor + materials billed at actual cost with separate labor categories."""


class DocumentType(str, Enum):
    """Type of contract document."""

    MSA = "Master Service Agreement"
    SOW = "Statement of Work"
    AMENDMENT = "Amendment"
    CHANGE_ORDER = "Change Order"
    LOA = "Letter of Agreement"
    ADDENDUM = "Addendum"
    OTHER = "Other"


# ---------------------------------------------------------------------------
# Supporting models
# ---------------------------------------------------------------------------


class EffectivePeriod(BaseModel):
    """Date range for which a charge term or contract is valid."""

    start: date
    end: date

    @model_validator(mode="after")
    def end_after_start(self) -> "EffectivePeriod":
        if self.end <= self.start:
            raise ValueError(f"end ({self.end}) must be after start ({self.start})")
        return self


class InclusionExclusions(BaseModel):
    """What is and is not included in a charge term's scope."""

    included: List[str] = Field(default_factory=list)
    excluded: List[str] = Field(default_factory=list)


class SourceCitation(BaseModel):
    """Reference back to the exact location in the source contract document."""

    document_id: str
    document_type: str = ""
    page: Optional[int] = None
    section: Optional[str] = None
    line_reference: Optional[str] = None
    span_text: Optional[str] = None
    """Optional verbatim excerpt from the contract that supports this term."""


# ---------------------------------------------------------------------------
# Core models
# ---------------------------------------------------------------------------


class Location(BaseModel):
    """A named service location."""

    id: str
    name: str
    address: Optional[str] = None
    notes: Optional[str] = None


class ChargeTerm(BaseModel):
    """
    A single billable service or fee defined in a contract.

    This is the central object the reconciliation engine validates against.
    Every invoice line is matched to a ChargeTerm and then validated using
    the validators appropriate for the ChargeTerm's charge_type.
    """

    id: str
    """Unique identifier, e.g. 'abc-std-cleaning-2025'. Used as RDF subject URI."""

    vendor_relationship_id: str
    """ID of the VendorRelationship this term belongs to."""

    name: str
    """Human-readable name from the contract (e.g. 'Standard Cleaning')."""

    service_scope: str = ""
    """Plain-language description of what service is being provided."""

    charge_type: ChargeType
    """Drives which validators are applied during reconciliation."""

    rate: float
    """Contract rate (dollar amount per rate_unit)."""

    rate_unit: str
    """Unit for the rate: 'month', 'hour', 'event', 'year', etc."""

    rate_currency: str = "USD"
    """ISO 4217 currency code."""

    billing_interval: str = ""
    """Frequency: 'monthly', 'quarterly', 'per occurrence', 'annually', etc."""

    invoice_cadence: str = ""
    """When invoices are issued: e.g. '15th of month for following month'."""

    location_scope: List[str] = Field(default_factory=list)
    """Location names this term applies to. Empty list means all locations."""

    effective_period: Optional[EffectivePeriod] = None
    """Date range this term is active. Derived from contract effective/renewal dates if not set."""

    effective_date: Optional[date] = None
    """Explicit effective date; used when effective_period is not set."""

    renewal_date: Optional[date] = None
    """Explicit renewal/expiration date; used when effective_period is not set."""

    preconditions: List[str] = Field(default_factory=list)
    """Conditions that must be met before this charge is valid.
    E.g. ['PO required', 'written approval required']."""

    is_passthrough: bool = False
    """True if this charge passes actual vendor cost to customer."""

    requires_cost_evidence: bool = False
    """True if supporting cost documentation (receipt, quote) must be provided."""

    inclusion_exclusions: Optional[InclusionExclusions] = None
    """What services are included and excluded from the scope."""

    max_amount: Optional[float] = None
    """If set, invoiced amount must not exceed this cap (e.g., pass-through ceiling)."""

    overage_rate: Optional[float] = None
    """For SUBSCRIPTION/OVERAGE types: the per-unit rate beyond the base included quantity."""

    included_quantity: Optional[float] = None
    """For SUBSCRIPTION/OVERAGE: quantity included in the base rate before overages apply."""

    contingency_pct: Optional[float] = None
    """For CONTINGENCY type: percentage of recovery basis (0.0–1.0)."""

    source: Optional[SourceCitation] = None
    """Where in the document this term was extracted from."""

    extraction_confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    """Confidence score from the LLM extraction agent (0.0–1.0)."""

    extraction_notes: str = ""
    """Free-text notes from the extraction agent about ambiguities or caveats."""

    def is_active_on(self, check_date: date) -> bool:
        """Return True if this charge term is active on the given date."""
        if self.effective_period:
            return self.effective_period.start <= check_date <= self.effective_period.end
        if self.effective_date and self.renewal_date:
            return self.effective_date <= check_date <= self.renewal_date
        # No period information — assume active
        return True

    def get_effective_start(self) -> Optional[date]:
        if self.effective_period:
            return self.effective_period.start
        return self.effective_date

    def get_effective_end(self) -> Optional[date]:
        if self.effective_period:
            return self.effective_period.end
        return self.renewal_date


class Amendment(BaseModel):
    """
    A contract amendment that modifies one or more charge terms.

    Amendments take precedence over the base contract for the modified terms.
    """

    id: str
    base_contract_id: str
    amendment_number: int = 1
    effective_date: date
    document_type: DocumentType = DocumentType.AMENDMENT
    modified_terms: List[ChargeTerm] = Field(default_factory=list)
    """Charge terms as they appear in this amendment (override base contract terms)."""
    notes: str = ""
    source: Optional[SourceCitation] = None


class ContractDocument(BaseModel):
    """
    Metadata for a single contract document (MSA, SOW, amendment, etc.).

    A VendorRelationship may have multiple ContractDocuments (e.g., base MSA + amendments).
    """

    id: str
    vendor_id: str
    vendor_name: str
    customer_id: str
    customer_name: str
    document_type: DocumentType
    effective_date: Optional[date] = None
    renewal_date: Optional[date] = None
    amendment_date: Optional[date] = None
    amendment_number: Optional[int] = None
    base_contract_id: Optional[str] = None
    """For amendments: the ID of the contract this amends."""
    markdown_text: str = ""
    """Full document text (already OCR'd / extracted, passed to LLM)."""
    page_count: Optional[int] = None
    source_path: str = ""
    """Original file path."""


class VendorRelationship(BaseModel):
    """
    The top-level entity representing the relationship between a vendor and customer
    under one or more contracts.

    All charge terms belong to a VendorRelationship. This is the entry point for
    reconciling invoices from a vendor.
    """

    id: str
    """Unique ID, e.g. 'abc-cleaning-uh-2025'. Used as RDF subject URI."""

    vendor_id: str
    vendor_name: str
    customer_id: str
    customer_name: str

    effective_date: Optional[date] = None
    renewal_date: Optional[date] = None

    charge_terms: List[ChargeTerm] = Field(default_factory=list)
    """All active charge terms extracted from the contract documents."""

    amendments: List[Amendment] = Field(default_factory=list)
    """Amendments; their modified_terms take precedence over base charge_terms."""

    documents: List[ContractDocument] = Field(default_factory=list)
    """All source documents (MSA, SOW, amendments) that make up this relationship."""

    status: str = "draft"
    """'draft' | 'indexed' | 'finalized'. Must be 'finalized' before invoices can be reconciled."""

    def get_active_terms(self, on_date: date) -> List[ChargeTerm]:
        """
        Return all charge terms active on the given date, with amendment terms
        taking precedence over base contract terms.
        """
        # Start with base terms active on the date
        base = {t.id: t for t in self.charge_terms if t.is_active_on(on_date)}

        # Apply amendments in order (later amendments take precedence)
        for amendment in sorted(self.amendments, key=lambda a: a.amendment_number):
            if amendment.effective_date <= on_date:
                for term in amendment.modified_terms:
                    if term.is_active_on(on_date):
                        base[term.id] = term

        return list(base.values())
