"""
Domain models for reconciliation findings.

A Finding is the output of running validators against an invoice line.
ValidationResult is the output of a single validator function.
InvoiceFinding aggregates line findings for a whole invoice.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class FindingStatus(str, Enum):
    """
    Status of a reconciliation finding.

    - PASS: all validators passed; line can be approved.
    - REJECT: one or more validators failed with hard failures; line must be disputed.
    - NEEDS_REVIEW: ambiguous or conditional; human review required before approval.
    - NO_MATCH: no contract charge term could be matched to this line.
    - SKIPPED: line was explicitly skipped (e.g., a total-row line item).
    """

    PASS = "PASS"
    REJECT = "REJECT"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    NO_MATCH = "NO_MATCH"
    SKIPPED = "SKIPPED"


class RoutingPath(str, Enum):
    """Which routing path was taken for this line."""

    FAST_PATH = "fast_path"
    DEEP_PATH = "deep_path"


# ---------------------------------------------------------------------------
# Validator result
# ---------------------------------------------------------------------------


class ValidationResult(BaseModel):
    """
    Output of a single deterministic validator function.

    Validators are pure functions — they never call the LLM.
    Each validator runs one specific check (e.g., 'does amount match rate × qty?').
    """

    validator_name: str
    """Name of the validator function that produced this result."""

    passed: bool
    """True if the check passed (no violation found)."""

    expected: Optional[Any] = None
    """Expected value per contract (e.g., expected_amount=450.00)."""

    actual: Optional[Any] = None
    """Actual value from invoice (e.g., actual_amount=525.00)."""

    variance: Optional[float] = None
    """Numeric difference (actual - expected). Positive = overbilled."""

    variance_pct: Optional[float] = None
    """Percentage variance = variance / expected × 100."""

    reason: str = ""
    """Human-readable explanation of the result."""

    severity: str = "error"
    """'error' | 'warning' | 'info'. Errors cause REJECT; warnings cause NEEDS_REVIEW."""

    @classmethod
    def pass_result(cls, validator_name: str, reason: str = "") -> "ValidationResult":
        return cls(validator_name=validator_name, passed=True, reason=reason, severity="info")

    @classmethod
    def fail_result(
        cls,
        validator_name: str,
        reason: str,
        expected: Any = None,
        actual: Any = None,
        variance: Optional[float] = None,
        severity: str = "error",
    ) -> "ValidationResult":
        variance_pct: Optional[float] = None
        if variance is not None and expected is not None and float(expected) != 0:
            variance_pct = round(variance / float(expected) * 100, 2)
        return cls(
            validator_name=validator_name,
            passed=False,
            reason=reason,
            expected=expected,
            actual=actual,
            variance=variance,
            variance_pct=variance_pct,
            severity=severity,
        )


# ---------------------------------------------------------------------------
# Line finding
# ---------------------------------------------------------------------------


class Finding(BaseModel):
    """
    Reconciliation finding for a single invoice line.

    Produced by the finding generator after matching + validation.
    """

    invoice_id: str
    line_number: int

    description: str
    """Invoice line description (copied for readability)."""

    status: FindingStatus

    matched_charge_term_id: Optional[str] = None
    """ID of the contract charge term this line was matched to."""

    matched_charge_term_name: Optional[str] = None

    matching_confidence: float = 0.0
    """Confidence score from the matching engine (0.0–1.0)."""

    routing_path: RoutingPath = RoutingPath.DEEP_PATH
    """Whether this line was handled by the fast or deep path."""

    llm_resolved: bool = False
    """True if the LLM was called to resolve matching ambiguity."""

    amount_invoiced: float = 0.0
    amount_expected: float = 0.0
    variance: float = 0.0

    validators_run: List[str] = Field(default_factory=list)
    """Names of validators that were executed."""

    validator_results: Dict[str, ValidationResult] = Field(default_factory=dict)
    """Keyed by validator_name."""

    source_evidence: str = ""
    """Citation: 'MSA page 2, section 3.2' etc."""

    recommended_action: Optional[str] = None
    """Human-readable recommended next step."""

    audit_trail_id: Optional[str] = None
    """ID linking to the detailed audit log for this finding."""

    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def failed_validators(self) -> List[str]:
        return [name for name, r in self.validator_results.items() if not r.passed]

    @property
    def has_errors(self) -> bool:
        return any(
            not r.passed and r.severity == "error"
            for r in self.validator_results.values()
        )

    @property
    def has_warnings(self) -> bool:
        return any(
            not r.passed and r.severity == "warning"
            for r in self.validator_results.values()
        )


# ---------------------------------------------------------------------------
# Invoice-level finding
# ---------------------------------------------------------------------------


class InvoiceFinding(BaseModel):
    """
    Aggregated reconciliation result for an entire invoice.

    Contains a Finding for every line, plus invoice-level summary.
    """

    invoice_id: str
    contract_id: str
    overall_status: FindingStatus

    total_invoiced: float = 0.0
    total_expected: float = 0.0
    total_variance: float = 0.0

    line_findings: List[Finding] = Field(default_factory=list)

    tax_finding: Optional[ValidationResult] = None
    """Result of the invoice-level tax arithmetic check."""

    audit_trail_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def compute_overall_status(cls, line_findings: List[Finding]) -> FindingStatus:
        """Derive invoice-level status from line statuses."""
        statuses = {f.status for f in line_findings}
        if FindingStatus.NO_MATCH in statuses:
            return FindingStatus.NEEDS_REVIEW
        if FindingStatus.REJECT in statuses:
            return FindingStatus.REJECT
        if FindingStatus.NEEDS_REVIEW in statuses:
            return FindingStatus.NEEDS_REVIEW
        return FindingStatus.PASS
