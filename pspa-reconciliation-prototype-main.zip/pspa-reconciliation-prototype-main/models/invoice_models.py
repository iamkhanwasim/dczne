"""
Domain models for invoices.

These represent a vendor invoice after it has been parsed from markdown or YAML.
They are the input to the reconciliation / matching / validation pipeline.
"""

from __future__ import annotations

from datetime import date
from typing import List, Optional

from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Supporting models
# ---------------------------------------------------------------------------


class SupportingDocRef(BaseModel):
    """
    Reference to a supporting document provided with the invoice.

    Supporting documents satisfy preconditions (e.g., PO for after-hours work)
    and provide cost evidence for pass-through charges (e.g., receipts).
    """

    doc_type: str
    """Type: 'PO', 'receipt', 'work_order', 'quote', 'approval', etc."""

    reference: str
    """Reference number or identifier (e.g., 'PO#1042', 'Receipt #RS-2025-01-019')."""

    amount: Optional[float] = None
    """Dollar amount on the document, if applicable (useful for pass-through evidence)."""

    date: Optional[date] = None
    """Date of the supporting document."""

    notes: str = ""


# ---------------------------------------------------------------------------
# Core models
# ---------------------------------------------------------------------------


class InvoiceLine(BaseModel):
    """A single line item on an invoice."""

    line_number: int
    """1-based line number as it appears on the invoice."""

    description: str
    """Service description exactly as written on the invoice."""

    quantity: float
    """Quantity billed (e.g., 1 month, 3 hours)."""

    unit: str
    """Unit of measure (e.g., 'month', 'hour', 'event')."""

    unit_rate: float
    """Rate per unit as invoiced."""

    line_amount: float
    """Total for this line (should equal quantity × unit_rate)."""

    service_date: Optional[date] = None
    """Date the service was performed (for per-occurrence charges)."""

    service_period_start: Optional[date] = None
    service_period_end: Optional[date] = None
    """For period-based charges: the range of service covered by this line."""

    supporting_docs: List[SupportingDocRef] = Field(default_factory=list)
    """Supporting documents attached to this line (POs, receipts, work orders)."""

    notes: str = ""
    """Any notes or comments on the line as parsed from the invoice."""

    @model_validator(mode="after")
    def amount_is_positive(self) -> "InvoiceLine":
        if self.line_amount < 0:
            raise ValueError(f"Line {self.line_number}: line_amount must not be negative")
        return self

    def expected_amount(self, contract_rate: float) -> float:
        """Return the expected amount based on the contract rate and this line's quantity."""
        return round(contract_rate * self.quantity, 2)


class Invoice(BaseModel):
    """
    A parsed vendor invoice ready for reconciliation.

    One Invoice corresponds to one POST /invoices/reconcile request.
    """

    invoice_id: str
    """Unique invoice identifier as printed on the invoice."""

    vendor_id: str
    vendor_name: str
    customer_name: str

    invoice_date: date
    """The date the invoice was issued."""

    service_period_start: Optional[date] = None
    service_period_end: Optional[date] = None
    """Period covered by this invoice."""

    due_date: Optional[date] = None

    contract_id: str
    """ID of the VendorRelationship (contract) this invoice is being reconciled against."""

    lines: List[InvoiceLine] = Field(default_factory=list, min_length=1)

    subtotal: float = 0.0
    tax_rate: Optional[float] = None
    tax_amount: float = 0.0
    total: float = 0.0

    raw_text: str = ""
    """Original invoice markdown/YAML text, preserved for audit purposes."""

    source_path: str = ""

    @model_validator(mode="after")
    def total_is_consistent(self) -> "Invoice":
        """Warn (not error) if subtotal + tax_amount doesn't match total within $0.02."""
        computed = round(self.subtotal + self.tax_amount, 2)
        if self.total > 0 and abs(computed - self.total) > 0.02:
            # We allow this — arithmetic errors on the invoice are themselves a finding.
            pass
        return self
