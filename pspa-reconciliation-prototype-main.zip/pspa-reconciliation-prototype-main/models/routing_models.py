"""
Domain models for matching and routing decisions.

These are intermediate objects produced by the matching engine and routing engine.
They are not persisted to the graph directly, but are logged in the audit trail.
"""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Field

from models.contract_models import ChargeTerm
from models.finding_models import RoutingPath


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------


class MatchCandidate(BaseModel):
    """
    A single candidate match: one contract ChargeTerm that could correspond
    to an invoice line, with a confidence score.
    """

    charge_term: ChargeTerm
    confidence: float = Field(ge=0.0, le=1.0)
    """Overall match confidence (0.0–1.0). Composed from name, unit, rate, and other signals."""

    name_similarity: float = 0.0
    """Component: text similarity between invoice line description and term name."""

    unit_match: bool = False
    """Component: True if invoice unit matches term rate_unit."""

    rate_proximity: float = 0.0
    """Component: how close the invoice rate is to the contract rate (0.0–1.0)."""

    date_in_range: bool = True
    """Component: True if the invoice date is within the term's effective period."""

    reason: str = ""
    """Human-readable explanation of the confidence score."""


class MatchResult(BaseModel):
    """
    The outcome of matching one invoice line against all candidates.

    'selected' is the best match (or None if no match found).
    'alternatives' are other candidates that were considered.
    """

    invoice_line_id: str
    selected: Optional[MatchCandidate] = None
    alternatives: List[MatchCandidate] = Field(default_factory=list)
    ambiguous: bool = False
    """True if multiple candidates had similar confidence (within 0.1 of each other)."""
    llm_needed: bool = False
    """True if the LLM should be called to resolve ambiguity."""
    llm_call_id: Optional[str] = None
    """Set after LLM is called, links to the audit log entry."""

    @property
    def is_matched(self) -> bool:
        return self.selected is not None

    @property
    def confidence(self) -> float:
        return self.selected.confidence if self.selected else 0.0


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------


class RoutingDecision(BaseModel):
    """
    Decision produced by the routing engine for one invoice line.

    Determines whether to use the fast path (cached outcome) or deep path
    (full matching + validation pipeline).
    """

    invoice_line_id: str
    route: RoutingPath
    fast_path_hit: bool = False
    """True if a valid fast-path cache entry was found."""

    cached_charge_term_id: Optional[str] = None
    """If fast_path_hit: the charge term ID from the cache."""

    cache_age_days: Optional[int] = None
    """If fast_path_hit: how old the cache entry is."""

    match_result: Optional[MatchResult] = None
    """If deep path: the result from the matching engine."""

    validators_to_run: List[str] = Field(default_factory=list)
    """Names of validator functions to execute for this line."""

    decided_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ValidationOutcome(BaseModel):
    """
    Complete validation outcome for one invoice line:
    the routing decision + all validator results.

    Used internally by the invoice processor to aggregate results
    before generating a Finding.
    """

    invoice_line_id: str
    routing_decision: RoutingDecision
    validator_results: List["ValidationResultRef"] = Field(default_factory=list)
    """All validator results for this line, in execution order."""


class ValidationResultRef(BaseModel):
    """Lightweight reference pairing a validator name with its result."""

    validator_name: str
    passed: bool
    severity: str = "error"
    reason: str = ""
