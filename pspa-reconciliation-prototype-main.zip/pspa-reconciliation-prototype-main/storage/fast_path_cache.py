from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple


@dataclass
class CacheEntry:
    charge_term_id: str
    validators_to_run: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def age_days(self) -> int:
        return max(0, (datetime.now(timezone.utc) - self.created_at).days)


class FastPathCache:
    """Simple in-memory fast-path cache keyed by contract and normalized description."""

    def __init__(self, ttl_days: int = 30) -> None:
        self.ttl_days = ttl_days
        self._entries: Dict[Tuple[str, str], CacheEntry] = {}

    @staticmethod
    def normalize_description(description: str) -> str:
        return " ".join(description.lower().split())

    def _key(self, contract_id: str, description: str) -> Tuple[str, str]:
        return contract_id, self.normalize_description(description)

    def get(self, contract_id: str, description: str) -> Optional[CacheEntry]:
        key = self._key(contract_id, description)
        entry = self._entries.get(key)
        if entry is None:
            return None
        if entry.age_days() > self.ttl_days:
            self._entries.pop(key, None)
            return None
        return entry

    def set(
        self,
        contract_id: str,
        description: str,
        charge_term_id: str,
        validators_to_run: Optional[List[str]] = None,
    ) -> None:
        self._entries[self._key(contract_id, description)] = CacheEntry(
            charge_term_id=charge_term_id,
            validators_to_run=list(validators_to_run or []),
        )

    def invalidate_contract(self, contract_id: str) -> None:
        stale_keys = [key for key in self._entries if key[0] == contract_id]
        for key in stale_keys:
            self._entries.pop(key, None)

    def clear(self) -> None:
        self._entries.clear()

    def size(self) -> int:
        return len(self._entries)

    def force_age(self, contract_id: str, description: str, days: int) -> None:
        key = self._key(contract_id, description)
        if key in self._entries:
            self._entries[key].created_at = datetime.now(timezone.utc) - timedelta(days=days)
