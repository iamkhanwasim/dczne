"""
pytest configuration and shared fixtures for the reconciliation service test suite.

All fixture paths are relative to this conftest.py file.
"""

import json
import os
import pytest
from pathlib import Path

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

FIXTURES_DIR = Path(__file__).parent / "fixtures"


def _load_env_file() -> None:
    root = Path(__file__).resolve().parents[1]
    env_path = root / ".env"
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue

        if not (value.startswith('"') or value.startswith("'")) and "#" in value:
            value = value.split("#", 1)[0].rstrip()

        if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
            value = value[1:-1]

        os.environ.setdefault(key, value)


_load_env_file()


def load_fixture_text(filename: str) -> str:
    """Return the raw text of a fixture file."""
    return (FIXTURES_DIR / filename).read_text(encoding="utf-8")


def load_fixture_json(filename: str) -> dict:
    """Return parsed JSON of a fixture file."""
    return json.loads((FIXTURES_DIR / filename).read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# Contract text fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def abc_cleaning_contract_text() -> str:
    """Raw markdown text of the ABC Cleaning MSA."""
    return load_fixture_text("abc_cleaning_contract.md")


@pytest.fixture
def abc_cleaning_contract_amended_text() -> str:
    """Raw markdown text of the ABC Cleaning Amendment No. 1."""
    return load_fixture_text("abc_cleaning_contract_amended.md")


@pytest.fixture
def greentech_contract_text() -> str:
    """Raw markdown text of the GreenTech Landscape agreement."""
    return load_fixture_text("greentech_landscape_contract.md")


# ---------------------------------------------------------------------------
# Invoice text fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def abc_invoice_pass_text() -> str:
    """Raw markdown text of invoice where all lines should PASS."""
    return load_fixture_text("abc_cleaning_invoice_pass.md")


@pytest.fixture
def abc_invoice_variance_text() -> str:
    """Raw markdown text of invoice with a rate variance on line 2."""
    return load_fixture_text("abc_cleaning_invoice_variance.md")


@pytest.fixture
def abc_invoice_missing_docs_text() -> str:
    """Raw markdown text of invoice missing supporting documentation."""
    return load_fixture_text("abc_cleaning_invoice_missing_docs.md")


@pytest.fixture
def abc_invoice_ambiguous_text() -> str:
    """Raw markdown text of invoice with an ambiguous line description."""
    return load_fixture_text("abc_cleaning_invoice_ambiguous.md")


@pytest.fixture
def greentech_invoice_pass_text() -> str:
    """Raw markdown text of a GreenTech invoice that should fully pass."""
    return load_fixture_text("greentech_invoice_pass.md")


# ---------------------------------------------------------------------------
# Expected findings fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def expected_findings_pass() -> dict:
    """Expected findings output for the all-pass ABC invoice."""
    return load_fixture_json("expected_findings_pass.json")


@pytest.fixture
def expected_findings_variance() -> dict:
    """Expected findings output for the variance ABC invoice."""
    return load_fixture_json("expected_findings_variance.json")


# ---------------------------------------------------------------------------
# Contract metadata dicts (parsed from fixture frontmatter)
# ---------------------------------------------------------------------------

@pytest.fixture
def abc_cleaning_contract_meta() -> dict:
    return {
        "contract_id": "abc-cleaning-uh-2025",
        "vendor_id": "abc-cleaning",
        "vendor_name": "ABC Cleaning Services",
        "customer_name": "UHS",
        "customer_id": "uhs",
        "effective_date": "2025-01-01",
        "renewal_date": "2026-01-01",
        "document_type": "Master Service Agreement",
    }


@pytest.fixture
def greentech_contract_meta() -> dict:
    return {
        "contract_id": "greentech-landscape-uh-2025",
        "vendor_id": "greentech-landscape",
        "vendor_name": "GreenTech Landscape Services",
        "customer_name": "UHS",
        "customer_id": "uhs",
        "effective_date": "2025-03-01",
        "renewal_date": "2026-03-01",
        "document_type": "Service Agreement",
    }
