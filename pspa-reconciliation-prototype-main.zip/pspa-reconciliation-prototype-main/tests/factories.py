"""
Test object factories.

These functions create Pydantic domain model instances for use in tests.
They set sensible defaults so tests only need to specify what they care about.

Usage:
    term = make_charge_term(name="Custom Term", rate=500.00)
    invoice = make_invoice(lines=[make_invoice_line(description="Foo")])
"""

from __future__ import annotations

from datetime import date
from typing import List, Optional

from models.contract_models import (
    ChargeType,
    ChargeTerm,
    SourceCitation,
    VendorRelationship,
)
from models.invoice_models import Invoice, InvoiceLine, SupportingDocRef


# ---------------------------------------------------------------------------
# Contract factories
# ---------------------------------------------------------------------------


def make_vendor_relationship(
    *,
    id: str = "test-vendor-uh-2025",
    vendor_id: str = "test-vendor",
    vendor_name: str = "Test Vendor Inc.",
    customer_id: str = "uhs",
    customer_name: str = "UHS",
    effective_date: date = date(2025, 1, 1),
    renewal_date: date = date(2026, 1, 1),
    charge_terms: Optional[List[ChargeTerm]] = None,
) -> VendorRelationship:
    """Create a VendorRelationship with sensible defaults."""
    return VendorRelationship(
        id=id,
        vendor_id=vendor_id,
        vendor_name=vendor_name,
        customer_id=customer_id,
        customer_name=customer_name,
        effective_date=effective_date,
        renewal_date=renewal_date,
        charge_terms=charge_terms or [],
    )


def make_charge_term(
    *,
    id: str = "test-term-001",
    vendor_relationship_id: str = "test-vendor-uh-2025",
    name: str = "Test Service",
    charge_type: ChargeType = ChargeType.FIXED_RATE,
    rate: float = 1000.00,
    rate_unit: str = "month",
    rate_currency: str = "USD",
    billing_interval: str = "monthly",
    location_scope: Optional[List[str]] = None,
    effective_date: date = date(2025, 1, 1),
    renewal_date: date = date(2026, 1, 1),
    preconditions: Optional[List[str]] = None,
    is_passthrough: bool = False,
    requires_cost_evidence: bool = False,
    extraction_confidence: float = 0.95,
    source_document_id: str = "test-contract",
    source_page: int = 1,
    source_section: str = "Pricing",
) -> ChargeTerm:
    """Create a ChargeTerm with sensible defaults."""
    return ChargeTerm(
        id=id,
        vendor_relationship_id=vendor_relationship_id,
        name=name,
        charge_type=charge_type,
        rate=rate,
        rate_unit=rate_unit,
        rate_currency=rate_currency,
        billing_interval=billing_interval,
        location_scope=location_scope or [],
        effective_date=effective_date,
        renewal_date=renewal_date,
        preconditions=preconditions or [],
        is_passthrough=is_passthrough,
        requires_cost_evidence=requires_cost_evidence,
        extraction_confidence=extraction_confidence,
        source=SourceCitation(
            document_id=source_document_id,
            document_type="MSA",
            page=source_page,
            section=source_section,
        ),
    )


# ---------------------------------------------------------------------------
# Invoice factories
# ---------------------------------------------------------------------------


def make_supporting_doc(
    *,
    doc_type: str = "PO",
    reference: str = "PO#1000",
    amount: Optional[float] = None,
) -> SupportingDocRef:
    """Create a SupportingDocRef."""
    return SupportingDocRef(doc_type=doc_type, reference=reference, amount=amount)


def make_invoice_line(
    *,
    line_number: int = 1,
    description: str = "Test Service – January 2025",
    quantity: float = 1.0,
    unit: str = "month",
    unit_rate: float = 1000.00,
    line_amount: float = 1000.00,
    service_date: Optional[date] = None,
    supporting_docs: Optional[List[SupportingDocRef]] = None,
) -> InvoiceLine:
    """Create an InvoiceLine with sensible defaults."""
    return InvoiceLine(
        line_number=line_number,
        description=description,
        quantity=quantity,
        unit=unit,
        unit_rate=unit_rate,
        line_amount=line_amount,
        service_date=service_date,
        supporting_docs=supporting_docs or [],
    )


def make_invoice(
    *,
    invoice_id: str = "test-inv-2025-01-001",
    vendor_id: str = "test-vendor",
    vendor_name: str = "Test Vendor Inc.",
    customer_name: str = "UHS",
    invoice_date: date = date(2025, 2, 1),
    service_period_start: date = date(2025, 1, 1),
    service_period_end: date = date(2025, 1, 31),
    contract_id: str = "test-vendor-uh-2025",
    lines: Optional[List[InvoiceLine]] = None,
    subtotal: float = 1000.00,
    tax_rate: float = 0.085,
    tax_amount: float = 85.00,
    total: float = 1085.00,
) -> Invoice:
    """Create an Invoice with sensible defaults."""
    if lines is None:
        lines = [make_invoice_line()]
    return Invoice(
        invoice_id=invoice_id,
        vendor_id=vendor_id,
        vendor_name=vendor_name,
        customer_name=customer_name,
        invoice_date=invoice_date,
        service_period_start=service_period_start,
        service_period_end=service_period_end,
        contract_id=contract_id,
        lines=lines,
        subtotal=subtotal,
        tax_rate=tax_rate,
        tax_amount=tax_amount,
        total=total,
    )


# ---------------------------------------------------------------------------
# Convenience: ABC Cleaning canonical objects
# ---------------------------------------------------------------------------


def make_abc_std_cleaning_term() -> ChargeTerm:
    """Return the Standard Cleaning charge term from the ABC Cleaning MSA."""
    return make_charge_term(
        id="abc-std-cleaning-2025",
        vendor_relationship_id="abc-cleaning-uh-2025",
        name="Standard Cleaning",
        charge_type=ChargeType.FIXED_RATE,
        rate=2500.00,
        rate_unit="month",
        billing_interval="monthly",
        location_scope=["Building A, Suite 100"],
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        extraction_confidence=0.98,
        source_page=2,
        source_section="Pricing, table row 1",
    )


def make_abc_adhoc_cleaning_term() -> ChargeTerm:
    """Return the After-hours Cleaning charge term from the ABC Cleaning MSA."""
    return make_charge_term(
        id="abc-adhoc-cleaning-2025",
        vendor_relationship_id="abc-cleaning-uh-2025",
        name="After-hours Cleaning",
        charge_type=ChargeType.VARIABLE_RATE,
        rate=150.00,
        rate_unit="hour",
        billing_interval="per occurrence",
        location_scope=["Building A, Suite 100"],
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        preconditions=["PO required"],
        extraction_confidence=0.95,
        source_page=2,
        source_section="Pricing, table row 2",
    )


def make_abc_restroom_supplies_term() -> ChargeTerm:
    """Return the Restroom Supplies charge term from the ABC Cleaning MSA."""
    return make_charge_term(
        id="abc-restroom-supplies-2025",
        vendor_relationship_id="abc-cleaning-uh-2025",
        name="Restroom Supplies",
        charge_type=ChargeType.PASS_THROUGH,
        rate=200.00,
        rate_unit="month",
        billing_interval="monthly",
        location_scope=["Building A, Suite 100"],
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        is_passthrough=True,
        requires_cost_evidence=True,
        extraction_confidence=0.97,
        source_page=2,
        source_section="Pricing, table row 3",
    )


def make_abc_vendor_relationship() -> VendorRelationship:
    """Return a fully populated ABC Cleaning VendorRelationship with all three terms."""
    return make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        vendor_id="abc-cleaning",
        vendor_name="ABC Cleaning Services",
        customer_id="uhs",
        customer_name="UHS",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        charge_terms=[
            make_abc_std_cleaning_term(),
            make_abc_adhoc_cleaning_term(),
            make_abc_restroom_supplies_term(),
        ],
    )
