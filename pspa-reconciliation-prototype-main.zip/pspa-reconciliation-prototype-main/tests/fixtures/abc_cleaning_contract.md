---
contract_id: abc-cleaning-uh-2025
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_name: UHS
customer_id: uhs
effective_date: 2025-01-01
renewal_date: 2026-01-01
document_type: Master Service Agreement
---

# Master Service Agreement

**Vendor:** ABC Cleaning Services  
**Customer:** United Health Services (UHS)  
**Effective Date:** January 1, 2025  
**Renewal Date:** January 1, 2026  
**Location:** Building A, Suite 100

---

## 1. Service Description

ABC Cleaning Services ("Vendor") agrees to provide weekly facility cleaning at the Customer's single location (Building A, Suite 100). The service begins January 1, 2025 and renews annually unless terminated with 30 days written notice.

Standard cleaning includes four (4) weekly visits per month, trash removal, vacuuming, and surface cleaning. Floor waxing and special event cleaning are excluded.

## 2. After-Hours Cleaning

Additional ad-hoc cleaning is available outside the standard schedule at the rate specified in Section 3. After-hours cleaning requires pre-approval by Customer in the form of a Purchase Order (PO) issued prior to the service date. Invoices for after-hours cleaning must reference the applicable PO number.

## 3. Pricing

Invoices are issued on the 15th of each month for the following month's services. Payment terms are Net 30 from invoice date.

| Service Type            | Unit   | Rate     | Frequency    | Notes                                     |
|-------------------------|--------|----------|--------------|-------------------------------------------|
| Standard Cleaning       | Month  | $2,500   | Monthly      | Includes 4 weekly visits                  |
| After-hours Cleaning    | Hour   | $150     | As-needed    | Requires PO; billed with next invoice     |
| Restroom Supplies       | Month  | $200     | Monthly      | Pass-through; actual cost billed with receipt |

## 4. Pass-Through Costs

Restroom supply costs are billed at actual cost, not to exceed $200 per month. Invoices for restroom supplies must be accompanied by the vendor's receipt or supply order confirmation.

## 5. Tax

Sales tax will be applied where required by applicable law. UHS is responsible for providing any tax exemption documentation.

## 6. Amendments

Any modification to this agreement must be made in writing and signed by both parties.
