---
contract_id: abc-cleaning-uh-2025-amend1
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_name: UHS
customer_id: uhs
effective_date: 2025-01-01
renewal_date: 2026-01-01
amendment_date: 2025-07-01
amendment_number: 1
document_type: Amendment
base_contract_id: abc-cleaning-uh-2025
---

# Amendment No. 1 to Master Service Agreement

**Vendor:** ABC Cleaning Services  
**Customer:** United Health Services (UHS)  
**Base Agreement Date:** January 1, 2025  
**Amendment Effective Date:** July 1, 2025

---

## Purpose

This Amendment modifies the pricing terms of the Master Service Agreement dated January 1, 2025. All other terms remain in effect.

## Modified Terms

Effective July 1, 2025, the following pricing changes apply:

| Service Type            | Unit   | Old Rate | New Rate | Notes                                     |
|-------------------------|--------|----------|----------|-------------------------------------------|
| After-hours Cleaning    | Hour   | $150     | $165     | Rate adjustment per CPI review            |
| Restroom Supplies       | Month  | $200     | $225     | Cap increase due to supply cost increases |

## Precedence

This Amendment supersedes Section 3 of the Master Service Agreement with respect to the modified services listed above. All other provisions of the Master Service Agreement remain unchanged.
