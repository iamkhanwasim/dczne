---
invoice_id: abc-inv-2025-02-001
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_name: UHS
invoice_date: 2025-02-01
service_period_start: 2025-01-01
service_period_end: 2025-01-31
due_date: 2025-03-03
contract_id: abc-cleaning-uh-2025
---

# Invoice

**Invoice Number:** ABC-2025-02-001  
**Vendor:** ABC Cleaning Services  
**Bill To:** United Health Services (UHS)  
**Invoice Date:** February 1, 2025  
**Service Period:** January 2025  
**Due Date:** March 3, 2025  

---

## Line Items

| Line | Description                                 | Qty | Unit  | Unit Rate | Amount     |
|------|---------------------------------------------|-----|-------|-----------|------------|
| 1    | Standard Cleaning – January 2025            | 1   | month | $2,500.00 | $2,500.00  |
| 2    | After-hours Cleaning (Jan 15) – PO#1042     | 2   | hour  | $150.00   | $300.00    |
| 3    | Restroom Supplies – January 2025            | 1   | month | $200.00   | $200.00    |

---

**Subtotal:** $3,000.00  
**Sales Tax (8.5%):** $255.00  
**Total Due:** $3,255.00

---

## Supporting Documents

- Line 2: PO#1042 attached (pre-approved after-hours cleaning, Jan 15)
- Line 3: Supply receipt #RS-2025-01-019 attached ($200.00 actual cost)
