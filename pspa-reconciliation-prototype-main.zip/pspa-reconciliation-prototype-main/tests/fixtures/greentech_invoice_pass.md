---
invoice_id: greentech-inv-2025-04-001
vendor_id: greentech-landscape
vendor_name: GreenTech Landscape Services
customer_name: UHS
invoice_date: 2025-04-05
service_period_start: 2025-03-01
service_period_end: 2025-03-31
due_date: 2025-05-20
contract_id: greentech-landscape-uh-2025
---

# Invoice

**Invoice Number:** GT-2025-04-001  
**Vendor:** GreenTech Landscape Services  
**Bill To:** United Health Services (UHS)  
**Invoice Date:** April 5, 2025  
**Service Period:** March 2025  
**Due Date:** May 20, 2025  

---

## Line Items

| Line | Description                        | Qty | Unit  | Unit Rate | Amount   |
|------|------------------------------------|-----|-------|-----------|----------|
| 1    | Grounds Maintenance – March 2025   | 1   | month | $1,800.00 | $1,800.00 |

---

**Subtotal:** $1,800.00  
**Sales Tax:** $0.00 (Tax Exempt)  
**Total Due:** $1,800.00
