---
contract_id: greentech-landscape-uh-2025
vendor_id: greentech-landscape
vendor_name: GreenTech Landscape Services
customer_name: UHS
customer_id: uhs
effective_date: 2025-03-01
renewal_date: 2026-03-01
document_type: Service Agreement
---

# Landscape Maintenance Service Agreement

**Vendor:** GreenTech Landscape Services  
**Customer:** United Health Services (UHS)  
**Effective Date:** March 1, 2025  
**Expiration Date:** February 28, 2026  
**Locations:** Main Campus Grounds, Parking Lot A

---

## 1. Services

GreenTech Landscape Services will provide grounds maintenance at the above locations. Monthly services include mowing (bi-weekly), edging, and seasonal mulching. Snow removal is excluded.

## 2. Pricing

Invoices are issued monthly in arrears for prior-month services. Payment terms are Net 45.

| Service Type          | Unit   | Rate     | Frequency    | Notes                                         |
|-----------------------|--------|----------|--------------|-----------------------------------------------|
| Grounds Maintenance   | Month  | $1,800   | Monthly      | Bi-weekly mowing, edging, cleanup             |
| Mulching              | Event  | $450     | Twice/year   | Spring and fall; requires advance scheduling  |
| Tree Trimming         | Hour   | $95      | As-needed    | Requires written work order                   |

## 3. Exclusions

Snow removal, irrigation repair, and plant replacement are not included and will be quoted separately.

## 4. Tax

UHS is a tax-exempt entity. Vendor shall not apply sales tax. UHS will provide exemption certificate upon request.
