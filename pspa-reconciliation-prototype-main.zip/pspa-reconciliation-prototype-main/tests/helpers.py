"""
Test assertion helpers and comparison utilities.

These helpers make test assertions more readable and robust against
irrelevant differences (ordering, timestamps, floating-point rounding).
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Numeric helpers
# ---------------------------------------------------------------------------

def approx_equal(a: float, b: float, tolerance: float = 0.01) -> bool:
    """Return True if |a - b| <= tolerance."""
    return abs(a - b) <= tolerance


def assert_amounts_match(actual: float, expected: float, label: str = "amount", tolerance: float = 0.01) -> None:
    """Assert two dollar amounts match within tolerance. Raises AssertionError with useful message."""
    if not approx_equal(actual, expected, tolerance):
        raise AssertionError(
            f"{label}: expected {expected:.2f}, got {actual:.2f} "
            f"(variance {actual - expected:+.2f}, tolerance ±{tolerance:.2f})"
        )


# ---------------------------------------------------------------------------
# Triple comparison helpers
# ---------------------------------------------------------------------------

def triples_contain(triples: List[Tuple], subject: str, predicate: str, obj: Any = None) -> bool:
    """
    Return True if triples contains a triple with the given subject and predicate.
    If obj is provided, also check that the object matches.
    """
    for s, p, o in triples:
        if s == subject and p == predicate:
            if obj is None:
                return True
            if o == obj:
                return True
    return False


def assert_triple_exists(triples: List[Tuple], subject: str, predicate: str, obj: Any = None) -> None:
    """Assert that a triple with the given subject/predicate/object exists."""
    if not triples_contain(triples, subject, predicate, obj):
        obj_clause = f" with object={obj!r}" if obj is not None else ""
        raise AssertionError(
            f"Expected triple ({subject!r}, {predicate!r}{obj_clause}) not found in {len(triples)} triples."
        )


def get_triple_object(triples: List[Tuple], subject: str, predicate: str) -> Any:
    """Return the object for the first triple matching subject + predicate, or None."""
    for s, p, o in triples:
        if s == subject and p == predicate:
            return o
    return None


# ---------------------------------------------------------------------------
# Finding comparison helpers
# ---------------------------------------------------------------------------

def assert_finding_status(finding: dict, expected_status: str) -> None:
    """Assert that a finding dict has the expected status."""
    actual = finding.get("status")
    if actual != expected_status:
        line = finding.get("line_number", "?")
        desc = finding.get("description", "")
        raise AssertionError(
            f"Line {line} ({desc!r}): expected status={expected_status!r}, got {actual!r}"
        )


def assert_all_lines_pass(findings: dict) -> None:
    """Assert every line_finding in an invoice findings dict has status PASS."""
    for lf in findings.get("line_findings", []):
        assert_finding_status(lf, "PASS")


def assert_line_status(findings: dict, line_number: int, expected_status: str) -> None:
    """Assert a specific line number has the expected status."""
    for lf in findings.get("line_findings", []):
        if lf.get("line_number") == line_number:
            assert_finding_status(lf, expected_status)
            return
    raise AssertionError(f"Line {line_number} not found in findings.")


def assert_overall_status(findings: dict, expected_status: str) -> None:
    """Assert the invoice-level overall_status."""
    actual = findings.get("overall_status")
    if actual != expected_status:
        raise AssertionError(f"Overall status: expected {expected_status!r}, got {actual!r}")


def assert_validator_ran(finding: dict, validator_name: str) -> None:
    """Assert that a validator was run for a line finding."""
    ran = finding.get("validators_run", [])
    if validator_name not in ran:
        line = finding.get("line_number", "?")
        raise AssertionError(
            f"Line {line}: expected validator {validator_name!r} to have run. "
            f"Validators run: {ran}"
        )


def assert_validator_passed(finding: dict, validator_name: str) -> None:
    """Assert that a specific validator passed."""
    assert_validator_ran(finding, validator_name)
    result = finding.get("validator_results", {}).get(validator_name, {})
    if not result.get("passed", False):
        line = finding.get("line_number", "?")
        reason = result.get("reason", "no reason given")
        raise AssertionError(
            f"Line {line}: validator {validator_name!r} did not pass. Reason: {reason}"
        )


def assert_validator_failed(finding: dict, validator_name: str) -> None:
    """Assert that a specific validator failed."""
    assert_validator_ran(finding, validator_name)
    result = finding.get("validator_results", {}).get(validator_name, {})
    if result.get("passed", True):
        line = finding.get("line_number", "?")
        raise AssertionError(
            f"Line {line}: validator {validator_name!r} was expected to fail but passed."
        )


# ---------------------------------------------------------------------------
# Match helpers
# ---------------------------------------------------------------------------

def assert_matched_to(finding: dict, expected_term_id: str) -> None:
    """Assert that a line was matched to the expected charge term."""
    actual = finding.get("matched_charge_term_id")
    if actual != expected_term_id:
        line = finding.get("line_number", "?")
        raise AssertionError(
            f"Line {line}: expected match to {expected_term_id!r}, got {actual!r}"
        )


def assert_confidence_above(finding: dict, threshold: float) -> None:
    """Assert that matching confidence is above the given threshold."""
    actual = finding.get("matching_confidence", 0.0)
    if actual < threshold:
        line = finding.get("line_number", "?")
        raise AssertionError(
            f"Line {line}: expected confidence >= {threshold}, got {actual}"
        )
