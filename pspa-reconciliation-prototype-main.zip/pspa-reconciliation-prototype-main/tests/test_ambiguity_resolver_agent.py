from typing import Any, Dict

import pytest

from llm.ambiguity_resolver_agent import AmbiguityResolverAgent
from llm.llm_client import LLMClient
from llm.prompts import build_ambiguity_resolution_prompt
from tests.factories import make_charge_term
from utils.errors import ExtractionError


def _success_transport(**_: Any) -> Dict[str, Any]:
    return {
        "text": """
        {
          "selected_charge_term_id": "abc-std-cleaning-2025",
          "confidence": 0.91,
          "reasoning": "Description and rate best align with Standard Cleaning.",
          "alternatives": [
            {
              "charge_term_id": "abc-adhoc-cleaning-2025",
              "rank": 2,
              "reason": "Similar scope but wrong unit/rate."
            }
          ]
        }
        """,
        "usage": {"prompt_tokens": 110, "completion_tokens": 55, "total_tokens": 165},
        "raw": {"id": "mock-ambiguity"},
    }


def test_build_ambiguity_prompt_includes_excerpts() -> None:
    prompt = build_ambiguity_resolution_prompt(
        invoice_line={"description": "Standard Cleaning - January"},
        candidates=[{"id": "abc-std-cleaning-2025", "name": "Standard Cleaning"}],
        relevant_excerpts=["Section 3: Standard Cleaning is billed monthly at $2,500"],
        context={"vendor": "ABC Cleaning"},
    )

    assert "Relevant contract excerpts" in prompt["user_prompt"]
    assert "Section 3" in prompt["user_prompt"]


def test_ambiguity_resolver_agent_maps_resolution_result() -> None:
    client = LLMClient(provider="openai", model="mock-model", transport=_success_transport)
    agent = AmbiguityResolverAgent(llm_client=client, min_confidence=0.7)

    candidates = [
        make_charge_term(id="abc-std-cleaning-2025", name="Standard Cleaning", rate=2500.0, rate_unit="month"),
        make_charge_term(id="abc-adhoc-cleaning-2025", name="After-hours Cleaning", rate=150.0, rate_unit="hour"),
    ]

    result = agent.resolve_match(
        invoice_line={"description": "Standard Cleaning - January", "unit_rate": 2500.0},
        candidates=candidates,
        relevant_excerpts=["Section 3 pricing table includes Standard Cleaning at $2,500/month."],
        context={"contract_id": "abc-cleaning-uh-2025"},
    )

    assert result.selected_charge_term_id == "abc-std-cleaning-2025"
    assert result.confidence == 0.91
    assert result.alternatives[0].charge_term_id == "abc-adhoc-cleaning-2025"
    assert result.provenance.total_tokens == 165


def test_ambiguity_resolver_rejects_selection_not_in_candidates() -> None:
    def bad_selection_transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": '{"selected_charge_term_id": "nonexistent-term", "confidence": 0.9, "reasoning": "Best guess"}',
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=bad_selection_transport)
    agent = AmbiguityResolverAgent(llm_client=client)

    with pytest.raises(ExtractionError):
        agent.resolve_match(
            invoice_line={"description": "Standard Cleaning - January"},
            candidates=[make_charge_term(id="abc-std-cleaning-2025")],
        )


def test_ambiguity_resolver_rejects_low_confidence() -> None:
    def low_conf_transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": '{"selected_charge_term_id": "abc-std-cleaning-2025", "confidence": 0.4, "reasoning": "unsure"}',
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=low_conf_transport)
    agent = AmbiguityResolverAgent(llm_client=client, min_confidence=0.7)

    with pytest.raises(ExtractionError):
        agent.resolve_match(
            invoice_line={"description": "Standard Cleaning - January"},
            candidates=[make_charge_term(id="abc-std-cleaning-2025")],
        )
