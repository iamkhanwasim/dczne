from __future__ import annotations

from fastapi.testclient import TestClient

from main import app


client = TestClient(app)


def _contract_yaml(contract_id: str) -> str:
    return f"""
contract_id: {contract_id}
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_id: uhs
customer_name: UHS
effective_date: 2025-01-01
renewal_date: 2026-01-01
document_type: Master Service Agreement
charge_terms:
  - id: abc-std-cleaning-2025
    name: Standard Cleaning
    charge_type: FIXED_RATE
    rate: 2500.0
    rate_unit: month
    extraction_confidence: 0.99
""".strip()


def test_contract_ingest_status_delete_flow() -> None:
    contract_id = "api-contract-flow-2026"

    ingest_response = client.post(
        "/contracts/ingest",
        json={
            "documents": [_contract_yaml(contract_id)],
            "metadata": {"vendor_id": "abc-cleaning"},
        },
    )
    assert ingest_response.status_code == 200

    ingest_data = ingest_response.json()
    assert ingest_data["contract_id"] == contract_id
    assert ingest_data["status"] == "finalized"
    assert ingest_data["term_count"] == 1

    status_response = client.get(f"/contracts/{contract_id}/status")
    assert status_response.status_code == 200

    status_data = status_response.json()
    assert status_data["contract_id"] == contract_id
    assert status_data["status"] == "finalized"
    assert status_data["term_count"] == 1

    delete_response = client.delete(f"/contracts/{contract_id}")
    assert delete_response.status_code == 204

    status_after_delete = client.get(f"/contracts/{contract_id}/status")
    assert status_after_delete.status_code == 404
