from __future__ import annotations

import json
from fastapi.testclient import TestClient
import yaml

from main import app


client = TestClient(app)


def _invoice_payload(yaml_text: str) -> dict:
    return json.loads(json.dumps(yaml.safe_load(yaml_text), default=str))


def _contract_yaml(contract_id: str) -> str:
    return f"""
contract_id: {contract_id}
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_id: uhs
customer_name: UHS
effective_date: 2025-01-01
renewal_date: 2026-01-01
document_type: Master Service Agreement
charge_terms:
  - id: abc-std-cleaning-2025
    name: Standard Cleaning
    charge_type: FIXED_RATE
    rate: 2500.0
    rate_unit: month
    extraction_confidence: 0.99
""".strip()


INVOICE_YAML = """
invoice_id: api-inv-001
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_name: UHS
invoice_date: 2025-02-01
contract_id: {contract_id}
lines:
  - line_number: 1
    description: Standard Cleaning
    quantity: 1
    unit: month
    unit_rate: 2500.0
    line_amount: 2500.0
subtotal: 2500.0
tax_rate: 0.0
tax_amount: 0.0
total: 2500.0
""".strip()


def test_reconcile_happy_path_and_unknown_contract() -> None:
    contract_id = "api-invoice-flow-2026"

    ingest_response = client.post(
        "/contracts/ingest",
        json={
            "documents": [_contract_yaml(contract_id)],
            "metadata": {"vendor_id": "abc-cleaning"},
        },
    )
    assert ingest_response.status_code == 200

    reconcile_response = client.post(
        "/reconcile",
        json={
            "contract_id": contract_id,
            "invoice": _invoice_payload(INVOICE_YAML.format(contract_id=contract_id)),
            "metadata": {},
        },
    )
    assert reconcile_response.status_code == 200

    data = reconcile_response.json()
    assert data["invoice_id"] == "api-inv-001"
    assert data["status"] in {"PASS", "REJECT", "NEEDS_REVIEW"}
    assert isinstance(data["findings"], list)
    assert "summary" in data
    assert "audit_trail" in data

    unknown_response = client.post(
        "/reconcile",
        json={
            "contract_id": "does-not-exist",
            "invoice": _invoice_payload(INVOICE_YAML.format(contract_id="does-not-exist")),
            "metadata": {},
        },
    )
    assert unknown_response.status_code == 404
