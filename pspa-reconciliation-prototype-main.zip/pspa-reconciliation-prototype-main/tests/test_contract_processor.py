from datetime import date

import pytest

from core.contract_processor import ContractProcessor
from graph.mock_graph import MockGraph
from llm.contract_extraction_agent import ExtractionProvenance, ExtractionResult
from models.contract_models import ChargeTerm, ChargeType, SourceCitation
from utils.errors import ValidationError


class StubExtractionAgent:
    def __init__(self, terms):
        self.terms = terms

    def extract_charge_terms(
        self,
        document_text: str,
        vendor_relationship_id: str,
        source_document_id: str,
        source_document_type: str = "ContractDocument",
        metadata=None,
    ):
        mapped = []
        for term in self.terms:
            mapped.append(term.model_copy(update={"vendor_relationship_id": vendor_relationship_id}))
        return ExtractionResult(
            charge_terms=mapped,
            provenance=ExtractionProvenance(
                provider="mock",
                model="mock-model",
                prompt_tokens=1,
                completion_tokens=1,
                total_tokens=2,
                extracted_at="2026-05-26T00:00:00+00:00",
            ),
            raw_response={"charge_terms": []},
        )


def _term(term_id: str, name: str, rate: float = 100.0) -> ChargeTerm:
    return ChargeTerm(
        id=term_id,
        vendor_relationship_id="placeholder",
        name=name,
        charge_type=ChargeType.FIXED_RATE,
        rate=rate,
        rate_unit="month",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        extraction_confidence=0.95,
        source=SourceCitation(document_id="doc-1"),
    )


def test_ingest_contract_markdown_and_finalize(abc_cleaning_contract_text: str) -> None:
    graph = MockGraph()
    agent = StubExtractionAgent(
        terms=[
            _term("abc-std-cleaning-2025", "Standard Cleaning", 2500.0),
            _term("abc-adhoc-cleaning-2025", "After-hours Cleaning", 150.0),
        ]
    )
    processor = ContractProcessor(graph_repository=graph, extraction_agent=agent)

    ingest = processor.ingest_contract(vendor_id="abc-cleaning", documents=[abc_cleaning_contract_text])
    assert ingest.contract_id == "abc-cleaning-uh-2025"
    assert ingest.terms_extracted == 2
    assert ingest.status == "indexed"

    finalize = processor.finalize_contract(ingest.contract_id)
    assert finalize.status == "finalized"
    assert finalize.ready_for_invoices is True
    assert finalize.triples_inserted > 0
    assert graph.subject_exists("http://vizientinc.com/data/reconciliation/abc-cleaning-uh-2025") is True


def test_ingest_yaml_uses_structured_charge_terms_without_llm() -> None:
    class FailingAgent:
        def extract_charge_terms(self, *args, **kwargs):
            raise AssertionError("LLM extraction should not be called for structured YAML terms")

    yaml_text = """
contract_id: xyz-uh-2025
vendor_id: xyz
vendor_name: XYZ Services
customer_id: uhs
customer_name: UHS
effective_date: 2025-01-01
renewal_date: 2026-01-01
document_type: Service Agreement
charge_terms:
  - id: xyz-monthly
    name: Monthly Service
    charge_type: FIXED_RATE
    rate: 1200.0
    rate_unit: month
    extraction_confidence: 0.99
"""

    processor = ContractProcessor(graph_repository=MockGraph(), extraction_agent=FailingAgent())
    ingest = processor.ingest_contract(vendor_id="xyz", documents=[{"source_name": "xyz.yaml", "content": yaml_text}])

    assert ingest.contract_id == "xyz-uh-2025"
    assert ingest.terms_extracted == 1
    contract = processor.get_contract("xyz-uh-2025")
    assert contract.charge_terms[0].id == "xyz-monthly"


def test_ingest_amendment_creates_amendment_record(abc_cleaning_contract_text: str) -> None:
    amendment_text = """---
contract_id: abc-cleaning-uh-2025
vendor_id: abc-cleaning
vendor_name: ABC Cleaning Services
customer_id: uhs
customer_name: UHS
document_type: Amendment
amendment_number: 2
amendment_date: 2025-06-01
---

# Amendment
Updated pricing.
"""

    agent = StubExtractionAgent(terms=[_term("abc-std-cleaning-2025", "Standard Cleaning", 2750.0)])
    processor = ContractProcessor(graph_repository=MockGraph(), extraction_agent=agent)

    ingest = processor.ingest_contract(vendor_id="abc-cleaning", documents=[abc_cleaning_contract_text, amendment_text])
    contract = processor.get_contract(ingest.contract_id)

    assert len(contract.amendments) == 1
    assert contract.amendments[0].amendment_number == 2
    assert len(contract.amendments[0].modified_terms) == 1


def test_finalize_contract_raises_when_no_terms() -> None:
    processor = ContractProcessor(graph_repository=MockGraph(), extraction_agent=StubExtractionAgent(terms=[]))
    markdown = """
---
contract_id: empty-uh-2025
vendor_id: empty-vendor
vendor_name: Empty Vendor
customer_id: uhs
customer_name: UHS
document_type: Master Service Agreement
---

# Empty Contract
No billable terms here.
"""

    ingest = processor.ingest_contract(vendor_id="empty-vendor", documents=[markdown])

    with pytest.raises(ValidationError):
        processor.finalize_contract(ingest.contract_id)


def test_ingest_contract_propagates_extraction_review_flags(abc_cleaning_contract_text: str) -> None:
    class ReviewStubExtractionAgent(StubExtractionAgent):
        def extract_charge_terms(
            self,
            document_text: str,
            vendor_relationship_id: str,
            source_document_id: str,
            source_document_type: str = "ContractDocument",
            metadata=None,
        ):
            mapped = [
                term.model_copy(update={"vendor_relationship_id": vendor_relationship_id})
                for term in self.terms
            ]
            return ExtractionResult(
                charge_terms=mapped,
                provenance=ExtractionProvenance(
                    provider="mock",
                    model="mock-model",
                    prompt_tokens=1,
                    completion_tokens=1,
                    total_tokens=2,
                    extracted_at="2026-05-26T00:00:00+00:00",
                ),
                raw_response={"charge_terms": []},
                conflicts=["Conflicting extraction for term_id=abc-std-cleaning-2025"],
                manual_review_required=True,
                review_reasons=["Extraction confidence below manual-review threshold 0.80"],
            )

    processor = ContractProcessor(
        graph_repository=MockGraph(),
        extraction_agent=ReviewStubExtractionAgent(terms=[_term("abc-std-cleaning-2025", "Standard Cleaning")]),
    )

    ingest = processor.ingest_contract(vendor_id="abc-cleaning", documents=[abc_cleaning_contract_text])

    assert ingest.manual_review_required is True
    assert any("manual-review threshold" in reason for reason in ingest.review_reasons)
    assert any("Conflicting extraction" in conflict for conflict in ingest.conflicts)
