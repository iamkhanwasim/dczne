from datetime import date

import pytest
from pydantic import ValidationError

from models.contract_models import (
    Amendment,
    ChargeTerm,
    ChargeType,
    EffectivePeriod,
    VendorRelationship,
)
from models.finding_models import (
    Finding,
    FindingStatus,
    InvoiceFinding,
    RoutingPath,
    ValidationResult,
)
from models.invoice_models import Invoice, InvoiceLine
from models.routing_models import MatchResult


def _make_charge_term(
    *,
    term_id: str,
    rate: float,
    start: date,
    end: date,
    name: str = "Standard Cleaning",
    charge_type: ChargeType = ChargeType.FIXED_RATE,
) -> ChargeTerm:
    return ChargeTerm(
        id=term_id,
        vendor_relationship_id="abc-cleaning-uh-2025",
        name=name,
        charge_type=charge_type,
        rate=rate,
        rate_unit="month",
        effective_date=start,
        renewal_date=end,
    )


def test_effective_period_requires_end_after_start() -> None:
    with pytest.raises(ValidationError):
        EffectivePeriod(start=date(2025, 1, 1), end=date(2025, 1, 1))


def test_vendor_relationship_amendment_overrides_base_term() -> None:
    base_term = _make_charge_term(
        term_id="abc-std-cleaning-2025",
        rate=2500.0,
        start=date(2025, 1, 1),
        end=date(2025, 12, 31),
    )
    amended_term = _make_charge_term(
        term_id="abc-std-cleaning-2025",
        rate=2750.0,
        start=date(2025, 7, 1),
        end=date(2025, 12, 31),
    )

    vr = VendorRelationship(
        id="abc-cleaning-uh-2025",
        vendor_id="abc-cleaning",
        vendor_name="ABC Cleaning Services",
        customer_id="uhs",
        customer_name="UHS",
        charge_terms=[base_term],
        amendments=[
            Amendment(
                id="abc-cleaning-amendment-1",
                base_contract_id="abc-cleaning-uh-2025",
                amendment_number=1,
                effective_date=date(2025, 7, 1),
                modified_terms=[amended_term],
            )
        ],
    )

    june_terms = vr.get_active_terms(date(2025, 6, 15))
    august_terms = vr.get_active_terms(date(2025, 8, 15))

    assert june_terms[0].rate == 2500.0
    assert august_terms[0].rate == 2750.0


def test_charge_term_is_active_on_from_dates() -> None:
    term = _make_charge_term(
        term_id="term-1",
        rate=100.0,
        start=date(2025, 1, 1),
        end=date(2025, 3, 31),
    )
    assert term.is_active_on(date(2025, 2, 1)) is True
    assert term.is_active_on(date(2025, 4, 1)) is False


def test_invoice_line_expected_amount_and_negative_amount_validation() -> None:
    line = InvoiceLine(
        line_number=1,
        description="After-hours Cleaning",
        quantity=3,
        unit="hour",
        unit_rate=150,
        line_amount=450,
    )
    assert line.expected_amount(150) == 450.0

    with pytest.raises(ValidationError):
        InvoiceLine(
            line_number=2,
            description="Invalid Line",
            quantity=1,
            unit="month",
            unit_rate=100,
            line_amount=-1,
        )


def test_invoice_requires_at_least_one_line() -> None:
    with pytest.raises(ValidationError):
        Invoice(
            invoice_id="inv-001",
            vendor_id="abc-cleaning",
            vendor_name="ABC Cleaning Services",
            customer_name="UHS",
            invoice_date=date(2025, 2, 1),
            contract_id="abc-cleaning-uh-2025",
            lines=[],
            subtotal=0.0,
            tax_amount=0.0,
            total=0.0,
        )


def test_validation_result_fail_result_computes_variance_pct() -> None:
    result = ValidationResult.fail_result(
        validator_name="amount_validator",
        reason="Amount mismatch",
        expected=100,
        actual=125,
        variance=25,
    )

    assert result.passed is False
    assert result.variance_pct == 25.0


def test_finding_error_and_warning_properties() -> None:
    error_result = ValidationResult.fail_result(
        validator_name="amount_validator",
        reason="Mismatch",
        expected=100,
        actual=150,
        variance=50,
        severity="error",
    )
    warning_result = ValidationResult.fail_result(
        validator_name="evidence_validator",
        reason="Missing supporting doc",
        severity="warning",
    )

    finding = Finding(
        invoice_id="inv-001",
        line_number=1,
        description="Restroom Supplies",
        status=FindingStatus.NEEDS_REVIEW,
        routing_path=RoutingPath.DEEP_PATH,
        validator_results={
            "amount_validator": error_result,
            "evidence_validator": warning_result,
        },
    )

    assert set(finding.failed_validators) == {"amount_validator", "evidence_validator"}
    assert finding.has_errors is True
    assert finding.has_warnings is True


def test_invoice_finding_status_priority_and_match_result_properties() -> None:
    findings = [
        Finding(
            invoice_id="inv-001",
            line_number=1,
            description="Line 1",
            status=FindingStatus.PASS,
            routing_path=RoutingPath.FAST_PATH,
        ),
        Finding(
            invoice_id="inv-001",
            line_number=2,
            description="Line 2",
            status=FindingStatus.NO_MATCH,
            routing_path=RoutingPath.DEEP_PATH,
        ),
    ]

    overall = InvoiceFinding.compute_overall_status(findings)
    match_result = MatchResult(invoice_line_id="inv-001-l2")

    assert overall == FindingStatus.NEEDS_REVIEW
    assert match_result.is_matched is False
    assert match_result.confidence == 0.0
