"""Debug test to diagnose contract normalization and charge term extraction."""
import os
from pathlib import Path
import yaml
import fitz
import pytest

from llm.llm_client import LLMClient
from core.contract_processor import ContractProcessor
from graph.mock_graph import MockGraph


pytestmark = pytest.mark.live


def test_debug_single_contract_extraction():
    """Debug: normalize a real contract and inspect what SUT extracts."""
    # Only run if live env vars set
    if not all(
        os.getenv(k)
        for k in ["AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"]
    ):
        print("Skipping: AZURE_OPENAI_* env vars not set")
        return

    # Pick a real contract PDF
    # Path from test file up to workspace root (PSPA-Rec), then into Data
    # test -> implementation -> 05-ontology-agent-d-hybrid -> approaches -> reconciliation-engine -> docs -> PSPA-Rec
    workspace_root = Path(__file__).parents[6]  # Go up 6 levels to PSPA-Rec
    data_root = workspace_root / "Data"
    pair_folder = data_root / "Contract and Invoice Pairs" / "UHS - Reputation Management" / "Reputation.com Contracts"
    contract_candidates = sorted(pair_folder.glob("*.pdf"))
    
    print(f"Workspace root: {workspace_root}")
    print(f"Data root: {data_root}")
    print(f"Looking for contracts in: {pair_folder}")
    print(f"Exists: {pair_folder.exists()}")
    
    if pair_folder.exists():
        all_files = list(pair_folder.glob("*"))
        print(f"Files in folder: {all_files}")
    
    if not contract_candidates:
        print("No contract PDFs found in test folder")
        return

    contract_pdf = contract_candidates[0]
    print(f"\n{'='*80}")
    print(f"Debug: Testing contract: {contract_pdf.name}")
    print(f"{'='*80}\n")

    # Step 1: Extract raw PDF text
    print("[1] Extracting raw text from PDF...")
    doc = fitz.open(contract_pdf)
    raw_text = ""
    for page_num, page in enumerate(doc, 1):
        raw_text += f"-- Page {page_num} --\n"
        raw_text += page.get_text()
    doc.close()
    
    print(f"Raw text length: {len(raw_text)} chars")
    print(f"\n--- EXTRACTED PDF TEXT (first 1000 chars) ---")
    print(raw_text[:1000])
    print("..." if len(raw_text) > 1000 else "")

    # Step 2: Normalize via LLM
    print("[2] Normalizing to YAML via LLM...")
    client = LLMClient(provider="azure-apim")
    
    prompt = f"""Convert this contract PDF text to YAML format. Include these exact fields:
- contract_id: unique identifier derived from contract number or name
- vendor_id: unique id (snake_case, lowercase, no spaces) for the vendor
- vendor_name: the service provider name
- customer_name: the customer org name (assume UHS if not clear)  
- contract_text: the FULL original contract text exactly as extracted from PDF

Output ONLY valid YAML, no markdown, no extra text. These fields are REQUIRED.

Contract text:
{raw_text}
"""
    
    normalized_yaml_str = None
    try:
        response = client.complete_text(prompt, max_tokens=4000)
        normalized_yaml_str = response.text  # Extract text from LLMResponse
        print(f"Normalized YAML length: {len(normalized_yaml_str)} chars")
        
        # Parse to validate
        normalized_yaml = yaml.safe_load(normalized_yaml_str)
        print(f"Parsed YAML keys: {list(normalized_yaml.keys())}")
        
        contract_text_extracted = normalized_yaml.get("contract_text", "")
        print(f"contract_text field length: {len(contract_text_extracted)} chars")
        
        print(f"\n--- NORMALIZED YAML (complete) ---")
        print(normalized_yaml_str)
        print()
        
    except Exception as e:
        print(f"ERROR in normalization: {e}")
        if normalized_yaml_str:
            print(f"Raw LLM response:\n{normalized_yaml_str}\n")
        return

    # Step 3: Use SUT to ingest and extract charge terms
    print("[3] Ingesting normalized YAML contract via SUT (ContractProcessor)...")
    graph = MockGraph()
    processor = ContractProcessor(graph_repository=graph)

    try:
        # Pass the FULL YAML (not just the contract_text field) to the SUT
        # The SUT parser recognizes YAML and extracts metadata + contract_text
        # Then the extraction agent can extract charge terms from the contract_text
        vendor_id = normalized_yaml.get("vendor_name", "Unknown").replace(" ", "-").lower()
        
        ingest_result = processor.ingest_contract(
            vendor_id=vendor_id,
            documents=[normalized_yaml_str]  # Pass the FULL YAML to SUT
        )
        
        print(f"✓ Contract ingested: {ingest_result.contract_id}")
        print(f"  Extracted {ingest_result.terms_extracted} charge terms")
        print(f"  Documents processed: {ingest_result.documents_processed}")
        
        if ingest_result.terms_extracted > 0:
            contract = processor.get_contract(ingest_result.contract_id)
            print(f"\n--- EXTRACTED CHARGE TERMS (raw data) ---")
            for i, term in enumerate(contract.charge_terms, 1):
                print(f"\n  Term {i}:")
                print(f"    id: {term.id}")
                print(f"    name: {term.name}")
                print(f"    charge_type: {term.charge_type}")
                print(f"    rate: {term.rate}")
                print(f"    unit: {term.unit}")
                print(f"    description: {term.description if hasattr(term, 'description') else 'N/A'}")
                print(f"    confidence: {term.extraction_confidence if hasattr(term, 'extraction_confidence') else 'N/A'}")
            
            print("\n[4] Finalizing to RDF triples...")
            finalize_result = processor.finalize_contract(ingest_result.contract_id)
            print(f"✓ Contract finalized")
            print(f"  Triples inserted: {finalize_result.triples_inserted}")
            print(f"  Total triples in graph: {graph.triple_count()}")
        else:
            print("\n⚠️ WARNING: Zero charge terms extracted by SUT!")
            print(f"This suggests the SUT extraction agent failed to find terms in the contract.")
            print(f"Possible causes:")
            print(f"  A) Contract doesn't actually contain identifiable charge terms")
            print(f"  B) SUT extraction agent is failing silently")
            print(f"\nDebug info:")
            print(f"  - vendor_id passed to ingest: {vendor_id}")
            print(f"  - Status: {ingest_result.status}")
            print(f"  - Conflicts: {ingest_result.conflicts}")
            
    except Exception as e:
        print(f"ERROR during SUT ingestion: {e}")
        print(f"\nThis is the actual extraction error. The LLM was called but produced malformed data.")
        print(f"The extraction agent could not map the LLM response to valid ChargeTerm objects.")
        import traceback
        traceback.print_exc()
        return

    print(f"\n{'='*80}")
    print("Debug test complete")
    print(f"{'='*80}\n")


if __name__ == "__main__":
    test_debug_single_contract_extraction()
