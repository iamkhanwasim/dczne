"""Debug test to see raw extraction output."""
import os
from pathlib import Path
import json
import fitz
import pytest

from llm.llm_client import LLMClient
from llm.contract_extraction_agent import ContractExtractionAgent


pytestmark = pytest.mark.live


def test_debug_raw_extraction_output():
    """Debug: see what the extraction agent actually returns from the LLM."""
    # Only run if live env vars set
    if not all(
        os.getenv(k)
        for k in ["AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"]
    ):
        print("Skipping: AZURE_OPENAI_* env vars not set")
        return

    # Get a real contract
    workspace_root = Path(__file__).parents[6]
    data_root = workspace_root / "Data"
    pair_folder = data_root / "Contract and Invoice Pairs" / "UHS - Reputation Management" / "Reputation.com Contracts"
    contract_candidates = sorted(pair_folder.glob("*.pdf"))
    
    if not contract_candidates:
        print("No contracts found")
        return

    contract_pdf = contract_candidates[0]
    print(f"\nTesting contract: {contract_pdf.name}\n")

    # Extract text from PDF
    doc = fitz.open(contract_pdf)
    raw_text = ""
    for page_num, page in enumerate(doc, 1):
        raw_text += f"-- Page {page_num} --\n"
        raw_text += page.get_text()
    doc.close()

    print(f"Document text length: {len(raw_text)} chars\n")
    
    # Create extraction agent and call it directly
    print("=" * 80)
    print("Calling ContractExtractionAgent.extract_charge_terms() directly...")
    print("=" * 80)
    
    agent = ContractExtractionAgent()
    
    try:
        result = agent.extract_charge_terms(
            document_text=raw_text,
            vendor_relationship_id="reputation_com_contract",
            source_document_id="test_doc_1",
            source_document_type="ContractDocument",
            metadata={"vendor_name": "Reputation.com", "customer_name": "UHS"},
        )
        
        print(f"\n+ Extraction succeeded!")
        print(f"  Extracted {len(result.charge_terms)} charge terms")
        
        if result.charge_terms:
            print(f"\n--- EXTRACTED CHARGE TERMS ---")
            for i, term in enumerate(result.charge_terms, 1):
                print(f"\nTerm {i}:")
                print(f"  id: {term.id}")
                print(f"  name: {term.name}")
                print(f"  charge_type: {term.charge_type.value}")
                print(f"  rate: {term.rate} {term.rate_unit}")
                print(f"  confidence: {term.extraction_confidence:.2f}")
                
    except Exception as e:
        print(f"\nX Extraction failed: {e}")
        print(f"\nThis means the LLM returned data, but it was malformed.")
        print(f"Let's look at the RAW LLM response...\n")
        
        # Call the LLM prompt directly to see what it returns  
        from llm.prompts import build_contract_extraction_prompt
        from utils.config import config
        
        prompt = build_contract_extraction_prompt(
            document_text=raw_text,
            metadata={"vendor_name": "Reputation.com", "customer_name": "UHS"}
        )
        
        print("Calling LLM directly with the extraction prompt...")
        client = LLMClient(provider=config.llm_provider, model=config.llm_model)
        
        try:
            payload, response = client.complete_json_response(
                user_prompt=prompt["user_prompt"],
                system_prompt=prompt["system_prompt"],
                temperature=config.llm_temperature_extraction,
                max_tokens=config.llm_max_tokens,
            )
            
            print(f"\n--- RAW LLM RESPONSE (JSON Payload) ---")
            print(json.dumps(payload, indent=2))
            
            print(f"\n--- ANALYSIS ---")
            charge_terms = payload.get("charge_terms", [])
            print(f"Number of terms returned: {len(charge_terms)}")
            
            if charge_terms:
                print(f"\nFirst term structure:")
                print(json.dumps(charge_terms[0], indent=2))
                
                print(f"\nMissing 'name' field?")
                if "name" not in charge_terms[0]:
                    print(f"  -> YES! 'name' field is missing")
                    print(f"  Available fields: {list(charge_terms[0].keys())}")
                else:
                    print(f"  -> NO, 'name' is present: {charge_terms[0].get('name')}")
                    
        except Exception as e2:
            print(f"ERROR calling LLM directly: {e2}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    test_debug_raw_extraction_output()
