"""
Simple end-to-end validation: Load real contract PDF, extract terms, verify all fields present.
Not matching invoice, just validating that extraction with hardened prompt produces valid output.
"""

import os
import pytest
from pathlib import Path
from llm.contract_extraction_agent import ContractExtractionAgent
from llm.llm_client import LLMClient
from data_parsers.pdf_extractor import extract_text


def _require_live_env() -> None:
    required = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_API_VERSION",
        "AZURE_OPENAI_DEPLOYMENT",
    ]
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        pytest.skip(f"Missing live Azure OpenAI env vars: {', '.join(missing)}")


@pytest.mark.live
def test_e2e_contract_extraction_with_hardened_prompt():
    """Extract charge terms from a real contract PDF using hardened prompt."""
    _require_live_env()
    
    # Use Reputation.com contract (smallest file, should load quickly)
    contract_path = Path(
        "c:/Users/maclark/OneDrive - vizientinc.com/Documents/PSPA-Rec/"
        "Data/Contract and Invoice Pairs/UHS - Reputation Management/"
        "Reputation.com Contracts/Reputation.com.UHSH.Addendum_Cover_Memo.1-17-22.pdf"
    )
    
    assert contract_path.exists(), f"Contract not found: {contract_path}"
    
    # Extract PDF text
    raw_text = extract_text(str(contract_path))
    assert raw_text and len(raw_text) > 100, f"Failed to extract text from {contract_path}"
    print(f"\nExtracted {len(raw_text)} chars from contract")
    
    # Initialize extraction agent with lower confidence threshold for testing field structure
    llm_client = LLMClient()
    agent = ContractExtractionAgent(llm_client=llm_client, min_confidence=0.5)
    
    # Extract charge terms
    # Note: Use min_confidence=0.0 to validate field structure regardless of quality
    agent.min_confidence = 0.0
    result = agent.extract_charge_terms(
        document_text=raw_text,
        vendor_relationship_id="reputation-com",
        source_document_id="test-contract-123",
        source_document_type="Contract",
        metadata={
            "vendor_name": "Reputation.com",
            "customer_name": "UHS",
        }
    )
    
    # Validate structure
    from llm.contract_extraction_agent import ExtractionResult
    assert isinstance(result, ExtractionResult), f"Expected ExtractionResult, got {type(result)}"
    charge_terms = result.charge_terms
    assert isinstance(charge_terms, list), f"Expected list of ChargeTerm, got {type(charge_terms)}"
    assert len(charge_terms) > 0, "Expected at least one charge term extracted"
    
    # Check first term
    term = charge_terms[0]
    print(f"\n✓ Extracted {len(charge_terms)} charge term(s)")
    print(f"\nFirst term validation:")
    print(f"  - name: {term.name!r} (minLength: 3 required, actual: {len(term.name)})")
    print(f"  - charge_type: {term.charge_type.value!r} (enum required, valid: {term.charge_type in [ct for ct in type(term.charge_type)]})") 
    print(f"  - rate: {term.rate!r} (numeric >= 0.01, valid: {term.rate >= 0.01})")
    print(f"  - rate_unit: {term.rate_unit!r} (minLength: 2 required, actual: {len(term.rate_unit)})")
    print(f"  - extraction_confidence: {term.extraction_confidence!r} (0.0-1.0, valid: {0.0 <= term.extraction_confidence <= 1.0})")
    
    # Assertions for required fields
    assert len(term.name) >= 3, f"name must be minLength 3, got {len(term.name)!r}"
    assert term.charge_type is not None, "charge_type must not be None"
    assert term.rate >= 0.01, f"rate must be >= 0.01, got {term.rate}"
    assert len(term.rate_unit) >= 2, f"rate_unit must be minLength 2, got {len(term.rate_unit)!r}"
    assert 0.0 <= term.extraction_confidence <= 1.0, f"extraction_confidence must be 0.0-1.0, got {term.extraction_confidence}"
    
    print(f"\n✓ All validations passed!")


if __name__ == "__main__":
    test_e2e_contract_extraction_with_hardened_prompt()
