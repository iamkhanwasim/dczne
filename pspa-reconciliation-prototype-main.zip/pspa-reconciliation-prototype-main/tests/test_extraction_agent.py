from typing import Any, Dict

import pytest

from llm.contract_extraction_agent import ContractExtractionAgent
from llm.llm_client import LLMClient
from llm.prompts import build_contract_extraction_prompt
from utils.errors import ExtractionError


def _success_transport(**_: Any) -> Dict[str, Any]:
    return {
        "text": """
        {
          "charge_terms": [
            {
              "id": "abc-std-cleaning-2025",
              "name": "Standard Cleaning",
              "charge_type": "FIXED_RATE",
              "rate": 2500.0,
              "rate_unit": "month",
              "billing_interval": "monthly",
              "location_scope": ["Building A, Suite 100"],
              "effective_date": "2025-01-01",
              "renewal_date": "2026-01-01",
              "extraction_confidence": 0.98
            }
          ]
        }
        """,
        "usage": {"prompt_tokens": 120, "completion_tokens": 80, "total_tokens": 200},
        "raw": {"id": "mock"},
    }


def test_prompt_builder_includes_metadata_block() -> None:
    prompt = build_contract_extraction_prompt(
        document_text="Contract body",
        metadata={"vendor_id": "abc-cleaning", "contract_id": "abc-cleaning-uh-2025"},
    )

    assert "vendor_id" in prompt["user_prompt"]
    assert "contract_id" in prompt["user_prompt"]
    assert "Return a JSON object" in prompt["user_prompt"]


def test_contract_extraction_agent_maps_charge_terms_and_provenance(abc_cleaning_contract_text: str) -> None:
    client = LLMClient(provider="openai", model="mock-model", transport=_success_transport)
    agent = ContractExtractionAgent(llm_client=client, min_confidence=0.7)

    result = agent.extract_charge_terms(
        document_text=abc_cleaning_contract_text,
        vendor_relationship_id="abc-cleaning-uh-2025",
        source_document_id="abc-cleaning-msa-2025",
        source_document_type="Master Service Agreement",
        metadata={"vendor_id": "abc-cleaning"},
    )

    assert len(result.charge_terms) == 1
    term = result.charge_terms[0]
    assert term.id == "abc-std-cleaning-2025"
    assert term.rate == 2500.0
    assert term.extraction_confidence == 0.98
    assert result.provenance.total_tokens == 200
    assert result.provenance.model == "mock-model"


def test_contract_extraction_agent_rejects_low_confidence(abc_cleaning_contract_text: str) -> None:
    def low_conf_transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": '{"charge_terms": [{"name": "Standard Cleaning", "charge_type": "FIXED_RATE", "rate": 2500, "rate_unit": "month", "extraction_confidence": 0.5}]}',
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=low_conf_transport)
    agent = ContractExtractionAgent(llm_client=client, min_confidence=0.7)

    with pytest.raises(ExtractionError):
        agent.extract_charge_terms(
            document_text=abc_cleaning_contract_text,
            vendor_relationship_id="abc-cleaning-uh-2025",
            source_document_id="abc-cleaning-msa-2025",
        )


def test_contract_extraction_agent_flags_manual_review_for_medium_confidence(
    abc_cleaning_contract_text: str,
) -> None:
    def medium_conf_transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": '{"charge_terms": [{"name": "Standard Cleaning", "charge_type": "FIXED_RATE", "rate": 2500, "rate_unit": "month", "extraction_confidence": 0.75}]}',
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=medium_conf_transport)
    agent = ContractExtractionAgent(llm_client=client, min_confidence=0.7, review_confidence_threshold=0.8)

    result = agent.extract_charge_terms(
        document_text=abc_cleaning_contract_text,
        vendor_relationship_id="abc-cleaning-uh-2025",
        source_document_id="abc-cleaning-msa-2025",
    )

    assert result.manual_review_required is True
    assert any("manual-review threshold" in reason for reason in result.review_reasons)


def test_contract_extraction_agent_marks_amendment_precedence_note(abc_cleaning_contract_text: str) -> None:
    client = LLMClient(provider="openai", model="mock-model", transport=_success_transport)
    agent = ContractExtractionAgent(llm_client=client, min_confidence=0.7)

    result = agent.extract_charge_terms(
        document_text=abc_cleaning_contract_text,
        vendor_relationship_id="abc-cleaning-uh-2025",
        source_document_id="abc-cleaning-amd-1",
        source_document_type="Amendment",
        metadata={"document_type": "Amendment", "amendment_number": 2},
    )

    assert "amendment_term_precedence" in result.charge_terms[0].extraction_notes


def test_contract_extraction_agent_detects_conflicting_duplicate_ids(abc_cleaning_contract_text: str) -> None:
    def conflict_transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": """
            {
              "charge_terms": [
                {
                  "id": "abc-std-cleaning-2025",
                  "name": "Standard Cleaning",
                  "charge_type": "FIXED_RATE",
                  "rate": 2500.0,
                  "rate_unit": "month",
                  "extraction_confidence": 0.95
                },
                {
                  "id": "abc-std-cleaning-2025",
                  "name": "Standard Cleaning",
                  "charge_type": "FIXED_RATE",
                  "rate": 2750.0,
                  "rate_unit": "month",
                  "extraction_confidence": 0.95
                }
              ]
            }
            """,
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=conflict_transport)
    agent = ContractExtractionAgent(llm_client=client, min_confidence=0.7)

    result = agent.extract_charge_terms(
        document_text=abc_cleaning_contract_text,
        vendor_relationship_id="abc-cleaning-uh-2025",
        source_document_id="abc-cleaning-msa-2025",
    )

    assert result.manual_review_required is True
    assert len(result.conflicts) == 1
