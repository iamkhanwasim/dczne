"""
Tests for core/finding_generator.py — Phase 6.1.

Covers:
- generate_line_finding: PASS, REJECT, NEEDS_REVIEW, NO_MATCH cases
- generate_line_finding: variance computation, source_evidence, recommended_action
- generate_invoice_finding: totals, overall_status aggregation
"""

from datetime import date

from models.contract_models import ChargeType
from models.finding_models import FindingStatus, RoutingPath
from core.finding_generator import generate_invoice_finding, generate_line_finding
from models.finding_models import ValidationResult
from tests.factories import (
    make_abc_std_cleaning_term,
    make_charge_term,
    make_invoice,
    make_invoice_line,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _pass_result(name: str) -> ValidationResult:
    return ValidationResult.pass_result(name, reason="ok")


def _fail_result(
    name: str,
    severity: str = "error",
    expected: float = 2500.0,
    actual: float = 2600.0,
) -> ValidationResult:
    return ValidationResult.fail_result(
        name,
        reason="mismatch",
        expected=expected,
        actual=actual,
        variance=actual - expected,
        severity=severity,
    )


# ---------------------------------------------------------------------------
# generate_line_finding — PASS
# ---------------------------------------------------------------------------


def test_generate_line_finding_pass_sets_correct_status() -> None:
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(
        line_number=1,
        description="Standard Cleaning",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2500.0,
    )
    results = [_pass_result("active_term"), _pass_result("line_amount_equals")]

    finding = generate_line_finding(
        term, line, results, invoice_id="INV-001", matching_confidence=0.98
    )

    assert finding.status == FindingStatus.PASS
    assert finding.matched_charge_term_id == term.id
    assert finding.matched_charge_term_name == term.name
    assert finding.matching_confidence == 0.98
    assert finding.amount_invoiced == 2500.0
    assert finding.amount_expected == 2500.0
    assert finding.variance == 0.0
    assert finding.validators_run == ["active_term", "line_amount_equals"]
    assert "active_term" in finding.validator_results
    assert finding.recommended_action == "Approve for payment."


def test_generate_line_finding_pass_embeds_source_evidence() -> None:
    term = make_charge_term(
        name="Standard Cleaning",
        source_document_id="msa-2025",
        source_page=2,
        source_section="Pricing",
    )
    line = make_invoice_line(line_amount=1000.0)
    results = [_pass_result("line_amount_equals")]

    finding = generate_line_finding(term, line, results, invoice_id="INV-001")

    assert "Standard Cleaning" in finding.source_evidence
    assert "p.2" in finding.source_evidence
    assert "Pricing" in finding.source_evidence


# ---------------------------------------------------------------------------
# generate_line_finding — REJECT
# ---------------------------------------------------------------------------


def test_generate_line_finding_reject_on_error_validator() -> None:
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(line_number=1, line_amount=2600.0)
    results = [_pass_result("active_term"), _fail_result("line_amount_equals")]

    finding = generate_line_finding(term, line, results, invoice_id="INV-001")

    assert finding.status == FindingStatus.REJECT
    assert finding.variance == pytest_approx_variance(2600.0 - 2500.0)
    assert "Dispute" in finding.recommended_action


def pytest_approx_variance(v: float) -> float:
    """Thin helper to make the test assertion readable."""
    return v


def test_generate_line_finding_reject_uses_orchestrator_status_if_provided() -> None:
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(line_amount=2500.0)
    # All validators pass, but caller says FAIL — caller wins.
    results = [_pass_result("active_term"), _pass_result("line_amount_equals")]

    finding = generate_line_finding(
        term, line, results, invoice_id="INV-001", orchestrator_status="FAIL"
    )

    assert finding.status == FindingStatus.REJECT


# ---------------------------------------------------------------------------
# generate_line_finding — NEEDS_REVIEW
# ---------------------------------------------------------------------------


def test_generate_line_finding_needs_review_on_warning() -> None:
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(line_amount=2500.0)
    results = [_pass_result("active_term"), _fail_result("precondition_check", severity="warning")]

    finding = generate_line_finding(term, line, results, invoice_id="INV-001")

    assert finding.status == FindingStatus.NEEDS_REVIEW
    assert "manual review" in finding.recommended_action.lower()


# ---------------------------------------------------------------------------
# generate_line_finding — NO_MATCH
# ---------------------------------------------------------------------------


def test_generate_line_finding_no_match_when_term_is_none() -> None:
    line = make_invoice_line(line_number=2, description="Unknown Service", line_amount=500.0)

    finding = generate_line_finding(None, line, [], invoice_id="INV-001")

    assert finding.status == FindingStatus.NO_MATCH
    assert finding.matched_charge_term_id is None
    assert finding.validators_run == []
    assert finding.amount_invoiced == 500.0
    assert finding.variance == 500.0  # full invoiced amount is unreconciled
    assert "escalate" in finding.recommended_action.lower()


# ---------------------------------------------------------------------------
# generate_line_finding — routing path
# ---------------------------------------------------------------------------


def test_generate_line_finding_defaults_to_deep_path() -> None:
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(line_amount=2500.0)
    finding = generate_line_finding(term, line, [], invoice_id="INV-001")
    assert finding.routing_path == RoutingPath.DEEP_PATH


def test_generate_line_finding_fast_path_when_routing_decision_hit(monkeypatch) -> None:
    from models.routing_models import RoutingDecision
    from models.finding_models import RoutingPath

    rd = RoutingDecision(
        invoice_line_id="line-1",
        route=RoutingPath.FAST_PATH,
        fast_path_hit=True,
        cached_charge_term_id="abc-std-cleaning-2025",
    )
    term = make_abc_std_cleaning_term()
    line = make_invoice_line(line_amount=2500.0)

    finding = generate_line_finding(term, line, [], invoice_id="INV-001", routing_decision=rd)
    assert finding.routing_path == RoutingPath.FAST_PATH


# ---------------------------------------------------------------------------
# generate_invoice_finding
# ---------------------------------------------------------------------------


def _make_pass_finding(line_num: int, amount: float, invoice_id: str = "INV-001") -> None:
    from models.finding_models import Finding, FindingStatus, RoutingPath

    return Finding(
        invoice_id=invoice_id,
        line_number=line_num,
        description=f"Line {line_num}",
        status=FindingStatus.PASS,
        amount_invoiced=amount,
        amount_expected=amount,
        variance=0.0,
        routing_path=RoutingPath.DEEP_PATH,
    )


def _make_reject_finding(line_num: int, invoiced: float, expected: float, invoice_id: str = "INV-001"):
    from models.finding_models import Finding, FindingStatus, RoutingPath

    return Finding(
        invoice_id=invoice_id,
        line_number=line_num,
        description=f"Line {line_num}",
        status=FindingStatus.REJECT,
        amount_invoiced=invoiced,
        amount_expected=expected,
        variance=round(invoiced - expected, 2),
        routing_path=RoutingPath.DEEP_PATH,
    )


def test_generate_invoice_finding_all_pass() -> None:
    invoice = make_invoice(
        invoice_id="INV-2025-01",
        contract_id="abc-cleaning-uh-2025",
        lines=[make_invoice_line(line_number=1, line_amount=2500.0)],
        subtotal=2500.0,
        tax_amount=0.0,
        total=2500.0,
    )
    line_findings = [_make_pass_finding(1, 2500.0, "INV-2025-01")]

    inv_finding = generate_invoice_finding(invoice, line_findings, contract_id="abc-cleaning-uh-2025")

    assert inv_finding.invoice_id == "INV-2025-01"
    assert inv_finding.contract_id == "abc-cleaning-uh-2025"
    assert inv_finding.overall_status == FindingStatus.PASS
    assert inv_finding.total_invoiced == 2500.0
    assert inv_finding.total_expected == 2500.0
    assert inv_finding.total_variance == 0.0
    assert len(inv_finding.line_findings) == 1


def test_generate_invoice_finding_reject_propagates_to_invoice() -> None:
    invoice = make_invoice(
        invoice_id="INV-2025-02",
        contract_id="abc-cleaning-uh-2025",
        lines=[
            make_invoice_line(line_number=1, line_amount=2500.0),
            make_invoice_line(line_number=2, line_amount=300.0),
        ],
        subtotal=2800.0,
        tax_amount=0.0,
        total=2800.0,
    )
    line_findings = [
        _make_pass_finding(1, 2500.0, "INV-2025-02"),
        _make_reject_finding(2, 300.0, 200.0, "INV-2025-02"),
    ]

    inv_finding = generate_invoice_finding(invoice, line_findings, contract_id="abc-cleaning-uh-2025")

    assert inv_finding.overall_status == FindingStatus.REJECT
    assert inv_finding.total_invoiced == 2800.0
    assert inv_finding.total_expected == 2700.0
    assert inv_finding.total_variance == 100.0


def test_generate_invoice_finding_no_match_causes_needs_review() -> None:
    from models.finding_models import Finding, FindingStatus, RoutingPath

    invoice = make_invoice(invoice_id="INV-2025-03", contract_id="x")
    no_match = Finding(
        invoice_id="INV-2025-03",
        line_number=1,
        description="Unknown",
        status=FindingStatus.NO_MATCH,
        amount_invoiced=500.0,
        amount_expected=0.0,
        variance=500.0,
        routing_path=RoutingPath.DEEP_PATH,
    )
    pass_f = _make_pass_finding(2, 1000.0, "INV-2025-03")

    inv_finding = generate_invoice_finding(invoice, [no_match, pass_f], contract_id="x")

    assert inv_finding.overall_status == FindingStatus.NEEDS_REVIEW
