from datetime import date

from graph.mock_graph import MockGraph
from graph.ontology_schema import Classes, Props, RDF_TYPE
from graph.prefixes import SCB, uri_for, xsd_decimal, xsd_string
from graph.rdf_generator import contract_to_triples
from models.contract_models import ChargeTerm, ChargeType, VendorRelationship


def _make_vendor_relationship() -> VendorRelationship:
    vr_id = "abc-cleaning-uh-2025"
    return VendorRelationship(
        id=vr_id,
        vendor_id="abc-cleaning",
        vendor_name="ABC Cleaning Services",
        customer_id="uhs",
        customer_name="UHS",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        charge_terms=[
            ChargeTerm(
                id="abc-std-cleaning-2025",
                vendor_relationship_id=vr_id,
                name="Standard Cleaning",
                charge_type=ChargeType.FIXED_RATE,
                rate=2500.0,
                rate_unit="month",
                location_scope=["Building A"],
                effective_date=date(2025, 1, 1),
                renewal_date=date(2025, 12, 31),
            ),
            ChargeTerm(
                id="abc-adhoc-cleaning-2025",
                vendor_relationship_id=vr_id,
                name="After-hours Cleaning",
                charge_type=ChargeType.VARIABLE_RATE,
                rate=150.0,
                rate_unit="hour",
                location_scope=["Building B"],
                effective_date=date(2025, 1, 1),
                renewal_date=date(2025, 6, 30),
            ),
        ],
    )


def test_mock_graph_insert_is_idempotent_and_query_by_subject() -> None:
    repo = MockGraph()
    subject = uri_for("subject-1")
    triple = (subject, Props.name, xsd_string("Example"))

    repo.insert_triples([triple, triple])

    assert repo.triple_count() == 1
    assert repo.query_by_subject(subject) == [triple]


def test_query_by_predicate_object_matches_typed_literal_value() -> None:
    repo = MockGraph()
    subject = uri_for("term-1")
    repo.insert_triples([(subject, Props.rate, xsd_decimal(2500.0))])

    matches_tuple = repo.query_by_predicate_object(Props.rate, xsd_decimal(2500.0))
    matches_plain = repo.query_by_predicate_object(Props.rate, "2500")

    assert len(matches_tuple) == 1
    assert len(matches_plain) == 1


def test_query_charge_terms_filters_by_date_and_location() -> None:
    repo = MockGraph()
    vr = _make_vendor_relationship()
    repo.insert_triples(contract_to_triples(vr))

    all_terms = repo.query_charge_terms("abc-cleaning-uh-2025")
    jan_building_a = repo.query_charge_terms(
        "abc-cleaning-uh-2025", on_date=date(2025, 1, 15), location="Building A"
    )
    aug_building_b = repo.query_charge_terms(
        "abc-cleaning-uh-2025", on_date=date(2025, 8, 1), location="Building B"
    )

    assert len(all_terms) == 2
    assert uri_for("abc-std-cleaning-2025") in jan_building_a
    assert uri_for("abc-adhoc-cleaning-2025") not in aug_building_b


def test_round_trip_contract_triples_and_helpers() -> None:
    repo = MockGraph()
    vr = _make_vendor_relationship()
    triples = contract_to_triples(vr)

    repo.insert_triples(triples)

    vr_uri = uri_for(vr.id)
    term_uri = uri_for("abc-std-cleaning-2025")

    assert repo.subject_exists(vr_uri) is True
    assert repo.get_literal(vr_uri, Props.vendorName) == "ABC Cleaning Services"

    term_type = repo.get_object(term_uri, RDF_TYPE)
    assert term_type == Classes.ChargeTerm

    linked_terms = repo.get_objects(vr_uri, Props.hasChargeTerm)
    assert term_uri in linked_terms


def test_update_delete_and_export() -> None:
    repo = MockGraph()
    s = uri_for("subject-2")
    old = (s, Props.status, xsd_string("draft"))
    new = (s, Props.status, xsd_string("finalized"))
    extra = (s, SCB.customField, xsd_string("value"))

    repo.insert_triples([old, extra])
    repo.update_triple(old, new)

    exported = repo.export_all_triples()
    assert new in exported
    assert old not in exported

    deleted = repo.delete_triples(s)
    assert deleted == 2
    assert repo.subject_exists(s) is False
