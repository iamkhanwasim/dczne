"""
Integration tests for the full invoice reconciliation pipeline — Phase 6.4.

Tests complete end-to-end workflows:
  1. Parse invoice from markdown/YAML
  2. Route each line (fast-path vs. deep-path)
  3. Match invoice lines to contract charge terms
  4. Validate matched terms against invoice data
  5. Generate findings with audit trail
  6. Aggregate findings to invoice level

Scenarios covered:
  - All lines pass (exact match, all validators pass)
  - Rate variance (line amount exceeds expected)
  - Missing supporting documents (pass-through without evidence)
  - Ambiguous line (multiple possible term matches)
"""

from __future__ import annotations

import json
import textwrap
from datetime import date
from typing import Any

import pytest

from core.contract_processor import ContractProcessor
from core.invoice_processor import InvoiceProcessor
from graph.mock_graph import MockGraph
from models.contract_models import ChargeType
from models.finding_models import FindingStatus, RoutingPath
from tests.conftest import load_fixture_json, load_fixture_text
from tests.factories import (
    make_abc_std_cleaning_term,
    make_abc_adhoc_cleaning_term,
    make_abc_restroom_supplies_term,
)
from tests.helpers import (
    approx_equal,
    assert_amounts_match,
)


# ---------------------------------------------------------------------------
# Shared fixtures & helpers
# ---------------------------------------------------------------------------

_ABC_CONTRACT_ID = "abc-cleaning-uh-2025"


def _make_stub_extraction_agent(terms):
    """Factory for a mock extraction agent that returns fixed terms."""

    class _Stub:
        def extract_charge_terms(self, *args, **kwargs):
            return type(
                "ExtractionResult",
                (),
                {
                    "charge_terms": terms,
                    "conflicts": [],
                    "manual_review_required": False,
                    "review_reasons": [],
                },
            )()

    return _Stub()


@pytest.fixture
def finalized_abc_contract():
    """Fixture: finalized ABC Cleaning contract with standard, adhoc, & supply terms."""
    graph = MockGraph()
    terms = [
        make_abc_std_cleaning_term(),
        make_abc_adhoc_cleaning_term(),
        make_abc_restroom_supplies_term(),
    ]
    stub = _make_stub_extraction_agent(terms)
    cp = ContractProcessor(graph_repository=graph, extraction_agent=stub)

    contract_yaml = textwrap.dedent(f"""
        contract_id: {_ABC_CONTRACT_ID}
        vendor_id: abc-cleaning
        vendor_name: ABC Cleaning Services
        customer_name: UHS
        customer_id: uhs
        effective_date: 2025-01-01
        renewal_date: 2026-01-01
        document_type: Master Service Agreement
    """).strip()

    ingest = cp.ingest_contract(vendor_id="abc-cleaning", documents=[contract_yaml])
    cp.finalize_contract(ingest.contract_id)

    return cp, ingest.contract_id, graph


@pytest.fixture
def invoice_processor_with_abc_contract(finalized_abc_contract):
    """Fixture: InvoiceProcessor connected to finalized ABC contract."""
    cp, contract_id, graph = finalized_abc_contract
    processor = InvoiceProcessor(contract_processor=cp)
    return processor, contract_id


# ---------------------------------------------------------------------------
# Scenario 1: All Lines Pass (Happy Path)
# ---------------------------------------------------------------------------


def test_pipeline_all_lines_pass(invoice_processor_with_abc_contract, abc_invoice_pass_text):
    """
    End-to-end: Parse → Route → Match → Validate → Find for invoice_pass fixture.

    Expected:
    - All 3 lines match contract terms
    - All validators pass
    - Overall invoice status = PASS
    - No variance
    - Audit trail populated
    """
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # Overall status
    assert finding.overall_status == FindingStatus.PASS, (
        f"Expected overall_status=PASS, got {finding.overall_status}. "
        f"Details: invoice={finding.invoice_id}"
    )

    # Line count
    assert len(finding.line_findings) == 3, f"Expected 3 lines, got {len(finding.line_findings)}"

    # Line 1: Standard Cleaning
    line1 = finding.line_findings[0]
    assert line1.line_number == 1
    assert line1.status == FindingStatus.PASS
    assert line1.matched_charge_term_id == "abc-std-cleaning-2025"
    assert approx_equal(line1.amount_invoiced, 2500.00, tolerance=0.01)
    assert approx_equal(line1.amount_expected, 2500.00, tolerance=0.01)
    assert approx_equal(line1.variance, 0.00, tolerance=0.01)
    assert "active_term" in line1.validators_run
    assert "line_amount_equals" in line1.validators_run

    # Line 2: After-hours Cleaning
    line2 = finding.line_findings[1]
    assert line2.line_number == 2
    assert line2.status == FindingStatus.PASS
    assert line2.matched_charge_term_id == "abc-adhoc-cleaning-2025"
    assert approx_equal(line2.amount_invoiced, 300.00, tolerance=0.01)
    assert approx_equal(line2.amount_expected, 300.00, tolerance=0.01)
    assert approx_equal(line2.variance, 0.00, tolerance=0.01)
    assert "precondition_check" in line2.validators_run

    # Line 3: Restroom Supplies
    line3 = finding.line_findings[2]
    assert line3.line_number == 3
    assert line3.status == FindingStatus.PASS
    assert line3.matched_charge_term_id == "abc-restroom-supplies-2025"
    assert approx_equal(line3.amount_invoiced, 200.00, tolerance=0.01)
    assert approx_equal(line3.amount_expected, 200.00, tolerance=0.01)
    assert approx_equal(line3.variance, 0.00, tolerance=0.01)

    # Invoice totals (including tax)
    assert finding.invoice_id == "abc-inv-2025-02-001"
    assert finding.contract_id == contract_id
    assert approx_equal(finding.total_invoiced, 3255.00, tolerance=0.01)
    assert approx_equal(finding.total_expected, 3255.00, tolerance=0.01)
    assert approx_equal(finding.total_variance, 0.00, tolerance=0.01)

    # Promotion summary present
    assert result.promotion_summary is not None


def test_pipeline_all_lines_pass_matches_expected_findings(invoice_processor_with_abc_contract, abc_invoice_pass_text):
    """Verify that the processing output matches the expected_findings_pass.json structure."""
    processor, contract_id = invoice_processor_with_abc_contract
    expected = load_fixture_json("expected_findings_pass.json")

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # Overall status matches
    assert finding.overall_status.value.upper() == expected["overall_status"].upper()

    # Totals match
    assert_amounts_match(
        finding.total_invoiced,
        expected["total_invoiced"],
        label="total_invoiced",
        tolerance=0.01,
    )
    assert_amounts_match(
        finding.total_expected,
        expected["total_expected"],
        label="total_expected",
        tolerance=0.01,
    )

    # Line count matches
    assert len(finding.line_findings) == len(expected["line_findings"])

    # Each line matches expected
    for i, (line_result, line_expected) in enumerate(
        zip(finding.line_findings, expected["line_findings"])
    ):
        assert line_result.line_number == line_expected["line_number"], f"Line {i+1} number mismatch"
        assert line_result.status == FindingStatus.PASS or str(line_result.status) == line_expected["status"], (
            f"Line {i+1} status mismatch: {line_result.status} vs {line_expected['status']}"
        )


# ---------------------------------------------------------------------------
# Scenario 2: Rate Variance (One Line Exceeds Contract Rate)
# ---------------------------------------------------------------------------


def test_pipeline_rate_variance(invoice_processor_with_abc_contract, abc_invoice_variance_text):
    """
    End-to-end: Invoice with rate variance on one line (after-hours $175/hr vs. $150/hr).

    Expected:
    - Lines 1 & 3 pass
    - Line 2 variance detected
    - Overall status = VARIANCE or NEEDS_REVIEW
    - Variance amount captured in findings
    - Audit trail shows which validator detected variance
    """
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_variance_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # Overall status should not be PASS (could be VARIANCE or NEEDS_REVIEW)
    assert finding.overall_status != FindingStatus.PASS, (
        f"Expected variance invoice to NOT pass, got {finding.overall_status}"
    )

    # Should have 3 lines
    assert len(finding.line_findings) == 3

    # Line 1 should pass (standard cleaning unchanged)
    line1 = finding.line_findings[0]
    assert line1.line_number == 1
    assert line1.status == FindingStatus.PASS
    assert approx_equal(line1.variance, 0.00, tolerance=0.01)

    # Line 2 should have variance (after-hours rate increased)
    line2 = finding.line_findings[1]
    assert line2.line_number == 2
    # Line 2 is $525 (3 hr * $175/hr) vs expected $450 (3 hr * $150/hr)
    # Variance = $525 - $450 = $75
    assert 0.0 < line2.variance < 100.0, f"Expected positive variance, got {line2.variance}"
    assert not approx_equal(line2.variance, 0.00, tolerance=0.01)

    # Line 3 should pass (supplies unchanged)
    line3 = finding.line_findings[2]
    assert line3.line_number == 3
    assert line3.status == FindingStatus.PASS
    assert approx_equal(line3.variance, 0.00, tolerance=0.01)

    # Total variance should match sum of line variances
    total_variance = sum(lf.variance for lf in finding.line_findings)
    assert approx_equal(finding.total_variance, total_variance, tolerance=0.01)


def test_pipeline_variance_invoice_totals_computed(invoice_processor_with_abc_contract, abc_invoice_variance_text):
    """Verify that invoice totals are correctly computed for variance scenario."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_variance_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # The variance invoice has:
    # Line 1: $2,500 (std cleaning)
    # Line 2: $525 (3 hr * $175/hr after-hours, variance scenario - expected $300)
    # Line 3: $200 (supplies)
    # Subtotal: $3,225
    # Tax 8.5%: $274.13
    # Total: $3,499.13

    # Verify totals were computed
    assert finding.total_invoiced > 0, "total_invoiced should be > 0"
    assert finding.total_expected > 0, "total_expected should be > 0"
    # The variance invoice has higher invoiced than expected due to line 2 rate variance
    assert finding.total_invoiced > finding.total_expected, "variance invoice should have higher invoiced than expected"


# ---------------------------------------------------------------------------
# Scenario 3: Missing Supporting Documents (PASS_THROUGH without evidence)
# ---------------------------------------------------------------------------


def test_pipeline_missing_supporting_docs(invoice_processor_with_abc_contract, abc_invoice_missing_docs_text):
    """
    End-to-end: Invoice with pass-through line missing supporting doc evidence.

    Expected:
    - Lines 1 & 3 pass
    - Line 3 (supplies) fails precondition_check due to missing receipt
    - Overall status = NEEDS_REVIEW
    - Finding shows which precondition failed
    - Audit trail indicates missing document
    """
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_missing_docs_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # Not all lines should pass
    passed_lines = [lf for lf in finding.line_findings if lf.status == FindingStatus.PASS]
    assert len(passed_lines) < 3, "Expected at least one line to fail due to missing docs"

    # There should be at least one line with failing validators or warnings
    lines_with_issues = [lf for lf in finding.line_findings if lf.has_errors or lf.has_warnings]
    assert len(lines_with_issues) > 0, "Expected at least one line with errors or warnings"


# ---------------------------------------------------------------------------
# Scenario 4: Ambiguous Line (Multiple Possible Matches)
# ---------------------------------------------------------------------------


def test_pipeline_ambiguous_line(invoice_processor_with_abc_contract, abc_invoice_ambiguous_text):
    """
    End-to-end: Invoice with line description matching multiple contract terms.

    Expected:
    - Either top-confidence match is used, or ambiguity is flagged
    - Finding includes matching_confidence and alternatives (if tracked)
    - Audit trail shows matching results
    """
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_ambiguous_text,
    )

    # Access the invoice_finding wrapped in the result
    finding = result.invoice_finding

    # Should process without error
    assert finding is not None
    assert len(finding.line_findings) > 0

    # Check if ambiguous line has lower confidence or is flagged
    for line_finding in finding.line_findings:
        if line_finding.status == FindingStatus.NEEDS_REVIEW:
            # Low-confidence or ambiguous match
            assert line_finding.matching_confidence is not None
            assert line_finding.matching_confidence < 0.90


# ---------------------------------------------------------------------------
# Comprehensive Pipeline Validations
# ---------------------------------------------------------------------------


def test_pipeline_audit_trail_populated_for_all_lines(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify audit trail is populated for every line finding."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        assert line_finding.audit_trail_id is not None or line_finding.created_at is not None, (
            f"Line {line_finding.line_number}: no audit trail info"
        )


def test_pipeline_validator_results_present_for_passing_lines(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify validator results are captured for passing lines."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        if line_finding.status == FindingStatus.PASS:
            assert len(line_finding.validators_run) > 0, (
                f"Line {line_finding.line_number}: PASS status but no validators_run"
            )
            # Each validator in validators_run should appear in validator_results
            # (validator_results structure depends on implementation)


def test_pipeline_matching_confidence_in_reasonable_range(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify matching_confidence values are in valid range [0.0, 1.0]."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        assert line_finding.matching_confidence is not None, (
            f"Line {line_finding.line_number}: matching_confidence is None"
        )
        assert 0.0 <= line_finding.matching_confidence <= 1.0, (
            f"Line {line_finding.line_number}: confidence {line_finding.matching_confidence} out of range"
        )


def test_pipeline_amount_fields_populated(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify all amount fields are populated in line findings."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        assert line_finding.amount_invoiced is not None, (
            f"Line {line_finding.line_number}: amount_invoiced is None"
        )
        assert line_finding.amount_expected is not None, (
            f"Line {line_finding.line_number}: amount_expected is None"
        )
        assert line_finding.variance is not None, (
            f"Line {line_finding.line_number}: variance is None"
        )
        # Variance should be invoiced - expected
        expected_variance = line_finding.amount_invoiced - line_finding.amount_expected
        assert approx_equal(line_finding.variance, expected_variance, tolerance=0.01), (
            f"Line {line_finding.line_number}: variance {line_finding.variance} != "
            f"computed {expected_variance}"
        )


def test_pipeline_invoice_total_equals_sum_of_lines(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify invoice-level totals equal sum of line-level totals."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    # Sum of line amounts should equal invoice total
    sum_invoiced = sum(lf.amount_invoiced for lf in finding.line_findings)
    # Note: invoice total includes tax, so this is a loose comparison
    # Just verify invoice total is in reasonable range
    assert finding.total_invoiced >= sum_invoiced, (
        f"Invoice total {finding.total_invoiced} < sum of lines {sum_invoiced}"
    )


def test_pipeline_routing_path_captured(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify routing path (FAST_PATH vs DEEP_PATH) is captured for each line."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        assert hasattr(line_finding, "routing_path"), (
            f"Line {line_finding.line_number}: routing_path attribute missing"
        )
        if line_finding.routing_path is not None:
            # Should be either FAST_PATH or DEEP_PATH
            valid_paths = [RoutingPath.FAST_PATH, RoutingPath.DEEP_PATH]
            assert line_finding.routing_path in valid_paths, (
                f"Line {line_finding.line_number}: routing_path {line_finding.routing_path} invalid"
            )


def test_pipeline_matched_term_id_populated(
    invoice_processor_with_abc_contract, abc_invoice_pass_text
):
    """Verify matched_charge_term_id is populated for all lines."""
    processor, contract_id = invoice_processor_with_abc_contract

    result = processor.process_invoice(
        contract_id=contract_id,
        invoice_text=abc_invoice_pass_text,
    )

    finding = result.invoice_finding

    for line_finding in finding.line_findings:
        assert line_finding.matched_charge_term_id is not None, (
            f"Line {line_finding.line_number}: matched_charge_term_id is None"
        )
        assert len(line_finding.matched_charge_term_id) > 0, (
            f"Line {line_finding.line_number}: matched_charge_term_id is empty"
        )


# ---------------------------------------------------------------------------
# Error Handling & Edge Cases
# ---------------------------------------------------------------------------


def test_pipeline_rejects_invoice_for_nonexistent_contract(invoice_processor_with_abc_contract):
    """Verify pipeline raises error when contract_id does not exist."""
    processor, _ = invoice_processor_with_abc_contract

    with pytest.raises(Exception):  # Should raise ContractNotFoundError or similar
        processor.process_invoice(
            contract_id="nonexistent-contract-id",
            invoice_text="invoice text here",
        )


def test_pipeline_rejects_unparseable_invoice_text(invoice_processor_with_abc_contract):
    """Verify pipeline raises error for unparseable invoice text."""
    processor, contract_id = invoice_processor_with_abc_contract

    with pytest.raises(Exception):  # Should raise ParseError or similar
        processor.process_invoice(
            contract_id=contract_id,
            invoice_text="this is not a valid invoice; no structure at all",
        )
