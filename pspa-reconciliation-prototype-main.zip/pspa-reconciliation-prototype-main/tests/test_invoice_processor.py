"""
Tests for data_parsers/invoice_parser.py and core/invoice_processor.py — Phase 6.2.

Covers:
- Invoice parser: YAML format, markdown front-matter + table, error cases
- InvoiceProcessor: happy path, variance/reject, no-match, error guards, fast-path promotion
"""

from __future__ import annotations

import textwrap
from datetime import date

import pytest

from core.contract_processor import ContractProcessor
from core.invoice_processor import InvoiceProcessor
from data_parsers.invoice_parser import parse_invoice
from graph.mock_graph import MockGraph
from models.contract_models import ChargeType
from models.finding_models import FindingStatus, RoutingPath
from tests.factories import (
    make_abc_std_cleaning_term,
    make_abc_adhoc_cleaning_term,
    make_charge_term,
    make_invoice,
    make_invoice_line,
)
from utils.errors import ContractNotFinalizedError, ContractNotFoundError, ParseError


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

_ABC_CONTRACT_ID = "abc-cleaning-uh-2025"

SIMPLE_YAML_INVOICE = textwrap.dedent("""
    invoice_id: INV-TEST-001
    vendor_id: abc-cleaning
    vendor_name: ABC Cleaning Services
    customer_name: UHS
    invoice_date: 2025-02-01
    contract_id: abc-cleaning-uh-2025
    lines:
      - line_number: 1
        description: Standard Cleaning
        quantity: 1.0
        unit: month
        unit_rate: 2500.00
        line_amount: 2500.00
    subtotal: 2500.00
    tax_rate: 0.085
    tax_amount: 212.50
    total: 2712.50
""").strip()

VARIANCE_YAML_INVOICE = textwrap.dedent("""
    invoice_id: INV-TEST-002
    vendor_id: abc-cleaning
    vendor_name: ABC Cleaning Services
    customer_name: UHS
    invoice_date: 2025-02-01
    contract_id: abc-cleaning-uh-2025
    lines:
      - line_number: 1
        description: Standard Cleaning
        quantity: 1.0
        unit: month
        unit_rate: 2750.00
        line_amount: 2750.00
    subtotal: 2750.00
    total: 2750.00
""").strip()

UNKNOWN_SERVICE_YAML_INVOICE = textwrap.dedent("""
    invoice_id: INV-TEST-003
    vendor_id: abc-cleaning
    vendor_name: ABC Cleaning Services
    customer_name: UHS
    invoice_date: 2025-02-01
    contract_id: abc-cleaning-uh-2025
    lines:
      - line_number: 1
        description: PowerWashing Service XYZ999
        quantity: 1.0
        unit: event
        unit_rate: 9999.00
        line_amount: 9999.00
    subtotal: 9999.00
    total: 9999.00
""").strip()

def _make_stub_extraction_agent(terms):
    """Return a stub that always returns the given terms."""
    class _Stub:
        def extract_charge_terms(self, *args, **kwargs):
            return type(
                "ExtractionResult",
                (),
                {
                    "charge_terms": terms,
                    "conflicts": [],
                    "manual_review_required": False,
                    "review_reasons": [],
                },
            )()
    return _Stub()


def _build_finalized_processor():
    """
    Return a (ContractProcessor, str) with a finalized ABC Cleaning contract.

    Uses a stub extraction agent so no LLM is called.
    """
    graph = MockGraph()
    terms = [make_abc_std_cleaning_term(), make_abc_adhoc_cleaning_term()]
    stub = _make_stub_extraction_agent(terms)
    cp = ContractProcessor(graph_repository=graph, extraction_agent=stub)

    contract_yaml = textwrap.dedent(f"""
        contract_id: {_ABC_CONTRACT_ID}
        vendor_id: abc-cleaning
        vendor_name: ABC Cleaning Services
        customer_name: UHS
        customer_id: uhs
        effective_date: 2025-01-01
        renewal_date: 2026-01-01
        document_type: Master Service Agreement
    """).strip()

    ingest = cp.ingest_contract(vendor_id="abc-cleaning", documents=[contract_yaml])
    cp.finalize_contract(ingest.contract_id)
    return cp, ingest.contract_id


# ---------------------------------------------------------------------------
# Invoice parser — YAML format
# ---------------------------------------------------------------------------


def test_parse_invoice_yaml_parses_required_fields() -> None:
    invoice = parse_invoice(SIMPLE_YAML_INVOICE)

    assert invoice.invoice_id == "INV-TEST-001"
    assert invoice.vendor_id == "abc-cleaning"
    assert invoice.customer_name == "UHS"
    assert invoice.invoice_date == date(2025, 2, 1)
    assert invoice.contract_id == _ABC_CONTRACT_ID
    assert len(invoice.lines) == 1
    line = invoice.lines[0]
    assert line.line_number == 1
    assert line.description == "Standard Cleaning"
    assert line.quantity == 1.0
    assert line.unit_rate == 2500.0
    assert line.line_amount == 2500.0
    assert invoice.subtotal == 2500.0
    assert invoice.tax_rate == pytest.approx(0.085)
    assert invoice.total == 2712.50


def test_parse_invoice_yaml_missing_required_field_raises() -> None:
    bad_yaml = textwrap.dedent("""
        vendor_id: abc
        vendor_name: ABC
        customer_name: UHS
        invoice_date: 2025-01-01
        contract_id: abc-contract
        lines:
          - line_number: 1
            description: Service
            quantity: 1.0
            unit: month
            unit_rate: 100.0
            line_amount: 100.0
    """).strip()
    with pytest.raises(ParseError, match="invoice_id"):
        parse_invoice(bad_yaml)


def test_parse_invoice_yaml_no_lines_raises() -> None:
    bad_yaml = textwrap.dedent("""
        invoice_id: INV-001
        vendor_id: abc
        vendor_name: ABC
        customer_name: UHS
        invoice_date: 2025-01-01
        contract_id: abc-contract
        lines: []
    """).strip()
    with pytest.raises(ParseError, match="line"):
        parse_invoice(bad_yaml)


# ---------------------------------------------------------------------------
# Invoice parser — markdown front-matter + table
# ---------------------------------------------------------------------------


def test_parse_invoice_markdown_front_matter_and_table(abc_invoice_pass_text: str) -> None:
    invoice = parse_invoice(abc_invoice_pass_text, source_name="abc_cleaning_invoice_pass.md")

    assert invoice.invoice_id == "abc-inv-2025-02-001"
    assert invoice.contract_id == _ABC_CONTRACT_ID
    assert invoice.invoice_date == date(2025, 2, 1)
    assert len(invoice.lines) == 3

    line1, line2, line3 = invoice.lines
    assert line1.description == "Standard Cleaning – January 2025"
    assert line1.quantity == 1.0
    assert line1.unit_rate == pytest.approx(2500.0)
    assert line1.line_amount == pytest.approx(2500.0)

    assert line2.quantity == pytest.approx(2.0)
    assert line2.unit_rate == pytest.approx(150.0)
    assert line2.line_amount == pytest.approx(300.0)

    assert line3.unit_rate == pytest.approx(200.0)

    # Totals parsed from markdown bold labels
    assert invoice.subtotal == pytest.approx(3000.0)
    assert invoice.tax_rate == pytest.approx(0.085)
    assert invoice.tax_amount == pytest.approx(255.0)
    assert invoice.total == pytest.approx(3255.0)


# ---------------------------------------------------------------------------
# InvoiceProcessor — guard conditions
# ---------------------------------------------------------------------------


def test_process_invoice_raises_when_contract_not_found() -> None:
    cp, _ = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)
    with pytest.raises(ContractNotFoundError):
        ip.process_invoice("nonexistent-contract-id", SIMPLE_YAML_INVOICE)


def test_process_invoice_raises_when_contract_not_finalized() -> None:
    graph = MockGraph()
    terms = [make_abc_std_cleaning_term()]
    stub = _make_stub_extraction_agent(terms)
    cp = ContractProcessor(graph_repository=graph, extraction_agent=stub)
    contract_yaml = textwrap.dedent(f"""
        contract_id: {_ABC_CONTRACT_ID}
        vendor_id: abc-cleaning
        vendor_name: ABC Cleaning Services
        customer_name: UHS
        customer_id: uhs
        effective_date: 2025-01-01
        renewal_date: 2026-01-01
        document_type: Master Service Agreement
    """).strip()
    cp.ingest_contract(vendor_id="abc-cleaning", documents=[contract_yaml])
    # NOT finalized

    ip = InvoiceProcessor(contract_processor=cp)
    with pytest.raises(ContractNotFinalizedError):
        ip.process_invoice(_ABC_CONTRACT_ID, SIMPLE_YAML_INVOICE)


# ---------------------------------------------------------------------------
# InvoiceProcessor — happy path (FIXED_RATE, all pass)
# ---------------------------------------------------------------------------


def test_process_invoice_all_pass_returns_pass_finding() -> None:
    cp, contract_id = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)

    result = ip.process_invoice(contract_id, SIMPLE_YAML_INVOICE)

    assert result.lines_processed == 1
    assert result.lines_no_match == 0
    inv_finding = result.invoice_finding
    assert inv_finding.invoice_id == "INV-TEST-001"
    assert inv_finding.contract_id == contract_id
    assert inv_finding.overall_status == FindingStatus.PASS
    # total_invoiced = invoice.total (including tax: 2500 + 212.50)
    assert inv_finding.total_invoiced == pytest.approx(2712.50)
    # total_expected = expected line amounts + invoice tax_amount
    assert inv_finding.total_expected == pytest.approx(2712.50)
    assert inv_finding.total_variance == pytest.approx(0.0)

    line_finding = inv_finding.line_findings[0]
    assert line_finding.status == FindingStatus.PASS
    assert line_finding.matched_charge_term_id == "abc-std-cleaning-2025"
    assert line_finding.variance == pytest.approx(0.0)
    assert "active_term" in line_finding.validators_run
    assert "line_amount_equals" in line_finding.validators_run


# ---------------------------------------------------------------------------
# InvoiceProcessor — variance → REJECT
# ---------------------------------------------------------------------------


def test_process_invoice_rate_variance_gives_reject() -> None:
    cp, contract_id = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)

    result = ip.process_invoice(contract_id, VARIANCE_YAML_INVOICE)

    inv_finding = result.invoice_finding
    assert inv_finding.overall_status == FindingStatus.REJECT

    line_finding = inv_finding.line_findings[0]
    assert line_finding.status == FindingStatus.REJECT
    assert line_finding.variance == pytest.approx(250.0)  # 2750 - 2500
    assert line_finding.amount_expected == pytest.approx(2500.0)
    assert line_finding.amount_invoiced == pytest.approx(2750.0)
    assert "Dispute" in line_finding.recommended_action


# ---------------------------------------------------------------------------
# InvoiceProcessor — unknown service → NO_MATCH
# ---------------------------------------------------------------------------


def test_process_invoice_unmatched_line_gives_no_match() -> None:
    cp, contract_id = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)

    result = ip.process_invoice(contract_id, UNKNOWN_SERVICE_YAML_INVOICE)

    assert result.lines_no_match == 1
    inv_finding = result.invoice_finding
    assert inv_finding.overall_status == FindingStatus.NEEDS_REVIEW

    line_finding = inv_finding.line_findings[0]
    assert line_finding.status == FindingStatus.NO_MATCH
    assert line_finding.matched_charge_term_id is None
    assert "escalate" in line_finding.recommended_action.lower()


def test_process_parsed_invoice_returns_all_lines_and_match_determinations() -> None:
    cp, contract_id = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)

    parsed_invoice = make_invoice(
        invoice_id="INV-TEST-004",
        vendor_id="abc-cleaning",
        vendor_name="ABC Cleaning Services",
        customer_name="UHS",
        contract_id=contract_id,
        lines=[
            make_invoice_line(
                line_number=1,
                description="Standard Cleaning",
                quantity=1.0,
                unit="month",
                unit_rate=2500.0,
                line_amount=2500.0,
            ),
            make_invoice_line(
                line_number=2,
                description="Unknown Custom Service",
                quantity=1.0,
                unit="event",
                unit_rate=125.0,
                line_amount=125.0,
            ),
        ],
        subtotal=2625.0,
        tax_rate=0.0,
        tax_amount=0.0,
        total=2625.0,
    )
    result = ip.process_parsed_invoice(contract_id=contract_id, invoice=parsed_invoice)

    assert result.lines_processed == 2
    assert len(result.invoice_finding.line_findings) == 2
    assert result.lines_no_match == 1

    by_line = {f.line_number: f for f in result.invoice_finding.line_findings}
    assert by_line[1].status == FindingStatus.PASS
    assert by_line[1].matched_charge_term_id == "abc-std-cleaning-2025"
    assert by_line[2].status == FindingStatus.NO_MATCH
    assert by_line[2].matched_charge_term_id is None


# ---------------------------------------------------------------------------
# InvoiceProcessor — fast path promoted on second identical invoice
# ---------------------------------------------------------------------------


def test_process_invoice_second_run_uses_fast_path() -> None:
    cp, contract_id = _build_finalized_processor()
    ip = InvoiceProcessor(contract_processor=cp)

    # First run: deep path, high confidence → cache written by route_line
    result1 = ip.process_invoice(contract_id, SIMPLE_YAML_INVOICE)
    assert result1.lines_deep_path == 1
    assert result1.lines_fast_path == 0

    # Second run with identical description: should hit the cache
    result2 = ip.process_invoice(contract_id, SIMPLE_YAML_INVOICE.replace("INV-TEST-001", "INV-TEST-001B"))
    assert result2.lines_fast_path == 1
    assert result2.lines_deep_path == 0
    assert result2.invoice_finding.overall_status == FindingStatus.PASS
