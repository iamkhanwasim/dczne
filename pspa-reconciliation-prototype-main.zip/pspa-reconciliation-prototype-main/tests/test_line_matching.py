from datetime import date

from matching.matching_engine import match_line_to_term
from tests.factories import make_charge_term, make_invoice_line


def test_match_line_exact_name_gets_high_confidence() -> None:
    line = make_invoice_line(
        line_number=1,
        description="Standard Cleaning - January 2025",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2500.0,
    )
    candidates = [
        make_charge_term(
            id="abc-std-cleaning-2025",
            name="Standard Cleaning",
            rate=2500.0,
            rate_unit="month",
        ),
        make_charge_term(
            id="abc-other-2025",
            name="Window Cleaning",
            rate=300.0,
            rate_unit="event",
        ),
    ]

    result = match_line_to_term(line, candidates)

    assert result.is_matched is True
    assert result.selected is not None
    assert result.selected.charge_term.id == "abc-std-cleaning-2025"
    assert result.confidence >= 0.90
    assert result.ambiguous is False
    assert result.llm_needed is False


def test_match_line_near_tie_flags_ambiguous() -> None:
    line = make_invoice_line(
        line_number=2,
        description="Standard Cleaning Service",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2500.0,
    )
    candidates = [
        make_charge_term(id="term-a", name="Standard Cleaning", rate=2500.0, rate_unit="month"),
        make_charge_term(id="term-b", name="Standard Cleaning Service", rate=2500.0, rate_unit="month"),
    ]

    result = match_line_to_term(line, candidates)

    assert result.is_matched is True
    assert result.selected is not None
    assert result.ambiguous is True
    assert result.llm_needed is True


def test_match_line_low_confidence_returns_no_selection() -> None:
    line = make_invoice_line(
        line_number=3,
        description="Unrelated Managed Security Service",
        quantity=1.0,
        unit="month",
        unit_rate=9999.0,
        line_amount=9999.0,
    )
    candidates = [
        make_charge_term(
            id="cleaning-term",
            name="Restroom Supplies",
            rate=200.0,
            rate_unit="month",
            effective_date=date(2025, 1, 1),
            renewal_date=date(2026, 1, 1),
        )
    ]

    result = match_line_to_term(line, candidates)

    assert result.is_matched is False
    assert result.selected is None
    assert result.ambiguous is True
    assert result.llm_needed is True
    assert len(result.alternatives) == 1
