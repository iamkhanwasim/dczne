import os

import pytest

from llm.llm_client import LLMClient


pytestmark = pytest.mark.live


def _require_live_env() -> None:
    required = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_API_VERSION",
        "AZURE_OPENAI_DEPLOYMENT",
    ]
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        pytest.skip(f"Missing live Azure OpenAI env vars: {', '.join(missing)}")


def test_live_azure_openai_complete_text_smoke() -> None:
    _require_live_env()

    client = LLMClient(provider="azure-apim")
    response = client.complete_text(
        user_prompt="Reply with exactly: LIVE_OK",
        system_prompt="You are a concise assistant.",
        temperature=0.0,
        max_tokens=16,
    )

    assert response.provider == "azure-apim"
    assert isinstance(response.text, str)
    assert len(response.text.strip()) > 0
    assert response.usage.total_tokens >= 0
