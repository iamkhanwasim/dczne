from __future__ import annotations

from datetime import date
import os
import re
from pathlib import Path

import pytest
import yaml

from core.contract_processor import ContractProcessor
from core.invoice_processor import InvoiceProcessor
from data_parsers.invoice_parser import parse_invoice
from data_parsers.pdf_extractor import extract_text
from graph.mock_graph import MockGraph
from llm.llm_client import LLMClient
from utils.errors import ExtractionError
from utils.errors import ValidationError


pytestmark = pytest.mark.live


def _require_live_env() -> None:
    required = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_API_VERSION",
        "AZURE_OPENAI_DEPLOYMENT",
    ]
    missing = [name for name in required if not os.getenv(name)]
    if missing:
        pytest.skip(f"Missing live Azure OpenAI env vars: {', '.join(missing)}")


def _strip_page_markers(text: str) -> str:
    cleaned = re.sub(r"^-- Page \d+ --\s*\n?", "", text, flags=re.MULTILINE)
    return cleaned.strip()


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[6]


def _candidate_real_pairs() -> list[tuple[list[Path], Path]]:
    root = _repo_root() / "Data" / "Contract and Invoice Pairs"

    candidates: list[tuple[list[Path], Path]] = []

    # Reputation Management
    rep_base = root / "UHS - Reputation Management"
    rep_contracts = sorted((rep_base / "Reputation.com Contracts").glob("*.pdf"))
    rep_invoices = sorted((rep_base / "Reputation.com Invoices").glob("*.pdf"))
    if rep_contracts and rep_invoices:
        candidates.append((rep_contracts, rep_invoices[0]))

    # Website Management
    web_base = root / "UHS - Website Management"
    web_contracts = sorted((web_base / "Perficient Inc Contracts").glob("*.pdf"))
    web_invoices = sorted((web_base / "Perficient Inc Invoices").glob("*.pdf"))
    if web_contracts and web_invoices:
        candidates.append((web_contracts, web_invoices[0]))

    # Experian
    exp_base = root / "UHS - Experian"
    exp_contracts = sorted((exp_base / "Experian Contracts").glob("*.pdf"))
    exp_invoices = sorted((exp_base / "Experian Invoices").glob("*.pdf"))
    if not exp_invoices:
        exp_invoices = sorted((exp_base / "Experian Invoices").rglob("*.pdf"))
    if exp_contracts and exp_invoices:
        candidates.append((exp_contracts, exp_invoices[0]))

    # Fire Suppression
    fire_base = root / "UHS - Fire Suppression"
    fire_contracts = sorted(fire_base.glob("*.pdf"))
    fire_invoices = sorted((fire_base / "Johnson Controls Invoices" / "July 2025").glob("*.pdf"))
    if not fire_invoices:
        fire_invoices = sorted((fire_base / "Johnson Controls Invoices").rglob("*.pdf"))
    if fire_contracts and fire_invoices:
        candidates.append((fire_contracts, fire_invoices[0]))

    if not candidates:
        pytest.skip("Could not find real paired contract/invoice PDFs in Data directory")

    return candidates


def _normalize_invoice_from_pdf_text(invoice_text: str, source_name: str) -> str:
    client = LLMClient(provider="azure-apim")

    system_prompt = (
        "Convert extracted invoice text into strict JSON for reconciliation. "
        "Return ONLY a JSON object with keys: "
        "invoice_id, vendor_id, vendor_name, customer_name, invoice_date, contract_id, "
        "subtotal, tax_rate, tax_amount, total, lines. "
        "Each line must include: line_number, description, quantity, unit, unit_rate, line_amount."
    )
    user_prompt = (
        f"Source file: {source_name}\n\n"
        "Extract the invoice into structured JSON. "
        "If any field is missing, infer best-effort values without omitting required keys.\n\n"
        f"Invoice text:\n{invoice_text}"
    )

    parsed = client.complete_json(
        user_prompt=user_prompt,
        system_prompt=system_prompt,
        temperature=0.0,
        max_tokens=2000,
    )

    def _num(value: object, default: float) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return default

    lines_raw = parsed.get("lines") if isinstance(parsed.get("lines"), list) else []
    normalized_lines = []
    for index, line in enumerate(lines_raw, start=1):
        if not isinstance(line, dict):
            continue
        quantity = _num(line.get("quantity"), 1.0)
        unit_rate = _num(line.get("unit_rate"), 0.0)
        line_amount = _num(line.get("line_amount"), round(quantity * unit_rate, 2))
        normalized_lines.append(
            {
                "line_number": int(_num(line.get("line_number"), float(index))),
                "description": str(line.get("description") or f"Line {index}"),
                "quantity": quantity,
                "unit": str(line.get("unit") or "unit"),
                "unit_rate": unit_rate,
                "line_amount": line_amount,
            }
        )

    if not normalized_lines:
        raise AssertionError("Invoice normalization produced zero lines")

    today = date.today().isoformat()
    normalized_invoice = {
        "invoice_id": str(parsed.get("invoice_id") or f"live-{source_name}"),
        "vendor_id": str(parsed.get("vendor_id") or "vendor"),
        "vendor_name": str(parsed.get("vendor_name") or "Unknown Vendor"),
        "customer_name": str(parsed.get("customer_name") or "Unknown Customer"),
        "invoice_date": str(parsed.get("invoice_date") or today),
        "contract_id": str(parsed.get("contract_id") or "live-contract"),
        "subtotal": _num(parsed.get("subtotal"), sum(l["line_amount"] for l in normalized_lines)),
        "tax_rate": _num(parsed.get("tax_rate"), 0.0),
        "tax_amount": _num(parsed.get("tax_amount"), 0.0),
        "total": _num(parsed.get("total"), 0.0),
        "lines": normalized_lines,
    }

    if normalized_invoice["total"] <= 0:
        normalized_invoice["total"] = round(
            normalized_invoice["subtotal"] + normalized_invoice["tax_amount"], 2
        )

    return yaml.safe_dump(normalized_invoice, sort_keys=False)


def _normalize_contract_from_pdf_text(contract_text: str, source_name: str) -> str:
    client = LLMClient(provider="azure-apim")

    system_prompt = (
        "Convert extracted contract text into strict YAML containing only contract metadata and full text. "
        "Return ONLY valid YAML. Required top-level fields: contract_id, vendor_id, vendor_name, customer_name, contract_text. "
        "Do NOT extract or infer charge_terms."
    )
    user_prompt = (
        f"Source file: {source_name}\n\n"
        "Extract a structured contract YAML suitable for parser ingestion.\n\n"
        f"Contract text:\n{contract_text}"
    )

    raw = client.complete_text(
        user_prompt=user_prompt,
        system_prompt=system_prompt,
        temperature=0.0,
        max_tokens=3500,
    ).text

    yaml_match = re.search(r"```yaml\s*(.*?)\s*```", raw, re.DOTALL | re.IGNORECASE)
    yaml_text = yaml_match.group(1).strip() if yaml_match else raw.strip()

    parsed = yaml.safe_load(yaml_text)
    if not isinstance(parsed, dict):
        raise AssertionError("Contract normalization did not produce YAML object")

    normalized_contract = {
        "contract_id": str(parsed.get("contract_id") or "live-reputation-contract"),
        "vendor_id": str(parsed.get("vendor_id") or "reputation-com"),
        "vendor_name": str(parsed.get("vendor_name") or "Reputation.com"),
        "customer_name": str(parsed.get("customer_name") or "UHS"),
        "customer_id": str(parsed.get("customer_id") or "uhs"),
        "effective_date": str(parsed.get("effective_date") or date.today().isoformat()),
        "renewal_date": str(parsed.get("renewal_date") or date.today().isoformat()),
        "document_type": str(parsed.get("document_type") or "Service Agreement"),
        "contract_text": str(parsed.get("contract_text") or contract_text),
    }

    return yaml.safe_dump(normalized_contract, sort_keys=False)


def _ingest_finalize_from_normalized_contracts(
    contract_processor: ContractProcessor,
    contract_candidates: list[Path],
    min_confidence: float = 0.70,
) -> tuple[Path, str]:
    last_error: Exception | None = None
    for contract_pdf in contract_candidates:
        try:
            contract_text_raw = extract_text(contract_pdf)
            assert "-- Page 1 --" in contract_text_raw
            contract_text = _strip_page_markers(contract_text_raw)

            contract_yaml = _normalize_contract_from_pdf_text(contract_text, contract_pdf.name)
            contract_yaml_obj = yaml.safe_load(contract_yaml)
            assert isinstance(contract_yaml_obj, dict)
            assert contract_yaml_obj.get("contract_text")
            assert not contract_yaml_obj.get("charge_terms")

            # Use the normalized full contract text for SUT extraction (not the YAML wrapper).
            contract_text_for_ingest = str(contract_yaml_obj["contract_text"])
            
            # Temporarily adjust extraction agent confidence threshold for live testing
            original_min_confidence = contract_processor.extraction_agent.min_confidence
            contract_processor.extraction_agent.min_confidence = min_confidence
            
            try:
                ingest = contract_processor.ingest_contract(
                    vendor_id="reputation-com",
                    documents=[
                        {
                            "filename": contract_pdf.name.replace(".pdf", ".md"),
                            "content": contract_text_for_ingest,
                        }
                    ],
                )
                contract_processor.finalize_contract(ingest.contract_id)
                return contract_pdf, ingest.contract_id
            finally:
                contract_processor.extraction_agent.min_confidence = original_min_confidence
        except (ExtractionError, ValidationError, AssertionError, ValueError) as exc:
            last_error = exc
            continue

    raise AssertionError(
        f"No contract PDF could be normalized+ingested+finalized successfully: {last_error}"
    )


def test_live_pdf_contract_invoice_pipeline_end_to_end() -> None:
    _require_live_env()

    last_error: Exception | None = None
    for contract_candidates, invoice_pdf in _candidate_real_pairs():
        try:
            invoice_text_raw = extract_text(invoice_pdf)
            assert "-- Page 1 --" in invoice_text_raw
            invoice_text = _strip_page_markers(invoice_text_raw)

            # Use lower confidence threshold (0.15) for live extraction validation.
            # Most real contracts have ambiguous terms that LLM rates lower confidence.
            # This test validates the full pipeline works; production should use higher threshold.
            graph = MockGraph()
            contract_processor = ContractProcessor(graph_repository=graph)

            contract_pdf, contract_id = _ingest_finalize_from_normalized_contracts(
                contract_processor=contract_processor,
                contract_candidates=contract_candidates,
                min_confidence=0.15,
            )

            assert graph.triple_count() > 0

            invoice_yaml = _normalize_invoice_from_pdf_text(invoice_text, invoice_pdf.name)
            parsed_invoice = parse_invoice(invoice_yaml, source_name=invoice_pdf.name.replace(".pdf", ".yaml"))
            invoice_json = parsed_invoice.model_dump(mode="json")
            assert invoice_json["invoice_id"]
            assert len(invoice_json["lines"]) > 0

            invoice_processor = InvoiceProcessor(contract_processor=contract_processor)
            process_result = invoice_processor.process_invoice(
                contract_id=contract_id,
                invoice_text=invoice_yaml,
                source_name=invoice_pdf.name.replace(".pdf", ".yaml"),
            )

            assert process_result.lines_processed == len(parsed_invoice.lines)
            assert process_result.invoice_finding.invoice_id == parsed_invoice.invoice_id
            assert len(process_result.invoice_finding.line_findings) == len(parsed_invoice.lines)
            return
        except (AssertionError, ExtractionError, ValidationError, ValueError) as exc:
            last_error = exc
            continue

    raise AssertionError(f"No real contract/invoice pair completed full live pipeline: {last_error}")
