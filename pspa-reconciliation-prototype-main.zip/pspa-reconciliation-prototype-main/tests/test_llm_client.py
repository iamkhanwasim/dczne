from typing import Any, Dict, List

import pytest

from llm.llm_client import LLMClient
from utils.errors import ExtractionError


def test_llm_client_complete_json_parses_object_from_text() -> None:
    def transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": '{"charge_terms": []}',
            "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            "raw": {"id": "mock-1"},
        }

    client = LLMClient(provider="openai", model="mock-model", transport=transport)
    parsed, response = client.complete_json_response(user_prompt="hello", system_prompt="json")

    assert parsed == {"charge_terms": []}
    assert response.usage.total_tokens == 15


def test_llm_client_complete_json_parses_embedded_json() -> None:
    def transport(**_: Any) -> Dict[str, Any]:
        return {
            "text": "Result:\n```json\n{\"charge_terms\": []}\n```",
            "usage": {},
            "raw": None,
        }

    client = LLMClient(provider="openai", model="mock-model", transport=transport)
    parsed = client.complete_json(user_prompt="extract", system_prompt="json")
    assert parsed["charge_terms"] == []


def test_llm_client_retries_then_succeeds() -> None:
    calls: List[int] = []

    def transport(**_: Any) -> Dict[str, Any]:
        calls.append(1)
        if len(calls) < 3:
            raise RuntimeError("temporary")
        return {
            "text": '{"charge_terms": []}',
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
            "raw": None,
        }

    client = LLMClient(
        provider="openai",
        model="mock-model",
        transport=transport,
        max_retries=3,
        sleep_fn=lambda _: None,
    )
    parsed = client.complete_json(user_prompt="extract", system_prompt="json")

    assert parsed["charge_terms"] == []
    assert len(calls) == 3


def test_llm_client_raises_after_retries() -> None:
    def transport(**_: Any) -> Dict[str, Any]:
        raise RuntimeError("always fail")

    client = LLMClient(
        provider="openai",
        model="mock-model",
        transport=transport,
        max_retries=2,
        sleep_fn=lambda _: None,
    )

    with pytest.raises(ExtractionError):
        client.complete_text(user_prompt="hello", system_prompt="world")


def test_llm_client_honors_retry_after_hint_in_backoff() -> None:
    observed_sleeps: List[float] = []

    def transport(**_: Any) -> Dict[str, Any]:
        raise ExtractionError(
            "Azure APIM request failed: 429 Client Error: Too Many Requests for url: "
            "https://example [retry_after=5]"
        )

    client = LLMClient(
        provider="openai",
        model="mock-model",
        transport=transport,
        max_retries=2,
        sleep_fn=lambda seconds: observed_sleeps.append(seconds),
    )

    with pytest.raises(ExtractionError):
        client.complete_text(user_prompt="hello", system_prompt="world")

    assert len(observed_sleeps) == 1
    assert observed_sleeps[0] >= 5.0


def test_llm_client_notifies_retry_observer() -> None:
    observed: List[tuple[float, int, int, str]] = []

    def transport(**_: Any) -> Dict[str, Any]:
        raise RuntimeError("temporary")

    def retry_observer(wait_seconds: float, attempt: int, max_attempts: int, exc: Exception) -> None:
        observed.append((wait_seconds, attempt, max_attempts, str(exc)))

    client = LLMClient(
        provider="openai",
        model="mock-model",
        transport=transport,
        max_retries=2,
        sleep_fn=lambda _: None,
        retry_observer=retry_observer,
    )

    with pytest.raises(ExtractionError):
        client.complete_text(user_prompt="hello", system_prompt="world")

    assert len(observed) == 1
    wait_seconds, attempt, max_attempts, message = observed[0]
    assert wait_seconds > 0
    assert attempt == 1
    assert max_attempts == 2
    assert "temporary" in message
