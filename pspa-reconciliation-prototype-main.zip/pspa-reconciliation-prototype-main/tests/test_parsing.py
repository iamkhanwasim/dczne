from data_parsers.markdown_parser import parse_markdown
from data_parsers.parser_registry import DocumentFormat, detect_format, parse_document
from data_parsers.yaml_parser import parse_yaml
from utils.errors import ParseError


def test_markdown_parser_extracts_frontmatter_sections_and_tables(abc_cleaning_contract_text: str) -> None:
    parsed = parse_markdown(abc_cleaning_contract_text, source_name="abc_cleaning_contract.md")

    assert parsed.metadata["contract_id"] == "abc-cleaning-uh-2025"
    assert parsed.structured_fields["effective_date"] == "2025-01-01"
    assert len(parsed.sections) >= 4
    assert any(section.title == "3. Pricing" for section in parsed.sections)

    assert len(parsed.tables) >= 1
    pricing_table = parsed.tables[0]
    assert "Service Type" in pricing_table.headers
    assert len(pricing_table.rows) == 3
    assert pricing_table.rows[0]["Service Type"] == "Standard Cleaning"
    assert pricing_table.start_line > 1
    assert pricing_table.end_line >= pricing_table.start_line

    pricing_section = next(section for section in parsed.sections if section.title == "3. Pricing")
    assert pricing_section.start_line > 1
    assert pricing_section.end_line >= pricing_section.start_line
    assert "Invoices are issued" in pricing_section.content


def test_markdown_parser_extracts_invoice_dates_and_amount_mentions(abc_invoice_pass_text: str) -> None:
    parsed = parse_markdown(abc_invoice_pass_text, source_name="abc_invoice_pass.md")

    assert parsed.metadata["invoice_id"] == "abc-inv-2025-02-001"
    assert parsed.structured_fields["invoice_date"] == "2025-02-01"
    assert parsed.structured_fields["due_date"] == "2025-03-03"
    assert len(parsed.structured_fields.get("amount_mentions", [])) > 0


def test_yaml_parser_extracts_charge_terms() -> None:
    yaml_text = """
contract_id: acme-facilities-2025
vendor_id: acme-facilities
vendor_name: ACME Facilities
customer_name: UHS
charge_terms:
  - id: acme-monthly-cleaning
    name: Monthly Cleaning
    charge_type: FIXED_RATE
    rate: 1250.00
    rate_unit: month
    effective_date: 2025-01-01
    renewal_date: 2025-12-31
"""
    parsed = parse_yaml(yaml_text, source_name="acme_contract.yaml")

    assert parsed.data["contract_id"] == "acme-facilities-2025"
    assert len(parsed.charge_terms) == 1
    assert parsed.charge_terms[0].id == "acme-monthly-cleaning"
    assert parsed.charge_terms[0].rate == 1250.00


def test_yaml_parser_requires_core_fields() -> None:
    yaml_text = """
vendor_id: acme-facilities
vendor_name: ACME Facilities
"""
    try:
        parse_yaml(yaml_text, source_name="invalid_contract.yaml")
        assert False, "Expected ParseError"
    except ParseError as exc:
        assert "Missing required fields" in str(exc)


def test_registry_detects_by_extension_and_content(abc_cleaning_contract_text: str) -> None:
    detected_md = detect_format(abc_cleaning_contract_text, source_name="contract.md")
    assert detected_md == DocumentFormat.MARKDOWN

    yaml_text = """
contract_id: xyz-2025
vendor_id: xyz
vendor_name: XYZ Services
customer_name: UHS
"""
    detected_yaml = detect_format(yaml_text, source_name="contract.yaml")
    assert detected_yaml == DocumentFormat.YAML


def test_registry_parse_document_dispatches_correctly(abc_cleaning_contract_text: str) -> None:
    parsed_md = parse_document(abc_cleaning_contract_text, source_name="contract.md")
    assert hasattr(parsed_md, "sections")

    yaml_text = """
contract_id: xyz-2025
vendor_id: xyz
vendor_name: XYZ Services
customer_name: UHS
charge_terms: []
"""
    parsed_yaml = parse_document(yaml_text, source_name="contract.yaml")
    assert hasattr(parsed_yaml, "charge_terms")
