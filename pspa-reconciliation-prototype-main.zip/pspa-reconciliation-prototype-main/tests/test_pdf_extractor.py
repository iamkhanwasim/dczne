"""
Tests for PDF extraction layer.

Tests extract_text, render_pages, and other utilities using synthetic PDFs.
"""

from pathlib import Path
from io import BytesIO

import fitz
import pytest

from data_parsers.pdf_extractor import (
    extract_text,
    render_pages,
    extract_text_and_pages,
    get_page_count,
    get_pdf_metadata,
)


@pytest.fixture
def simple_pdf():
    """Create a simple synthetic PDF for testing."""
    doc = fitz.open()

    # Page 1
    page = doc.new_page(width=612, height=792)
    page.insert_text((50, 50), "Test Document\nPage 1", fontsize=14)

    # Page 2
    page = doc.new_page(width=612, height=792)
    page.insert_text((50, 50), "Test Document\nPage 2", fontsize=14)

    # Save to bytes
    pdf_bytes = doc.write()
    doc.close()

    return pdf_bytes


@pytest.fixture
def temp_pdf_file(simple_pdf, tmp_path):
    """Write PDF to temporary file."""
    pdf_file = tmp_path / "test.pdf"
    pdf_file.write_bytes(simple_pdf)
    return pdf_file


def test_extract_text_basic(temp_pdf_file):
    """Test basic text extraction."""
    text = extract_text(temp_pdf_file)
    assert isinstance(text, str)
    assert "Test Document" in text
    assert "Page 1" in text
    assert "Page 2" in text
    assert "-- Page 1 --" in text
    assert "-- Page 2 --" in text


def test_extract_text_missing_file():
    """Test extraction with missing file."""
    with pytest.raises(FileNotFoundError):
        extract_text("/nonexistent/path/file.pdf")


def test_render_pages_basic(temp_pdf_file):
    """Test page rendering."""
    images = render_pages(temp_pdf_file, dpi=150)
    assert isinstance(images, list)
    assert len(images) == 2
    assert all(isinstance(img, bytes) for img in images)
    assert all(img.startswith(b"\x89PNG") for img in images)


def test_render_pages_missing_file():
    """Test rendering with missing file."""
    with pytest.raises(FileNotFoundError):
        render_pages("/nonexistent/path/file.pdf")


def test_extract_text_and_pages(temp_pdf_file):
    """Test combined extraction."""
    text, images = extract_text_and_pages(temp_pdf_file, dpi=150)
    assert isinstance(text, str)
    assert "Test Document" in text
    assert isinstance(images, list)
    assert len(images) == 2


def test_get_page_count(temp_pdf_file):
    """Test page count."""
    count = get_page_count(temp_pdf_file)
    assert count == 2


def test_get_pdf_metadata(temp_pdf_file):
    """Test metadata extraction."""
    metadata = get_pdf_metadata(temp_pdf_file)
    assert isinstance(metadata, dict)
    assert "page_count" in metadata
    assert metadata["page_count"] == 2
    assert "file_size" in metadata
    assert metadata["file_size"] > 0


def test_render_pages_dpi_variation(temp_pdf_file):
    """Test rendering at different DPI levels."""
    images_150 = render_pages(temp_pdf_file, dpi=150)
    images_300 = render_pages(temp_pdf_file, dpi=300)

    # Higher DPI should produce larger images (roughly 4x for 2x DPI)
    assert len(images_300[0]) > len(images_150[0])


def test_extract_text_preserves_page_structure(temp_pdf_file):
    """Test that page structure is preserved in extracted text."""
    text = extract_text(temp_pdf_file)
    lines = text.split("\n")
    assert any("-- Page 1 --" in line for line in lines)
    assert any("-- Page 2 --" in line for line in lines)

    # Page 1 content should come before Page 2 content
    page1_idx = next(i for i, line in enumerate(lines) if "-- Page 1 --" in line)
    page2_idx = next(i for i, line in enumerate(lines) if "-- Page 2 --" in line)
    assert page1_idx < page2_idx
