from core.promotion_engine import PromotionEngine
from models.finding_models import Finding, FindingStatus, RoutingPath
from storage.fast_path_cache import FastPathCache


def _finding(
    *,
    status: FindingStatus = FindingStatus.PASS,
    routing_path: RoutingPath = RoutingPath.DEEP_PATH,
    confidence: float = 0.95,
    description: str = "Standard Cleaning",
    matched_charge_term_id: str | None = "abc-std-cleaning-2025",
) -> Finding:
    return Finding(
        invoice_id="INV-001",
        line_number=1,
        description=description,
        status=status,
        routing_path=routing_path,
        matching_confidence=confidence,
        matched_charge_term_id=matched_charge_term_id,
        validators_run=["active_term", "line_amount_equals"],
    )


def test_check_for_promotion_promotes_eligible_deep_pass() -> None:
    cache = FastPathCache(ttl_days=30)
    engine = PromotionEngine(cache)

    record = engine.check_for_promotion(
        contract_id="abc-cleaning-uh-2025",
        finding=_finding(),
    )

    assert record.promoted is True
    assert record.reason == "promoted"
    cached = cache.get("abc-cleaning-uh-2025", "Standard Cleaning")
    assert cached is not None
    assert cached.charge_term_id == "abc-std-cleaning-2025"

    metrics = engine.get_rule_metrics()
    assert metrics["abc-cleaning-uh-2025::standard cleaning"].promotions == 1
    assert engine.get_marked_terms_for_ruleset() == ["abc-std-cleaning-2025"]


def test_check_for_promotion_rejects_when_below_threshold() -> None:
    cache = FastPathCache(ttl_days=30)
    engine = PromotionEngine(cache)

    record = engine.check_for_promotion(
        contract_id="abc-cleaning-uh-2025",
        finding=_finding(confidence=0.90),
    )

    assert record.promoted is False
    assert record.reason == "confidence_too_low"
    assert cache.get("abc-cleaning-uh-2025", "Standard Cleaning") is None


def test_record_rule_firing_tracks_success_rate_for_fast_path() -> None:
    cache = FastPathCache(ttl_days=30)
    engine = PromotionEngine(cache)

    engine.record_rule_firing(
        contract_id="abc-cleaning-uh-2025",
        finding=_finding(routing_path=RoutingPath.FAST_PATH, status=FindingStatus.PASS),
    )
    engine.record_rule_firing(
        contract_id="abc-cleaning-uh-2025",
        finding=_finding(routing_path=RoutingPath.FAST_PATH, status=FindingStatus.REJECT),
    )

    metrics = engine.get_rule_metrics()
    rule = metrics["abc-cleaning-uh-2025::standard cleaning"]
    assert rule.rule_fires == 2
    assert rule.rule_passes == 1
    assert rule.success_rate == 0.5
