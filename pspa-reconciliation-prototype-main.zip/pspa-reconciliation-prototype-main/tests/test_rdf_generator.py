from datetime import date

from core.contract_processor import ContractProcessor
from graph.mock_graph import MockGraph
from graph.ontology_schema import Props
from graph.prefixes import SCB, uri_for, xsd_decimal, xsd_integer, xsd_string
from graph.rdf_generator import amendment_to_triples, charge_term_to_triples, contract_to_triples
from models.contract_models import Amendment, ChargeTerm, ChargeType, SourceCitation, VendorRelationship
from tests.helpers import assert_triple_exists


def _make_term(term_id: str, name: str, rate: float) -> ChargeTerm:
    return ChargeTerm(
        id=term_id,
        vendor_relationship_id="abc-cleaning-uh-2025",
        name=name,
        charge_type=ChargeType.FIXED_RATE,
        rate=rate,
        rate_unit="month",
        rate_currency="USD",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        extraction_confidence=0.96,
        extraction_notes="Extracted from pricing table row 1",
        source=SourceCitation(
            document_id="abc-contract-msa",
            document_type="MSA",
            page=2,
            section="Pricing",
            span_text="Standard Cleaning | Month | $2,500",
        ),
    )


def test_contract_to_triples_includes_extraction_provenance_and_source_citations() -> None:
    term = _make_term("abc-std-cleaning-2025", "Standard Cleaning", 2500.0)
    vr = VendorRelationship(
        id="abc-cleaning-uh-2025",
        vendor_id="abc-cleaning",
        vendor_name="ABC Cleaning Services",
        customer_id="uhs",
        customer_name="UHS",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
        charge_terms=[term],
        status="indexed",
    )

    triples = contract_to_triples(vr)
    term_uri = uri_for(term.id)

    assert_triple_exists(triples, term_uri, Props.sourceDocument, xsd_string("abc-contract-msa"))
    assert_triple_exists(triples, term_uri, Props.sourcePage, xsd_integer(2))
    assert_triple_exists(triples, term_uri, Props.sourceSection, xsd_string("Pricing"))
    assert_triple_exists(
        triples,
        term_uri,
        Props.spanText,
        xsd_string("Standard Cleaning | Month | $2,500"),
    )
    assert_triple_exists(
        triples,
        term_uri,
        Props.extractionNotes,
        xsd_string("Extracted from pricing table row 1"),
    )
    assert_triple_exists(triples, term_uri, Props.extractionConfidence, xsd_decimal(0.96))


def test_amendment_to_triples_contains_amendment_number_predicate() -> None:
    amended_term = _make_term("abc-std-cleaning-2025", "Standard Cleaning", 2750.0)
    amendment = Amendment(
        id="abc-cleaning-amd-2",
        base_contract_id="abc-cleaning-uh-2025",
        amendment_number=2,
        effective_date=date(2025, 6, 1),
        modified_terms=[amended_term],
    )

    triples = amendment_to_triples(amendment)
    amendment_uri = uri_for(amendment.id)

    assert_triple_exists(triples, amendment_uri, SCB.amendmentNumber, xsd_integer(2))


def test_charge_term_to_triples_captures_type_specific_fields() -> None:
    term = ChargeTerm(
        id="abc-pass-through-2025",
        vendor_relationship_id="abc-cleaning-uh-2025",
        name="Restroom Supplies",
        charge_type=ChargeType.PASS_THROUGH,
        rate=200.0,
        rate_unit="month",
        rate_currency="USD",
        location_scope=["Building A"],
        preconditions=["Receipt required"],
        is_passthrough=True,
        requires_cost_evidence=True,
        max_amount=200.0,
        extraction_confidence=0.97,
    )

    triples = charge_term_to_triples(term)
    term_uri = uri_for(term.id)

    assert_triple_exists(triples, term_uri, Props.chargeType, xsd_string("PASS_THROUGH"))
    assert_triple_exists(triples, term_uri, Props.rate, xsd_decimal(200.0))
    assert_triple_exists(triples, term_uri, Props.passthrough, ("true", "http://www.w3.org/2001/XMLSchema#boolean"))
    assert_triple_exists(triples, term_uri, Props.requiresCostEvidence, ("true", "http://www.w3.org/2001/XMLSchema#boolean"))
    assert_triple_exists(triples, term_uri, Props.maxAmount, xsd_decimal(200.0))
    assert_triple_exists(triples, term_uri, Props.precondition, xsd_string("Receipt required"))


def test_finalize_contract_persists_contract_to_triples_output(abc_cleaning_contract_text: str) -> None:
    class StubExtractionAgent:
        def extract_charge_terms(self, *args, **kwargs):
            term = _make_term("abc-std-cleaning-2025", "Standard Cleaning", 2500.0)
            return type("ExtractionResult", (), {"charge_terms": [term], "conflicts": [], "manual_review_required": False, "review_reasons": []})()

    graph = MockGraph()
    processor = ContractProcessor(graph_repository=graph, extraction_agent=StubExtractionAgent())

    ingest = processor.ingest_contract(vendor_id="abc-cleaning", documents=[abc_cleaning_contract_text])
    contract = processor.get_contract(ingest.contract_id)
    finalize = processor.finalize_contract(contract.id)
    expected_triples = contract_to_triples(contract)
    exported = graph.export_all_triples()

    assert finalize.triples_inserted == len(expected_triples)
    for triple in expected_triples:
        assert triple in exported
