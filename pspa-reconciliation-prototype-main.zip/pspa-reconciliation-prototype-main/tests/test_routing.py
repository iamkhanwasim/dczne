from datetime import date

from core.routing_engine import route_line
from graph.mock_graph import MockGraph
from graph.rdf_generator import contract_to_triples
from models.finding_models import RoutingPath
from storage.fast_path_cache import FastPathCache
from tests.factories import make_charge_term, make_invoice_line, make_vendor_relationship


def _prepare_graph() -> MockGraph:
    repo = MockGraph()
    contract = make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        charge_terms=[
            make_charge_term(
                id="std-cleaning",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Standard Cleaning",
                rate=2500.0,
                rate_unit="month",
                effective_date=date(2025, 1, 1),
                renewal_date=date(2026, 1, 1),
            ),
            make_charge_term(
                id="after-hours",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="After-hours Cleaning",
                rate=150.0,
                rate_unit="hour",
                effective_date=date(2025, 1, 1),
                renewal_date=date(2026, 1, 1),
            ),
        ],
    )
    repo.insert_triples(contract_to_triples(contract))
    return repo


def test_routing_cache_miss_then_hit() -> None:
    repo = _prepare_graph()
    cache = FastPathCache(ttl_days=30)
    line = make_invoice_line(
        line_number=1,
        description="Standard Cleaning - January 2025",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2500.0,
    )

    first = route_line(
        invoice_line=line,
        contract_id="abc-cleaning-uh-2025",
        fast_path_cache=cache,
        graph_repo=repo,
        invoice_date=date(2025, 2, 1),
    )
    second = route_line(
        invoice_line=line,
        contract_id="abc-cleaning-uh-2025",
        fast_path_cache=cache,
        graph_repo=repo,
        invoice_date=date(2025, 2, 1),
    )

    assert first.route == RoutingPath.DEEP_PATH
    assert first.fast_path_hit is False
    assert first.match_result is not None
    assert first.match_result.selected is not None
    assert first.match_result.selected.charge_term.id == "std-cleaning"

    assert second.route == RoutingPath.FAST_PATH
    assert second.fast_path_hit is True
    assert second.cached_charge_term_id == "std-cleaning"


def test_routing_sets_llm_needed_for_ambiguous_line() -> None:
    repo = MockGraph()
    contract = make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        charge_terms=[
            make_charge_term(
                id="term-a",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Standard Cleaning",
                rate=2500.0,
                rate_unit="month",
            ),
            make_charge_term(
                id="term-b",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Standard Cleaning Service",
                rate=2500.0,
                rate_unit="month",
            ),
        ],
    )
    repo.insert_triples(contract_to_triples(contract))

    decision = route_line(
        invoice_line=make_invoice_line(
            line_number=2,
            description="Standard Cleaning Service",
            quantity=1.0,
            unit="month",
            unit_rate=2500.0,
            line_amount=2500.0,
        ),
        contract_id="abc-cleaning-uh-2025",
        fast_path_cache=FastPathCache(ttl_days=30),
        graph_repo=repo,
        invoice_date=date(2025, 2, 1),
    )

    assert decision.route == RoutingPath.DEEP_PATH
    assert decision.fast_path_hit is False
    assert decision.match_result is not None
    assert decision.match_result.ambiguous is True
    assert decision.match_result.llm_needed is True


def test_fast_path_cache_ttl_expiration() -> None:
    repo = _prepare_graph()
    cache = FastPathCache(ttl_days=1)
    line = make_invoice_line(
        line_number=3,
        description="After-hours Cleaning",
        quantity=2.0,
        unit="hour",
        unit_rate=150.0,
        line_amount=300.0,
    )

    route_line(
        invoice_line=line,
        contract_id="abc-cleaning-uh-2025",
        fast_path_cache=cache,
        graph_repo=repo,
        invoice_date=date(2025, 2, 1),
    )
    cache.force_age("abc-cleaning-uh-2025", "After-hours Cleaning", days=2)

    expired_lookup = cache.get("abc-cleaning-uh-2025", "After-hours Cleaning")
    assert expired_lookup is None
