from datetime import date

import pytest

from graph.mock_graph import MockGraph
from graph.rdf_generator import contract_to_triples
from matching.term_retriever import retrieve_terms_for_contract
from tests.factories import make_charge_term, make_vendor_relationship
from utils.errors import ContractNotFoundError


def test_retrieve_terms_for_contract_filters_by_date() -> None:
    repo = MockGraph()
    contract = make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        charge_terms=[
            make_charge_term(
                id="active-term",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Active Service",
                effective_date=date(2025, 1, 1),
                renewal_date=date(2025, 12, 31),
            ),
            make_charge_term(
                id="expired-term",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Expired Service",
                effective_date=date(2024, 1, 1),
                renewal_date=date(2024, 12, 31),
            ),
        ],
    )
    repo.insert_triples(contract_to_triples(contract))

    terms = retrieve_terms_for_contract(
        contract_id="abc-cleaning-uh-2025",
        invoice_date=date(2025, 6, 1),
        graph_repo=repo,
    )

    assert [term.id for term in terms] == ["active-term"]


def test_retrieve_terms_for_contract_filters_by_location() -> None:
    repo = MockGraph()
    contract = make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        charge_terms=[
            make_charge_term(
                id="building-a",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Building A Service",
                location_scope=["Building A"],
            ),
            make_charge_term(
                id="building-b",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Building B Service",
                location_scope=["Building B"],
            ),
        ],
    )
    repo.insert_triples(contract_to_triples(contract))

    terms = retrieve_terms_for_contract(
        contract_id="abc-cleaning-uh-2025",
        invoice_date=date(2025, 2, 1),
        graph_repo=repo,
        location="Building A, Suite 100",
    )

    assert [term.id for term in terms] == ["building-a"]


def test_retrieve_terms_for_unknown_contract_raises() -> None:
    repo = MockGraph()

    with pytest.raises(ContractNotFoundError):
        retrieve_terms_for_contract(
            contract_id="missing-contract",
            invoice_date=date(2025, 2, 1),
            graph_repo=repo,
        )
