from datetime import date

from models.contract_models import ChargeType
from tests.factories import make_charge_term, make_invoice_line, make_supporting_doc
from validators.orchestrator import determine_line_status, validate_line
from validators.validator_registry import ValidatorRegistry


def test_validate_line_fixed_rate_happy_path() -> None:
    term = make_charge_term(
        charge_type=ChargeType.FIXED_RATE,
        rate=2500.0,
        rate_unit="month",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
    )
    line = make_invoice_line(
        description="Standard Cleaning",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2500.0,
    )

    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 1),
        customer_name="UHS",
        location="NY",
        tax_rate=0.085,
    )

    names = [result.validator_name for result in results]
    assert names == ["active_term", "line_amount_equals", "tax_allowed"]
    assert determine_line_status(results) == "PASS"


def test_validate_line_skips_tax_when_arithmetic_fails() -> None:
    term = make_charge_term(
        charge_type=ChargeType.FIXED_RATE,
        rate=2500.0,
        rate_unit="month",
        effective_date=date(2025, 1, 1),
        renewal_date=date(2026, 1, 1),
    )
    line = make_invoice_line(
        description="Standard Cleaning",
        quantity=1.0,
        unit="month",
        unit_rate=2500.0,
        line_amount=2600.0,
    )

    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 1),
        customer_name="UHS",
        location="NY",
        tax_rate=0.085,
    )

    line_amount_result = next(result for result in results if result.validator_name == "line_amount_equals")
    tax_result = next(result for result in results if result.validator_name == "tax_allowed")

    assert line_amount_result.passed is False
    assert tax_result.passed is True
    assert "Skipped because line_amount_equals failed" in tax_result.reason
    assert determine_line_status(results) == "FAIL"


def test_validate_line_short_circuits_when_active_term_fails() -> None:
    term = make_charge_term(
        charge_type=ChargeType.FIXED_RATE,
        effective_date=date(2025, 1, 1),
        renewal_date=date(2025, 1, 31),
    )
    line = make_invoice_line(
        description="Expired Service",
        quantity=1.0,
        unit="month",
        unit_rate=1000.0,
        line_amount=1000.0,
    )

    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 15),
    )

    assert len(results) == 1
    assert results[0].validator_name == "active_term"
    assert results[0].passed is False


def test_validate_line_pass_through_uses_evidence_validator() -> None:
    term = make_charge_term(
        charge_type=ChargeType.PASS_THROUGH,
        is_passthrough=True,
        requires_cost_evidence=True,
        rate=200.0,
        rate_unit="month",
    )
    line = make_invoice_line(
        description="Restroom Supplies",
        quantity=1.0,
        unit="month",
        unit_rate=200.0,
        line_amount=200.0,
        supporting_docs=[make_supporting_doc(doc_type="receipt", reference="RS-019", amount=200.0)],
    )

    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 1),
    )

    names = [result.validator_name for result in results]
    assert names == ["active_term", "line_amount_equals", "pass_through_requires_cost_evidence"]
    assert determine_line_status(results) == "PASS"


def test_validate_line_registry_override_changes_dispatch() -> None:
    term = make_charge_term(charge_type=ChargeType.FIXED_RATE)
    line = make_invoice_line(line_amount=1000.0, unit_rate=1000.0)

    registry = ValidatorRegistry()
    registry.set_validators_for_charge_type(ChargeType.FIXED_RATE, ["active_term", "precondition_check"])

    term = term.model_copy(update={"preconditions": ["PO required"]})
    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 1),
        validator_registry=registry,
    )

    names = [result.validator_name for result in results]
    assert names == ["active_term", "precondition_check"]
    assert determine_line_status(results) == "FAIL"


def test_determine_line_status_conditional() -> None:
    term = make_charge_term(charge_type=ChargeType.SUBSCRIPTION).model_copy(
        update={"included_quantity": None, "overage_rate": None}
    )
    line = make_invoice_line(
        description="Subscription Service",
        quantity=2.0,
        unit="month",
        unit_rate=1000.0,
        line_amount=2000.0,
    )

    results = validate_line(
        matched_charge_term=term,
        invoice_line=line,
        invoice_date=date(2025, 2, 1),
    )

    assert any((not result.passed) and result.severity == "warning" for result in results)
    assert determine_line_status(results) == "CONDITIONAL"
