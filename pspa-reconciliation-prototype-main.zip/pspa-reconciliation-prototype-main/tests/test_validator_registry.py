from datetime import date

from core.routing_engine import route_line
from graph.mock_graph import MockGraph
from graph.rdf_generator import contract_to_triples
from models.contract_models import ChargeType
from storage.fast_path_cache import FastPathCache
from tests.factories import make_charge_term, make_invoice_line, make_vendor_relationship
from validators.validator_registry import ValidatorRegistry, default_validator_registry


def _prepare_repo_for_subscription() -> MockGraph:
    repo = MockGraph()
    contract = make_vendor_relationship(
        id="abc-cleaning-uh-2025",
        charge_terms=[
            make_charge_term(
                id="subscription-term",
                vendor_relationship_id="abc-cleaning-uh-2025",
                name="Subscription Service",
                charge_type=ChargeType.SUBSCRIPTION,
                rate=1000.0,
                rate_unit="month",
                effective_date=date(2025, 1, 1),
                renewal_date=date(2026, 1, 1),
            )
        ],
    )
    repo.insert_triples(contract_to_triples(contract))
    return repo


def test_default_registry_contains_expected_mapping() -> None:
    validators = default_validator_registry.get_validators_for_charge_type(ChargeType.PASS_THROUGH)
    assert validators == ["active_term", "line_amount_equals", "pass_through_requires_cost_evidence"]


def test_registry_can_override_mapping() -> None:
    registry = ValidatorRegistry()
    registry.set_validators_for_charge_type(ChargeType.FIXED_RATE, ["active_term", "custom_check"])

    validators = registry.get_validators_for_charge_type(ChargeType.FIXED_RATE)
    assert validators == ["active_term", "custom_check"]


def test_routing_uses_provided_registry_override() -> None:
    repo = _prepare_repo_for_subscription()
    line = make_invoice_line(
        line_number=1,
        description="Subscription Service",
        quantity=1.0,
        unit="month",
        unit_rate=1000.0,
        line_amount=1000.0,
    )

    custom_registry = ValidatorRegistry()
    custom_registry.set_validators_for_charge_type(ChargeType.SUBSCRIPTION, ["active_term", "custom_subscription_check"])

    decision = route_line(
        invoice_line=line,
        contract_id="abc-cleaning-uh-2025",
        fast_path_cache=FastPathCache(ttl_days=30),
        graph_repo=repo,
        invoice_date=date(2025, 2, 1),
        validator_registry=custom_registry,
    )

    assert decision.validators_to_run == ["active_term", "custom_subscription_check"]
