from datetime import date

from models.contract_models import ChargeType
from tests.factories import make_charge_term, make_supporting_doc
from validators.arithmetic_validators import (
    invoice_total_recomputes,
    line_amount_equals,
    overage_amount,
)
from validators.contingency_validators import contingency_fee_requires_realized_recovery
from validators.pass_through_validators import pass_through_requires_cost_evidence
from validators.precondition_validators import precondition_check
from validators.tax_validators import tax_allowed
from validators.temporal_validators import active_term, within_billing_interval


def test_line_amount_equals_pass_and_fail() -> None:
    passing = line_amount_equals(rate=150.0, quantity=2.0, invoice_amount=300.0)
    failing = line_amount_equals(rate=150.0, quantity=2.0, invoice_amount=315.0)

    assert passing.passed is True
    assert failing.passed is False
    assert failing.variance == 15.0


def test_invoice_total_recomputes_pass() -> None:
    result = invoice_total_recomputes(lines_total=1000.0, tax_rate=0.08, tax_amount=80.0, total=1080.0)
    assert result.passed is True


def test_overage_amount_pass() -> None:
    result = overage_amount(quantity=130, included=100, overage_rate=2.5, charged=75.0)
    assert result.passed is True


def test_active_term_out_of_range_fails() -> None:
    term = make_charge_term(effective_date=date(2025, 1, 1), renewal_date=date(2025, 12, 31))
    result = active_term(invoice_date=date(2026, 1, 15), charge_term=term)
    assert result.passed is False


def test_within_billing_interval_monthly_pass() -> None:
    result = within_billing_interval(
        invoice_date=date(2025, 2, 1),
        service_date=date(2025, 1, 15),
        cadence="monthly",
    )
    assert result.passed is True


def test_precondition_check_missing_doc_fails() -> None:
    result = precondition_check(
        required_conditions=["PO required"],
        supporting_docs=[make_supporting_doc(doc_type="receipt", reference="R-1")],
    )
    assert result.passed is False


def test_precondition_check_with_po_passes() -> None:
    result = precondition_check(
        required_conditions=["PO required"],
        supporting_docs=[make_supporting_doc(doc_type="PO", reference="PO#1042")],
    )
    assert result.passed is True


def test_tax_allowed_bounds() -> None:
    pass_result = tax_allowed(customer="UHS", location="NY", charge_type="FIXED_RATE", tax_rate=0.085)
    fail_result = tax_allowed(customer="UHS", location="NY", charge_type="FIXED_RATE", tax_rate=0.30)

    assert pass_result.passed is True
    assert fail_result.passed is False


def test_pass_through_requires_cost_evidence() -> None:
    term = make_charge_term(
        charge_type=ChargeType.PASS_THROUGH,
        is_passthrough=True,
        requires_cost_evidence=True,
    )

    fail_result = pass_through_requires_cost_evidence(term, supporting_docs=[])
    pass_result = pass_through_requires_cost_evidence(
        term,
        supporting_docs=[make_supporting_doc(doc_type="receipt", reference="RS-019", amount=200.0)],
    )

    assert fail_result.passed is False
    assert pass_result.passed is True


def test_contingency_requires_realized_recovery_and_basis() -> None:
    term = make_charge_term(charge_type=ChargeType.CONTINGENCY).model_copy(
        update={"contingency_pct": 0.2}
    )

    missing_recovery = contingency_fee_requires_realized_recovery(
        charge_term=term,
        recovery_data={"realized_recovery": 0},
        charged_amount=100.0,
    )
    valid = contingency_fee_requires_realized_recovery(
        charge_term=term,
        recovery_data={"realized_recovery": 1000.0},
        charged_amount=200.0,
    )

    assert missing_recovery.passed is False
    assert valid.passed is True
