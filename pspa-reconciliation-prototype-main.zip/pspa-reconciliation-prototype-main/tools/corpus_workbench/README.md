# Contract Corpus Workbench

This folder contains the lightweight tooling used to inventory, extract, chunk,
and pressure-test the contract and invoice examples under:

`Data/Contract and Invoice Pairs`

The tooling is intentionally not a reconciliation engine. It exists so the
design documents can be traced back to the source contracts and invoices and so
future model revisions can be rerun against the same corpus.

## What It Produces

- `docs/reconciliation-engine/domain-model/generated/corpus_manifest.json`
  - One record per source file with category, inferred document type, page or
    sheet counts, extracted text length, and extraction warnings.
- `docs/reconciliation-engine/domain-model/generated/corpus_chunks.jsonl`
  - Chunked source text for downstream LLM review or human spot checks.
- `docs/reconciliation-engine/domain-model/generated/corpus_signals.json`
  - Heuristic evidence signals for pricing, service period, location, volume,
    amendment, SOW, subscription, tax, and invoice total patterns.
- `docs/reconciliation-engine/domain-model/corpus-evidence-summary.md`
  - Human-readable corpus coverage and pressure-test observations.

## Run

From the repository root:

```powershell
& 'C:\Users\maclark\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' tools\corpus_workbench\analyze_corpus.py
```

The script uses `pypdf` for PDFs and `openpyxl` for spreadsheets.
