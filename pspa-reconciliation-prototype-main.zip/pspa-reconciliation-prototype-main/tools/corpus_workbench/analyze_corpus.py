"""Inventory and extract the contract/invoice corpus for design analysis.

This is a corpus workbench, not the reconciliation engine. It creates a
manifest, chunk file, heuristic signal file, and a concise Markdown summary that
the design documents can reference.
"""

from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

from openpyxl import load_workbook
from pypdf import PdfReader


REPO_ROOT = Path(__file__).resolve().parents[2]
SOURCE_ROOT = REPO_ROOT / "Data" / "Contract and Invoice Pairs"
OUTPUT_ROOT = REPO_ROOT / "docs" / "reconciliation-engine" / "domain-model"
GENERATED_ROOT = OUTPUT_ROOT / "generated"

CHUNK_SIZE = 2400
CHUNK_OVERLAP = 300


SIGNAL_PATTERNS = {
    "pricing": re.compile(
        r"\b(rate|fee|fees|price|pricing|amount|charge|charges|cost|unit price|monthly|annual|per\s+(?:hour|unit|visit|month|year|claim|transaction))\b",
        re.IGNORECASE,
    ),
    "invoice_total": re.compile(
        r"\b(invoice total|total due|amount due|balance due|subtotal|sales tax|tax|remit|payment due)\b",
        re.IGNORECASE,
    ),
    "service_period": re.compile(
        r"\b(term|effective date|expiration|renewal|service period|billing period|month ending|date of service|period)\b",
        re.IGNORECASE,
    ),
    "location": re.compile(
        r"\b(location|site|facility|hospital|clinic|address|premises|campus|building|property)\b",
        re.IGNORECASE,
    ),
    "volume": re.compile(
        r"\b(quantity|qty|volume|minimum|maximum|overage|usage|transactions|claims|hours|visits|acres|square feet)\b",
        re.IGNORECASE,
    ),
    "amendment": re.compile(
        r"\b(amendment|addendum|change order|extension|renewal|supersede|modified|revision)\b",
        re.IGNORECASE,
    ),
    "sow": re.compile(
        r"\b(statement of work|sow|scope of work|deliverable|milestone|project|task order|work order)\b",
        re.IGNORECASE,
    ),
    "subscription": re.compile(
        r"\b(subscription|license|saas|platform|module|annual recurring|monthly recurring|recurring)\b",
        re.IGNORECASE,
    ),
    "retainer": re.compile(r"\b(retainer|reserved hours|minimum hours|block of hours)\b", re.IGNORECASE),
    "break_fix": re.compile(
        r"\b(emergency|repair|break[- ]fix|time and materials|t&m|labor|parts|service call)\b",
        re.IGNORECASE,
    ),
    "tax": re.compile(r"\b(tax|sales tax|exempt|taxable|non-taxable)\b", re.IGNORECASE),
}


@dataclass
class SourceRecord:
    path: str
    category: str
    vendor_hint: str
    extension: str
    inferred_doc_type: str
    page_count: int | None
    sheet_count: int | None
    text_chars: int
    extraction_warnings: list[str]


def normalize_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def infer_doc_type(path: Path, text: str) -> str:
    relative_path = path.relative_to(SOURCE_ROOT).as_posix().lower()
    name_and_local_folders = f"{relative_path} {path.name}".lower()
    text_sample = text[:4000].lower()
    contract_path_markers = [
        " contracts/",
        "agreement",
        "contract",
        "sow",
        "statement of work",
        "loa",
        "letter of agreement",
        "amendment",
        "addendum",
        "cover memo",
        "summary",
        "terms service",
    ]
    invoice_path_markers = [" invoices/", "invoice"]

    if any(marker in name_and_local_folders for marker in contract_path_markers):
        return "contract-admin" if any(marker in name_and_local_folders for marker in ["cover memo", "summary"]) else "contract"
    if any(marker in name_and_local_folders for marker in invoice_path_markers):
        return "invoice"
    if re.fullmatch(r"\d+\.pdf", path.name.lower()) or path.suffix.lower() == ".xlsx":
        return "invoice"
    if any(token in text_sample for token in ["master agreement", "service agreement", "statement of work", "business associate agreement", "amendment"]):
        return "contract"
    if re.search(r"\binv(?:oice)?\s*#", text_sample) or "invoice total" in text_sample:
        return "invoice"
    return "unknown"


def category_for(path: Path) -> str:
    rel = path.relative_to(SOURCE_ROOT)
    return rel.parts[0] if rel.parts else "unknown"


def vendor_hint_for(path: Path, text: str) -> str:
    category = category_for(path)
    if " - " in category:
        return category.split(" - ", 1)[1]
    for candidate in ["Experian", "Johnson Controls", "Quality Lawn", "HealthROI", "Perficient", "Reputation", "NRC", "Office Depot"]:
        if candidate.lower() in f"{path} {text[:2000]}".lower():
            return candidate
    return category


def read_pdf(path: Path) -> tuple[str, int, list[str]]:
    warnings: list[str] = []
    reader = PdfReader(str(path))
    pages: list[str] = []
    for index, page in enumerate(reader.pages, start=1):
        try:
            page_text = page.extract_text() or ""
        except Exception as exc:  # pragma: no cover - defensive corpus tooling
            warnings.append(f"page {index}: {exc}")
            page_text = ""
        pages.append(f"\n\n--- page {index} ---\n{page_text}")
    text = normalize_text("\n".join(pages))
    if len(text) < 200:
        warnings.append("very low extracted text; source may be scanned or image-heavy")
    return text, len(reader.pages), warnings


def read_xlsx(path: Path) -> tuple[str, int, list[str]]:
    warnings: list[str] = []
    workbook = load_workbook(path, data_only=True)
    pieces: list[str] = []
    for sheet in workbook.worksheets:
        pieces.append(f"\n\n--- sheet {sheet.title} ---")
        for row in sheet.iter_rows(values_only=True):
            cells = [str(value).strip() for value in row if value is not None and str(value).strip()]
            if cells:
                pieces.append(" | ".join(cells))
    text = normalize_text("\n".join(pieces))
    if len(text) < 200:
        warnings.append("very low extracted spreadsheet text")
    return text, len(workbook.worksheets), warnings


def chunk_text(text: str) -> Iterable[str]:
    if not text:
        return
    start = 0
    while start < len(text):
        end = min(len(text), start + CHUNK_SIZE)
        yield text[start:end].strip()
        if end == len(text):
            break
        start = max(0, end - CHUNK_OVERLAP)


def sentence_window(text: str, start: int, end: int, radius: int = 220) -> str:
    window = text[max(0, start - radius) : min(len(text), end + radius)]
    return normalize_text(window)


def extract_signals(text: str) -> dict[str, list[str]]:
    signals: dict[str, list[str]] = {}
    for name, pattern in SIGNAL_PATTERNS.items():
        snippets: list[str] = []
        for match in pattern.finditer(text):
            snippets.append(sentence_window(text, match.start(), match.end()))
            if len(snippets) == 5:
                break
        if snippets:
            signals[name] = snippets
    return signals


def iter_sources() -> list[Path]:
    return sorted(path for path in SOURCE_ROOT.rglob("*") if path.is_file() and path.suffix.lower() in {".pdf", ".xlsx"})


def analyze() -> tuple[list[SourceRecord], list[dict], list[dict]]:
    GENERATED_ROOT.mkdir(parents=True, exist_ok=True)
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)

    records: list[SourceRecord] = []
    chunks: list[dict] = []
    signals: list[dict] = []

    for source in iter_sources():
        extension = source.suffix.lower()
        page_count: int | None = None
        sheet_count: int | None = None
        try:
            if extension == ".pdf":
                text, page_count, warnings = read_pdf(source)
            elif extension == ".xlsx":
                text, sheet_count, warnings = read_xlsx(source)
            else:
                continue
        except Exception as exc:  # pragma: no cover - defensive corpus tooling
            text = ""
            warnings = [str(exc)]

        doc_type = infer_doc_type(source, text)
        rel = source.relative_to(REPO_ROOT).as_posix()
        record = SourceRecord(
            path=rel,
            category=category_for(source),
            vendor_hint=vendor_hint_for(source, text),
            extension=extension,
            inferred_doc_type=doc_type,
            page_count=page_count,
            sheet_count=sheet_count,
            text_chars=len(text),
            extraction_warnings=warnings,
        )
        records.append(record)

        source_signals = extract_signals(text)
        signals.append({"path": rel, "signals": source_signals})

        for chunk_index, chunk in enumerate(chunk_text(text), start=1):
            chunks.append(
                {
                    "path": rel,
                    "category": record.category,
                    "inferred_doc_type": doc_type,
                    "chunk_index": chunk_index,
                    "text": chunk,
                }
            )

    return records, chunks, signals


def write_outputs(records: list[SourceRecord], chunks: list[dict], signals: list[dict]) -> None:
    manifest_path = GENERATED_ROOT / "corpus_manifest.json"
    chunks_path = GENERATED_ROOT / "corpus_chunks.jsonl"
    signals_path = GENERATED_ROOT / "corpus_signals.json"
    csv_path = GENERATED_ROOT / "corpus_manifest.csv"

    manifest_path.write_text(json.dumps([asdict(record) for record in records], indent=2), encoding="utf-8")
    signals_path.write_text(json.dumps(signals, indent=2), encoding="utf-8")
    with chunks_path.open("w", encoding="utf-8") as handle:
        for chunk in chunks:
            handle.write(json.dumps(chunk, ensure_ascii=False) + "\n")

    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "path",
                "category",
                "vendor_hint",
                "extension",
                "inferred_doc_type",
                "page_count",
                "sheet_count",
                "text_chars",
                "extraction_warnings",
            ],
        )
        writer.writeheader()
        for record in records:
            row = asdict(record)
            row["extraction_warnings"] = "; ".join(record.extraction_warnings)
            writer.writerow(row)

    write_summary(records, chunks, signals)


def count_signals(signals: list[dict]) -> Counter:
    counts: Counter = Counter()
    for source in signals:
        for name, snippets in source["signals"].items():
            if snippets:
                counts[name] += 1
    return counts


def write_summary(records: list[SourceRecord], chunks: list[dict], signals: list[dict]) -> None:
    by_category: dict[str, list[SourceRecord]] = defaultdict(list)
    for record in records:
        by_category[record.category].append(record)

    signal_counts = count_signals(signals)
    lines = [
        "# Corpus Evidence Summary",
        "",
        "Generated by `tools/corpus_workbench/analyze_corpus.py`.",
        "",
        "## Coverage",
        "",
        f"- Source files processed: {len(records)}",
        f"- PDFs: {sum(1 for record in records if record.extension == '.pdf')}",
        f"- Spreadsheets: {sum(1 for record in records if record.extension == '.xlsx')}",
        f"- Text chunks generated: {len(chunks)}",
        f"- Contract-like documents: {sum(1 for record in records if record.inferred_doc_type.startswith('contract'))}",
        f"- Invoice-like documents: {sum(1 for record in records if record.inferred_doc_type == 'invoice')}",
        f"- Unknown document type: {sum(1 for record in records if record.inferred_doc_type == 'unknown')}",
        "",
        "## Category Inventory",
        "",
        "| Category | Files | Contract/Admin | Invoice | Unknown | Text chars |",
        "| --- | ---: | ---: | ---: | ---: | ---: |",
    ]

    for category, category_records in sorted(by_category.items()):
        lines.append(
            "| {category} | {files} | {contracts} | {invoices} | {unknown} | {chars} |".format(
                category=category.replace("|", "\\|"),
                files=len(category_records),
                contracts=sum(1 for record in category_records if record.inferred_doc_type.startswith("contract")),
                invoices=sum(1 for record in category_records if record.inferred_doc_type == "invoice"),
                unknown=sum(1 for record in category_records if record.inferred_doc_type == "unknown"),
                chars=sum(record.text_chars for record in category_records),
            )
        )

    lines.extend(
        [
            "",
            "## Signal Coverage",
            "",
            "| Signal | Files with Evidence |",
            "| --- | ---: |",
        ]
    )
    for name, count in sorted(signal_counts.items()):
        lines.append(f"| {name} | {count} |")

    warnings = [record for record in records if record.extraction_warnings]
    lines.extend(["", "## Extraction Warnings", ""])
    if warnings:
        for record in warnings:
            lines.append(f"- `{record.path}`: {'; '.join(record.extraction_warnings)}")
    else:
        lines.append("- None.")

    lines.extend(
        [
            "",
            "## Design Implications Observed in the Corpus",
            "",
            "- The corpus contains service relationships whose billability depends on more than a product SKU: named sites, service periods, SOW scopes, amendments, subscriptions, transaction volumes, inspections, consulting reviews, and invoice-level tax or total rules all appear as first-class evidence signals.",
            "- A useful logical model must represent both contract hierarchy and invoice evidence: master agreements, amendments, SOWs, cover memos, location-specific agreements, invoice headers, line items, service periods, quantities, rates, and totals.",
            "- The same vendor relationship can need different reconciliation strategies by charge type. Fixed recurring fees, per-location maintenance, transaction/usage fees, contingency or recovery-based consulting fees, project SOW deliverables, and reimbursable/tax charges should not be flattened into one generic line-item rule.",
            "- The model must preserve source provenance because many compliance decisions rely on an exact clause, schedule row, amendment, or invoice field rather than a broad summary.",
        ]
    )

    (OUTPUT_ROOT / "corpus-evidence-summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    records, chunks, signals = analyze()
    write_outputs(records, chunks, signals)
    print(f"Processed {len(records)} files and wrote {len(chunks)} chunks to {GENERATED_ROOT}")


if __name__ == "__main__":
    main()
