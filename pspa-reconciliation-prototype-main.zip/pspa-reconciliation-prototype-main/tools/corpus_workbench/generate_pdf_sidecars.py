"""Generate sidecar text files next to PDFs in Data/Contract and Invoice Pairs.

Usage:
  python tools/corpus_workbench/generate_pdf_sidecars.py
  python tools/corpus_workbench/generate_pdf_sidecars.py --root "C:/.../Data/Contract and Invoice Pairs"
  python tools/corpus_workbench/generate_pdf_sidecars.py --overwrite
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


REPO_ROOT = Path(__file__).resolve().parents[2]
IMPL_ROOT = REPO_ROOT / "docs" / "reconciliation-engine" / "approaches" / "05-ontology-agent-d-hybrid" / "implementation"
if str(IMPL_ROOT) not in sys.path:
    sys.path.insert(0, str(IMPL_ROOT))

from data_parsers.pdf_extractor import extract_text_with_ocr_fallback  # noqa: E402
from data_parsers.sidecar_text import load_sidecar_text, write_sidecar_text  # noqa: E402


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--root",
        type=str,
        default=str(REPO_ROOT / "Data" / "Contract and Invoice Pairs"),
        help="Root directory to scan for PDFs",
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="Overwrite existing sidecars",
    )
    parser.add_argument(
        "--suffix",
        type=str,
        default=".txt",
        choices=[".txt", ".md"],
        help="Sidecar suffix to write",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(args.root)
    if not root.exists() or not root.is_dir():
        print(f"ERROR: root does not exist: {root}")
        return 2

    pdfs = sorted(root.rglob("*.pdf"))
    if not pdfs:
        print(f"No PDFs found under: {root}")
        return 0

    written = 0
    skipped = 0
    failed = 0

    print(f"Found {len(pdfs)} PDFs under {root}")

    for pdf in pdfs:
        try:
            existing_text, existing_path = load_sidecar_text(pdf)
            if existing_text is not None and not args.overwrite:
                skipped += 1
                continue

            text = extract_text_with_ocr_fallback(pdf)
            write_sidecar_text(pdf, text, suffix=args.suffix)
            written += 1
        except Exception as exc:
            failed += 1
            print(f"FAILED: {pdf} -> {exc}")

    print(
        f"Done. written={written}, skipped={skipped}, failed={failed}, total={len(pdfs)}"
    )
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
