[CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
param(
    [string]$RepoRoot = (Get-Location).Path,
    [ValidateSet('all', 'preflight', 'batch1', 'batch2', 'batch3', 'batch4')]
    [string]$Run = 'all',
    [switch]$Execute,
    [switch]$SkipTests,
    [switch]$KillLockingProcesses
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Stage {
    param([string]$Message)
    Write-Host "`n=== $Message ===" -ForegroundColor Cyan
}

function Assert-Command {
    param([string]$Name)
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "Required command not found: $Name"
    }
}

function Invoke-SafeMove {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination,
        [switch]$AllowMissing,
        [int]$MaxRetries = 5
    )

    if (-not (Test-Path -LiteralPath $Source)) {
        if ($AllowMissing) {
            Write-Host "Skip (missing): $Source" -ForegroundColor DarkYellow
            return
        }
        throw "Source not found: $Source"
    }

    if (Test-Path -LiteralPath $Destination) {
        throw "Destination already exists: $Destination"
    }

    $destParent = Split-Path -Path $Destination -Parent
    if ($destParent -and -not (Test-Path -LiteralPath $destParent)) {
        New-Item -ItemType Directory -Path $destParent -Force | Out-Null
    }

    if ($PSCmdlet.ShouldProcess("$Source -> $Destination", "Move-Item")) {
        $attempt = 1
        while ($true) {
            try {
                Move-Item -LiteralPath $Source -Destination $Destination
                break
            }
            catch {
                $isLockError = ($_.Exception.Message -match 'Access to the path' -or $_.Exception.Message -match 'being used by another process')
                if (-not $isLockError -or $attempt -ge $MaxRetries) {
                    if ($isLockError) {
                        if ((Test-Path -LiteralPath $Source -PathType Container) -and -not (Test-Path -LiteralPath $Destination)) {
                            Write-Host "Locked move fallback: copying directory $Source -> $Destination" -ForegroundColor Yellow
                            Copy-Item -LiteralPath $Source -Destination $Destination -Recurse -Force
                            try {
                                Remove-Item -LiteralPath $Source -Recurse -Force -ErrorAction Stop
                            }
                            catch {
                                Write-Host "Warning: copied but could not delete locked source $Source. Close locking process/cwd and remove it later." -ForegroundColor Yellow
                            }
                            break
                        }
                        throw "Unable to move locked path after $attempt attempt(s): $Source. Remediation: close terminals whose cwd is inside implementation, stop Streamlit/Python processes, then rerun batch1 with -KillLockingProcesses. Inner error: $($_.Exception.Message)"
                    }
                    throw
                }
                Start-Sleep -Milliseconds (300 * $attempt)
                $attempt += 1
            }
        }
    }
}

function Stop-LikelyLockingProcesses {
    param([string]$PathHint)

    $normHint = [System.IO.Path]::GetFullPath($PathHint).ToLowerInvariant()
    $processes = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
        Where-Object {
            ($_.Name -in @('python.exe', 'streamlit.exe')) -and
            (($_.CommandLine -as [string]).ToLowerInvariant().Contains($normHint))
        }

    foreach ($proc in $processes) {
        try {
            Write-Host "Stopping locking process PID $($proc.ProcessId): $($proc.Name)" -ForegroundColor DarkYellow
            Stop-Process -Id $proc.ProcessId -Force -ErrorAction Stop
        }
        catch {
            Write-Host "Could not stop PID $($proc.ProcessId): $($_.Exception.Message)" -ForegroundColor Yellow
        }
    }
}

function New-Checkpoint {
    param(
        [Parameter(Mandatory = $true)][string]$Message,
        [Parameter(Mandatory = $true)][string]$Tag
    )

    $status = git status --porcelain
    if ([string]::IsNullOrWhiteSpace(($status -join "`n"))) {
        Write-Host "No changes to checkpoint." -ForegroundColor DarkYellow
        return
    }

    if ($PSCmdlet.ShouldProcess("git commit", $Message)) {
        git add -A
        git commit -m $Message | Out-Host
        git tag $Tag | Out-Host
    }
}

function Assert-CleanWorkingTree {
    $status = git status --porcelain
    if (-not [string]::IsNullOrWhiteSpace(($status -join "`n"))) {
        throw "Working tree is not clean. Commit/stash before running reorg."
    }
}

Assert-Command git

$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
Set-Location -LiteralPath $RepoRoot

$Timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$BackupDir = Join-Path $RepoRoot ".reorg\backups\$Timestamp"
$DocsRoot = Join-Path $RepoRoot 'docs\reconciliation-engine'
$ApproachesRoot = Join-Path $DocsRoot 'approaches'
$A5Root = Join-Path $ApproachesRoot '05-ontology-agent-d-hybrid'
$ImplRoot = Join-Path $A5Root 'implementation'
$ActiveRoot = Join-Path $DocsRoot 'active'
$HistoryRoot = Join-Path $RepoRoot 'docs\history\approaches'

if (-not $Execute) {
    Write-Host 'Dry-run mode enabled. No changes will be made unless -Execute is provided.' -ForegroundColor Yellow
    $WhatIfPreference = $true
}

if (-not (Test-Path -LiteralPath $ImplRoot)) {
    throw "Implementation root not found: $ImplRoot"
}

if ($Run -in @('all', 'preflight')) {
    Write-Stage 'Preflight'
    Assert-CleanWorkingTree

    if ($PSCmdlet.ShouldProcess($BackupDir, 'Create backup directory')) {
        New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
    }

    $baseline = [ordered]@{
        DataCount  = (Get-ChildItem (Join-Path $RepoRoot 'Data') -Recurse -Force | Measure-Object).Count
        ToolsCount = (Get-ChildItem (Join-Path $RepoRoot 'tools') -Recurse -Force | Measure-Object).Count
    }

    if ($PSCmdlet.ShouldProcess((Join-Path $BackupDir 'baseline_counts.json'), 'Write baseline counts')) {
        $baseline | ConvertTo-Json | Set-Content (Join-Path $BackupDir 'baseline_counts.json')
    }

    if ($PSCmdlet.ShouldProcess((Join-Path $BackupDir 'pre_reorg_head.txt'), 'Write current HEAD')) {
        git rev-parse HEAD | Set-Content (Join-Path $BackupDir 'pre_reorg_head.txt')
    }

    if ($PSCmdlet.ShouldProcess((Join-Path $BackupDir "repo-$Timestamp.bundle"), 'Create git bundle')) {
        git bundle create (Join-Path $BackupDir "repo-$Timestamp.bundle") --all | Out-Host
    }

    if ($PSCmdlet.ShouldProcess((Join-Path $BackupDir "approaches-$Timestamp.zip"), 'Archive approaches docs')) {
        Compress-Archive -Path $ApproachesRoot -DestinationPath (Join-Path $BackupDir "approaches-$Timestamp.zip") -Force
    }

    $activeSubdirs = @('architecture', 'api', 'domain', 'implementation', 'quality', 'releases')
    foreach ($sub in $activeSubdirs) {
        if ($PSCmdlet.ShouldProcess((Join-Path $ActiveRoot $sub), 'Create active docs folder')) {
            New-Item -ItemType Directory -Path (Join-Path $ActiveRoot $sub) -Force | Out-Null
        }
    }

    if ($PSCmdlet.ShouldProcess($HistoryRoot, 'Create history approaches folder')) {
        New-Item -ItemType Directory -Path $HistoryRoot -Force | Out-Null
    }
}

if ($Run -in @('all', 'batch1')) {
    Write-Stage 'Batch 1: Promote runtime to repository root'

    if ($KillLockingProcesses) {
        Stop-LikelyLockingProcesses -PathHint $ImplRoot
    }

    $runtimeItems = @(
        'api', 'core', 'data_parsers', 'graph', 'llm', 'matching', 'models', 'storage', 'validators', 'utils', 'ui', 'tests',
        'main.py', 'pyproject.toml', 'requirements.txt', 'requirements-dev.txt', '.env.example', 'README.md'
    )

    foreach ($item in $runtimeItems) {
        $src = Join-Path $ImplRoot $item
        $dst = Join-Path $RepoRoot $item
        Invoke-SafeMove -Source $src -Destination $dst -AllowMissing
    }

    New-Checkpoint -Message 'reorg batch1: promote approach5 runtime to root' -Tag "reorg-b1-$Timestamp"
}

if ($Run -in @('all', 'batch2')) {
    Write-Stage 'Batch 2: Move selected-solution docs to active'

    $docMoves = @(
        @{ S = (Join-Path $A5Root 'ADR.md');                D = (Join-Path $ActiveRoot 'architecture\ADR.md') },
        @{ S = (Join-Path $A5Root 'plan.md');               D = (Join-Path $ActiveRoot 'architecture\plan.md') },
        @{ S = (Join-Path $A5Root 'README.md');             D = (Join-Path $ActiveRoot 'architecture\README.md') },
        @{ S = (Join-Path $A5Root 'AGENTS.md');             D = (Join-Path $ActiveRoot 'implementation\AGENTS.md') },
        @{ S = (Join-Path $A5Root 'IMPL_CHECKLIST.md');     D = (Join-Path $ActiveRoot 'implementation\IMPL_CHECKLIST.md') },
        @{ S = (Join-Path $A5Root 'API.md');                D = (Join-Path $ActiveRoot 'api\API.md') },
        @{ S = (Join-Path $A5Root 'DATA_MODEL.md');         D = (Join-Path $ActiveRoot 'domain\DATA_MODEL.md') },
        @{ S = (Join-Path $A5Root 'COVERAGE_REPORT.md');    D = (Join-Path $ActiveRoot 'quality\COVERAGE_REPORT.md') },
        @{ S = (Join-Path $A5Root 'PHASE_8_COMPLETION.md'); D = (Join-Path $ActiveRoot 'releases\PHASE_8_COMPLETION.md') }
    )

    foreach ($move in $docMoves) {
        Invoke-SafeMove -Source $move.S -Destination $move.D -AllowMissing
    }

    New-Checkpoint -Message 'reorg batch2: move approach5 docs to active structure' -Tag "reorg-b2-$Timestamp"
}

if ($Run -in @('all', 'batch3')) {
    Write-Stage 'Batch 3: Archive non-selected approaches to history'

    Invoke-SafeMove -Source (Join-Path $ApproachesRoot '01-llm-generated-rules-engine') -Destination (Join-Path $HistoryRoot '01-llm-generated-rules-engine') -AllowMissing
    Invoke-SafeMove -Source (Join-Path $ApproachesRoot '02-whole-document-llm-adjudication') -Destination (Join-Path $HistoryRoot '02-whole-document-llm-adjudication') -AllowMissing
    Invoke-SafeMove -Source (Join-Path $ApproachesRoot '03-ontology-backed-agent') -Destination (Join-Path $HistoryRoot '03-ontology-backed-agent') -AllowMissing

    if ($PSCmdlet.ShouldProcess((Join-Path $HistoryRoot '04'), 'Create history 04 folder')) {
        New-Item -ItemType Directory -Path (Join-Path $HistoryRoot '04') -Force | Out-Null
    }

    Invoke-SafeMove -Source (Join-Path $ApproachesRoot '04-alternative-approaches.md') -Destination (Join-Path $HistoryRoot '04\README.md') -AllowMissing
    Invoke-SafeMove -Source (Join-Path $DocsRoot 'comparison.md') -Destination (Join-Path $HistoryRoot 'comparison.md') -AllowMissing

    New-Checkpoint -Message 'reorg batch3: archive alternative approaches in docs history' -Tag "reorg-b3-$Timestamp"
}

if ($Run -in @('all', 'batch4')) {
    Write-Stage 'Batch 4: Path-fix checks and validation'

    $searchPatterns = @(
        'docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/implementation',
        'docs\reconciliation-engine\approaches\05-ontology-agent-d-hybrid\implementation',
        'reconciliation-engine/approaches',
        'reconciliation-engine\approaches',
        '05-ontology-agent-d-hybrid'
    )

    $searchFiles = Get-ChildItem $RepoRoot -Recurse -File -Include *.py, *.md, *.toml, *.yaml, *.yml, *.json, *.ini, *.cfg
    foreach ($pattern in $searchPatterns) {
        Write-Host "Pattern: $pattern" -ForegroundColor DarkCyan
        $matches = $searchFiles | Select-String -Pattern $pattern -SimpleMatch
        if ($matches) {
            $matches | Select-Object Path, LineNumber, Line | Format-Table -AutoSize | Out-Host
        }
    }

    if (-not $SkipTests) {
        if ($PSCmdlet.ShouldProcess('python validation commands', 'Run py_compile + pytest smoke')) {
            $python = Join-Path $RepoRoot '.venv\Scripts\python.exe'
            if (-not (Test-Path -LiteralPath $python)) {
                throw "Python executable not found: $python"
            }

            & $python -m py_compile (Join-Path $RepoRoot 'main.py') (Join-Path $RepoRoot 'ui\pages\workbench.py') (Join-Path $RepoRoot 'data_parsers\pdf_extractor.py') (Join-Path $RepoRoot 'llm\llm_client.py')
            & $python -m pytest (Join-Path $RepoRoot 'tests\test_llm_client.py') -xvs --tb=short
        }
    }

    $baselineFile = Join-Path $BackupDir 'baseline_counts.json'
    if (Test-Path -LiteralPath $baselineFile) {
        $baseline = Get-Content $baselineFile | ConvertFrom-Json
        $dataNow = (Get-ChildItem (Join-Path $RepoRoot 'Data') -Recurse -Force | Measure-Object).Count
        $toolsNow = (Get-ChildItem (Join-Path $RepoRoot 'tools') -Recurse -Force | Measure-Object).Count

        if ($dataNow -ne [int]$baseline.DataCount) {
            throw "Data folder count changed unexpectedly: $($baseline.DataCount) -> $dataNow"
        }
        if ($toolsNow -ne [int]$baseline.ToolsCount) {
            throw "tools folder count changed unexpectedly: $($baseline.ToolsCount) -> $toolsNow"
        }
    }

    New-Checkpoint -Message 'reorg batch4: path checks and validation' -Tag "reorg-b4-$Timestamp"
}

Write-Stage 'Completed'
Write-Host "Run mode: $Run"
Write-Host "Repo root: $RepoRoot"
Write-Host "Backup dir: $BackupDir"
Write-Host 'Rollback quick command:' -ForegroundColor Yellow
Write-Host '  git reset --hard (Get-Content .reorg\backups\<timestamp>\pre_reorg_head.txt); git clean -fd'