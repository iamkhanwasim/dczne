# PSPA Reconciliation Demo UI

Interactive Streamlit web application for demonstrating the reconciliation engine with real contract and invoice PDFs.

## Quick Start

### Prerequisites

- Python 3.10+
- Virtual environment with dependencies installed

### Installation

From the `implementation/` directory:

```bash
pip install -r requirements.txt
```

### Running the App

```bash
streamlit run ui/app.py
```

The app will open at `http://localhost:8501` in your browser.

## Features

### 1. Contract Explorer (`pages/01_contract.py`)

Upload and analyze contract PDFs to extract charge terms and visualize the ontology.

**Steps**:
1. Select a vendor from the Data directory
2. Choose a contract PDF
3. View the PDF pages with navigation controls
4. Click "Parse Contract" to extract terms using LLM
5. View extracted charge terms in a table
6. Explore the ontology graph showing relationships between vendor, terms, and documents

**Outputs**:
- Extracted charge terms with confidence scores
- Interactive RDF graph visualization
- Ontology triples (downloadable as Turtle format)

### 2. Invoice Reconciliation (`pages/02_reconcile.py`)

Match invoices to the parsed contract and validate against terms.

**Steps**:
1. Contract summary (auto-populated from Contract Explorer)
2. Select invoice month and PDF
3. View invoice PDF
4. Parse invoice to extract line items
5. Click "Reconcile Against Contract" to validate
6. Review findings for each line item

**Outputs**:
- Reconciliation status (PASS / REJECT / NEEDS_REVIEW)
- Line-by-line validation results
- Variance analysis (invoiced vs. expected)
- Detailed audit trail of validation pipeline

## Configuration

### Sidebar Settings

- **Data Directory**: Path to the `Data/Contract and Invoice Pairs` folder (relative to `implementation/`)
- **LLM Mode**: Choose between "Stub (Offline)" for demos or "Real (Online)" for actual LLM calls
- **Model**: Select LLM model (gpt-4o, gpt-4-turbo, claude-3-5-sonnet)
- **Confidence Threshold**: Minimum confidence for term extraction (0.70 - 0.99)
- **Graph Layout**: Graph visualization style (Force-Directed, Hierarchical, Circular)

### Offline Demo Mode (Stub LLM)

The stub LLM provides pre-canned extraction results for known vendors:
- Experian
- Johnson Controls
- Quality Lawn
- Reputation.com
- Perficient
- Generic fallback

**Advantages**:
- No API keys required
- Fast demos without network latency
- Consistent, reproducible results
- Great for stakeholder presentations

**Usage**:
```bash
streamlit run ui/app.py
```

Then in sidebar, select "🤖 Stub (Offline)" mode.

## Data Directory Structure

Expected structure in `Data/Contract and Invoice Pairs/`:

```
Data/Contract and Invoice Pairs/
├── UHS - Vendor Name/
│   ├── {Vendor} Contracts/
│   │   ├── contract1.pdf
│   │   └── contract2.pdf
│   └── {Vendor} Invoices/
│       ├── January 2025/
│       │   ├── invoice1.pdf
│       │   └── invoice2.pdf
│       ├── February 2025/
│       │   └── invoice3.pdf
│       └── ...
├── UHS - Another Vendor/
│   └── [similar structure]
└── ...
```

## Architecture

### Key Components

**Data Layer**:
- `data_parsers/pdf_extractor.py`: PyMuPDF extraction (text + images)
- `data_parsers/data_directory.py`: Vendor pair scanner for UI
- `llm/stub_llm_client.py`: Mock LLM for offline demos

**UI Layer**:
- `ui/app.py`: Main entry point and routing
- `ui/session.py`: Typed session state management
- `ui/pages/01_contract.py`: Contract Explorer page
- `ui/pages/02_reconcile.py`: Invoice Reconciliation page
- `ui/components/`: Reusable Streamlit components:
  - `pdf_viewer.py`: PDF rendering with page navigation
  - `graph_viewer.py`: RDF graph visualization (pyvis)
  - `findings_table.py`: Color-coded reconciliation results

**Tests**:
- `tests/test_pdf_extractor.py`: Unit tests for PDF extraction

### State Management

Session state is managed through typed helpers in `ui/session.py` to ensure consistency across pages:

```python
from ui import session

# Contract page
contract = session.get_parsed_contract()
session.set_parsed_contract(new_contract)

# Invoice page
result = session.get_reconciliation_result()
session.set_reconciliation_result(finding)
```

## Troubleshooting

### "Data directory not found"

Ensure:
- You're running from the `implementation/` directory
- The data path in sidebar is correct (relative to `implementation/`)
- The data directory exists: `../../../Data/Contract and Invoice Pairs`

### "No vendors found"

Check that the data directory has the expected structure with vendor folders inside.

### "ModuleNotFoundError: No module named 'streamlit'"

Run:
```bash
pip install -r requirements.txt
```

### PDF rendering is slow

- Try a lower DPI (default 150) in the code
- Consider pre-rendering PDFs offline
- Use a faster machine for demo presentations

### LLM API errors (Real mode)

Ensure:
- `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` environment variable is set
- API account has sufficient credit
- Model name is correct in settings

## Performance Notes

- **First load**: Slower (extracts vendor pairs from disk)
- **Page navigation**: Fast (cached in session state)
- **PDF rendering**: ~1-3 sec per page (depends on resolution)
- **Contract parsing**: 5-10 sec (depends on document length and LLM)
- **Reconciliation**: 1-2 sec (in-memory validation)

## Dependencies

Core:
- `streamlit>=1.35` - Web UI framework
- `pymupdf>=1.24` - PDF extraction and rendering
- `pyvis>=0.3` - Interactive graph visualization
- `pandas>=2.0` - Tabular data

Plus all dependencies from main `requirements.txt` (FastAPI, Pydantic, rdflib, LLM clients, etc.).

## Limitations

- **Read-only**: The demo UI doesn't modify contracts or invoices
- **In-memory**: Contract state only persists during the session (not persistent storage)
- **Simplified reconciliation**: Demo page shows simulated results; full pipeline integration in progress
- **Single user**: Streamlit is single-threaded; not suitable for production multi-user deployments

## Future Enhancements

- [ ] Persistent storage of parsed contracts
- [ ] Real reconciliation pipeline integration
- [ ] Upload custom PDFs
- [ ] Comparison of multiple contracts
- [ ] Batch reconciliation for multiple invoices
- [ ] Export findings to CSV/PDF
- [ ] Authentication and multi-user support
- [ ] Historical reconciliation results
- [ ] Advanced filtering and search

## Development

### Adding a New Page

1. Create `ui/pages/03_new_feature.py`
2. Import components and session helpers
3. Update `ui/app.py` to add the page to navigation

### Adding a New Component

1. Create `ui/components/new_component.py`
2. Implement a render function taking Streamlit columns/expanders
3. Use typed session helpers for state
4. Import in pages as needed

### Testing

Run unit tests:
```bash
pytest tests/test_pdf_extractor.py -v
```

Run with coverage:
```bash
pytest tests/ --cov=data_parsers --cov=ui -v
```

## Support

For issues or questions, refer to:
- [Streamlit Documentation](https://docs.streamlit.io/)
- [PyMuPDF Documentation](https://pymupdf.readthedocs.io/)
- [pyvis Documentation](https://pyvis.readthedocs.io/)
- Implementation README: `docs/reconciliation-engine/approaches/05-ontology-agent-d-hybrid/implementation/README.md`
