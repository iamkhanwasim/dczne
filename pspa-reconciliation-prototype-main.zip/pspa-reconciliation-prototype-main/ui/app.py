"""
PSPA Reconciliation Demo UI - Main Entry Point.

Interactive Streamlit application for demonstrating the reconciliation engine
against real contract and invoice PDFs from the Data directory.

Run with: streamlit run ui/app.py
"""

from pathlib import Path
import sys
import os

import streamlit as st

if __package__ is None or __package__ == "":
    implementation_root = Path(__file__).resolve().parents[1]
    if str(implementation_root) not in sys.path:
        sys.path.insert(0, str(implementation_root))

from ui.session import init_session_state


def _load_env_file() -> None:
    env_path = Path(__file__).resolve().parents[1] / ".env"
    if not env_path.exists():
        return

    for raw_line in env_path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        else:
            value = value.split(" #", 1)[0].strip()
        os.environ[key] = value


_load_env_file()

# Page configuration
st.set_page_config(
    page_title="PSPA Reconciliation Demo",
    page_icon="📋",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Initialize session state
init_session_state()

# Main navigation
with st.sidebar:
    st.markdown("## 🔍 PSPA Reconciliation Engine")
    st.markdown("**Interactive Demo UI**")
    st.divider()

    # Configuration section
    with st.expander("⚙️ Configuration", expanded=False):
        # Data directory
        data_dir = st.text_input(
            "Data Directory",
            value="Data/Contract and Invoice Pairs",
            help="Absolute path or relative path. If invalid, app auto-discovers from parent folders.",
        )

        # LLM config is read-only from .env / environment
        provider = os.getenv("LLM_PROVIDER", "azure-apim").strip().lower()
        model = os.getenv("LLM_MODEL", "gpt-4-turbo").strip()
        use_stub = provider in {"stub", "offline"}

        st.markdown("**LLM Configuration (.env)**")
        st.caption(f"Provider: {provider or 'not set'}")
        st.caption(f"Model: {model or 'not set'}")

        if use_stub:
            st.info("Stub mode enabled from .env (LLM_PROVIDER=stub).")
        elif provider == "azure-apim":
            key_present = bool(os.getenv("AZURE_OPENAI_ENDPOINT") and os.getenv("AZURE_OPENAI_API_KEY"))
            if key_present:
                st.success("Azure APIM config detected from .env")
            else:
                st.warning("Missing AZURE_OPENAI_ENDPOINT or AZURE_OPENAI_API_KEY in .env")
        elif provider == "openai":
            st.success("OpenAI provider set via .env") if os.getenv("OPENAI_API_KEY") else st.warning(
                "Missing OPENAI_API_KEY in .env"
            )
        elif provider == "anthropic":
            st.success("Anthropic provider set via .env") if os.getenv("ANTHROPIC_API_KEY") else st.warning(
                "Missing ANTHROPIC_API_KEY in .env"
            )
        else:
            st.warning("LLM_PROVIDER in .env must be one of: azure-apim, openai, anthropic, stub")

        # Threshold
        threshold = st.slider(
            "Confidence Threshold",
            min_value=0.70,
            max_value=0.99,
            value=0.80,
            step=0.01,
            help="Minimum confidence for term extraction",
        )

        # Graph layout
        layout = st.selectbox(
            "Graph Layout",
            options=["Force-Directed", "Hierarchical", "Circular"],
            help="How to arrange ontology graph nodes",
        )

        # Update session state
        from ui import session
        session.set_data_directory(data_dir)
        session.set_use_stub_llm(use_stub)
        session.set_llm_mode("stub" if use_stub else "real")
        st.session_state["llm_provider"] = provider
        session.set_llm_model(model)
        session.set_confidence_threshold(threshold)
        layout_map = {"Force-Directed": "force", "Hierarchical": "hierarchical", "Circular": "circular"}
        session.set_graph_layout(layout_map.get(layout, "force"))

    st.divider()
    st.markdown("**Workspace**")
    st.markdown(
        """
    Single-page demo with simplified selectors and tabs for:
    - Contract PDF
    - Invoice PDF
    - Ontology
    - Parsed outputs
    - Reconciliation
    - JSON outputs
    """
    )

if use_stub:
    st.sidebar.warning("🤖 Running in **offline demo mode** (stub LLM)\n\nNo API keys needed!")

# Single-page routing
page_path = Path(__file__).parent / "pages/workbench.py"

if page_path.exists():
    try:
        page_source = page_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        page_source = page_path.read_text(encoding="utf-8", errors="replace")
    exec(page_source)  # noqa: S102
else:
    st.error(f"Page not found: {page_path}")
    st.stop()
