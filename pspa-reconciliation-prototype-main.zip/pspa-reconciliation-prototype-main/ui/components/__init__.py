"""UI components for Streamlit demo app."""
