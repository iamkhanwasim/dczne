"""
Reusable findings table component for Streamlit UI.

Displays reconciliation findings in a color-coded, expandable table format.
"""

from typing import Optional

import pandas as pd
import streamlit as st

from models.finding_models import InvoiceFinding, Finding, FindingStatus


def render_findings_summary(finding: Optional[InvoiceFinding]) -> None:
    """
    Render a summary card of reconciliation findings.

    Args:
        finding: The InvoiceFinding result
    """
    if not finding:
        st.info("No reconciliation results yet. Parse an invoice first.")
        return

    st.subheader("📊 Reconciliation Summary")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        status_color = {
            FindingStatus.PASS: "🟢",
            FindingStatus.REJECT: "🔴",
            FindingStatus.NEEDS_REVIEW: "🟡",
        }
        status_emoji = status_color.get(finding.overall_status, "⚪")
        st.metric("Status", f"{status_emoji} {finding.overall_status.value.upper()}")

    with col2:
        st.metric("Total Invoiced", f"${finding.total_invoiced:,.2f}")

    with col3:
        st.metric("Total Expected", f"${finding.total_expected:,.2f}")

    with col4:
        variance = finding.total_invoiced - finding.total_expected
        variance_pct = (variance / finding.total_expected * 100) if finding.total_expected else 0
        color = "normal" if abs(variance) < 0.01 else "inverse"
        st.metric("Variance", f"${variance:+,.2f} ({variance_pct:+.1f}%)", delta_color=color)

    # Counts breakdown
    line_findings = getattr(finding, "line_findings", [])
    pass_count = sum(1 for lr in line_findings if lr.status == FindingStatus.PASS)
    reject_count = sum(1 for lr in line_findings if lr.status == FindingStatus.REJECT)
    review_count = sum(1 for lr in line_findings if lr.status == FindingStatus.NEEDS_REVIEW)
    no_match_count = sum(1 for lr in line_findings if lr.status == FindingStatus.NO_MATCH)

    st.write(
        f"**Lines**: 🟢 {pass_count} pass | 🔴 {reject_count} reject | 🟡 {review_count} review | ⚪ {no_match_count} no match"
    )


def render_findings_table(finding: Optional[InvoiceFinding]) -> None:
    """
    Render an interactive table of line-item findings.

    Args:
        finding: The InvoiceFinding result
    """
    line_findings = getattr(finding, "line_findings", []) if finding else []
    if not finding or not line_findings:
        st.info("No line items to display.")
        return

    st.subheader("📋 Line Item Findings")

    # Build dataframe
    rows = []
    for idx, line_result in enumerate(line_findings):
        status_icon = {
            FindingStatus.PASS: "🟢",
            FindingStatus.REJECT: "🔴",
            FindingStatus.NEEDS_REVIEW: "🟡",
            FindingStatus.NO_MATCH: "⚪",
        }.get(line_result.status, "❓")

        rows.append(
            {
                "Line": line_result.line_number,
                "Description": line_result.description[:50] + "..." if len(line_result.description) > 50 else line_result.description,
                "Amount Invoiced": f"${line_result.amount_invoiced:,.2f}",
                "Amount Expected": f"${line_result.amount_expected:,.2f}",
                "Matched Term": line_result.matched_charge_term_name or line_result.matched_charge_term_id or "—",
                "Route": line_result.routing_path.value if line_result.routing_path else "—",
                "Variance": f"${line_result.variance:+,.2f}",
                "Status": f"{status_icon} {line_result.status.value}",
                "Index": idx,
            }
        )

    df = pd.DataFrame(rows)

    # Display as interactive table
    st.dataframe(df, width="stretch", hide_index=True)

    # Detailed expander for each line
    st.subheader("📄 Detailed Line Analysis")

    for line_result in line_findings:
        status_icon = {
            FindingStatus.PASS: "🟢",
            FindingStatus.REJECT: "🔴",
            FindingStatus.NEEDS_REVIEW: "🟡",
            FindingStatus.NO_MATCH: "⚪",
        }.get(line_result.status, "❓")

        with st.expander(f"{status_icon} Line {line_result.line_number}: {line_result.description[:60]}"):
            col1, col2 = st.columns(2)

            with col1:
                st.write("**Invoice Data**")
                st.write(f"- Amount Invoiced: ${line_result.amount_invoiced:,.2f}")
                st.write(f"- Amount Expected: ${line_result.amount_expected:,.2f}")
                st.write(f"- Variance: ${line_result.variance:+,.2f}")

            with col2:
                st.write("**Matching & Validation**")
                st.write(
                    f"- Matched Term: {line_result.matched_charge_term_name or line_result.matched_charge_term_id or 'None'}"
                )
                st.write(f"- Route: {line_result.routing_path.value if line_result.routing_path else 'Not specified'}")
                st.write(f"- Matching Confidence: {line_result.matching_confidence:.1%}")

            validator_results = list(line_result.validator_results.values()) if line_result.validator_results else []
            if validator_results:
                st.write("**Validators Run**")
                for validator_result in validator_results:
                    result_icon = "✅" if validator_result.passed else "❌"
                    st.write(f"{result_icon} {validator_result.validator_name}")
                    if validator_result.reason:
                        st.caption(f"Reason: {validator_result.reason}")

            if line_result.recommended_action:
                st.info(f"💡 Recommended: {line_result.recommended_action}")


def render_audit_trail(finding: Optional[InvoiceFinding]) -> None:
    """
    Render an audit trail of the reconciliation process.

    Args:
        finding: The InvoiceFinding result
    """
    if not finding:
        return

    with st.expander("🔍 Audit Trail"):
        st.write("**Reconciliation Pipeline**")

        line_findings = getattr(finding, "line_findings", [])
        if line_findings:
            for idx, line_result in enumerate(line_findings):
                with st.expander(f"Line {line_result.line_number}"):
                    st.write(
                        f"**Route Type**: {line_result.routing_path.value if line_result.routing_path else 'Not determined'}"
                    )
                    st.write(f"**Matched Confidence**: {line_result.matching_confidence:.1%}")

                    validator_results = list(line_result.validator_results.values()) if line_result.validator_results else []
                    if validator_results:
                        st.write("**Validators Run**")
                        for vr in validator_results:
                            status = "✅ PASS" if vr.passed else "❌ FAIL"
                            st.write(f"- {vr.validator_name}: {status}")
                            if vr.reason:
                                st.caption(vr.reason)
