"""
Reusable ontology graph viewer component for Streamlit UI.

Renders RDF triples as an interactive pyvis force-directed graph.
"""

import json
from typing import Optional

import streamlit as st
from pyvis.network import Network


def render_graph_viewer(
    triples: Optional[list],
    title: str = "Ontology Graph",
    layout: str = "force",
    show_all: bool = True,
) -> None:
    """
    Render an interactive graph from RDF triples.

    Args:
        triples: List of RDF triple strings (e.g., ["contract-1 hasChargeTerm term-1", ...])
        title: Title for the graph section
        layout: Layout type ("force", "hierarchical", "circular")
        show_all: Whether to show all triples or filter "key relationships"
    """
    if not triples:
        st.info("No ontology data available yet. Parse a contract first.")
        return

    st.subheader(title)

    # Filter controls
    col1, col2 = st.columns(2)
    with col1:
        show_all_triples = st.checkbox("Show all triples", value=show_all, key="graph_show_all")
    with col2:
        layout_option = st.selectbox(
            "Layout",
            options=["force", "hierarchical", "circular"],
            index=["force", "hierarchical", "circular"].index(layout),
            key="graph_layout_select",
        )

    # Build graph
    net = Network(directed=True, height="600px", width="100%", cdn_resources="remote")

    # Configure physics based on layout
    if layout_option == "force":
        net.physics = True
        net.set_options(
            json.dumps(
                {
                    "physics": {
                        "enabled": True,
                        "barnesHut": {"gravitationalConstant": -26000, "centralGravity": 0.3, "springLength": 200},
                    }
                }
            )
        )
    elif layout_option == "hierarchical":
        net.physics = False
        net.set_options(
            json.dumps(
                {
                    "layout": {"hierarchical": {"enabled": True, "direction": "UD", "sortMethod": "directed"}},
                    "physics": {"enabled": False},
                }
            )
        )
    else:  # circular
        net.physics = False
        net.set_options(json.dumps({"layout": {"randomSeed": 42}, "physics": {"enabled": False}}))

    # Parse triples and build nodes/edges
    nodes_seen = set()
    edges_seen = set()

    for triple in triples:
        subject = ""
        predicate = ""
        obj = ""
        is_literal = False

        if isinstance(triple, tuple) and len(triple) == 3:
            subject = str(triple[0])
            predicate = str(triple[1])
            raw_obj = triple[2]
            if isinstance(raw_obj, tuple) and len(raw_obj) >= 1:
                obj = str(raw_obj[0])
                is_literal = True
            else:
                obj = str(raw_obj)
        elif isinstance(triple, str):
            parts = triple.strip().split()
            if len(parts) < 3:
                continue
            subject = parts[0]
            predicate = " ".join(parts[1:-1]) if len(parts) > 3 else parts[1]
            obj = parts[-1]
            is_literal = obj.startswith('"') or obj.startswith("'")
        else:
            continue

        # Filter: skip literal values if not showing all
        if not show_all_triples:
            if is_literal:
                continue

        # Add nodes
        for node_id in [subject, obj]:
            if node_id not in nodes_seen:
                # Color by type (heuristic)
                if "contract" in node_id.lower():
                    color = "#888888"  # Gray
                    group = "Contract"
                elif "term" in node_id.lower():
                    color = "#00AA00"  # Green
                    group = "Term"
                elif "vendor" in node_id.lower() or "relationship" in node_id.lower():
                    color = "#0066CC"  # Blue
                    group = "Vendor"
                elif "invoice" in node_id.lower():
                    color = "#FF9900"  # Orange
                    group = "Invoice"
                else:
                    color = "#CCCCCC"  # Light gray
                    group = "Other"

                net.add_node(node_id, label=node_id, color=color, group=group, title=node_id)
                nodes_seen.add(node_id)

        # Add edge
        edge_key = (subject, predicate, obj)
        if edge_key not in edges_seen:
            net.add_edge(subject, obj, label=predicate, title=predicate)
            edges_seen.add(edge_key)

    # Render
    net.write_html("temp_graph.html", notebook=False, open_browser=False)

    # Display in Streamlit
    with open("temp_graph.html", "r", encoding="utf-8") as f:
        html_content = f.read()

    st.components.v1.html(html_content, height=650)

    # Statistics
    with st.expander("📊 Graph Statistics"):
        st.write(f"**Nodes**: {len(nodes_seen)}")
        st.write(f"**Edges**: {len(edges_seen)}")
        st.write(f"**Triples**: {len(triples)}")

    # Download option
    if st.button("📥 Export as Turtle (.ttl)", key="export_ttl"):
        # Convert triples to Turtle format
        ttl_content = "# RDF/Turtle Export\n@prefix : <http://example.org/> .\n\n"
        for triple in triples:
            if isinstance(triple, tuple) and len(triple) == 3:
                ttl_content += f"{triple[0]} {triple[1]} {triple[2]} .\n"
            else:
                ttl_content += f"{triple} .\n"

        st.download_button(
            label="Download Turtle",
            data=ttl_content,
            file_name="ontology.ttl",
            mime="text/plain",
        )
