"""
Reusable PDF viewer component for Streamlit UI.

Handles rendering, page navigation, and display of PDF pages.
"""

from typing import Optional

import streamlit as st


def render_pdf_viewer(
    page_images: Optional[list[bytes]],
    key_prefix: str = "pdf",
    show_metadata: bool = True,
) -> Optional[int]:
    """
    Render a PDF viewer with page navigation controls.

    Args:
        page_images: List of PNG image bytes, one per page
        key_prefix: Prefix for session state keys (for multiple viewers on same page)
        show_metadata: Whether to show page count and navigation info

    Returns:
        Current page index (0-based)
    """
    if not page_images:
        st.info("No PDF loaded. Select a file to view.")
        return 0

    page_count = len(page_images)
    state_key = f"{key_prefix}_page_index"
    if state_key not in st.session_state:
        st.session_state[state_key] = 0
    current_page = st.session_state[state_key]

    # Ensure current page is valid
    if current_page >= page_count:
        current_page = page_count - 1
    if current_page < 0:
        current_page = 0

    # Navigation controls
    if show_metadata:
        col1, col2, col3 = st.columns([1, 1, 2])
        with col1:
            if st.button("◀ Prev", key=f"{key_prefix}_prev"):
                current_page = max(0, current_page - 1)
                st.session_state[state_key] = current_page
        with col2:
            if st.button("Next ▶", key=f"{key_prefix}_next"):
                current_page = min(page_count - 1, current_page + 1)
                st.session_state[state_key] = current_page
        with col3:
            st.write(f"**{current_page + 1} / {page_count}**")
    else:
        col1, col2 = st.columns(2)
        with col1:
            if st.button("◀ Prev", key=f"{key_prefix}_prev_no_meta"):
                current_page = max(0, current_page - 1)
                st.session_state[state_key] = current_page
        with col2:
            if st.button("Next ▶", key=f"{key_prefix}_next_no_meta"):
                current_page = min(page_count - 1, current_page + 1)
                st.session_state[state_key] = current_page

    # Update session state
    st.session_state[state_key] = current_page

    # Display the page
    st.image(page_images[current_page], width="stretch")

    return current_page
