"""
Contract Explorer Page - UI for loading and examining contract PDFs.

Features:
- Vendor selection from Data directory
- Contract PDF viewer
- Contract parsing and term extraction
- Ontology graph visualization
"""

from pathlib import Path

import streamlit as st

from data_parsers.data_directory import scan_vendor_pairs
from data_parsers.pdf_extractor import extract_text, render_pages, get_pdf_metadata
from graph.rdf_generator import contract_to_triples
from llm.contract_extraction_agent import ContractExtractionAgent
from llm.stub_llm_client import StubLLMClient
from core.contract_processor import ContractProcessor
from ui import session
from ui.components.pdf_viewer import render_pdf_viewer
from ui.components.graph_viewer import render_graph_viewer
from ui.path_utils import resolve_data_root


st.title("📄 Contract Explorer")
st.markdown(
    """
    Load contract PDFs from the Data directory, extract terms, and visualize the resulting ontology graph.
    """
)

# Get configuration
data_dir_input = session.get_data_directory()
use_stub_llm = session.get_use_stub_llm()
confidence_threshold = session.get_confidence_threshold()

# Resolve data directory path
data_root = resolve_data_root(data_dir_input)
if data_root is None:
    st.error(
        "Data directory not found. Configure a valid path in sidebar (e.g., "
        "Data/Contract and Invoice Pairs)."
    )
    st.caption(f"Current input: {data_dir_input!r}")
    st.stop()

# ============================================================================
# Left Column: Vendor & Contract Selection + PDF Viewer
# ============================================================================
left_col, right_col = st.columns([2, 3])

with left_col:
    st.subheader("📂 Vendor Selection")

    # Scan vendors
    vendors = scan_vendor_pairs(data_root)
    vendor_names = [v.vendor_name for v in vendors]

    if not vendors:
        st.warning("No vendors found in data directory")
        st.stop()

    selected_vendor_name = st.selectbox("Select Vendor", vendor_names, key="vendor_select")
    selected_vendor = next(v for v in vendors if v.vendor_name == selected_vendor_name)

    if not selected_vendor.contract_pdfs:
        st.info(f"No contracts found for {selected_vendor_name}")
        st.stop()

    st.markdown("**Available Contracts**")
    selected_contract_path = st.radio(
        "Select contract",
        options=selected_vendor.contract_pdfs,
        format_func=lambda p: p.name,
        key="contract_radio",
    )

    # Show contract metadata
    if selected_contract_path:
        metadata = get_pdf_metadata(selected_contract_path)
        st.markdown("**Metadata**")
        st.caption(f"Pages: {metadata['page_count']}")
        st.caption(f"Size: {metadata['file_size'] / 1024:.1f} KB")

with right_col:
    st.subheader("📖 PDF Viewer")

    # Extract and cache contract images
    cache_key = f"contract_images_{selected_contract_path.name}"
    if cache_key not in st.session_state:
        try:
            with st.spinner("Rendering PDF..."):
                images = render_pages(selected_contract_path, dpi=150)
                st.session_state[cache_key] = images
        except Exception as e:
            st.error(f"Failed to render PDF: {e}")
            st.stop()

    images = st.session_state[cache_key]
    render_pdf_viewer(images, key_prefix="contract_pdf", show_metadata=True)

# ============================================================================
# Center Column: Parse Contract & Extract Terms
# ============================================================================
st.divider()
st.subheader("🤖 Contract Analysis")

col1, col2 = st.columns(2)

with col1:
    st.markdown("**LLM Mode**")
    if use_stub_llm:
        st.info("🤖 Using stub LLM (offline mode)")
    else:
        st.info("🌐 Using real LLM (online mode)")

with col2:
    st.markdown(f"**Confidence Threshold**: {confidence_threshold:.0%}")

# Parse contract button
if st.button("🔍 Parse Contract", key="parse_contract_btn", use_container_width=True):
    try:
        with st.spinner("Extracting contract text..."):
            contract_text = extract_text(selected_contract_path)
            session.set_contract_text(contract_text)

        with st.spinner("Parsing contract..."):
            # Set up extraction agent (stub or real)
            if use_stub_llm:
                stub_client = StubLLMClient()
                extraction_result = stub_client.extract_charge_terms_stub(
                    document_text=contract_text,
                    vendor_relationship_id=selected_vendor_name,
                    source_document_id=f"{selected_vendor_name}-doc-1",
                    source_document_type="ContractDocument",
                    metadata={"vendor_name": selected_vendor_name},
                )
                # Build VendorRelationship from extraction result
                from models.contract_models import VendorRelationship, ContractDocument, DocumentType, SourceCitation
                parsed_contract = VendorRelationship(
                    id=f"{selected_vendor_name}-contract",
                    vendor_id=selected_vendor_name,
                    vendor_name=selected_vendor_name,
                    customer_id="UHS",
                    customer_name="Universal Health Services",
                    status="finalized",
                    charge_terms=extraction_result.charge_terms,
                )
                parsed_contract.documents.append(
                    ContractDocument(
                        id=f"{parsed_contract.id}-doc-1",
                        vendor_id=selected_vendor_name,
                        vendor_name=selected_vendor_name,
                        customer_id="UHS",
                        customer_name="Universal Health Services",
                        document_type=DocumentType.MSA,
                        markdown_text=contract_text,
                        source_path=str(selected_contract_path),
                    )
                )
            else:
                extraction_agent = ContractExtractionAgent()
                processor = ContractProcessor(extraction_agent=extraction_agent)
                ingest_result = processor.ingest_contract(
                    vendor_id=selected_vendor_name,
                    documents=[
                        {
                            "filename": selected_contract_path.name,
                            "content": contract_text,
                        }
                    ],
                )
                parsed_contract = list(processor._contracts.values())[0] if processor._contracts else None
        if parsed_contract:
            session.set_parsed_contract(parsed_contract)

            # Also extract and render the page images
            with st.spinner("Rendering pages..."):
                images = render_pages(selected_contract_path, dpi=150)
                session.set_contract_page_images(images)

            # Generate triples
            with st.spinner("Generating RDF triples..."):
                triples = contract_to_triples(parsed_contract)
                session.set_contract_triples(triples)

            st.success("✅ Contract parsed successfully!")
        else:
            st.error("Failed to parse contract")

    except Exception as e:
        st.error(f"Error parsing contract: {e}")
        st.exception(e)

# ============================================================================
# Display Parsed Contract (if available)
# ============================================================================
parsed_contract = session.get_parsed_contract()

if parsed_contract:
    st.divider()
    st.subheader("📋 Extracted Charge Terms")

    # Terms table
    import pandas as pd

    terms_data = []
    for term in parsed_contract.charge_terms:
        terms_data.append(
            {
                "Term ID": term.id,
                "Name": term.name,
                "Type": term.charge_type.value,
                "Rate": f"${term.rate:,.2f}",
                "Unit": term.rate_unit,
                "Effective": term.effective_date or "—",
                "Confidence": f"{term.extraction_confidence:.0%}",
            }
        )

    df = pd.DataFrame(terms_data)
    st.dataframe(df, use_container_width=True, hide_index=True)

    # ========================================================================
    # Ontology Graph
    # ========================================================================
    st.divider()
    st.subheader("🕸️ Ontology Graph")

    triples = session.get_contract_triples()
    if triples:
        render_graph_viewer(
            triples,
            title="Contract Ontology",
            layout=session.get_graph_layout(),
            show_all=st.checkbox("Show all triples", value=False, key="show_all_triples"),
        )
    else:
        st.info("No triples generated yet.")

else:
    st.info("👈 Select a contract and click **Parse Contract** to get started!")
