"""
Invoice Reconciliation Page - UI for matching invoices to contracts and validating.

Features:
- Contract summary
- Invoice PDF selection
- Invoice parsing
- Reconciliation with findings
- Detailed audit trail
"""

from pathlib import Path

import streamlit as st

from data_parsers.data_directory import scan_vendor_pairs
from data_parsers.pdf_extractor import extract_text, render_pages, get_pdf_metadata
from data_parsers.invoice_parser import parse_invoice
from ui import session
from ui.components.pdf_viewer import render_pdf_viewer
from ui.components.findings_table import render_findings_summary, render_findings_table, render_audit_trail
from ui.path_utils import resolve_data_root


st.title("🧾 Invoice Reconciliation")
st.markdown(
    """
    Match invoices to contracts, validate against terms, and review reconciliation findings.
    """
)

# Get configuration
data_dir_input = session.get_data_directory()
use_stub_llm = session.get_use_stub_llm()

# Resolve data directory path
data_root = resolve_data_root(data_dir_input)
if data_root is None:
    st.error(
        "Data directory not found. Configure a valid path in sidebar (e.g., "
        "Data/Contract and Invoice Pairs)."
    )
    st.caption(f"Current input: {data_dir_input!r}")
    st.stop()

# ============================================================================
# Step 1: Contract Summary
# ============================================================================
st.subheader("📋 Step 1: Contract Summary")

parsed_contract = session.get_parsed_contract()

if not parsed_contract:
    st.warning("⚠️ No contract loaded yet. Go to **Contract Explorer** to parse a contract first.")
    st.stop()

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Vendor", parsed_contract.vendor_name)
with col2:
    st.metric("Terms", len(parsed_contract.charge_terms))
with col3:
    st.metric("Status", parsed_contract.status)

if st.button("🔄 Clear & Go to Contract Explorer", key="go_contract"):
    session.clear_contract_state()
    st.switch_page("pages/01_contract.py")

st.divider()

# ============================================================================
# Step 2: Invoice Selection
# ============================================================================
st.subheader("📂 Step 2: Select Invoice")

# Get vendor invoices
vendors = scan_vendor_pairs(data_root)
vendor = next((v for v in vendors if v.vendor_name == parsed_contract.vendor_name), None)

if not vendor or not vendor.invoice_folders:
    st.warning(f"No invoices found for {parsed_contract.vendor_name}")
    st.stop()

# Select month
month_folders = sorted(vendor.invoice_folders.keys())
selected_month = st.selectbox("Invoice Month", month_folders, key="month_select")

# List invoices in month
invoices_in_month = vendor.invoice_folders[selected_month]
selected_invoice_path = st.radio(
    "Select Invoice PDF",
    options=invoices_in_month,
    format_func=lambda p: p.name,
    key="invoice_radio",
)

if selected_invoice_path:
    session.set_selected_invoice(selected_invoice_path)
    metadata = get_pdf_metadata(selected_invoice_path)

    # Show PDF in viewer
    cache_key = f"invoice_images_{selected_invoice_path.name}"
    if cache_key not in st.session_state:
        try:
            with st.spinner("Rendering invoice PDF..."):
                images = render_pages(selected_invoice_path, dpi=150)
                st.session_state[cache_key] = images
        except Exception as e:
            st.error(f"Failed to render invoice: {e}")

    col1, col2 = st.columns([2, 1])
    with col1:
        st.subheader("📖 Invoice Preview")
        images = st.session_state.get(cache_key)
        if images:
            render_pdf_viewer(images, key_prefix="invoice_pdf", show_metadata=True)
    with col2:
        st.subheader("📊 Invoice Metadata")
        st.caption(f"**Pages**: {metadata['page_count']}")
        st.caption(f"**Size**: {metadata['file_size'] / 1024:.1f} KB")

st.divider()

# ============================================================================
# Step 3: Parse Invoice
# ============================================================================
st.subheader("🔍 Step 3: Parse Invoice")

if st.button("📄 Parse Invoice", key="parse_invoice_btn", use_container_width=True):
    if not selected_invoice_path:
        st.error("Please select an invoice first")
    else:
        try:
            with st.spinner("Extracting invoice text..."):
                invoice_text = extract_text(selected_invoice_path)
                session.set_invoice_text(invoice_text)

            with st.spinner("Parsing invoice..."):
                # Try strict invoice parsing first (works for YAML/markdown-structured invoices).
                # For raw PDF text that doesn't match parser schema, we still show extracted text.
                parsed_invoice = None
                try:
                    parsed_invoice = parse_invoice(invoice_text, source_name=selected_invoice_path.name)
                except Exception:
                    parsed_invoice = None

                st.success("✅ Invoice extracted successfully!")

                if parsed_invoice is not None:
                    st.markdown("**Parsed Invoice Header**")
                    h1, h2, h3 = st.columns(3)
                    with h1:
                        st.metric("Invoice ID", parsed_invoice.invoice_id)
                    with h2:
                        st.metric("Invoice Date", str(parsed_invoice.invoice_date))
                    with h3:
                        st.metric("Total", f"${parsed_invoice.total:,.2f}")

                    import pandas as pd

                    rows = [
                        {
                            "Line": line.line_number,
                            "Description": line.description,
                            "Qty": line.quantity,
                            "Unit": line.unit,
                            "Rate": line.unit_rate,
                            "Amount": line.line_amount,
                        }
                        for line in parsed_invoice.lines
                    ]
                    st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
                else:
                    st.info(
                        "Raw PDF text extracted. Structured invoice parsing is unavailable for this file format, "
                        "but you can continue to reconciliation demo mode."
                    )

                with st.expander("📄 Extracted Text (Raw)", expanded=False):
                    st.text_area(
                        "Extracted text",
                        value=invoice_text[:1000] + "..." if len(invoice_text) > 1000 else invoice_text,
                        height=200,
                        disabled=True,
                    )

        except Exception as e:
            st.error(f"Error parsing invoice: {e}")
            st.exception(e)

st.divider()

# ============================================================================
# Step 4: Reconciliation Results
# ============================================================================
st.subheader("✅ Step 4: Reconciliation Results")

if st.button("⚡ Reconcile Against Contract", key="reconcile_btn", use_container_width=True):
    if not session.get_invoice_text():
        st.error("Please parse invoice first")
    else:
        try:
            session.set_reconciliation_status("loading")

            with st.spinner("Running reconciliation pipeline..."):
                # For demo mode, we'll simulate a reconciliation result
                # In production, this would call the full InvoiceProcessor pipeline

                st.info(
                    "Demo mode: Showing simulated reconciliation results. "
                    "In production, this would run the full validation pipeline."
                )

                # Simulate some findings
                st.success("✅ Reconciliation complete!")
                session.set_reconciliation_status("complete")

        except Exception as e:
            st.error(f"Reconciliation error: {e}")
            session.set_reconciliation_status("error")
            st.exception(e)

# Display results if available (demo data for now)
reconciliation_result = session.get_reconciliation_result()

if session.get_reconciliation_status() == "complete" or reconciliation_result:
    st.markdown("---")
    st.subheader("📊 Reconciliation Summary")

    # Demo: Show simulated summary
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Status", "✅ PASS")
    with col2:
        st.metric("Total Invoiced", "$3,255.00")
    with col3:
        st.metric("Total Expected", "$3,250.00")
    with col4:
        st.metric("Variance", "+$5.00 (+0.2%)")

    st.write("**Lines**: 🟢 5 pass | 🔴 0 reject | 🟡 0 review | ⚪ 0 no match")

    st.divider()

    # Demo findings table
    st.subheader("📋 Line Item Findings")

    demo_findings_data = [
        {"Line": 1, "Description": "Monthly Base Service", "Amount": "$2,500.00", "Status": "✅ PASS"},
        {"Line": 2, "Description": "Regional Surcharge", "Amount": "$300.00", "Status": "✅ PASS"},
        {"Line": 3, "Description": "Emergency Support", "Amount": "$450.00", "Status": "✅ PASS"},
    ]

    import pandas as pd

    df_demo = pd.DataFrame(demo_findings_data)
    st.dataframe(df_demo, use_container_width=True, hide_index=True)

    # Audit trail
    with st.expander("🔍 Audit Trail", expanded=False):
        st.write("**Reconciliation Pipeline Trace**")
        st.write("- ✅ Parsing: Invoice text extracted (3 lines)")
        st.write("- ✅ Routing: All lines matched to contract terms")
        st.write("- ✅ Validation: All validators passed")
        st.write("- ✅ Findings: No issues detected")

else:
    st.info("👈 Click **Reconcile Against Contract** to run reconciliation")
