from __future__ import annotations

import re
from datetime import date, datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from core.contract_processor import ContractProcessor
from core.invoice_processor import InvoiceProcessor
from data_parsers.data_directory import scan_vendor_pairs
from data_parsers.invoice_parser import parse_invoice
from data_parsers.pdf_extractor import (
    extract_text,
    extract_text_with_ocr_fallback,
    get_ocr_engine_status,
    render_pages,
)
from data_parsers.sidecar_text import load_sidecar_text
from graph.rdf_generator import contract_to_triples
from llm.contract_extraction_agent import ContractExtractionAgent
from llm.llm_client import LLMClient
from llm.stub_llm_client import StubLLMClient
from models.contract_models import ContractDocument, DocumentType, VendorRelationship
from models.invoice_models import Invoice, InvoiceLine
from ui import session
from ui.components.graph_viewer import render_graph_viewer
from ui.components.pdf_viewer import render_pdf_viewer
from ui.path_utils import resolve_data_root
from utils.errors import ExtractionError, ValidationError


def _build_stub_contract(vendor_name: str, contract_path: Path, contract_text: str) -> tuple[VendorRelationship, dict]:
    stub_client = StubLLMClient()
    extraction = stub_client.extract_charge_terms_stub(
        document_text=contract_text,
        vendor_relationship_id=vendor_name,
        source_document_id=f"{vendor_name}-doc-1",
        source_document_type="ContractDocument",
        metadata={"vendor_name": vendor_name},
    )
    parsed_contract = VendorRelationship(
        id=f"{vendor_name}-contract",
        vendor_id=vendor_name,
        vendor_name=vendor_name,
        customer_id="UHS",
        customer_name="Universal Health Services",
        status="finalized",
        charge_terms=extraction.charge_terms,
    )
    parsed_contract.documents.append(
        ContractDocument(
            id=f"{parsed_contract.id}-doc-1",
            vendor_id=vendor_name,
            vendor_name=vendor_name,
            customer_id="UHS",
            customer_name="Universal Health Services",
            document_type=DocumentType.MSA,
            markdown_text=contract_text,
            source_path=str(contract_path),
        )
    )
    return parsed_contract, extraction.raw_response


def _build_core_ready_contract_processor(parsed_contract: VendorRelationship) -> ContractProcessor:
    contract_processor = ContractProcessor()
    contract_for_core = parsed_contract.model_copy(deep=True)
    contract_for_core.status = "finalized"
    contract_processor._contracts[contract_for_core.id] = contract_for_core
    contract_processor.graph_repository.insert_triples(contract_to_triples(contract_for_core))
    return contract_processor


def _run_demo_reconciliation(parsed_contract: VendorRelationship, parsed_invoice) -> dict:
    rows = []
    expected_total = 0.0
    for line in parsed_invoice.lines:
        matched_term = next(
            (
                term
                for term in parsed_contract.charge_terms
                if term.name.lower() in line.description.lower() or line.description.lower() in term.name.lower()
            ),
            None,
        )
        expected = round((matched_term.rate if matched_term else line.unit_rate) * line.quantity, 2)
        variance = round(line.line_amount - expected, 2)

        if matched_term is None:
            status = "NEEDS_REVIEW"
            review_reason = "No contract term match"
        else:
            status = "PASS" if abs(variance) <= 0.01 else "NEEDS_REVIEW"
            review_reason = ""

        expected_total += expected
        rows.append(
            {
                "Line": line.line_number,
                "Description": line.description,
                "Matched Term": matched_term.name if matched_term else "No direct match",
                "Invoiced": line.line_amount,
                "Expected": expected,
                "Variance": variance,
                "Status": status,
                "Reason": review_reason,
            }
        )

    expected_total = round(expected_total + (parsed_invoice.tax_amount or 0.0), 2)
    overall_status = "PASS" if all(r["Status"] == "PASS" for r in rows) else "NEEDS_REVIEW"

    return {
        "invoice_id": parsed_invoice.invoice_id,
        "contract_id": parsed_contract.id,
        "overall_status": overall_status,
        "total_invoiced": round(parsed_invoice.total, 2),
        "total_expected": expected_total,
        "total_variance": round(parsed_invoice.total - expected_total, 2),
        "line_results": rows,
    }


def _result_from_invoice_finding(invoice_finding, parsed_invoice: Invoice, contract_id: str) -> dict:
    rows = []
    for line_result in invoice_finding.line_findings:
        status = line_result.status.value
        heuristic_used = (
            line_result.llm_resolved
            or line_result.routing_path.value == "deep_path"
            or line_result.matched_charge_term_id is None
        )
        if line_result.matched_charge_term_id is None:
            match_method = "no_match"
        elif line_result.llm_resolved:
            match_method = "heuristic_llm_resolution"
        elif line_result.routing_path.value == "deep_path":
            match_method = "heuristic_deep_path"
        else:
            match_method = "exact_fast_path"

        rows.append(
            {
                "Line": line_result.line_number,
                "Description": line_result.description,
                "Matched Term": line_result.matched_charge_term_name or line_result.matched_charge_term_id or "No direct match",
                "Invoiced": line_result.amount_invoiced,
                "Expected": line_result.amount_expected,
                "Variance": line_result.variance,
                "Status": status,
                "Match Outcome": "MATCHED" if line_result.matched_charge_term_id else "NO_MATCH",
                "Match Method": match_method,
                "Heuristic Used": heuristic_used,
                "Reason": line_result.recommended_action or "",
            }
        )

    overall_status = invoice_finding.overall_status.value
    return {
        "invoice_id": parsed_invoice.invoice_id,
        "contract_id": contract_id,
        "overall_status": overall_status,
        "total_invoiced": invoice_finding.total_invoiced,
        "total_expected": invoice_finding.total_expected,
        "total_variance": invoice_finding.total_variance,
        "line_results": rows,
    }


def _parse_date_fallback(text: str) -> date:
    patterns = [
        r"\b(\d{4}-\d{2}-\d{2})\b",
        r"\b(\d{1,2}/\d{1,2}/\d{4})\b",
        r"\b(\d{1,2}/\d{1,2}/\d{2})\b",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if not m:
            continue
        raw = m.group(1)
        try:
            if "-" in raw:
                return date.fromisoformat(raw)
            parts = raw.split("/")
            month, day, year = int(parts[0]), int(parts[1]), int(parts[2])
            if year < 100:
                year += 2000
            return date(year, month, day)
        except Exception:
            continue
    return date.today()


def _parse_money(value: str) -> float:
    cleaned = re.sub(r"[^\d.-]", "", value)
    try:
        return float(cleaned)
    except Exception:
        return 0.0


def _clean_pdf_text(text: str) -> str:
    lines = []
    for line in (text or "").splitlines():
        stripped = line.strip()
        if re.match(r"^-- Page \d+ --$", stripped):
            continue
        if stripped == "[No extractable text (possible image-only page)]":
            continue
        lines.append(line)
    return "\n".join(lines).strip()


def _extract_structured_invoice_code_lines(lines_raw: list[str]) -> list[InvoiceLine]:
    """Extract lines from formats like: CL-0525 ... 770.00 0.00 770.00."""
    pattern = re.compile(
        r"^(?P<code>[A-Za-z]{2,5}-\d{4})\s+.+?\s+(?P<base>[\d,]+\.\d{2})\s+(?P<tax>[\d,]+\.\d{2})\s+(?P<total>[\d,]+\.\d{2})$"
    )

    parsed: list[InvoiceLine] = []
    seen_codes: set[str] = set()

    for raw in lines_raw:
        m = pattern.match(raw)
        if not m:
            continue

        code = m.group("code").upper()
        if code in seen_codes:
            continue

        line_total = _parse_money(m.group("total"))
        base_amount = _parse_money(m.group("base"))
        amount = line_total if line_total > 0 else base_amount
        if amount <= 0:
            continue

        seen_codes.add(code)
        parsed.append(
            InvoiceLine(
                line_number=len(parsed) + 1,
                description=f"Invoice {code}",
                quantity=1.0,
                unit="unit",
                unit_rate=amount,
                line_amount=amount,
            )
        )

    return parsed


def _extract_amounts_ocr_tolerant(text: str) -> list[float]:
    """Extract money amounts like 1,070.00 and OCR-noisy variants like 2, 1 65. 00."""
    values: list[float] = []
    for raw in re.findall(r"\$?\s*([0-9][0-9,\s]*\.\s*\d{2})", text):
        normalized = re.sub(r"\s+", "", raw)
        amount = _parse_money(normalized)
        if amount > 0:
            values.append(amount)
    return values


def _parse_short_date(raw: str) -> date | None:
    try:
        month_str, day_str, year_str = raw.split("/")
        month = int(month_str)
        day = int(day_str)
        year = int(year_str)
        if year < 100:
            year += 2000
        return date(year, month, day)
    except Exception:
        return None


def _extract_service_lines_from_stub_section(section: str, code: str, section_total: float | None = None) -> list[InvoiceLine]:
    service_lines: list[InvoiceLine] = []
    seen_keys: set[tuple[str, str, float]] = set()

    for raw_line in section.splitlines():
        line = re.sub(r"[^\x20-\x7E]", " ", raw_line).strip()
        if not line:
            continue

        lower = line.lower()
        if any(token in lower for token in ("subtotal", "total", "po total", "remittance", "invoice ")):
            continue

        date_match = re.search(r"\b(\d{2}/\d{2}/\d{2,4})\b", line)
        if not date_match:
            continue

        strict_amount_tokens = re.findall(r"\b\d{1,3}(?:,\d{3})*\.\d{2}\b|\b\d+\.\d{2}\b", line)
        if not strict_amount_tokens:
            continue
        amount = _parse_money(strict_amount_tokens[-1])
        if amount <= 0 or amount > 10000:
            continue
        if section_total and amount > section_total * 1.25:
            continue

        tail = line[date_match.end():]
        tail = re.sub(r"\$?\s*[0-9][0-9,\s]*\.\s*\d{2}", " ", tail)
        tail = re.sub(r"[|_]+", " ", tail)
        tail = re.sub(r"\s+", " ", tail).strip(" -:|")
        if len(re.sub(r"[^A-Za-z]", "", tail)) < 4:
            tail = "Service"

        service_date = _parse_short_date(date_match.group(1))
        dedupe_key = (date_match.group(1), tail.lower(), round(amount, 2))
        if dedupe_key in seen_keys:
            continue
        seen_keys.add(dedupe_key)

        service_lines.append(
            InvoiceLine(
                line_number=len(service_lines) + 1,
                description=f"{code} - {tail}",
                quantity=1.0,
                unit="service",
                unit_rate=amount,
                line_amount=amount,
                service_date=service_date,
            )
        )

    return service_lines


def _extract_invoice_stub_lines(invoice_text: str) -> list[InvoiceLine]:
    """Extract per-invoice line items from repeated 'Invoice <CODE>' remittance stubs."""
    stub_pattern = re.compile(r"\binvoice\s+(?P<code>[A-Za-z]{2,5}-\d{4})\b", flags=re.IGNORECASE)
    matches = list(stub_pattern.finditer(invoice_text))
    if not matches:
        return []

    parsed: list[InvoiceLine] = []
    seen_codes: set[str] = set()

    for index, match in enumerate(matches):
        code = match.group("code").upper()
        if code in seen_codes:
            continue

        section_start = match.start()
        section_end = matches[index + 1].start() if index + 1 < len(matches) else len(invoice_text)
        section = invoice_text[section_start:section_end]

        keyed_amounts = _extract_amounts_ocr_tolerant(
            "\n".join(
                re.findall(
                    r"(?:please\s+detach\s+and\s+return\s+with\s+your\s+remittance|po\s*tota[l!}])[^\n\r]*",
                    section,
                    flags=re.IGNORECASE,
                )
            )
        )
        section_amounts = _extract_amounts_ocr_tolerant(section)
        amount = max(keyed_amounts) if keyed_amounts else (max(section_amounts) if section_amounts else 0.0)
        service_lines = _extract_service_lines_from_stub_section(
            section=section,
            code=code,
            section_total=amount if amount > 0 else None,
        )

        if amount <= 0 and not service_lines:
            continue

        if amount > 0 and service_lines:
            service_total = round(sum(line.line_amount for line in service_lines), 2)
            if service_total < (amount * 0.25) or service_total > (amount * 1.75):
                service_lines = []

        seen_codes.add(code)

        if service_lines:
            for line in service_lines:
                line.line_number = len(parsed) + 1
                parsed.append(line)
        else:
            parsed.append(
                InvoiceLine(
                    line_number=len(parsed) + 1,
                    description=f"Invoice {code}",
                    quantity=1.0,
                    unit="unit",
                    unit_rate=amount,
                    line_amount=amount,
                )
            )

    return parsed


def _looks_like_multi_stub_invoice(invoice_text: str) -> bool:
    """Detect repeated detached invoice sections like 'Invoice CL-0525' in one document."""
    matches = re.findall(r"\binvoice\s+[A-Za-z]{2,5}-\d{4}\b", invoice_text, flags=re.IGNORECASE)
    return len(matches) >= 2


def _serialize_charge_terms(contract: VendorRelationship | None) -> list[dict]:
    if contract is None:
        return []
    return [
        {
            "id": t.id,
            "name": t.name,
            "charge_type": t.charge_type.value,
            "rate": t.rate,
            "rate_unit": t.rate_unit,
            "extraction_confidence": t.extraction_confidence,
            "extraction_notes": t.extraction_notes,
        }
        for t in contract.charge_terms
    ]


def _parse_invoice_fallback(
    invoice_text: str,
    source_name: str,
    vendor_name: str,
    contract_id: str,
) -> tuple[Invoice, dict]:
    lines_raw = [ln.strip() for ln in invoice_text.splitlines() if ln.strip()]
    source_stem = Path(source_name).stem

    invoice_id = source_stem
    invoice_id_match = re.search(
        r"invoice\s*(?:number|#|id)?\s*[:#-]?\s*([A-Za-z0-9-]{4,})",
        invoice_text,
        flags=re.IGNORECASE,
    )
    if invoice_id_match:
        candidate_invoice_id = invoice_id_match.group(1)
        if candidate_invoice_id.upper() not in {"INVOICE", "NUMBER", "ID"}:
            invoice_id = candidate_invoice_id

    invoice_date = _parse_date_fallback(invoice_text)

    total = 0.0
    subtotal = 0.0
    tax_amount = 0.0

    strong_total_matches = re.findall(
        r"(?:net\s+amount|total\s+amount|invoice\s+total|total\s+due)\s*[:$]?\s*([\d,]+\.\d{2})",
        invoice_text,
        flags=re.IGNORECASE,
    )
    if strong_total_matches:
        total = max(_parse_money(v) for v in strong_total_matches)

    subtotal_match = re.search(r"subtotal\s*[:$]?\s*([\d,]+\.\d{2})", invoice_text, re.IGNORECASE)
    if subtotal_match:
        subtotal = _parse_money(subtotal_match.group(1))

    tax_match = re.search(r"(?:tax|sales\s+tax)\s*[:$]?\s*([\d,]+\.\d{2})", invoice_text, re.IGNORECASE)
    if tax_match:
        tax_amount = _parse_money(tax_match.group(1))

    structured_summary_lines = _extract_structured_invoice_code_lines(lines_raw)
    invoice_stub_lines = _extract_invoice_stub_lines(invoice_text)

    # Prefer explicit invoice stub sections when available; they represent individual invoice pages.
    inferred_lines: list[InvoiceLine] = invoice_stub_lines or structured_summary_lines
    extraction_strategy = "stub_sections" if invoice_stub_lines else ("summary_table" if structured_summary_lines else "generic")
    amount_line_pattern = re.compile(r"^(?P<desc>.+?)\s+\$?(?P<amount>[\d,]+\.\d{2})$")
    skip_terms = {
        "total",
        "subtotal",
        "tax",
        "balance",
        "amount due",
        "invoice total",
        "po total",
        "check number",
        "check date",
        "vendor no",
        "please detach",
        "remittance",
        "authorized signature",
    }

    if not inferred_lines:
        for raw in lines_raw:
            m = amount_line_pattern.match(raw)
            if not m:
                continue

            desc = m.group("desc").strip(" -:\t")
            amount = _parse_money(m.group("amount"))
            if amount <= 0:
                continue

            lower_desc = desc.lower()
            if any(term in lower_desc for term in skip_terms):
                continue

            inferred_lines.append(
                InvoiceLine(
                    line_number=len(inferred_lines) + 1,
                    description=desc,
                    quantity=1.0,
                    unit="unit",
                    unit_rate=amount,
                    line_amount=amount,
                )
            )

    if not inferred_lines:
        money_candidates = re.findall(r"\$?([\d,]+\.\d{2})", invoice_text)
        parsed_money = sorted((_parse_money(v) for v in money_candidates), reverse=True)

        if total <= 0 and parsed_money:
            total = parsed_money[0]
        if subtotal <= 0 and total > 0:
            subtotal = max(round(total - tax_amount, 2), 0.0)

        fallback_amount = subtotal if subtotal > 0 else total
        if fallback_amount <= 0 and parsed_money:
            fallback_amount = parsed_money[0]

        if fallback_amount < 0:
            fallback_amount = 0.0

        inferred_lines.append(
            InvoiceLine(
                line_number=1,
                description="Inferred invoice line (fallback)",
                quantity=1.0,
                unit="unit",
                unit_rate=fallback_amount,
                line_amount=fallback_amount,
            )
        )

    if subtotal <= 0:
        subtotal = round(sum(line.line_amount for line in inferred_lines), 2)
    if total <= 0:
        total = round(subtotal + tax_amount, 2)

    vendor_slug = re.sub(r"[^a-z0-9]+", "-", vendor_name.lower()).strip("-") or "vendor"

    invoice = Invoice(
        invoice_id=invoice_id,
        vendor_id=vendor_slug,
        vendor_name=vendor_name,
        customer_name="UHS",
        invoice_date=invoice_date,
        contract_id=contract_id,
        lines=inferred_lines,
        subtotal=subtotal,
        tax_amount=tax_amount,
        total=total,
        raw_text=invoice_text,
        source_path=source_name,
    )

    parse_status = "success"
    parse_reason = "Inferred from PDF text"
    if len(inferred_lines) == 1 and inferred_lines[0].description == "Inferred invoice line (fallback)":
        parse_status = "minimal"
        parse_reason = "Minimal fallback from sparse PDF text"
        extraction_strategy = "minimal"
    elif extraction_strategy == "stub_sections":
        parse_reason = "Parsed from repeated invoice stub sections"
    elif extraction_strategy == "summary_table":
        parse_reason = "Parsed from invoice summary table"

    return invoice, {
        "mode": "fallback",
        "status": parse_status,
        "reason": parse_reason,
        "strategy": extraction_strategy,
        "invoice_id": invoice_id,
        "invoice_date": str(invoice_date),
        "line_count": len(inferred_lines),
        "subtotal": subtotal,
        "tax_amount": tax_amount,
        "total": total,
    }


st.title("📋 Reconciliation Workbench")
st.caption("Single-page workflow for contract + invoice selection, parsing, ontology, reconciliation, and JSON outputs.")

# State defaults
for key, default in {
    "wb_contract_text": None,
    "wb_invoice_text": None,
    "wb_contract_images": None,
    "wb_invoice_images": None,
    "wb_parsed_contract": None,
    "wb_parsed_invoice": None,
    "wb_contract_triples": None,
    "wb_contract_raw": None,
    "wb_reconciliation": None,
    "wb_invoice_parse_error": None,
    "wb_invoice_parse_meta": None,
    "wb_contract_processor": None,
}.items():
    if key not in st.session_state:
        st.session_state[key] = default

data_root = resolve_data_root(session.get_data_directory())
if data_root is None:
    st.error("Data directory not found. Set a valid path in sidebar (e.g., Data/Contract and Invoice Pairs).")
    st.stop()

vendors = scan_vendor_pairs(data_root)
if not vendors:
    st.warning("No vendors found in data directory.")
    st.stop()

st.caption(f"Data root: {data_root}")

# Simplified selection controls
select_col1, select_col2, select_col3 = st.columns([1.2, 1.4, 1.6])
with select_col1:
    vendor_name = st.selectbox("Vendor", [v.vendor_name for v in vendors], key="wb_vendor")
selected_vendor = next(v for v in vendors if v.vendor_name == vendor_name)

st.caption(
    f"Discovered for {selected_vendor.vendor_name}: "
    f"{len(selected_vendor.contract_pdfs)} contract(s), {len(selected_vendor.invoice_pdfs)} invoice(s)"
)

with select_col2:
    contract_options = selected_vendor.contract_pdfs or []
    selected_contract = st.selectbox(
        "Contract PDF",
        options=contract_options,
        format_func=lambda p: p.name if p else "",
        key="wb_contract_select",
    ) if contract_options else None

with select_col3:
    invoice_options = selected_vendor.invoice_pdfs or []
    selected_invoice = st.selectbox(
        "Invoice PDF",
        options=invoice_options,
        format_func=lambda p: f"{p.parent.name} / {p.name}" if p else "",
        key="wb_invoice_select",
    ) if invoice_options else None

action_col1, action_col2, action_col3 = st.columns(3)
with action_col1:
    parse_contract_clicked = st.button("Parse Contract", width="stretch", disabled=selected_contract is None)
with action_col2:
    parse_invoice_clicked = st.button("Parse Invoice", width="stretch", disabled=selected_invoice is None)
with action_col3:
    reconcile_clicked = st.button("Reconcile", width="stretch")

if parse_contract_clicked and selected_contract is not None:
    with st.spinner("Extracting contract..."):
        contract_sidecar_text, contract_sidecar_path = load_sidecar_text(selected_contract)
        contract_text_raw = contract_sidecar_text if contract_sidecar_text is not None else extract_text(selected_contract)
        contract_images = render_pages(selected_contract, dpi=150)
        contract_text = _clean_pdf_text(contract_text_raw)

    if contract_sidecar_path is not None:
        st.caption(f"Using pre-extracted text sidecar: {contract_sidecar_path.name}")

    if not contract_text:
        st.error("No extractable contract text was detected. This PDF appears image-only and requires OCR before parsing.")
        st.session_state["wb_contract_text"] = contract_text_raw
        st.session_state["wb_contract_images"] = contract_images
        st.session_state["wb_parsed_contract"] = None
        st.session_state["wb_contract_raw"] = {
            "mode": "real",
            "status": "error",
            "error": "No extractable contract text (possible image-only PDF)",
        }
        st.session_state["wb_contract_triples"] = None
        st.session_state["wb_contract_processor"] = None
        st.stop()

    use_stub = session.get_use_stub_llm()
    parsed_contract = None
    raw_output = {}
    contract_processor = None

    if use_stub:
        parsed_contract, raw_output = _build_stub_contract(vendor_name, selected_contract, contract_text)
    else:
        retry_notice = st.empty()
        excluded_non_positive_terms: list[str] = []

        def _show_retry_notice(wait_seconds: float, attempt: int, max_attempts: int, exc: Exception) -> None:
            message = str(exc)
            if "429" not in message and "Too Many Requests" not in message:
                return
            retry_notice.warning(
                "Rate limited by LLM provider (429). "
                f"Retrying in {wait_seconds:.1f}s (attempt {attempt + 1} of {max_attempts})."
            )

        def _finalize_with_non_positive_rate_recovery(contract_id: str) -> None:
            try:
                contract_processor.finalize_contract(contract_id)
                return
            except ValidationError as exc:
                if "non-positive rate" not in str(exc):
                    raise

            contract_for_recovery = contract_processor.get_contract(contract_id)
            invalid_terms = [term for term in contract_for_recovery.charge_terms if term.rate <= 0]
            if not invalid_terms:
                raise

            excluded_non_positive_terms.clear()
            excluded_non_positive_terms.extend(term.name for term in invalid_terms)
            contract_for_recovery.charge_terms = [term for term in contract_for_recovery.charge_terms if term.rate > 0]
            excluded_list = ", ".join(excluded_non_positive_terms)
            st.warning(
                "Excluded extracted term(s) with non-positive rate before finalization: "
                f"{excluded_list}"
            )
            contract_processor.finalize_contract(contract_id)

        try:
            model = session.get_llm_model()
            provider = st.session_state.get("llm_provider") or ("anthropic" if model.startswith("claude") else "openai")
            llm_client = LLMClient(provider=provider, model=model, retry_observer=_show_retry_notice)

            threshold = session.get_confidence_threshold()
            used_relaxed_retry = False
            initial_low_confidence_warning: str | None = None
            extraction_agent = ContractExtractionAgent(
                llm_client=llm_client,
                min_confidence=threshold,
            )
            contract_processor = ContractProcessor(extraction_agent=extraction_agent)

            try:
                ingest_result = contract_processor.ingest_contract(
                    vendor_id=vendor_name,
                    documents=[
                        {
                            "filename": selected_contract.name.replace(".pdf", ".md"),
                            "content": contract_text,
                        }
                    ],
                )
                _finalize_with_non_positive_rate_recovery(ingest_result.contract_id)
            except ExtractionError as exc:
                message = str(exc)
                if "Extraction confidence below threshold" not in message:
                    raise

                st.warning(
                    "Live extraction returned low-confidence terms. "
                    "Showing real output anyway with threshold bypass for review."
                )
                used_relaxed_retry = True
                initial_low_confidence_warning = message
                relaxed_agent = ContractExtractionAgent(
                    llm_client=llm_client,
                    min_confidence=0.0,
                )
                contract_processor = ContractProcessor(extraction_agent=relaxed_agent)
                ingest_result = contract_processor.ingest_contract(
                    vendor_id=vendor_name,
                    documents=[
                        {
                            "filename": selected_contract.name.replace(".pdf", ".md"),
                            "content": contract_text,
                        }
                    ],
                )
                _finalize_with_non_positive_rate_recovery(ingest_result.contract_id)

            parsed_contract = list(contract_processor._contracts.values())[0] if contract_processor._contracts else None
            extracted_terms = _serialize_charge_terms(parsed_contract)
            low_conf_terms = [
                t for t in extracted_terms if float(t.get("extraction_confidence", 0.0)) < float(threshold)
            ]

            if low_conf_terms:
                low_conf_details = ", ".join(
                    [f"{t.get('name', '(unnamed)')} ({float(t.get('extraction_confidence', 0.0)):.2f})" for t in low_conf_terms]
                )
                raw_output = {
                    "mode": "real",
                    "status": "ingested_low_confidence",
                    "provider": provider,
                    "model": model,
                    "confidence_threshold": threshold,
                    "warning": f"Final extracted terms below threshold {threshold:.2f}: {low_conf_details}",
                }
            elif used_relaxed_retry:
                raw_output = {
                    "mode": "real",
                    "status": "ingested_after_retry",
                    "provider": provider,
                    "model": model,
                    "confidence_threshold": threshold,
                    "warning": "Initial extraction attempt had low-confidence terms; displayed output is from relaxed retry.",
                }
                if initial_low_confidence_warning:
                    raw_output["initial_low_confidence_warning"] = initial_low_confidence_warning
            else:
                raw_output = {
                    "mode": "real",
                    "status": "ingested",
                    "provider": provider,
                    "model": model,
                    "confidence_threshold": threshold,
                }

            raw_output["extracted_term_count"] = len(extracted_terms)
            raw_output["extracted_terms"] = extracted_terms
            if excluded_non_positive_terms:
                raw_output["excluded_non_positive_terms"] = excluded_non_positive_terms
            if not extracted_terms:
                raw_output["warning"] = (
                    "No charge terms were extracted from contract text."
                    " Check source quality or lower confidence threshold."
                )
                st.warning("Live extraction completed but found zero charge terms.")
        except Exception as exc:
            st.error(f"Real extraction failed: {exc}")
            raw_output = {
                "mode": "real",
                "status": "error",
                "provider": st.session_state.get("llm_provider"),
                "model": session.get_llm_model(),
                "error": str(exc),
            }
        finally:
            retry_notice.empty()

    st.session_state["wb_contract_text"] = contract_text
    st.session_state["wb_contract_images"] = contract_images
    st.session_state["wb_parsed_contract"] = parsed_contract
    st.session_state["wb_contract_raw"] = raw_output
    st.session_state["wb_contract_triples"] = contract_to_triples(parsed_contract) if parsed_contract else None
    if contract_processor is None and parsed_contract is not None:
        contract_processor = _build_core_ready_contract_processor(parsed_contract)
    st.session_state["wb_contract_processor"] = contract_processor
    st.success("Contract parsed.")

if parse_invoice_clicked and selected_invoice is not None:
    with st.spinner("Extracting invoice..."):
        invoice_sidecar_text, invoice_sidecar_path = load_sidecar_text(selected_invoice)
        invoice_text_raw = invoice_sidecar_text if invoice_sidecar_text is not None else extract_text(selected_invoice)
        invoice_images = render_pages(selected_invoice, dpi=150)
        invoice_text = _clean_pdf_text(invoice_text_raw)

        ocr_used = False
        if not invoice_text and invoice_sidecar_text is None:
            invoice_text_raw_ocr = extract_text_with_ocr_fallback(selected_invoice)
            invoice_text_ocr = _clean_pdf_text(invoice_text_raw_ocr)
            if invoice_text_ocr:
                invoice_text_raw = invoice_text_raw_ocr
                invoice_text = invoice_text_ocr
                ocr_used = True

    if invoice_sidecar_path is not None:
        st.caption(f"Using pre-extracted text sidecar: {invoice_sidecar_path.name}")

    parsed_invoice = None
    parse_error = None
    parse_meta = {"mode": "yaml", "status": "success"}
    parse_meta["ocr_engine"] = get_ocr_engine_status()
    if not invoice_text:
        contract_id = (
            st.session_state["wb_parsed_contract"].id
            if st.session_state.get("wb_parsed_contract") is not None
            else f"{vendor_name}-contract"
        )
        parsed_invoice, parse_meta = _parse_invoice_fallback(
            invoice_text=invoice_text_raw,
            source_name=selected_invoice.name,
            vendor_name=vendor_name,
            contract_id=contract_id,
        )
        parse_meta.update(
            {
                "mode": "image_only_fallback",
                "status": "minimal",
                "reason": "No extractable invoice text detected; generated minimal parsed invoice from filename and best-effort fallback.",
                "ocr_used": False,
            }
        )
        parse_error = None
        st.warning("Invoice appears image-only. Using minimal fallback parse so workflow can continue.")
    else:
        contract_id = (
            st.session_state["wb_parsed_contract"].id
            if st.session_state.get("wb_parsed_contract") is not None
            else f"{vendor_name}-contract"
        )

        if _looks_like_multi_stub_invoice(invoice_text):
            parsed_invoice, parse_meta = _parse_invoice_fallback(
                invoice_text=invoice_text,
                source_name=selected_invoice.name,
                vendor_name=vendor_name,
                contract_id=contract_id,
            )
            parse_meta["mode"] = "heuristic_stub_sections"
            parse_meta["reason"] = "Detected multi-invoice remittance format; used section-based parser"
            if ocr_used:
                parse_meta["ocr_used"] = True
            parse_error = None
        else:
            try:
                parsed_invoice = parse_invoice(invoice_text, source_name=selected_invoice.name)
                if ocr_used:
                    parse_meta.update({
                        "mode": "ocr_yaml",
                        "status": "success",
                        "reason": "Parsed from OCR-extracted text",
                        "ocr_used": True,
                    })
            except Exception as exc:
                parse_error = str(exc)
                parsed_invoice, parse_meta = _parse_invoice_fallback(
                    invoice_text=invoice_text,
                    source_name=selected_invoice.name,
                    vendor_name=vendor_name,
                    contract_id=contract_id,
                )
                if ocr_used:
                    parse_meta["ocr_used"] = True

    if parsed_invoice is not None and parse_meta.get("mode") == "fallback":
        parse_error = None

    st.session_state["wb_invoice_text"] = invoice_text
    st.session_state["wb_invoice_images"] = invoice_images
    st.session_state["wb_parsed_invoice"] = parsed_invoice
    st.session_state["wb_invoice_parse_error"] = parse_error
    st.session_state["wb_invoice_parse_meta"] = parse_meta
    if parsed_invoice is not None:
        mode_label = (parse_meta or {}).get("mode", "yaml")
        st.success(f"Invoice parsed ({mode_label} mode).")
    else:
        st.info("Invoice text extracted; structured parse unavailable for this file format.")

if reconcile_clicked:
    parsed_contract = st.session_state.get("wb_parsed_contract")
    parsed_invoice = st.session_state.get("wb_parsed_invoice")
    st.session_state["wb_reconciliation_meta"] = None
    if parsed_contract is None:
        st.error("Parse a contract before reconciliation.")
    elif parsed_invoice is None:
        st.error("Parse an invoice before reconciliation.")
    else:
        contract_processor = st.session_state.get("wb_contract_processor")

        if contract_processor is None:
            st.error("Core reconciliation is unavailable because no core-ready contract processor is loaded.")
        else:
            reconciliation_ok = False
            try:
                invoice_processor = InvoiceProcessor(contract_processor=contract_processor)
                process_result = invoice_processor.process_parsed_invoice(
                    contract_id=parsed_contract.id,
                    invoice=parsed_invoice,
                    source_name=selected_invoice.name if selected_invoice is not None else parsed_invoice.source_path,
                )
                st.session_state["wb_reconciliation"] = _result_from_invoice_finding(
                    process_result.invoice_finding,
                    parsed_invoice,
                    parsed_contract.id,
                )
                st.session_state["wb_reconciliation_meta"] = {
                    "lines_processed": process_result.lines_processed,
                    "lines_fast_path": process_result.lines_fast_path,
                    "lines_deep_path": process_result.lines_deep_path,
                    "lines_no_match": process_result.lines_no_match,
                    "parse_warnings": process_result.parse_warnings,
                }
                reconciliation_ok = True
            except Exception as exc:
                st.session_state["wb_reconciliation"] = None
                st.error(f"Core reconciliation failed: {exc}")
            if reconciliation_ok:
                st.success("Reconciliation complete.")

tabs = st.tabs(
    [
        "Contract PDF",
        "Invoice PDF",
        "Ontology",
        "Parsed Contract",
        "Parsed Invoice",
        "Reconciliation Result",
        "JSON Outputs",
    ]
)

with tabs[0]:
    if st.session_state.get("wb_contract_images"):
        render_pdf_viewer(st.session_state["wb_contract_images"], key_prefix="wb_contract_pdf", show_metadata=True)
    else:
        st.info("Select and parse a contract to view PDF pages.")

with tabs[1]:
    if st.session_state.get("wb_invoice_images"):
        render_pdf_viewer(st.session_state["wb_invoice_images"], key_prefix="wb_invoice_pdf", show_metadata=True)
    else:
        st.info("Select and parse an invoice to view PDF pages.")

with tabs[2]:
    triples = st.session_state.get("wb_contract_triples")
    if triples:
        render_graph_viewer(triples, title="Contract Ontology", layout=session.get_graph_layout(), show_all=False)
    else:
        st.info("Parse a contract to generate ontology graph.")

with tabs[3]:
    parsed_contract = st.session_state.get("wb_parsed_contract")
    if parsed_contract:
        term_rows = [
            {
                "Term ID": t.id,
                "Name": t.name,
                "Type": t.charge_type.value,
                "Rate": t.rate,
                "Unit": t.rate_unit,
                "Confidence": t.extraction_confidence,
            }
            for t in parsed_contract.charge_terms
        ]
        st.dataframe(pd.DataFrame(term_rows), width="stretch", hide_index=True)
    else:
        st.info("No parsed contract yet.")

with tabs[4]:
    parsed_invoice = st.session_state.get("wb_parsed_invoice")
    parse_error = st.session_state.get("wb_invoice_parse_error")
    parse_meta = st.session_state.get("wb_invoice_parse_meta") or {}
    if parsed_invoice:
        mode = parse_meta.get("mode", "yaml")
        if mode == "fallback":
            st.caption("Parsed using fallback PDF-text extraction (inferred fields).")
        h1, h2, h3, h4 = st.columns(4)
        h1.metric("Invoice ID", parsed_invoice.invoice_id)
        h2.metric("Date", str(parsed_invoice.invoice_date))
        h3.metric("Subtotal", f"${parsed_invoice.subtotal:,.2f}")
        h4.metric("Total", f"${parsed_invoice.total:,.2f}")
        rows = [
            {
                "Line": line.line_number,
                "Description": line.description,
                "Qty": line.quantity,
                "Unit": line.unit,
                "Rate": line.unit_rate,
                "Amount": line.line_amount,
            }
            for line in parsed_invoice.lines
        ]
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)
    elif parse_error:
        st.info(f"Structured parsing unavailable: {parse_error}")
    else:
        st.info("No parsed invoice yet.")

with tabs[5]:
    reconciliation = st.session_state.get("wb_reconciliation")
    reconciliation_meta = st.session_state.get("wb_reconciliation_meta") or {}
    if reconciliation:
        r1, r2, r3, r4 = st.columns(4)
        r1.metric("Status", reconciliation["overall_status"])
        r2.metric("Invoiced", f"${reconciliation['total_invoiced']:,.2f}")
        r3.metric("Expected", f"${reconciliation['total_expected']:,.2f}")
        r4.metric("Variance", f"${reconciliation['total_variance']:+,.2f}")

        if reconciliation_meta:
            m1, m2, m3, m4 = st.columns(4)
            m1.metric("Lines Processed", reconciliation_meta.get("lines_processed", 0))
            m2.metric("Fast Path", reconciliation_meta.get("lines_fast_path", 0))
            m3.metric("Deep Path", reconciliation_meta.get("lines_deep_path", 0))
            m4.metric("No Match", reconciliation_meta.get("lines_no_match", 0))

            parse_warnings = reconciliation_meta.get("parse_warnings") or []
            if parse_warnings:
                st.warning("\n".join(parse_warnings))

        st.dataframe(pd.DataFrame(reconciliation["line_results"]), width="stretch", hide_index=True)
    else:
        st.info("Run reconciliation to view results.")

with tabs[6]:
    contract_obj = st.session_state.get("wb_parsed_contract")
    invoice_obj = st.session_state.get("wb_parsed_invoice")
    with st.expander("Contract Raw Output", expanded=False):
        st.json(st.session_state.get("wb_contract_raw") or {})
    with st.expander("Parsed Contract JSON", expanded=False):
        st.json(contract_obj.model_dump(mode="json") if contract_obj else {})
    with st.expander("Parsed Invoice JSON", expanded=False):
        st.json(invoice_obj.model_dump(mode="json") if invoice_obj else {})
    with st.expander("Invoice Parse Metadata", expanded=False):
        st.json(st.session_state.get("wb_invoice_parse_meta") or {})
    with st.expander("Invoice Parse Error (if any)", expanded=False):
        st.json({"error": st.session_state.get("wb_invoice_parse_error")})
    with st.expander("Reconciliation JSON", expanded=False):
        st.json(st.session_state.get("wb_reconciliation") or {})
    with st.expander("Reconciliation Metadata", expanded=False):
        st.json(st.session_state.get("wb_reconciliation_meta") or {})
    with st.expander("Ontology Triples", expanded=False):
        triples = st.session_state.get("wb_contract_triples") or []
        st.json([
            [str(t[0]), str(t[1]), str(t[2])] if isinstance(t, tuple) and len(t) == 3 else str(t)
            for t in triples
        ])
