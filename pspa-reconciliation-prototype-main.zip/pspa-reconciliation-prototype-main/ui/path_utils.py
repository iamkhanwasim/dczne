from __future__ import annotations

from pathlib import Path
from typing import Optional


def resolve_data_root(data_dir_input: Optional[str]) -> Optional[Path]:
    """
    Resolve Data/Contract and Invoice Pairs directory robustly.

    Resolution order:
    1) Explicit absolute path from sidebar input.
    2) Relative path from implementation root.
    3) Relative path from current working directory.
    4) Auto-discover by walking parents and checking Data/Contract and Invoice Pairs.
    """
    impl_dir = Path(__file__).resolve().parent.parent
    input_value = (data_dir_input or "").strip()

    candidates: list[Path] = []

    if input_value:
        raw = Path(input_value)
        if raw.is_absolute():
            candidates.append(raw)
        else:
            candidates.append((impl_dir / raw).resolve())
            candidates.append((Path.cwd() / raw).resolve())

    for parent in [impl_dir, *impl_dir.parents]:
        candidates.append(parent / "Data" / "Contract and Invoice Pairs")

    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate

    return None
