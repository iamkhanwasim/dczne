"""
Session state helpers for Streamlit UI.

Provides typed wrappers around st.session_state for consistent state management
across pages without page re-runs.
"""

from typing import Any, Optional

import streamlit as st

from models.contract_models import VendorRelationship
from models.invoice_models import Invoice


def init_session_state() -> None:
    """Initialize all session state keys with defaults."""
    defaults = {
        # Contract page state
        "parsed_contract": None,  # VendorRelationship
        "contract_text": None,  # str
        "contract_page_images": None,  # list[bytes]
        "contract_page_index": 0,  # int
        "contract_triples": None,  # list[str] RDF triples
        "use_stub_llm": True,  # bool
        "llm_mode": "stub",  # "stub" or "real"
        # Invoice page state
        "selected_invoice": None,  # Path
        "invoice_text": None,  # str
        "invoice_page_images": None,  # list[bytes]
        "invoice_page_index": 0,  # int
        "reconciliation_result": None,  # InvoiceFinding
        "reconciliation_status": "idle",  # "idle", "loading", "complete", "error"
        # Config
        "data_directory": None,  # str
        "llm_model": "gpt-4o",  # LLM model name
        "confidence_threshold": 0.80,  # float
        "graph_layout": "force",  # "force", "hierarchical", "circular"
    }

    for key, default_value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value


# Contract-related helpers


def get_parsed_contract() -> Optional[VendorRelationship]:
    """Get the currently parsed contract from session state."""
    return st.session_state.get("parsed_contract")


def set_parsed_contract(contract: Optional[VendorRelationship]) -> None:
    """Store a parsed contract in session state."""
    st.session_state["parsed_contract"] = contract


def get_contract_text() -> Optional[str]:
    """Get the extracted contract text."""
    return st.session_state.get("contract_text")


def set_contract_text(text: Optional[str]) -> None:
    """Store extracted contract text."""
    st.session_state["contract_text"] = text


def get_contract_page_images() -> Optional[list[bytes]]:
    """Get the rendered contract page images."""
    return st.session_state.get("contract_page_images")


def set_contract_page_images(images: Optional[list[bytes]]) -> None:
    """Store rendered contract page images."""
    st.session_state["contract_page_images"] = images


def get_contract_page_index() -> int:
    """Get the current contract page index."""
    return st.session_state.get("contract_page_index", 0)


def set_contract_page_index(index: int) -> None:
    """Set the current contract page index."""
    st.session_state["contract_page_index"] = index


def get_contract_triples() -> Optional[list[str]]:
    """Get the RDF triples for the parsed contract."""
    return st.session_state.get("contract_triples")


def set_contract_triples(triples: Optional[list[str]]) -> None:
    """Store RDF triples for the parsed contract."""
    st.session_state["contract_triples"] = triples


# Invoice-related helpers


def get_selected_invoice() -> Optional[Any]:
    """Get the currently selected invoice path."""
    return st.session_state.get("selected_invoice")


def set_selected_invoice(invoice_path: Optional[Any]) -> None:
    """Store the selected invoice path."""
    st.session_state["selected_invoice"] = invoice_path


def get_invoice_text() -> Optional[str]:
    """Get the extracted invoice text."""
    return st.session_state.get("invoice_text")


def set_invoice_text(text: Optional[str]) -> None:
    """Store extracted invoice text."""
    st.session_state["invoice_text"] = text


def get_invoice_page_images() -> Optional[list[bytes]]:
    """Get the rendered invoice page images."""
    return st.session_state.get("invoice_page_images")


def set_invoice_page_images(images: Optional[list[bytes]]) -> None:
    """Store rendered invoice page images."""
    st.session_state["invoice_page_images"] = images


def get_invoice_page_index() -> int:
    """Get the current invoice page index."""
    return st.session_state.get("invoice_page_index", 0)


def set_invoice_page_index(index: int) -> None:
    """Set the current invoice page index."""
    st.session_state["invoice_page_index"] = index


def get_reconciliation_result() -> Optional[Any]:
    """Get the reconciliation result (InvoiceFinding)."""
    return st.session_state.get("reconciliation_result")


def set_reconciliation_result(result: Optional[Any]) -> None:
    """Store the reconciliation result."""
    st.session_state["reconciliation_result"] = result


def get_reconciliation_status() -> str:
    """Get the reconciliation status."""
    return st.session_state.get("reconciliation_status", "idle")


def set_reconciliation_status(status: str) -> None:
    """Update the reconciliation status."""
    st.session_state["reconciliation_status"] = status


# Config helpers


def get_use_stub_llm() -> bool:
    """Check if stub LLM is enabled."""
    return st.session_state.get("use_stub_llm", True)


def set_use_stub_llm(enabled: bool) -> None:
    """Set stub LLM enabled state."""
    st.session_state["use_stub_llm"] = enabled


def get_llm_mode() -> str:
    """Get the current LLM mode ('stub' or 'real')."""
    return st.session_state.get("llm_mode", "stub")


def set_llm_mode(mode: str) -> None:
    """Set the LLM mode."""
    if mode not in ("stub", "real"):
        raise ValueError(f"Invalid llm_mode: {mode}")
    st.session_state["llm_mode"] = mode


def get_data_directory() -> Optional[str]:
    """Get the configured data directory path."""
    return st.session_state.get("data_directory")


def set_data_directory(path: str) -> None:
    """Store the data directory path."""
    st.session_state["data_directory"] = path


def get_llm_model() -> str:
    """Get the selected LLM model."""
    return st.session_state.get("llm_model", "gpt-4o")


def set_llm_model(model: str) -> None:
    """Set the LLM model."""
    st.session_state["llm_model"] = model


def get_confidence_threshold() -> float:
    """Get the confidence threshold."""
    return st.session_state.get("confidence_threshold", 0.80)


def set_confidence_threshold(threshold: float) -> None:
    """Set the confidence threshold."""
    st.session_state["confidence_threshold"] = threshold


def get_graph_layout() -> str:
    """Get the graph layout style."""
    return st.session_state.get("graph_layout", "force")


def set_graph_layout(layout: str) -> None:
    """Set the graph layout style."""
    if layout not in ("force", "hierarchical", "circular"):
        raise ValueError(f"Invalid graph_layout: {layout}")
    st.session_state["graph_layout"] = layout


# Utility functions


def clear_contract_state() -> None:
    """Clear all contract-related state."""
    st.session_state["parsed_contract"] = None
    st.session_state["contract_text"] = None
    st.session_state["contract_page_images"] = None
    st.session_state["contract_page_index"] = 0
    st.session_state["contract_triples"] = None


def clear_invoice_state() -> None:
    """Clear all invoice-related state."""
    st.session_state["selected_invoice"] = None
    st.session_state["invoice_text"] = None
    st.session_state["invoice_page_images"] = None
    st.session_state["invoice_page_index"] = 0
    st.session_state["reconciliation_result"] = None
    st.session_state["reconciliation_status"] = "idle"


def clear_all_state() -> None:
    """Clear all session state."""
    clear_contract_state()
    clear_invoice_state()
