"""
Application configuration loaded from environment variables.

Usage:
    from utils.config import config

    model = config.llm_model
    backend = config.graph_backend
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass
class Config:
    # LLM
    llm_provider: str = field(default_factory=lambda: os.getenv("LLM_PROVIDER", "azure-apim"))
    llm_model: str = field(default_factory=lambda: os.getenv("LLM_MODEL", "gpt-4-turbo"))
    llm_temperature_extraction: float = field(
        default_factory=lambda: float(os.getenv("LLM_TEMPERATURE_EXTRACTION", "0.1"))
    )
    llm_temperature_ambiguity: float = field(
        default_factory=lambda: float(os.getenv("LLM_TEMPERATURE_AMBIGUITY", "0.3"))
    )
    llm_max_tokens: int = field(
        default_factory=lambda: int(os.getenv("LLM_MAX_TOKENS", "4096"))
    )
    
    # Azure OpenAI via APIM configuration
    azure_openai_endpoint: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_ENDPOINT", os.getenv("AZURE_APIM_ENDPOINT", ""))
    )
    azure_openai_api_key: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_API_KEY", os.getenv("AZURE_APIM_KEY", ""))
    )
    azure_openai_api_version: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")
    )
    azure_openai_deployment: str = field(
        default_factory=lambda: os.getenv("AZURE_OPENAI_DEPLOYMENT", os.getenv("LLM_MODEL", "gpt-5.4"))
    )
    
    # Direct provider configuration (fallback)
    openai_api_key: str = field(default_factory=lambda: os.getenv("OPENAI_API_KEY", ""))
    anthropic_api_key: str = field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))

    # Graph backend
    graph_backend: str = field(default_factory=lambda: os.getenv("GRAPH_BACKEND", "mock"))
    stardog_url: str = field(default_factory=lambda: os.getenv("STARDOG_URL", "http://localhost:5820"))
    stardog_database: str = field(default_factory=lambda: os.getenv("STARDOG_DATABASE", "pspa-rec"))
    stardog_username: str = field(default_factory=lambda: os.getenv("STARDOG_USERNAME", "admin"))
    stardog_password: str = field(default_factory=lambda: os.getenv("STARDOG_PASSWORD", "admin"))

    # Application
    log_level: str = field(default_factory=lambda: os.getenv("LOG_LEVEL", "INFO"))
    fast_path_cache_ttl_days: int = field(
        default_factory=lambda: int(os.getenv("FAST_PATH_CACHE_TTL_DAYS", "30"))
    )
    validator_tolerance: float = field(
        default_factory=lambda: float(os.getenv("VALIDATOR_TOLERANCE", "0.01"))
    )


# Module-level singleton — import this directly in other modules
config = Config()
