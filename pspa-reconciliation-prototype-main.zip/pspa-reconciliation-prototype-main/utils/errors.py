"""
Custom exception types for the reconciliation engine.

Raising typed exceptions makes error handling in the API layer clean and explicit.
"""

from __future__ import annotations


class ReconciliationError(Exception):
    """Base class for all reconciliation engine errors."""


class ContractNotFoundError(ReconciliationError):
    """Raised when a contract_id is not found in the graph."""

    def __init__(self, contract_id: str) -> None:
        super().__init__(f"Contract not found: {contract_id!r}")
        self.contract_id = contract_id


class ContractNotFinalizedError(ReconciliationError):
    """Raised when an invoice is submitted against a contract that has not been finalized."""

    def __init__(self, contract_id: str) -> None:
        super().__init__(f"Contract {contract_id!r} has not been finalized; call /finalize first.")
        self.contract_id = contract_id


class ExtractionError(ReconciliationError):
    """Raised when the LLM extraction agent fails or returns invalid output."""


class MatchingError(ReconciliationError):
    """Raised when matching cannot produce any candidate (no terms in graph for the vendor)."""


class ValidationError(ReconciliationError):
    """Raised when validator configuration is invalid (not a validation failure — that is a Finding)."""


class ParseError(ReconciliationError):
    """Raised when a contract or invoice document cannot be parsed."""

    def __init__(self, filename: str, reason: str) -> None:
        super().__init__(f"Failed to parse {filename!r}: {reason}")
        self.filename = filename
        self.reason = reason


class GraphError(ReconciliationError):
    """Raised when the graph repository encounters an unexpected error."""
