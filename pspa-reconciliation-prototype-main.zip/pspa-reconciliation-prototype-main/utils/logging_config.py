"""
Logging configuration for the reconciliation engine.

Usage:
    from utils.logging_config import get_logger

    logger = get_logger(__name__)
    logger.info("Processing invoice", extra={"invoice_id": "abc-inv-001"})
"""

from __future__ import annotations

import logging
import sys
from typing import Optional

from utils.config import config


def configure_logging(level: Optional[str] = None) -> None:
    """Configure root logger. Call once at application startup."""
    log_level = getattr(logging, (level or config.log_level).upper(), logging.INFO)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(log_level)
    root.handlers.clear()
    root.addHandler(handler)


def get_logger(name: str) -> logging.Logger:
    """Return a named logger. Configures logging on first call if not yet configured."""
    if not logging.getLogger().handlers:
        configure_logging()
    return logging.getLogger(name)
