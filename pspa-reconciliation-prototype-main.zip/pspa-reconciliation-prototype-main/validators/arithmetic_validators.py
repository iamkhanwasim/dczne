from __future__ import annotations

from typing import Optional

from models.finding_models import ValidationResult


def line_amount_equals(
    rate: float,
    quantity: float,
    invoice_amount: float,
    tolerance: float = 0.0,
) -> ValidationResult:
    validator_name = "line_amount_equals"
    expected = round(rate * quantity, 2)
    actual = round(invoice_amount, 2)
    variance = round(actual - expected, 2)

    if abs(variance) <= tolerance:
        return ValidationResult.pass_result(
            validator_name,
            reason=f"Line amount matches expected value within tolerance ({tolerance:.2f}).",
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason="Line amount does not equal rate × quantity.",
        expected=expected,
        actual=actual,
        variance=variance,
        severity="error",
    )


def invoice_total_recomputes(
    lines_total: float,
    tax_rate: Optional[float],
    tax_amount: float,
    total: float,
    tolerance: float = 0.02,
) -> ValidationResult:
    validator_name = "invoice_total_recomputes"
    rate = max(0.0, float(tax_rate or 0.0))
    expected_tax = round(lines_total * rate, 2)
    expected_total = round(lines_total + tax_amount, 2)
    actual_total = round(total, 2)
    variance = round(actual_total - expected_total, 2)

    if abs(variance) <= tolerance:
        return ValidationResult.pass_result(
            validator_name,
            reason=(
                "Invoice total recomputes from line subtotal and tax amount "
                f"(calculated tax rate proxy={rate:.4f}, expected tax={expected_tax:.2f})."
            ),
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason="Invoice total does not recompute from subtotal + tax amount.",
        expected=expected_total,
        actual=actual_total,
        variance=variance,
        severity="error",
    )


def overage_amount(
    quantity: float,
    included: float,
    overage_rate: float,
    charged: float,
    tolerance: float = 0.0,
) -> ValidationResult:
    validator_name = "overage_amount"
    overage_qty = max(0.0, float(quantity) - float(included))
    expected = round(overage_qty * float(overage_rate), 2)
    actual = round(float(charged), 2)
    variance = round(actual - expected, 2)

    if abs(variance) <= tolerance:
        return ValidationResult.pass_result(
            validator_name,
            reason="Overage charge matches computed overage amount within tolerance.",
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason="Overage charge does not match expected overage amount.",
        expected=expected,
        actual=actual,
        variance=variance,
        severity="error",
    )
