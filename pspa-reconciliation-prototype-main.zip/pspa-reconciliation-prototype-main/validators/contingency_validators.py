from __future__ import annotations

from typing import Any

from models.contract_models import ChargeTerm, ChargeType
from models.finding_models import ValidationResult


def contingency_fee_requires_realized_recovery(
    charge_term: ChargeTerm,
    recovery_data: dict[str, Any] | None,
    charged_amount: float | None = None,
    tolerance: float = 0.01,
) -> ValidationResult:
    validator_name = "contingency_fee_requires_realized_recovery"

    is_contingency = (
        charge_term.charge_type == ChargeType.CONTINGENCY
        or charge_term.contingency_pct is not None
    )
    if not is_contingency:
        return ValidationResult.pass_result(
            validator_name,
            reason="Charge term is not contingency-based; recovery requirement not applicable.",
        )

    data = recovery_data or {}
    realized_recovery = float(data.get("realized_recovery", 0.0) or 0.0)
    if realized_recovery <= 0:
        return ValidationResult.fail_result(
            validator_name=validator_name,
            reason="Contingency charge requires positive realized recovery evidence.",
            expected="> 0 realized_recovery",
            actual=realized_recovery,
            severity="error",
        )

    if charged_amount is not None and charge_term.contingency_pct is not None:
        expected_fee = round(realized_recovery * charge_term.contingency_pct, 2)
        variance = round(float(charged_amount) - expected_fee, 2)
        if abs(variance) > tolerance:
            return ValidationResult.fail_result(
                validator_name=validator_name,
                reason="Charged contingency fee does not align with realized recovery basis.",
                expected=expected_fee,
                actual=charged_amount,
                variance=variance,
                severity="error",
            )

    return ValidationResult.pass_result(
        validator_name,
        reason="Contingency charge has realized recovery support and valid fee basis.",
    )
