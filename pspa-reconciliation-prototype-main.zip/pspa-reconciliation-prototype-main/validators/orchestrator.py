from __future__ import annotations

from datetime import date

from models.contract_models import ChargeTerm
from models.finding_models import ValidationResult
from models.invoice_models import InvoiceLine
from validators.arithmetic_validators import line_amount_equals, overage_amount
from validators.contingency_validators import contingency_fee_requires_realized_recovery
from validators.pass_through_validators import pass_through_requires_cost_evidence
from validators.precondition_validators import precondition_check
from validators.tax_validators import tax_allowed
from validators.temporal_validators import active_term
from validators.validator_registry import ValidatorRegistry, default_validator_registry


def determine_line_status(results: list[ValidationResult]) -> str:
    """
    Derive line-level status from validator results.

    PASS: all checks passed.
    FAIL: any failed result with severity="error".
    CONDITIONAL: no errors, but at least one warning failure.
    """
    has_error = any((not r.passed) and r.severity == "error" for r in results)
    if has_error:
        return "FAIL"
    has_warning = any((not r.passed) and r.severity == "warning" for r in results)
    if has_warning:
        return "CONDITIONAL"
    return "PASS"


def validate_line(
    matched_charge_term: ChargeTerm,
    invoice_line: InvoiceLine,
    *,
    invoice_date: date | None = None,
    customer_name: str = "",
    location: str = "",
    tax_rate: float = 0.0,
    recovery_data: dict | None = None,
    validator_registry: ValidatorRegistry | None = None,
) -> list[ValidationResult]:
    """
    Run validators in registry order and return all ValidationResults.

    Dependency rules:
    - `tax_allowed` runs only if `line_amount_equals` passed.
    - `overage_amount` is skipped with warning if overage config missing.

    Short-circuit rule:
    - Stop further execution if `active_term` fails as a hard error.
    """
    registry = validator_registry or default_validator_registry
    validator_names = registry.get_validators_for_charge_type(matched_charge_term.charge_type)
    results: list[ValidationResult] = []
    result_by_name: dict[str, ValidationResult] = {}

    effective_invoice_date = invoice_date or invoice_line.service_date or date.today()

    for validator_name in validator_names:
        if validator_name == "active_term":
            result = active_term(effective_invoice_date, matched_charge_term)

        elif validator_name == "line_amount_equals":
            result = line_amount_equals(
                rate=matched_charge_term.rate,
                quantity=invoice_line.quantity,
                invoice_amount=invoice_line.line_amount,
            )

        elif validator_name == "tax_allowed":
            arithmetic = result_by_name.get("line_amount_equals")
            if arithmetic and not arithmetic.passed:
                result = ValidationResult(
                    validator_name="tax_allowed",
                    passed=True,
                    reason="Skipped because line_amount_equals failed.",
                    severity="info",
                )
            else:
                result = tax_allowed(
                    customer=customer_name,
                    location=location,
                    charge_type=matched_charge_term.charge_type.value,
                    tax_rate=tax_rate,
                )

        elif validator_name == "overage_amount":
            if (
                matched_charge_term.included_quantity is None
                or matched_charge_term.overage_rate is None
            ):
                result = ValidationResult(
                    validator_name="overage_amount",
                    passed=False,
                    reason=(
                        "Skipped strict overage computation because included_quantity "
                        "or overage_rate is missing in contract term."
                    ),
                    severity="warning",
                )
            else:
                result = overage_amount(
                    quantity=invoice_line.quantity,
                    included=matched_charge_term.included_quantity,
                    overage_rate=matched_charge_term.overage_rate,
                    charged=invoice_line.line_amount,
                )

        elif validator_name == "pass_through_requires_cost_evidence":
            result = pass_through_requires_cost_evidence(
                charge_term=matched_charge_term,
                supporting_docs=invoice_line.supporting_docs,
            )

        elif validator_name == "contingency_fee_requires_realized_recovery":
            result = contingency_fee_requires_realized_recovery(
                charge_term=matched_charge_term,
                recovery_data=recovery_data,
                charged_amount=invoice_line.line_amount,
            )

        elif validator_name == "precondition_check":
            result = precondition_check(
                required_conditions=matched_charge_term.preconditions,
                supporting_docs=invoice_line.supporting_docs,
            )

        else:
            result = ValidationResult(
                validator_name=validator_name,
                passed=False,
                reason=f"Unknown validator '{validator_name}' configured in registry.",
                severity="warning",
            )

        results.append(result)
        result_by_name[validator_name] = result

        if (
            validator_name == "active_term"
            and not result.passed
            and result.severity == "error"
        ):
            break

    return results
