from __future__ import annotations

from models.contract_models import ChargeTerm, ChargeType
from models.invoice_models import SupportingDocRef
from models.finding_models import ValidationResult


_ALLOWED_EVIDENCE_TYPES = {"receipt", "invoice", "supply", "order", "quote", "po"}


def _has_cost_evidence(supporting_docs: list[SupportingDocRef]) -> bool:
    for doc in supporting_docs:
        doc_type = doc.doc_type.lower()
        if any(token in doc_type for token in _ALLOWED_EVIDENCE_TYPES):
            return True
        if doc.amount is not None and doc.amount >= 0:
            return True
    return False


def pass_through_requires_cost_evidence(
    charge_term: ChargeTerm,
    supporting_docs: list[SupportingDocRef],
) -> ValidationResult:
    validator_name = "pass_through_requires_cost_evidence"

    evidence_required = (
        charge_term.charge_type == ChargeType.PASS_THROUGH
        or charge_term.is_passthrough
        or charge_term.requires_cost_evidence
    )

    if not evidence_required:
        return ValidationResult.pass_result(
            validator_name,
            reason="Charge term does not require pass-through cost evidence.",
        )

    if _has_cost_evidence(supporting_docs):
        return ValidationResult.pass_result(
            validator_name,
            reason="Supporting cost evidence provided for pass-through charge.",
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason="Pass-through charge requires supporting cost evidence, but none was provided.",
        expected="receipt/invoice/PO or equivalent cost documentation",
        actual=[doc.reference for doc in supporting_docs],
        severity="error",
    )
