from __future__ import annotations

from collections.abc import Iterable

from models.invoice_models import SupportingDocRef
from models.finding_models import ValidationResult


def _normalize(value: str) -> str:
    return " ".join(value.lower().split())


def _supporting_texts(supporting_docs: Iterable[SupportingDocRef]) -> list[str]:
    values: list[str] = []
    for doc in supporting_docs:
        values.append(_normalize(doc.doc_type))
        values.append(_normalize(doc.reference))
        if doc.notes:
            values.append(_normalize(doc.notes))
    return values


def _condition_is_satisfied(condition: str, supporting_text_values: list[str]) -> bool:
    normalized = _normalize(condition)
    if not normalized:
        return True

    keywords = {
        token for token in normalized.replace("required", "").split(" ")
        if token and token not in {"and", "or", "written", "prior", "approval"}
    }
    if not keywords:
        keywords = {normalized}

    return any(any(keyword in text for keyword in keywords) for text in supporting_text_values)


def precondition_check(
    required_conditions: list[str],
    supporting_docs: list[SupportingDocRef],
) -> ValidationResult:
    validator_name = "precondition_check"
    if not required_conditions:
        return ValidationResult.pass_result(validator_name, reason="No preconditions required.")

    values = _supporting_texts(supporting_docs)
    unmet = [condition for condition in required_conditions if not _condition_is_satisfied(condition, values)]

    if not unmet:
        return ValidationResult.pass_result(
            validator_name,
            reason="All contract preconditions are satisfied by supporting documentation.",
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason=f"Missing supporting evidence for preconditions: {', '.join(unmet)}",
        expected=required_conditions,
        actual=[doc.reference for doc in supporting_docs],
        severity="error",
    )
