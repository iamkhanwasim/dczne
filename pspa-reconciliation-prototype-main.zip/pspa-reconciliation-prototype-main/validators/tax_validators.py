from __future__ import annotations

from models.finding_models import ValidationResult


def tax_allowed(
    customer: str,
    location: str,
    charge_type: str,
    tax_rate: float,
) -> ValidationResult:
    validator_name = "tax_allowed"
    normalized_customer = customer.lower()
    normalized_location = location.lower()

    if tax_rate < 0:
        return ValidationResult.fail_result(
            validator_name=validator_name,
            reason="Tax rate cannot be negative.",
            expected=">= 0",
            actual=tax_rate,
            severity="error",
        )

    if tax_rate > 0.25:
        return ValidationResult.fail_result(
            validator_name=validator_name,
            reason="Tax rate exceeds configured maximum allowed threshold (25%).",
            expected="<= 0.25",
            actual=tax_rate,
            severity="error",
        )

    tax_exempt_hint = "exempt" in normalized_customer or "tax exempt" in normalized_location
    if tax_exempt_hint and tax_rate > 0:
        return ValidationResult.fail_result(
            validator_name=validator_name,
            reason="Tax appears applied to an entity/location marked tax exempt.",
            expected=0.0,
            actual=tax_rate,
            severity="warning",
        )

    return ValidationResult.pass_result(
        validator_name,
        reason=(
            f"Tax rate {tax_rate:.4f} accepted for charge_type={charge_type} "
            f"at location '{location}'."
        ),
    )
