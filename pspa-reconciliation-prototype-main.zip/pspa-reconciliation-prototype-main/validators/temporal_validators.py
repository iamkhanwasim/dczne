from __future__ import annotations

from datetime import date

from models.contract_models import ChargeTerm
from models.finding_models import ValidationResult


def active_term(invoice_date: date, charge_term: ChargeTerm) -> ValidationResult:
    validator_name = "active_term"
    if charge_term.is_active_on(invoice_date):
        return ValidationResult.pass_result(
            validator_name,
            reason=f"Invoice date {invoice_date} is within the charge term active period.",
        )

    start = charge_term.get_effective_start()
    end = charge_term.get_effective_end()
    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason="Invoice date is outside the charge term effective period.",
        expected=f"between {start} and {end}",
        actual=str(invoice_date),
        severity="error",
    )


def within_billing_interval(
    invoice_date: date,
    service_date: date | None,
    cadence: str,
) -> ValidationResult:
    validator_name = "within_billing_interval"
    normalized = cadence.strip().lower()

    if service_date is None:
        return ValidationResult.pass_result(
            validator_name,
            reason="No service_date supplied; billing interval check skipped.",
        )

    month_diff = (invoice_date.year - service_date.year) * 12 + (invoice_date.month - service_date.month)

    if normalized in {"", "as-needed", "as needed", "per occurrence", "event"}:
        return ValidationResult.pass_result(
            validator_name,
            reason="Cadence indicates per-occurrence billing; interval check passed.",
        )

    if normalized in {"monthly", "month", "per month"}:
        passed = 0 <= month_diff <= 1
    elif normalized in {"quarterly", "quarter", "per quarter"}:
        passed = 0 <= month_diff <= 3
    elif normalized in {"annual", "annually", "yearly", "per year"}:
        passed = 0 <= month_diff <= 12
    else:
        return ValidationResult.pass_result(
            validator_name,
            reason=f"Unknown cadence '{cadence}'; interval check treated as informational pass.",
        )

    if passed:
        return ValidationResult.pass_result(
            validator_name,
            reason=(
                f"Service date {service_date} is within cadence '{cadence}' "
                f"relative to invoice date {invoice_date}."
            ),
        )

    return ValidationResult.fail_result(
        validator_name=validator_name,
        reason=(
            f"Service date {service_date} is not within cadence '{cadence}' "
            f"for invoice date {invoice_date}."
        ),
        expected=f"cadence window for {cadence}",
        actual=str(service_date),
        severity="warning",
    )
