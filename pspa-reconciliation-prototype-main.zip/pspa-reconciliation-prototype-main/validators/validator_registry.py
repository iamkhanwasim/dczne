from __future__ import annotations

from collections.abc import Callable

from models.contract_models import ChargeType


ValidatorFn = Callable[..., object]


class ValidatorRegistry:
    """Registry mapping charge types to validator execution order."""

    def __init__(self) -> None:
        self._registry: dict[ChargeType, list[str]] = {
            ChargeType.FIXED_RATE: [
                "active_term",
                "line_amount_equals",
                "tax_allowed",
            ],
            ChargeType.VARIABLE_RATE: [
                "active_term",
                "precondition_check",
                "line_amount_equals",
                "tax_allowed",
            ],
            ChargeType.PASS_THROUGH: [
                "active_term",
                "line_amount_equals",
                "pass_through_requires_cost_evidence",
            ],
            ChargeType.CONTINGENCY: [
                "active_term",
                "contingency_fee_requires_realized_recovery",
            ],
            ChargeType.SUBSCRIPTION: [
                "active_term",
                "line_amount_equals",
                "overage_amount",
            ],
            ChargeType.OVERAGE: [
                "active_term",
                "overage_amount",
            ],
            ChargeType.EVENT: [
                "active_term",
                "line_amount_equals",
            ],
            ChargeType.TIME_AND_MATERIALS: [
                "active_term",
                "line_amount_equals",
            ],
        }

    def get_validators_for_charge_type(self, charge_type: ChargeType) -> list[str]:
        """Return validator names in execution order for the charge type."""
        return list(self._registry.get(charge_type, ["active_term", "line_amount_equals"]))

    def set_validators_for_charge_type(self, charge_type: ChargeType, validators: list[str]) -> None:
        """Override validator sequence for a charge type."""
        self._registry[charge_type] = list(validators)

    def as_dict(self) -> dict[ChargeType, list[str]]:
        """Return a copy of registry contents for debugging/testing."""
        return {charge_type: list(validators) for charge_type, validators in self._registry.items()}


default_validator_registry = ValidatorRegistry()
